CREATE TABLE `/Innovation Lab/[ETL] Ticketing/data/clean/aotstm_lk_touch_org` AS
    SELECT distinct adj_mod_user
    , SVP_Name svp_name
    , VP_Name vp_name
    , AVP_Name avp_name
    , Director_Name director_name
    , dept_name
    , vp_org_name
    , supervisor_name 
    , cogs_1_name
    , cogs_2_name
    , cogs_3_name
    , cogs_4_name
    , cogs_5_name
    , cogs_6_name
    , cogs_7_name
    , cogs_8_name
    , cogs_9_name
    , cogs_10_name
    FROM `/Innovation Lab/[ETL] Ticketing/logic/aotstm/aotstm_lk_ticket_touch_instances_unique` MOD_USER
    LEFT JOIN `/Innovation Lab/[Source] Webphone/data/clean_data/webphone_with_org` WEBPHONE
    ON MOD_USER.adj_mod_user=WEBPHONE.a1_sbcuid_attuid
    AND WEBPHONE.a1_sbcuid_attuid is not null
