CREATE TABLE `ri.foundry.main.dataset.37311687-0017-44e4-ad4b-d63bedaa0a5b`  TBLPROPERTIES (foundry_transform_profiles = 'CROSS_JOIN_ENABLED, EXECUTOR_MEMORY_MEDIUM') AS
    SELECT distinct TICKETS.*
,  LK_CENTER.center_l1_area center
 , LK_CENTER.center_l2_platform
 , LK_CENTER.center_l3_unit
, CASE WHEN equipment_type IN ( 'Cell Site' ,'BSC' ,'DAS' ,'BTS' ,'COW' ,'MACRO' ,'RNC' ,'TOY' ,'Radio Site' ,'SIAD' ,'MSN' )
 AND entry_type='Trouble Report' 
 AND severity IN ('Critical','Major','SIR 1E','SIR 1','SIR 2','SIR 3','SIR 4' ) 
 AND call_origin IN ('FMS MANUAL','FMS RULE','TECH OPS') 
 AND submitter_district_sub_dept IN ( 'MNRC RAN/CSC East' ,'MNRC RAN/CSC West' ,'MNRC Transport/DACS' ,'TTRC Mobility ER ISM' ,'TTRC Mobility ER Tier II' ,'National Theft' ,'TTRC SIAD LEC Update') 
 AND submitter_department in ( 'MNRC' ,'RAN Performance','RAN PERFORMANCE') 
 AND submitter_zone in ( 'RAN Performance' ,'RAN T2- ALU/NSN' ,'RAN T2 CFBF' ,'RRC T1.5' ,'T2 CFBF' ,'RAN T2 - ERI' ,'RAN T2 - SAM' ,'National Theft' , 'TIER 1' ,'TIER II' ,'ISM SME' ,'Transport') 
 THEN  'Yes' 
 WHEN reported_by='zz0006a' and submitter_department is null THEN  'Yes'
 WHEN submitter_department='MCAC' and submitted_by in ('zz3202b','zz3202r','zh0020h','zz0007','zz320i') THEN 'Yes'
 WHEN submitter_department='MNRC' and submitted_by='Netcool User' 
 AND equipment_type IN ( 'Cell Site' ,'BSC' ,'DAS' ,'BTS' ,'COW' ,'MACRO' ,'RNC' ,'TOY' ,'Radio Site' ,'SIAD' ,'MSN' ) THEN 'Yes' 
 ELSE 'No' END AS ts_MER_RAN_TOTAL
 ,CASE WHEN problem_detail like '%Intraday%' or problem_detail like '%Interday%' THEN 'Yes' 
  else 'No'   END as ts_INTRADAY
,CASE 
  WHEN entry_type != 'Trouble Report' then 'No' 
  WHEN equipment_type = 'MW RADIO' then 'Yes' 
    WHEN reported_by ='zz1402c' then 'Yes'
    WHEN submitted_by ='zz1402c' then 'Yes' 
    WHEN (equipment_type = 'SIAD' and problem_detail IN ('SMART_MICROWAVE_DRAIN_DOWN','SMART_MICROWAVE_TARGET_DOWN'))  then 'Yes'
   else 'No'   END as ts_MW_RADIO
,CASE WHEN submitter_department IN ('RAN Engineering' ,'RAN Performance' ,'Real Estate/Construction' ,'RF Design Engineer' ,'RF Engineering' ,'RF Maintenance Engineer' ,'RF Safety Engineer') THEN 'Yes' 
  ELSE 'No'  END as ts_RAN_PERFORMANCE
, CASE WHEN (LK_MECH_CLOSED.id) is not null then 'Yes'
       WHEN not (closed_by REGEXP '^[a-zA-Z][a-zA-Z][0-9][0-9][0-9][0-9a-zA-Z]') THEN 'Yes'
       WHEN ticket_status = 'Closed' AND closed_by is null then 'Yes'
        ELSE 'No' END IS_AUTO_CLOSED
, CASE WHEN (LK_MECH_SUBMITTER.id) is not null then 'Yes'
       WHEN not (submitted_by REGEXP '^[a-zA-Z][a-zA-Z][0-9][0-9][0-9][0-9a-zA-Z]') THEN 'Yes'
        ELSE 'No' END is_auto_submitted
 /* 2020 MNOC MTTR Ticket Set */
, CASE WHEN ( ((equipment_type IN ( 'Cell Site' ,'BSC' ,'DAS' ,'BTS' ,'COW' ,'MACRO' ,'RNC' ,'TOY' ,'Radio Site' ,'SIAD' ,'MSN' )
 AND entry_type='Trouble Report' 
 AND severity IN ('Critical','Major','SIR 1E','SIR 1','SIR 2','SIR 3','SIR 4' ) 
 AND call_origin IN ('FMS MANUAL','FMS RULE','TECH OPS') 
 AND submitter_district_sub_dept IN ( 'MNRC RAN/CSC East' ,'MNRC RAN/CSC West' ,'MNRC Transport/DACS' ,'TTRC Mobility ER ISM' ,'TTRC Mobility ER Tier II' ,'National Theft' ,'TTRC SIAD LEC Update') 
 AND submitter_department in ( 'MNRC' ,'RAN PERFORMANCE','RAN Performance') 
 AND submitter_zone in ( 'RAN Performance' ,'RAN T2- ALU/NSN' ,'RAN T2 CFBF' ,'RRC T1.5' ,'T2 CFBF' ,'RAN T2 - ERI' ,'RAN T2 - SAM' ,'National Theft' , 'TIER 1' ,'TIER II' ,'ISM SME' ,'Transport'))
 OR (reported_by='zz0006a' and submitter_department is null)
 OR (submitter_department='MCAC' and submitted_by in ('zz3202b','zz3202r','zh0020h','zz0007','zz320i'))
 OR (submitter_department='MNRC' and submitted_by='Netcool User' 
 AND equipment_type IN ( 'Cell Site' ,'BSC' ,'DAS' ,'BTS' ,'COW' ,'MACRO' ,'RNC' ,'TOY' ,'Radio Site' ,'SIAD' ,'MSN' )) )
 AND cust_affect != 'No Outage' 
 AND ticket_status='Closed'
 AND NOT (equipment_type='MSN' AND ( UPPER(problem_detail) NOT LIKE '%SMART%' AND UPPER(problem_detail) NOT LIKE '%SIAD%' 
 AND problem_detail NOT IN ('EquipmentDown 1081' ,'EthernetPortRemoteFault 1081' ,'link down syslog 1065' ,'link down syslog 1132' ,'PortAIS 1061' ,'PortAIS 1061' ,'Protection Lost 1063' ,'Signal Fail 1063') ) ) 
 AND (resolution IS NULL OR resolution NOT IN ('Duplicate','DUPLICATE','Duplicate Ticket','Disaster/Storm','Natural Disaster','Disaster-Storm' ) ) 
 AND (resolution_type IS NULL or resolution_type != 'NEA Testing') 
 AND parent_trouble_report_id IS NULL 
 AND (equipsubtype is null or (UPPER(equipsubtype) !='METROCELL'))
 AND problem_detail not in ('UMTS ALU RNC CS Retainability StdDev Alert' ,'UMTS ALU RNC CS Accessibility StdDev Alert' ,'UMTS ALU RNC PS Retainability StdDev Alert' ,'SMART_UMTS Ericsson RNC PS Accessibility StdDev' ,'UMTS ALU RNC PS Accessibility StdDev Alert' ,'UMTS Ericsson RNC Zero Voice Traffic Alert' ,'SMART_UMTS Ericsson RNC CS Accessibility StdDev' ,'SMART_UMTS Ericsson RNC CS Retainability StdDev' ,'SMART_UMTS Ericsson RNC PS Retainability StdDev' ,'4AlarmsIn1Day_cold start trap 1133' ,'TemperatureThresholdCrossed 1089' ) 
 AND (submitter_department is null or submitter_department != 'RAN Performance')
 AND TICKETS.assigned_to not like 'RRC_Auto%' AND TICKETS.assigned_to not like 'RRC_Manual%')
 THEN 'Yes' ELSE 'No'
 END AS ts_MER_RAN_MTTR

 /* eq region update */
, CASE  WHEN (eq_market_cluster = 'NORTH CAROLINA/SOUTH CAROLINA' and eq_market in ('COLUMBIA','GREENVILLE'))
 then 'SOUTHEAST'
  WHEN (eq_market_cluster = 'NC/SC PARTITIONERS' and eq_market ='FARMERS')
 then 'SOUTHEAST'
 WHEN eq_market_cluster IN ('OHIO/WESTERN PENNSYLVANIA','TENNESSEE/KENTUCKY','NORTH CAROLINA/SOUTH CAROLINA')
 then 'NORTHEAST'
 WHEN eq_region IN ('MIDWEST','SOUTHWEST')
 then 'CENTRAL' 
 ELSE eq_region
 END AS EQ_REGION_NEW
 

, LK_HUMAN_TOUCH.first_human_attuid
, LK_HUMAN_TOUCH.last_human_attuid
, LK_HUMAN_TOUCH.human_pathway
, LK_HUMAN_TOUCH.distinct_humans
, LK_HUMAN_TOUCH.distinct_supervisor_name
, LK_HUMAN_TOUCH.first_supervisor_name
, LK_HUMAN_TOUCH.last_supervisor_name
, LK_HUMAN_TOUCH.distinct_director_name
, LK_HUMAN_TOUCH.first_director_name
, LK_HUMAN_TOUCH.last_director_name
, LK_HUMAN_TOUCH.distinct_avp_name
, LK_HUMAN_TOUCH.first_avp_name
, LK_HUMAN_TOUCH.last_avp_name
, LK_HUMAN_TOUCH.distinct_vp_name
, LK_HUMAN_TOUCH.first_vp_name
, LK_HUMAN_TOUCH.last_vp_name
, LK_HUMAN_TOUCH.distinct_svp_name
, LK_HUMAN_TOUCH.first_svp_name
, LK_HUMAN_TOUCH.last_svp_name
, LK_HUMAN_TOUCH.first_cogs_1_name
, LK_HUMAN_TOUCH.first_cogs_2_name
, LK_HUMAN_TOUCH.first_cogs_3_name
, LK_HUMAN_TOUCH.first_cogs_4_name
, LK_HUMAN_TOUCH.first_cogs_5_name
, LK_HUMAN_TOUCH.first_cogs_6_name
, LK_HUMAN_TOUCH.first_cogs_7_name
, LK_HUMAN_TOUCH.last_cogs_1_name
, LK_HUMAN_TOUCH.last_cogs_2_name
, LK_HUMAN_TOUCH.last_cogs_3_name
, LK_HUMAN_TOUCH.last_cogs_4_name
, LK_HUMAN_TOUCH.last_cogs_5_name
, LK_HUMAN_TOUCH.last_cogs_6_name
, LK_HUMAN_TOUCH.last_cogs_7_name
, LK_HUMAN_TOUCH.distinct_vp_org_name
, LK_HUMAN_TOUCH.first_human_touch
, LK_HUMAN_TOUCH.last_human_touch
, LK_HUMAN_TOUCH.total_human_touches
, LK_HUMAN_TOUCH.hist_first_cogs_1_name
, LK_HUMAN_TOUCH.hist_first_cogs_2_name
, LK_HUMAN_TOUCH.hist_first_cogs_3_name      
, LK_HUMAN_TOUCH.hist_first_cogs_4_name
, LK_HUMAN_TOUCH.hist_first_cogs_5_name
, LK_HUMAN_TOUCH.hist_first_cogs_6_name
, LK_HUMAN_TOUCH.hist_first_cogs_7_name
, LK_HUMAN_TOUCH.hist_last_cogs_1_name
, LK_HUMAN_TOUCH.hist_last_cogs_2_name
, LK_HUMAN_TOUCH.hist_last_cogs_3_name      
, LK_HUMAN_TOUCH.hist_last_cogs_4_name
, LK_HUMAN_TOUCH.hist_last_cogs_5_name
, LK_HUMAN_TOUCH.hist_last_cogs_6_name
, LK_HUMAN_TOUCH.hist_last_cogs_7_name
, LK_HUMAN_TOUCH.hist_first_svp_name
, LK_HUMAN_TOUCH.hist_first_vp_name
, LK_HUMAN_TOUCH.hist_first_avp_name
, LK_HUMAN_TOUCH.hist_first_director_name
, LK_HUMAN_TOUCH.hist_last_svp_name
, LK_HUMAN_TOUCH.hist_last_vp_name
, LK_HUMAN_TOUCH.hist_last_avp_name
, LK_HUMAN_TOUCH.hist_last_director_name
, LK_AUTO_TOUCH.first_auto_touch
, LK_AUTO_TOUCH.last_auto_touch
, LK_AUTO_TOUCH.total_auto_touches
 , coalesce(LK_ASSIGNED_TO_XFER.xfer, concat_ws("->", coalesce( CASE  when submitted_by = 'Netcool User' then concat('Netcool User - ', oss_vendor2)
        WHEN UP.employee_name is null then submitted_by else UP.employee_name end, RPTBY_GROUP.full_name), coalesce(TICKETS.assigned_to, "EMPTY"))) as xfer_assigned_to
 , coalesce(LK_ASSIGNED_TO_XFER.total_xfers, 0) xfer_assigned_to_total
 , coalesce(LK_DEPT_XFER.xfer, concat_ws("->", coalesce(submitter_department, RPTBY_GROUP.group_department), coalesce(assigned_department, "EMPTY"))) as xfer_dept
 , coalesce(LK_DEPT_XFER.total_xfers, 0) xfer_dept_total
 , coalesce(LK_ASSIGNED_TO_DISTRICT_XFER.xfer, concat_ws("->", coalesce(submitter_district_sub_dept, RPTBY_GROUP.district_sub_department), coalesce(assigned_district_sub_dept, "EMPTY"))) as xfer_district
 , coalesce(LK_ASSIGNED_TO_DISTRICT_XFER.total_xfers, 0) xfer_district_total
 , coalesce(LK_ASSIGNED_TO_ZONE_XFER.xfer, concat_ws("->", coalesce(submitter_zone, RPTBY_GROUP.zone), coalesce(assigned_zone, "EMPTY"))) as xfer_zone
 , coalesce(LK_ASSIGNED_TO_ZONE_XFER.total_xfers, 0) xfer_zone_total
 , CASE  when submitted_by = 'Netcool User' then concat('Netcool User - ', oss_vendor2)
        WHEN UP.employee_name is null then submitted_by else UP.employee_name end SUBMITTER_FULL_NAME
 , SUBMITTER_GROUP.primary_manager SUBMITTER_MANAGER
 , CASE WHEN total_auto_touches is null and total_human_touches > 0 then 'Manual'
        WHEN total_human_touches is null and total_auto_touches > 0 then 'Fully Automated'
        WHEN total_human_touches > 0 and total_auto_touches > 0 then 'Partially Automated'
        else 'TBD' end work_driver_type
, CASE WHEN total_human_touches is null THEN 'No Human Touch'
       WHEN total_human_touches = 0 THEN 'No Human Touch'
       WHEN total_human_touches = 1 THEN '1 Human Touch'
       WHEN total_human_touches between 2 and 3 THEN '2-3 Human Touch'
       WHEN total_human_touches > 3 THEN '4+ Human Touch'
       ELSE 'TBD' end Manual_Touch_Category
, CASE WHEN total_auto_touches is null THEN 'No Automation Touch'
       WHEN total_auto_touches = 0 THEN 'No Automation Touch'
       WHEN total_auto_touches BETWEEN 1 and 2 THEN '1-2 Automation Touch'
       WHEN total_auto_touches BETWEEN 3 and 10 THEN '3-10 Automation Touch'
       WHEN total_auto_touches BETWEEN 10 and 50 THEN '10-50 Automation Touch'
       WHEN total_auto_touches > 50 THEN '>50 Automation Touch'
       
       ELSE 'TBD' END Automation_Touch_Category
, CONCAT("http://aotsctswl.it.att.com:12080/AOTSMobilitySearch/TicketDetails.html?TicketNo=",TICKETS.ticket_number,"&Type=1") ticket_url
, (unix_timestamp(first_human_touch)-unix_timestamp(TICKETS.create_date))/3600 hours_create_to_touch
, (unix_timestamp(TICKETS.closed_time)-unix_timestamp(TICKETS.create_date))/3600 hours_open_to_close
, (unix_timestamp(last_human_touch)-unix_timestamp(first_human_touch))/3600 hours_first_last_human_touch
, LK_NDRT.force_wo_cnt
, LK_NDRT.force_wo_array
, LK_NDRT.force_start_dt
, LK_NDRT.force_finish_dt
, LK_NDRT.force_first_human_touch_dt
, LK_NDRT.force_total_touches
, LK_NDRT.force_human_touches
, LK_NDRT.force_dispatch_in_cnt
, LK_NDRT.force_dispatch_out_cnt
, LK_NDRT.force_truck_roll_in
, LK_NDRT.force_truck_roll_out
, LK_NDRT.force_human_user_unique_list
, LK_NDRT.force_human_user_unique_cnt 
, LK_NDRT.force_narrative_list
, LK_NDRT.force_dispatch_first_dt
, LK_NDRT.force_dispatch_last_dt
, case when LK_NDRT.force_start_dt is not null then 
      case when (unix_timestamp(LK_NDRT.force_start_dt)-unix_timestamp(TICKETS.create_date))/3600 < 0 then 0
      else (unix_timestamp(LK_NDRT.force_start_dt)-unix_timestamp(TICKETS.create_date))/3600 end
           when TICKETS.closed_time is not null then 
             case when (unix_timestamp(TICKETS.closed_time)-unix_timestamp(TICKETS.create_date))/3600 < 0 then 0
             else (unix_timestamp(TICKETS.closed_time)-unix_timestamp(TICKETS.create_date))/3600 end
           else null end noc_duration_hours
, force_start_to_first_human_hours
, force_start_to_first_dispatch_hours
, force_first_dipsatch_to_complete_hours
, force_start_to_finish_hours
, wfa_trouble_code
, wfa_start_dt
, wfa_finish_dt
, wfa_closeout_summary
, cause_code_list_in
, trbl_fnd_cd_list_in
, trbl_fnd_desc_in
, cause_code_list_out
, trbl_fnd_cd_list_out
, trbl_fnd_desc_out
, case when LK_REPEAT.ticket_number is not null then 1 else 0 end metric_repeat
, case when LK_REPEAT_MNOC.repeat_ticket_number_mnoc is not null then 1 else 0 end metric_repeat_mnoc
, case when LK_METRIC_NTF.ticket_number is not null then 1 else 0 end metric_ntf
, case when LK_METRIC_MAINT.ticket_number is not null then 1 else 0 end metric_maintenance
, case when LK_NTF_DISPATCH.ext_key1 is not null then 1 else 0 end metric_ntf_dispatch
    , case 
        when total_human_touches is null
                and total_auto_touches > 0
                and TICKETS.closed_time is not null then 0 
        when LK_METRIC_NOT_ACTIONABLE.ticket_number is null then 1
        else 0 end metric_actionable
, case when CASE WHEN total_auto_touches is null and total_human_touches > 0 then 'Manual'
        WHEN total_human_touches is null and total_auto_touches > 0 then 'Fully Automated'
        WHEN total_human_touches > 0 and total_auto_touches > 0 then 'Partially Automated'
        else 'TBD' end='Partially Automated' and LK_METRIC_NOT_ACTIONABLE.ticket_number is null then 1 else 0 end metric_actionable_part_mech
, case when CASE WHEN total_human_touches is null THEN 'No Human Touch'
       WHEN total_human_touches = 0 THEN 'No Human Touch'
       WHEN total_human_touches = 1 THEN '1 Human Touch'
       WHEN total_human_touches between 2 and 3 THEN '2-3 Human Touch'
       WHEN total_human_touches > 3 THEN '4+ Human Touch'
       ELSE 'TBD' end = 'No Human Touch' then 1 else 0 end metric_fully_automated_noc
, case when CASE WHEN total_human_touches is null THEN 'No Human Touch'
       WHEN total_human_touches = 0 THEN 'No Human Touch'
       WHEN total_human_touches = 1 THEN '1 Human Touch'
       WHEN total_human_touches between 2 and 3 THEN '2-3 Human Touch'
       WHEN total_human_touches > 3 THEN '4+ Human Touch'
       ELSE 'TBD' end = 'No Human Touch' and (force_human_touches is null or force_human_touches = 0) then 1 else 0 end metric_fully_automated_closed_loop
, case when force_start_dt is not null or trbl_fnd_desc_in is not null or trbl_fnd_desc_out is not null then 1 else 0 end metric_dispatched
, case when force_start_dt is not null or trbl_fnd_desc_in is not null or trbl_fnd_desc_out is not null and (force_truck_roll_out is null or force_truck_roll_out < 2) then 1 else 0 end metric_dispatched_ftr
, case when (unix_timestamp(TICKETS.closed_time)-unix_timestamp(TICKETS.create_date))/3600 <= 0 then null else (unix_timestamp(TICKETS.closed_time)-unix_timestamp(TICKETS.create_date))/3600 end metric_mttr
, case when case when (unix_timestamp(TICKETS.closed_time)-unix_timestamp(TICKETS.create_date))/3600 <= 0 then null else (unix_timestamp(TICKETS.closed_time)-unix_timestamp(TICKETS.create_date))/3600 end <= 10 then 1 else 0 end metric_mttr_met
, case when (unix_timestamp(TICKETS.return_to_service)-unix_timestamp(TICKETS.create_date))/3600 <= 0 then null else (unix_timestamp(TICKETS.return_to_service)-unix_timestamp(TICKETS.create_date))/3600 end metric_mrts_duration
, first_change_id
, CASE WHEN submitted_by like 'zz%' then 0
      WHEN submitted_by like 'nr%' then 0
      when submitted_by like 'zh%' then 0
    WHEN submitted_by REGEXP '^[a-zA-Z][a-zA-Z][0-9][0-9][0-9][0-9a-zA-Z]' THEN 1 ELSE 0 END is_human_submitter
, 'MOVED TO AOTSM_ALL_TICKET_CLEAN_TRANSFORMED_RESTRICTED DUE TO MARKINGS' note_firstname
, 'MOVED TO AOTSM_ALL_TICKET_CLEAN_TRANSFORMED_RESTRICTED DUE TO MARKINGS' note_lastname
, 'MOVED TO AOTSM_ALL_TICKET_CLEAN_TRANSFORMED_RESTRICTED DUE TO MARKINGS' note_email
, 'MOVED TO AOTSM_ALL_TICKET_CLEAN_TRANSFORMED_RESTRICTED DUE TO MARKINGS' note
, 'MOVED TO AOTSM_ALL_TICKET_CLEAN_TRANSFORMED_RESTRICTED DUE TO MARKINGS' note_triageCategory
, 'MOVED TO AOTSM_ALL_TICKET_CLEAN_TRANSFORMED_RESTRICTED DUE TO MARKINGS' note_extenderCategory
, 'MOVED TO AOTSM_ALL_TICKET_CLEAN_TRANSFORMED_RESTRICTED DUE TO MARKINGS' note_MOSDWorkOrderPriority
, 'MOVED TO AOTSM_ALL_TICKET_CLEAN_TRANSFORMED_RESTRICTED DUE TO MARKINGS' note_Acute
, after_hours_indicator
, LK_EIM_WORK_DESC.all_work_description eim_work_description
, CASE WHEN TICKETS.resolved_by_district is not null THEN TICKETS.resolved_by_district
                                          WHEN TICKETS.closed_by_district is not null THEN TICKETS.closed_by_district
                                          ELSE TICKETS.assigned_district_sub_dept END logic_group
FROM `ri.foundry.main.dataset.42b9fbd8-2b68-49aa-b17e-9d40d0c87f0a` TICKETS
LEFT JOIN `ri.foundry.main.dataset.cf7398fd-3f39-4f5c-8c01-49459dedd0f2` LK_MECH_CLOSED
on TICKETS.closed_by=LK_MECH_CLOSED.id
LEFT JOIN `ri.foundry.main.dataset.cf7398fd-3f39-4f5c-8c01-49459dedd0f2` LK_MECH_SUBMITTER
on TICKETS.submitted_by=LK_MECH_SUBMITTER.id
LEFT JOIN `ri.foundry.main.dataset.b63e24e5-2d6b-4a59-afb4-d4a04925680b` LK_HUMAN_TOUCH
ON TICKETS.ticket_number=LK_HUMAN_TOUCH.ticket_number
LEFT JOIN `ri.foundry.main.dataset.d49d27ed-7b7e-4d9c-bc56-aa56796ec7f5` LK_AUTO_TOUCH
ON TICKETS.ticket_number=LK_AUTO_TOUCH.ticket_number 
LEFT JOIN `ri.foundry.main.dataset.942bc24d-baf0-4ad6-9bab-080fff0f00cf` LK_ASSIGNED_TO_XFER
ON TICKETS.ticket_number=LK_ASSIGNED_TO_XFER.ticket_number AND LK_ASSIGNED_TO_XFER.field_changed='Assigned-to'
LEFT JOIN `ri.foundry.main.dataset.942bc24d-baf0-4ad6-9bab-080fff0f00cf` LK_DEPT_XFER
ON TICKETS.ticket_number=LK_DEPT_XFER.ticket_number AND LK_DEPT_XFER.field_changed='Department'
LEFT JOIN `ri.foundry.main.dataset.942bc24d-baf0-4ad6-9bab-080fff0f00cf` LK_ASSIGNED_TO_DISTRICT_XFER
ON TICKETS.ticket_number=LK_ASSIGNED_TO_DISTRICT_XFER.ticket_number AND LK_ASSIGNED_TO_XFER.field_changed='Assigned to District'
LEFT JOIN `ri.foundry.main.dataset.942bc24d-baf0-4ad6-9bab-080fff0f00cf` LK_ASSIGNED_TO_ZONE_XFER
ON TICKETS.ticket_number=LK_ASSIGNED_TO_ZONE_XFER.ticket_number AND LK_ASSIGNED_TO_XFER.field_changed='Assigned to Zone'
LEFT JOIN `ri.foundry.main.dataset.291668ab-8b06-4cc3-b4e2-7c2841abb380` SUBMITTER_GROUP
on TICKETS.submitted_by=SUBMITTER_GROUP.cuid and SUBMITTER_GROUP.status=1 and SUBMITTER_GROUP.primary_group=1
LEFT JOIN `ri.foundry.main.dataset.291668ab-8b06-4cc3-b4e2-7c2841abb380` RPTBY_GROUP
on TICKETS.reported_by=RPTBY_GROUP.cuid and RPTBY_GROUP.status=1 and RPTBY_GROUP.primary_group=1
LEFT JOIN `ri.foundry.main.dataset.4b92a11d-3543-401e-81c5-600cbe1fc73d` UP
ON TICKETS.submitted_by=UP.cuid
LEFT JOIN `ri.foundry.main.dataset.df0abf5d-677c-4cb9-8bf0-d8d7ff25b467` LK_CENTER
ON (
     (LK_CENTER._mapping_type=8 and (CASE WHEN TICKETS.resolved_by_district is not null THEN TICKETS.resolved_by_district
                                          WHEN TICKETS.closed_by_district is not null THEN TICKETS.closed_by_district
                                          ELSE TICKETS.assigned_district_sub_dept END)=LK_CENTER.logic_group)  
)
LEFT JOIN `ri.foundry.main.dataset.8cc5ddf9-30f5-4d15-b18f-18c116cbc5d5` LK_NDRT
ON TICKETS.ticket_number=LK_NDRT.extkey1
LEFT JOIN `ri.foundry.main.dataset.394e0874-dbcd-4e44-bedc-6c8e8fc2744f` LK_WFAC
ON TICKETS.ticket_number=LK_WFAC.ext_key1
LEFT JOIN `ri.foundry.main.dataset.7153f240-00a4-47aa-baf4-4fa306b9c599` LK_REPEAT
ON TICKETS.ticket_number=LK_REPEAT.ticket_number
LEFT JOIN `ri.foundry.main.dataset.a7df9c29-f8f3-4e83-aa69-1042149c009b` LK_METRIC_NTF
on TICKETS.ticket_number=LK_METRIC_NTF.ticket_number
LEFT JOIN `ri.foundry.main.dataset.ba6826ea-47e2-41f7-9690-81d0d94f9af3` LK_METRIC_MAINT
on TICKETS.ticket_number=LK_METRIC_MAINT.ticket_number
LEFT JOIN `ri.foundry.main.dataset.eeeb286b-fb47-4aa5-a5e4-2bb4b764a103` LK_NTF_DISPATCH
ON TICKETS.ticket_number=LK_NTF_DISPATCH.ext_key1
LEFT JOIN `ri.foundry.main.dataset.8e38d33e-0e4b-4550-8d47-5cf684314af4` LK_METRIC_NOT_ACTIONABLE
ON TICKETS.ticket_number=LK_METRIC_NOT_ACTIONABLE.ticket_number
LEFT JOIN `ri.foundry.main.dataset.8e409cba-fec9-429b-96bf-2273246ff0f8` LK_REPEAT_MNOC
ON TICKETS.ticket_number=LK_REPEAT_MNOC.repeat_ticket_number_mnoc
LEFT JOIN (SELECT ticket_number, min(first_change_id) as first_change_id FROM `ri.foundry.main.dataset.7200863b-ae2e-4ce6-b74e-ab00d05b9574` GROUP BY ticket_number) LK_FIRST_CHANGE
ON TICKETS.ticket_number=LK_FIRST_CHANGE.ticket_number
LEFT JOIN `ri.foundry.main.dataset.7cb0fe13-0c7a-4c2c-b0d4-f7aadd75f1ae` LK_AFTER_HOURS
ON TICKETS.ticket_number=LK_AFTER_HOURS.ticket_number
LEFT JOIN `ri.foundry.main.dataset.8d029662-de47-487e-ab58-eb88b7da5efd` LK_EIM_WORK_DESC
ON TICKETS.ticket_number=LK_EIM_WORK_DESC.related_ams_ticket