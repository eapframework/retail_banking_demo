from transforms.api import transform_df, Input, Output, incremental
import pyspark.sql.functions as F


@transform_df(
    Output("/Innovation Lab/[ETL] Tirks Combined/data/053_tirks_work_item_event"),
    asi=Input("ri.foundry.main.dataset.84385370-2036-4a4f-b37b-411fc3dc29fe"),
    telco=Input("ri.foundry.main.dataset.cd5060bd-834c-4bb1-ba51-acbfd8c2be46"),
)
def my_compute_function(telco, asi):
    telco = telco.withColumn("source", F.lit('telco'))
    asi = asi.withColumn("source", F.lit('asi'))
    df = telco.unionByName(asi)
    return df