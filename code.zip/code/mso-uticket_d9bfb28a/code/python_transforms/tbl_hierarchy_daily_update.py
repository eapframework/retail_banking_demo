from transforms.api import transform, Input, Output, incremental, configure
from pyspark.sql import functions as F, types as T
from pyspark.sql import SparkSession
from myproject.datasets.utils import structure_flushed, truncate_query_plan


@configure(profile='rubix-sixteen-executors')
@incremental(snapshot_inputs=['tbl_employees', 'initial_load'])
@transform(
    tbl_employees=Input("ri.foundry.main.dataset.9221b527-894f-4544-81d2-72f76c59ba4f"),
    initial_load=Input("ri.foundry.main.dataset.650f8b63-fbbc-4d86-9110-0936bc8f4264"),
    out=Output("ri.foundry.main.dataset.6680ece1-5820-40fb-8fbd-9025138edf80")
)
def my_compute_function(ctx, tbl_employees, initial_load, out):
    # set to true for incremental and false for initial load
    flag = True
    tbl_employees = tbl_employees.dataframe(mode='current')
    tbl_employees = tbl_employees.withColumn('mgmt_level', tbl_employees.mgmt_level.cast(T.IntegerType()))
    initial_load = initial_load.dataframe(mode='current')

    if flag:
        tbl_employees.createOrReplaceTempView("tbl_employees")

        # initialize vacant structure
        structure_stg = ctx.spark_session.sql("""
            SELECT l1.uid, CASE WHEN l1.vacant_supv_uid = 'X' THEN 'VACANT' ELSE l1.supv_uid END as l2_uid, CASE WHEN l1.vacant_supv_uid = 'X' THEN l1.supv_uid ELSE 'NOTAPP' END AS l2_supv_uid,
            CASE WHEN l2.vacant_supv_uid = 'X' THEN 'VACANT' ELSE l2.supv_uid END as l3_uid, CASE WHEN l2.vacant_supv_uid = 'X' THEN l2.supv_uid ELSE 'NOTAPP' END AS l3_supv_uid,
            CASE WHEN l3.vacant_supv_uid = 'X' THEN 'VACANT' ELSE l3.supv_uid END as l4_uid, CASE WHEN l3.vacant_supv_uid = 'X' THEN l3.supv_uid ELSE 'NOTAPP' END AS l4_supv_uid, 
            CASE WHEN l4.vacant_supv_uid = 'X' THEN 'VACANT' ELSE l4.supv_uid END as l5_uid, CASE WHEN l4.vacant_supv_uid = 'X' THEN l4.supv_uid ELSE 'NOTAPP' END AS l5_supv_uid, 
            CASE WHEN l5.vacant_supv_uid = 'X' THEN 'VACANT' ELSE l5.supv_uid END as l6_uid, CASE WHEN l5.vacant_supv_uid = 'X' THEN l5.supv_uid ELSE 'NOTAPP' END AS l6_supv_uid, 
            CASE WHEN l6.vacant_supv_uid = 'X' THEN 'VACANT' ELSE l6.supv_uid END as l7_uid, CASE WHEN l6.vacant_supv_uid = 'X' THEN l6.supv_uid ELSE 'NOTAPP' END AS l7_supv_uid, 
            CASE WHEN l7.vacant_supv_uid = 'X' THEN 'VACANT' ELSE l7.supv_uid END as l8_uid, CASE WHEN l7.vacant_supv_uid = 'X' THEN l7.supv_uid ELSE 'NOTAPP' END AS l8_supv_uid, 
            CASE WHEN l8.vacant_supv_uid = 'X' THEN 'VACANT' ELSE l8.supv_uid END as l9_uid, CASE WHEN l8.vacant_supv_uid = 'X' THEN l8.supv_uid ELSE 'NOTAPP' END AS l9_supv_uid, 
            CASE WHEN l9.vacant_supv_uid = 'X' THEN 'VACANT' ELSE l9.supv_uid END as l10_uid, CASE WHEN l9.vacant_supv_uid = 'X' THEN l9.supv_uid ELSE 'NOTAPP' END AS l10_supv_uid, 
            CASE WHEN l10.vacant_supv_uid = 'X' THEN 'VACANT' ELSE l10.supv_uid END as l11_uid, CASE WHEN l10.vacant_supv_uid = 'X' THEN l10.supv_uid ELSE 'NOTAPP' END AS l11_supv_uid, 
            CASE WHEN l11.vacant_supv_uid = 'X' THEN 'VACANT' ELSE l11.supv_uid END as l12_uid, CASE WHEN l11.vacant_supv_uid = 'X' THEN l11.supv_uid ELSE 'NOTAPP' END AS l12_supv_uid, 
            CASE WHEN l12.vacant_supv_uid = 'X' THEN 'VACANT' ELSE l12.supv_uid END as l13_uid, CASE WHEN l12.vacant_supv_uid = 'X' THEN l12.supv_uid ELSE 'NOTAPP' END AS l13_supv_uid,
            CASE WHEN l13.vacant_supv_uid = 'X' THEN 'VACANT' ELSE l13.supv_uid END as l14_uid, CASE WHEN l13.vacant_supv_uid = 'X' THEN l13.supv_uid ELSE 'NOTAPP' END AS l14_supv_uid,
            CASE WHEN l14.vacant_supv_uid = 'X' THEN 'VACANT' ELSE l14.supv_uid END as l15_uid, CASE WHEN l14.vacant_supv_uid = 'X' THEN l14.supv_uid ELSE 'NOTAPP' END AS l15_supv_uid 
            FROM tbl_employees l1
            LEFT JOIN tbl_employees l2
                ON l1.supv_uid = l2.uid
            LEFT JOIN tbl_employees l3
                ON l2.supv_uid = l3.uid
            LEFT JOIN tbl_employees l4
                ON l3.supv_uid = l4.uid
            LEFT JOIN tbl_employees l5
                ON l4.supv_uid = l5.uid
            LEFT JOIN tbl_employees l6
                ON l5.supv_uid = l6.uid
            LEFT JOIN tbl_employees l7
                ON l6.supv_uid = l7.uid
            LEFT JOIN tbl_employees l8
                ON l7.supv_uid = l8.uid
            LEFT JOIN tbl_employees l9
                ON l8.supv_uid = l9.uid
            LEFT JOIN tbl_employees l10
                ON l9.supv_uid = l10.uid
            LEFT JOIN tbl_employees l11
                ON l10.supv_uid = l11.uid
            LEFT JOIN tbl_employees l12
                ON l11.supv_uid = l12.uid
            LEFT JOIN tbl_employees l13
                ON l12.supv_uid = l13.uid
            LEFT JOIN tbl_employees l14
                ON l13.supv_uid = l14.uid
        """)

        structure_stg.createOrReplaceTempView("structure_stg")
        # Null to NOTAPP for concat function
        null_to_NOTAPP = ctx.spark_session.sql("""
        SELECT uid,
        CASE WHEN l2_uid IS NULL THEN 'NOTAPP' ELSE l2_uid END AS l2_uid,
        CASE WHEN l2_supv_uid IS NULL THEN 'NOTAPP' ELSE l2_supv_uid END AS l2_supv_uid,
        CASE WHEN l3_uid IS NULL THEN 'NOTAPP' ELSE l3_uid END AS l3_uid,
        CASE WHEN l3_supv_uid IS NULL THEN 'NOTAPP' ELSE l3_supv_uid END AS l3_supv_uid,
        CASE WHEN l4_uid IS NULL THEN 'NOTAPP' ELSE l4_uid END AS l4_uid,
        CASE WHEN l4_supv_uid IS NULL THEN 'NOTAPP' ELSE l4_supv_uid END AS l4_supv_uid,
        CASE WHEN l5_uid IS NULL THEN 'NOTAPP' ELSE l5_uid END AS l5_uid,
        CASE WHEN l5_supv_uid IS NULL THEN 'NOTAPP' ELSE l5_supv_uid END AS l5_supv_uid,
        CASE WHEN l6_uid IS NULL THEN 'NOTAPP' ELSE l6_uid END AS l6_uid,
        CASE WHEN l6_supv_uid IS NULL THEN 'NOTAPP' ELSE l6_supv_uid END AS l6_supv_uid,
        CASE WHEN l7_uid IS NULL THEN 'NOTAPP' ELSE l7_uid END AS l7_uid,
        CASE WHEN l7_supv_uid IS NULL THEN 'NOTAPP' ELSE l7_supv_uid END AS l7_supv_uid,
        CASE WHEN l8_uid IS NULL THEN 'NOTAPP' ELSE l8_uid END AS l8_uid,
        CASE WHEN l8_supv_uid IS NULL THEN 'NOTAPP' ELSE l8_supv_uid END AS l8_supv_uid,
        CASE WHEN l9_uid IS NULL THEN 'NOTAPP' ELSE l9_uid END AS l9_uid,
        CASE WHEN l9_supv_uid IS NULL THEN 'NOTAPP' ELSE l9_supv_uid END AS l9_supv_uid,
        CASE WHEN l10_uid IS NULL THEN 'NOTAPP' ELSE l10_uid END AS l10_uid,
        CASE WHEN l10_supv_uid IS NULL THEN 'NOTAPP' ELSE l10_supv_uid END AS l10_supv_uid,
        CASE WHEN l11_uid IS NULL THEN 'NOTAPP' ELSE l11_uid END AS l11_uid,
        CASE WHEN l11_supv_uid IS NULL THEN 'NOTAPP' ELSE l11_supv_uid END AS l11_supv_uid,
        CASE WHEN l12_uid IS NULL THEN 'NOTAPP' ELSE l12_uid END AS l12_uid,
        CASE WHEN l12_supv_uid IS NULL THEN 'NOTAPP' ELSE l12_supv_uid END AS l12_supv_uid,
        CASE WHEN l13_uid IS NULL THEN 'NOTAPP' ELSE l13_uid END AS l13_uid,
        CASE WHEN l13_supv_uid IS NULL THEN 'NOTAPP' ELSE l13_supv_uid END AS l13_supv_uid,
        CASE WHEN l14_uid IS NULL THEN 'NOTAPP' ELSE l14_uid END AS l14_uid,
        CASE WHEN l14_supv_uid IS NULL THEN 'NOTAPP' ELSE l14_supv_uid END AS l14_supv_uid,
        CASE WHEN l15_uid IS NULL THEN 'NOTAPP' ELSE l15_uid END AS l15_uid,
        CASE WHEN l15_supv_uid IS NULL THEN 'NOTAPP' ELSE l15_supv_uid END AS l15_supv_uid
        FROM structure_stg
        """)

        null_to_NOTAPP.createOrReplaceTempView("null_to_NOTAPP")

        # hierarchy creation
        hierarchy = ctx.spark_session.sql("""
                SELECT uid, CONCAT(uid, ',', l2_uid,',', l2_supv_uid,',', l3_uid,',', l3_supv_uid,',', l4_uid,',', 
                l4_supv_uid,',', l5_uid,',', l5_supv_uid,',', l6_uid,',', l6_supv_uid,',', l7_uid,',', l7_supv_uid,
                ',', l8_uid,',', l8_supv_uid,',',
                l9_uid,',', l9_supv_uid,',', l10_uid, ',', l10_supv_uid,',',l11_uid,',', l11_supv_uid,',', l12_uid,',', l12_supv_uid,
                ',', l13_uid,',', l13_supv_uid,',', l14_uid,',', l14_supv_uid,',', l15_uid,',', l15_supv_uid) as structure
                FROM null_to_NOTAPP
                """
                )

        # register the udf that is being used to get rid of the trailing 'VACANT' strings from structure
        spark = SparkSession.builder.getOrCreate()
        my_udf = F.udf(lambda z: structure_flushed(z), T.StringType())
        _ = spark.udf.register("my_udf", my_udf)
        tbl_hierarchy_daily_stg = hierarchy.withColumn('structure', my_udf('structure'))
        # tbl_hierarchy_daily_stg = hierarchy.withColumn('structure', F.regexp_replace('structure', ',NOTAPP', ''))  # can replace the above UDF with this one line of code

        tbl_hierarchy_daily_stg = truncate_query_plan(tbl_hierarchy_daily_stg)

        # change the hierarchy to be from right to left top-down, level 1 to level 15
        tbl_hierarchy_daily_stg.createOrReplaceTempView('flushed_out_structure')
        tbl_hierarchy_daily_stg = ctx.spark_session.sql(
            """
                select
                hier.uid as uid_0
                ,emp.rc
                ,emp.status
                ,emp.mgmt_level
                -- case statements are used to ensure nulls are where they need to be
                ,case
                        when length(structure) - 103 < 0
                        then null
                        when substring(structure, length(structure) - 103, 6) != ''
                        then substring(structure, length(structure) - 103, 6)
                        else null
                end uid_1
                ,case
                        when length(structure) - 96 < 0
                        then null
                        when substring(structure, length(structure) - 96, 6) != ''
                        then substring(structure, length(structure) - 96, 6)
                        else null
                end uid_2
                ,case
                        when length(structure) - 89 < 0
                        then null
                        when substring(structure, length(structure) - 89, 6) != ''
                        then substring(structure, length(structure) - 89, 6)
                        else null
                end uid_3
                ,case
                        when length(structure) - 82 < 0
                        then null
                        when substring(structure, length(structure) - 82, 6) != ''
                        then substring(structure, length(structure) - 82, 6)
                        else null
                end uid_4
                ,case
                        when length(structure) - 75 < 0
                        then null
                        when substring(structure, length(structure) - 75, 6) != ''
                        then substring(structure, length(structure) - 75, 6)
                        else null
                end uid_5
                ,case
                        when length(structure) - 68 < 0
                        then null
                        when substring(structure, length(structure) - 68, 6) != ''
                        then substring(structure, length(structure) - 68, 6)
                        else null
                end uid_6
                ,case
                        when length(structure) - 61 < 0
                        then null
                        when substring(structure, length(structure) - 61, 6) != ''
                        then substring(structure, length(structure) - 61, 6)
                        else null
                end uid_7
                ,case
                        when length(structure) - 54 < 0
                        then null
                        when substring(structure, length(structure) - 54, 6) != ''
                        then substring(structure, length(structure) - 54, 6)
                        else null
                end uid_8
                ,case
                        when length(structure) - 47 < 0
                        then null
                        when substring(structure, length(structure) - 47, 6) != ''
                        then substring(structure, length(structure) - 47, 6)
                        else null
                end uid_9
                ,case
                        when length(structure) - 40 < 0
                        then null
                        when substring(structure, length(structure) - 40, 6) != ''
                        then substring(structure, length(structure) - 40, 6)
                        else null
                end uid_10
                ,case
                        when length(structure) - 33 < 0
                        then null
                        when substring(structure, length(structure) - 33, 6) != ''
                        then substring(structure, length(structure) - 33, 6)
                        else null
                end uid_11
                ,case
                        when length(structure) - 26 < 0
                        then null
                        when substring(structure, length(structure) - 26, 6) != ''
                        then substring(structure, length(structure) - 26, 6)
                        else null
                end uid_12
                ,case
                        when length(structure) - 19 < 0
                        then null
                        when substring(structure, length(structure) - 19, 6) != ''
                        then substring(structure, length(structure) - 19, 6)
                        else null
                end uid_13
                ,case
                        when length(structure) - 12 < 0
                        then null
                        when substring(structure, length(structure) - 12, 6) != ''
                        then substring(structure, length(structure) - 12, 6)
                        else null
                end uid_14
                ,case
                        when hier.uid = 'js3658' then 'js3658'
                        when length(structure) - 5 < 0
                        then null
                        when substring(structure, length(structure) - 5, 6) != ''
                        then substring(structure, length(structure) - 5, 6)
                        else null
                end uid_15
                , emp.supv_uid AS supv_uid
            FROM flushed_out_structure hier
            INNER JOIN tbl_employees emp
                ON hier.uid = emp.uid
            """
            )

        # initialize position column
        tbl_hierarchy_daily_stg = tbl_hierarchy_daily_stg.selectExpr(
            "uid_0",
            "rc",
            "status",
            "CASE WHEN uid_1 = uid_0 THEN 1 \
            WHEN uid_2 = uid_0 THEN 2 \
            WHEN uid_3 = uid_0 THEN 3 \
            WHEN uid_4 = uid_0 THEN 4 \
            WHEN uid_5 = uid_0 THEN 5 \
            WHEN uid_6 = uid_0 THEN 6 \
            WHEN uid_7 = uid_0 THEN 7 \
            WHEN uid_8 = uid_0 THEN 8 \
            WHEN uid_9 = uid_0 THEN 9 \
            WHEN uid_10 = uid_0 THEN 10 \
            WHEN uid_11 = uid_0 THEN 11 \
            WHEN uid_12 = uid_0 THEN 12 \
            WHEN uid_13 = uid_0 THEN 13 \
            WHEN uid_14 = uid_0 THEN 14 \
            WHEN uid_15 = uid_0 THEN 15 \
            ELSE 0 END position",
            "mgmt_level",
            "uid_1",
            "uid_2",
            "uid_3",
            "uid_4",
            "uid_5",
            "uid_6",
            "uid_7",
            "uid_8",
            "uid_9",
            "uid_10",
            "uid_11",
            "uid_12",
            "uid_13",
            "uid_14",
            "uid_15",
            "CAST(from_utc_timestamp(current_timestamp(), 'PST') as DATE) as insert_date",
            "supv_uid",
            "CAST(from_utc_timestamp(current_timestamp(), 'PST') as DATE) as update_date",
            "'insert' as reason"
        )
        tbl_hierarchy_daily_stg = tbl_hierarchy_daily_stg.withColumn("insert_date", F.date_sub(tbl_hierarchy_daily_stg.insert_date, 1))
        tbl_hierarchy_daily_stg = tbl_hierarchy_daily_stg.withColumn("insert_date", F.date_sub(tbl_hierarchy_daily_stg.update_date, 1))

        # deleting all records that are in the current tbl_hierarchy_daily table, but aren't in the new records to be inserted
        curr_schema = T.StructType([
                                T.StructField('uid_0', T.StringType(), True),
                                T.StructField('rc', T.StringType(), True),
                                T.StructField('status',  T.StringType(), True),
                                T.StructField('position',  T.IntegerType(), True),
                                T.StructField('mgmt_level',  T.IntegerType(), True),
                                T.StructField('uid_1',  T.StringType(), True),
                                T.StructField('uid_2',  T.StringType(), True),
                                T.StructField('uid_3',  T.StringType(), True),
                                T.StructField('uid_4',  T.StringType(), True),
                                T.StructField('uid_5',  T.StringType(), True),
                                T.StructField('uid_6',  T.StringType(), True),
                                T.StructField('uid_7',  T.StringType(), True),
                                T.StructField('uid_8',  T.StringType(), True),
                                T.StructField('uid_9',  T.StringType(), True),
                                T.StructField('uid_10',  T.StringType(), True),
                                T.StructField('uid_11',  T.StringType(), True),
                                T.StructField('uid_12',  T.StringType(), True),
                                T.StructField('uid_13',  T.StringType(), True),
                                T.StructField('uid_14',  T.StringType(), True),
                                T.StructField('uid_15',  T.StringType(), True),
                                T.StructField('insert_date',  T.DateType(), True),
                                T.StructField('supv_uid', T.StringType(), True),
                                T.StructField('update_date',  T.DateType(), True),
                                T.StructField('reason',  T.StringType(), True)
                                ])
        tbl_hierarchy_daily_curr = out.dataframe(mode='previous', schema=curr_schema)

        left_cond = [tbl_hierarchy_daily_curr.uid_0 == tbl_hierarchy_daily_stg.uid_0]
        tbl_hierarchy_daily_curr = tbl_hierarchy_daily_curr.join(tbl_hierarchy_daily_stg, left_cond, how='left_semi')

        tbl_hierarchy_daily_stg = truncate_query_plan(tbl_hierarchy_daily_stg)
        tbl_hierarchy_daily_stg = tbl_hierarchy_daily_stg.alias('new')
        tbl_hierarchy_daily_curr = truncate_query_plan(tbl_hierarchy_daily_curr)
        tbl_hierarchy_daily_curr = tbl_hierarchy_daily_curr.alias('curr')

        # update new records that also appear in the current dataset
        tbl_hierarchy_daily_stg_updates = tbl_hierarchy_daily_stg.join(
            tbl_hierarchy_daily_curr, tbl_hierarchy_daily_curr.uid_0 == tbl_hierarchy_daily_stg.uid_0, 'inner')

        tbl_hierarchy_daily_stg_updates = tbl_hierarchy_daily_stg_updates.filter(
                (F.coalesce(tbl_hierarchy_daily_curr['curr.rc'], F.lit('')) != F.coalesce(tbl_hierarchy_daily_stg['new.rc'], F.lit('')))
                | (F.coalesce(tbl_hierarchy_daily_curr['curr.status'], F.lit('')) != F.coalesce(tbl_hierarchy_daily_stg['new.status'], F.lit('')))
                | (F.coalesce(tbl_hierarchy_daily_curr['curr.position'], F.lit(0)) != F.coalesce(tbl_hierarchy_daily_stg['new.position'], F.lit(0)))
                | (F.coalesce(tbl_hierarchy_daily_curr['curr.mgmt_level'], F.lit(0)) != F.coalesce(tbl_hierarchy_daily_stg['new.mgmt_level'], F.lit(0)))
                | (F.coalesce(tbl_hierarchy_daily_curr['curr.uid_1'], F.lit('')) != F.coalesce(tbl_hierarchy_daily_stg['new.uid_1'], F.lit('')))
                | (F.coalesce(tbl_hierarchy_daily_curr['curr.uid_2'], F.lit('')) != F.coalesce(tbl_hierarchy_daily_stg['new.uid_2'], F.lit('')))
                | (F.coalesce(tbl_hierarchy_daily_curr['curr.uid_3'], F.lit('')) != F.coalesce(tbl_hierarchy_daily_stg['new.uid_3'], F.lit('')))
                | (F.coalesce(tbl_hierarchy_daily_curr['curr.uid_4'], F.lit('')) != F.coalesce(tbl_hierarchy_daily_stg['new.uid_4'], F.lit('')))
                | (F.coalesce(tbl_hierarchy_daily_curr['curr.uid_5'], F.lit('')) != F.coalesce(tbl_hierarchy_daily_stg['new.uid_5'], F.lit('')))
                | (F.coalesce(tbl_hierarchy_daily_curr['curr.uid_6'], F.lit('')) != F.coalesce(tbl_hierarchy_daily_stg['new.uid_6'], F.lit('')))
                | (F.coalesce(tbl_hierarchy_daily_curr['curr.uid_7'], F.lit('')) != F.coalesce(tbl_hierarchy_daily_stg['new.uid_7'], F.lit('')))
                | (F.coalesce(tbl_hierarchy_daily_curr['curr.uid_8'], F.lit('')) != F.coalesce(tbl_hierarchy_daily_stg['new.uid_8'], F.lit('')))
                | (F.coalesce(tbl_hierarchy_daily_curr['curr.uid_9'], F.lit('')) != F.coalesce(tbl_hierarchy_daily_stg['new.uid_9'], F.lit('')))
                | (F.coalesce(tbl_hierarchy_daily_curr['curr.uid_10'], F.lit('')) != F.coalesce(tbl_hierarchy_daily_stg['new.uid_10'], F.lit('')))
                | (F.coalesce(tbl_hierarchy_daily_curr['curr.uid_11'], F.lit('')) != F.coalesce(tbl_hierarchy_daily_stg['new.uid_11'], F.lit('')))
                | (F.coalesce(tbl_hierarchy_daily_curr['curr.uid_12'], F.lit('')) != F.coalesce(tbl_hierarchy_daily_stg['new.uid_12'], F.lit('')))
                | (F.coalesce(tbl_hierarchy_daily_curr['curr.uid_13'], F.lit('')) != F.coalesce(tbl_hierarchy_daily_stg['new.uid_13'], F.lit('')))
                | (F.coalesce(tbl_hierarchy_daily_curr['curr.uid_14'], F.lit('')) != F.coalesce(tbl_hierarchy_daily_stg['new.uid_14'], F.lit('')))
                | (F.coalesce(tbl_hierarchy_daily_curr['curr.uid_15'], F.lit('')) != F.coalesce(tbl_hierarchy_daily_stg['new.uid_15'], F.lit('')))
                | (F.coalesce(tbl_hierarchy_daily_curr['curr.supv_uid'], F.lit('')) != F.coalesce(tbl_hierarchy_daily_stg['new.supv_uid'], F.lit(''))) \
            )

        tbl_hierarchy_daily_stg_updates = tbl_hierarchy_daily_stg_updates.selectExpr(
                "new.uid_0",
                "new.rc",
                "new.status",
                "new.position",
                "new.mgmt_level",
                "new.uid_1",
                "new.uid_2",
                "new.uid_3",
                "new.uid_4",
                "new.uid_5",
                "new.uid_6",
                "new.uid_7",
                "new.uid_8",
                "new.uid_9",
                "new.uid_10",
                "new.uid_11",
                "new.uid_12",
                "new.uid_13",
                "new.uid_14",
                "new.uid_15",
                "curr.insert_date",
                "new.supv_uid",
                "CAST(from_utc_timestamp(current_timestamp(), 'PST') as DATE) AS update_date",
                """CASE WHEN curr.uid_1 != new.uid_1 THEN 'uid_1' WHEN curr.uid_2 != new.uid_2 THEN 'uid_2'
                    WHEN curr.uid_3 != new.uid_3 THEN 'uid_3' WHEN curr.uid_4 != new.uid_4 THEN 'uid_4'
                    WHEN curr.uid_5 != new.uid_5 THEN 'uid_5' WHEN curr.uid_6 != new.uid_6 THEN 'uid_6'
                    WHEN curr.uid_7 != new.uid_7 THEN 'uid_7' WHEN curr.uid_8 != new.uid_8 THEN 'uid_8'
                    WHEN curr.uid_9 != new.uid_9 THEN 'uid_9' WHEN curr.uid_10 != new.uid_10 THEN 'uid_10'
                    WHEN curr.uid_11 != new.uid_11 THEN 'uid_11' WHEN curr.uid_12 != new.uid_12 THEN 'uid_12'
                    WHEN curr.uid_13 != new.uid_13 THEN 'uid_13'
                    WHEN curr.uid_14 != new.uid_14 THEN 'uid_14'
                    WHEN curr.uid_15 != new.uid_15 THEN 'uid_15' WHEN curr.position != new.position THEN 'position'
                    WHEN curr.mgmt_level != new.mgmt_level THEN 'mgmt_level'
                    WHEN curr.status != new.status THEN 'status'
                    WHEN curr.rc != new.rc THEN 'rc'
                    WHEN curr.supv_uid != new.supv_uid THEN 'supv_uid' ELSE '?' END AS reason
                    """
            ).alias('updates_stg')

        tbl_hierarchy_daily_stg_updates = tbl_hierarchy_daily_stg_updates.withColumn(
            "update_date", F.date_sub(tbl_hierarchy_daily_stg_updates.update_date, 1))

        # update old records so we can delete them later
        tbl_hierarchy_daily_stg_new_2 = tbl_hierarchy_daily_stg.selectExpr(
            "uid_0 as new_uid_0", "rc as new_rc", "status as new_status", "position as new_position",
            "mgmt_level as new_mgmt_level", "uid_1 as new_uid_1", "uid_2 as new_uid_2", "uid_3 as new_uid_3",
            "uid_4 as new_uid_4", "uid_5 as new_uid_5", "uid_6 as new_uid_6", "uid_7 as new_uid_7",
            "uid_8 as new_uid_8", "uid_9 as new_uid_9", "uid_10 as new_uid_10", "uid_11 as new_uid_11",
            "uid_12 as new_uid_12", "uid_13 as new_uid_13", "uid_14 as new_uid_14",
            "uid_15 as new_uid_15", "supv_uid as new_supv_uid"
            )
        tbl_hierarchy_daily_stg_new_2 = tbl_hierarchy_daily_stg_new_2.alias("new_2")
        tbl_hierarchy_daily_curr_2 = tbl_hierarchy_daily_curr.select(
            "uid_0", "rc", "status", "position", "mgmt_level", "uid_1", "uid_2", "uid_3",
            "uid_4", "uid_5", "uid_6", "uid_7", "uid_8", "uid_9", "uid_10", "uid_11", "uid_12",
            "uid_13", "uid_14", "uid_15", "insert_date", "supv_uid"
            )
        tbl_hierarchy_daily_curr_2 = tbl_hierarchy_daily_curr_2.alias("curr_2")

        tbl_hierarchy_daily_curr_updates = tbl_hierarchy_daily_curr_2.join(
            tbl_hierarchy_daily_stg_new_2, tbl_hierarchy_daily_curr_2.uid_0 == tbl_hierarchy_daily_stg_new_2['new_uid_0'], 'inner')\
            .filter(
                (F.coalesce(tbl_hierarchy_daily_curr_2['curr_2.rc'], F.lit('')) != F.coalesce(tbl_hierarchy_daily_stg_new_2['new_2.new_rc'], F.lit('')))
                | (F.coalesce(tbl_hierarchy_daily_curr_2['curr_2.status'], F.lit('')) != F.coalesce(tbl_hierarchy_daily_stg_new_2['new_2.new_status'], F.lit('')))
                | (F.coalesce(tbl_hierarchy_daily_curr_2['curr_2.position'], F.lit(0)) != F.coalesce(tbl_hierarchy_daily_stg_new_2['new_2.new_position'], F.lit(0)))
                | (F.coalesce(tbl_hierarchy_daily_curr_2['curr_2.mgmt_level'], F.lit(0)) != F.coalesce(tbl_hierarchy_daily_stg_new_2['new_2.new_mgmt_level'], F.lit(0)))
                | (F.coalesce(tbl_hierarchy_daily_curr_2['curr_2.uid_1'], F.lit('')) != F.coalesce(tbl_hierarchy_daily_stg_new_2['new_2.new_uid_1'], F.lit('')))
                | (F.coalesce(tbl_hierarchy_daily_curr_2['curr_2.uid_2'], F.lit('')) != F.coalesce(tbl_hierarchy_daily_stg_new_2['new_2.new_uid_2'], F.lit('')))
                | (F.coalesce(tbl_hierarchy_daily_curr_2['curr_2.uid_3'], F.lit('')) != F.coalesce(tbl_hierarchy_daily_stg_new_2['new_2.new_uid_3'], F.lit('')))
                | (F.coalesce(tbl_hierarchy_daily_curr_2['curr_2.uid_4'], F.lit('')) != F.coalesce(tbl_hierarchy_daily_stg_new_2['new_2.new_uid_4'], F.lit('')))
                | (F.coalesce(tbl_hierarchy_daily_curr_2['curr_2.uid_5'], F.lit('')) != F.coalesce(tbl_hierarchy_daily_stg_new_2['new_2.new_uid_5'], F.lit('')))
                | (F.coalesce(tbl_hierarchy_daily_curr_2['curr_2.uid_6'], F.lit('')) != F.coalesce(tbl_hierarchy_daily_stg_new_2['new_2.new_uid_6'], F.lit('')))
                | (F.coalesce(tbl_hierarchy_daily_curr_2['curr_2.uid_7'], F.lit('')) != F.coalesce(tbl_hierarchy_daily_stg_new_2['new_2.new_uid_7'], F.lit('')))
                | (F.coalesce(tbl_hierarchy_daily_curr_2['curr_2.uid_8'], F.lit('')) != F.coalesce(tbl_hierarchy_daily_stg_new_2['new_2.new_uid_8'], F.lit('')))
                | (F.coalesce(tbl_hierarchy_daily_curr_2['curr_2.uid_9'], F.lit('')) != F.coalesce(tbl_hierarchy_daily_stg_new_2['new_2.new_uid_9'], F.lit('')))
                | (F.coalesce(tbl_hierarchy_daily_curr_2['curr_2.uid_10'], F.lit('')) != F.coalesce(tbl_hierarchy_daily_stg_new_2['new_2.new_uid_10'], F.lit('')))
                | (F.coalesce(tbl_hierarchy_daily_curr_2['curr_2.uid_11'], F.lit('')) != F.coalesce(tbl_hierarchy_daily_stg_new_2['new_2.new_uid_11'], F.lit('')))
                | (F.coalesce(tbl_hierarchy_daily_curr_2['curr_2.uid_12'], F.lit('')) != F.coalesce(tbl_hierarchy_daily_stg_new_2['new_2.new_uid_12'], F.lit('')))
                | (F.coalesce(tbl_hierarchy_daily_curr_2['curr_2.uid_13'], F.lit('')) != F.coalesce(tbl_hierarchy_daily_stg_new_2['new_2.new_uid_13'], F.lit('')))
                | (F.coalesce(tbl_hierarchy_daily_curr_2['curr_2.uid_14'], F.lit('')) != F.coalesce(tbl_hierarchy_daily_stg_new_2['new_2.new_uid_14'], F.lit('')))
                | (F.coalesce(tbl_hierarchy_daily_curr_2['curr_2.uid_15'], F.lit('')) != F.coalesce(tbl_hierarchy_daily_stg_new_2['new_2.new_uid_15'], F.lit('')))
                | (F.coalesce(tbl_hierarchy_daily_curr_2['curr_2.supv_uid'], F.lit('')) != F.coalesce(tbl_hierarchy_daily_stg_new_2['new_2.new_supv_uid'], F.lit(''))) \
            ).selectExpr(
                "curr_2.uid_0",
                "curr_2.rc",
                "curr_2.status",
                "curr_2.position",
                "curr_2.mgmt_level",
                "curr_2.uid_1",
                "curr_2.uid_2",
                "curr_2.uid_3",
                "curr_2.uid_4",
                "curr_2.uid_5",
                "curr_2.uid_6",
                "curr_2.uid_7",
                "curr_2.uid_8",
                "curr_2.uid_9",
                "curr_2.uid_10",
                "curr_2.uid_11",
                "curr_2.uid_12",
                "curr_2.uid_13",
                "curr_2.uid_14",
                "curr_2.uid_15",
                "curr_2.insert_date",
                "curr_2.supv_uid",
                "CAST(from_utc_timestamp(current_timestamp(), 'PST') as DATE) AS update_date",
                """CASE WHEN curr_2.uid_1 != new_2.new_uid_1 THEN 'uid_1' WHEN curr_2.uid_2 != new_2.new_uid_2 THEN 'uid_2'
                    WHEN curr_2.uid_3 != new_2.new_uid_3 THEN 'uid_3' WHEN curr_2.uid_4 != new_2.new_uid_4 THEN 'uid_4'
                    WHEN curr_2.uid_5 != new_2.new_uid_5 THEN 'uid_5' WHEN curr_2.uid_6 != new_2.new_uid_6 THEN 'uid_6'
                    WHEN curr_2.uid_7 != new_2.new_uid_7 THEN 'uid_7' WHEN curr_2.uid_8 != new_2.new_uid_8 THEN 'uid_8'
                    WHEN curr_2.uid_9 != new_2.new_uid_9 THEN 'uid_9' WHEN curr_2.uid_10 != new_2.new_uid_10 THEN 'uid_10'
                    WHEN curr_2.uid_11 != new_2.new_uid_11 THEN 'uid_11' WHEN curr_2.uid_12 != new_2.new_uid_12 THEN 'uid_12'
                    WHEN curr_2.uid_13 != new_2.new_uid_13 THEN 'uid_13'
                    WHEN curr_2.uid_14 != new_2.new_uid_14 THEN 'uid_14'
                    WHEN curr_2.uid_15 != new_2.new_uid_15 THEN 'uid_15' WHEN curr_2.position != new_2.new_position THEN 'position'
                    WHEN curr_2.mgmt_level != new_2.new_mgmt_level THEN 'mgmt_level'
                    WHEN curr_2.status != new_2.new_status THEN 'status'
                    WHEN curr_2.rc != new_2.new_rc THEN 'rc' WHEN curr_2.supv_uid != new_2.new_supv_uid THEN 'supv_uid'
                    ELSE '?' END AS reason
                """
            ).alias('updates_curr')

        # remove the records from stg that have been updated and will be unioned through another table
        tbl_hierarchy_daily_stg_new = tbl_hierarchy_daily_stg.selectExpr(
                "new.uid_0 as x_uid_0",
                "new.rc as x_rc",
                "new.status as x_status",
                "new.position as x_position",
                "new.mgmt_level as x_mgmt_level",
                "new.uid_1 as x_uid_1",
                "new.uid_2 as x_uid_2",
                "new.uid_3 as x_uid_3",
                "new.uid_4 as x_uid_4",
                "new.uid_5 as x_uid_5",
                "new.uid_6 as x_uid_6",
                "new.uid_7 as x_uid_7",
                "new.uid_8 as x_uid_8",
                "new.uid_9 as x_uid_9",
                "new.uid_10 as x_uid_10",
                "new.uid_11 as x_uid_11",
                "new.uid_12 as x_uid_12",
                "new.uid_13 as x_uid_13",
                "new.uid_14 as x_uid_14",
                "new.uid_15 as x_uid_15",
                "new.update_date as x_update_date",
                "new.insert_date as x_insert_date",
                "new.supv_uid as x_supv_uid",
                "new.reason as x_reason"
        )
        tbl_hierarchy_daily_stg_new = tbl_hierarchy_daily_stg_new.join(tbl_hierarchy_daily_stg_updates,
                                                                   on=tbl_hierarchy_daily_stg_updates.uid_0 == tbl_hierarchy_daily_stg_new.x_uid_0,
                                                                   how='left_anti')

        # remove the records from tgt that have been updated
        tbl_hierarchy_daily_curr = tbl_hierarchy_daily_curr.join(tbl_hierarchy_daily_curr_updates,
                                                                 on=F.col('updates_curr.uid_0') == F.col('curr.uid_0'),
                                                                 how='left_anti')

        # remove the records from stg that appear in tgt and have no updates
        tbl_hierarchy_daily_stg_new = tbl_hierarchy_daily_stg_new.join(tbl_hierarchy_daily_curr,
                                                                       on=F.col('curr.uid_0') == tbl_hierarchy_daily_stg_new.x_uid_0,
                                                                       how='left_anti')

        # rename columns after joins
        tbl_hierarchy_daily_stg_new = tbl_hierarchy_daily_stg_new.selectExpr(
                "x_uid_0 as uid_0",
                "x_rc as rc",
                "x_status as status",
                "x_position as position",
                "x_mgmt_level as mgmt_level",
                "x_uid_1 as uid_1",
                "x_uid_2 as uid_2",
                "x_uid_3 as uid_3",
                "x_uid_4 as uid_4",
                "x_uid_5 as uid_5",
                "x_uid_6 as uid_6",
                "x_uid_7 as uid_7",
                "x_uid_8 as uid_8",
                "x_uid_9 as uid_9",
                "x_uid_10 as uid_10",
                "x_uid_11 as uid_11",
                "x_uid_12 as uid_12",
                "x_uid_13 as uid_13",
                "x_uid_14 as uid_14",
                "x_uid_15 as uid_15",
                "x_insert_date as insert_date",
                "x_supv_uid as supv_uid",
                "x_update_date as update_date",
                "x_reason as reason"
        )
        # insert the updated records with the new reasoning

        tbl_hierarchy_daily = tbl_hierarchy_daily_stg_new.unionByName(tbl_hierarchy_daily_curr).unionByName(tbl_hierarchy_daily_stg_updates)
        tbl_hierarchy_daily = tbl_hierarchy_daily.filter(F.isnull(tbl_hierarchy_daily.uid_0) == False)
        tbl_hierarchy_daily = tbl_hierarchy_daily.orderBy(tbl_hierarchy_daily.update_date.desc())

        out.set_mode('replace')
        out.write_dataframe(tbl_hierarchy_daily)
    else:
        # loading a temporary hierarchy table
        initial_load = initial_load.selectExpr(
            "uid_0",
            "rc",
            "status",
            "position + 4 as position",
            "0 as mgmt_level",
            "'' as uid_1",
            "'' as uid_2",
            "'' as uid_3",
            "'' as uid_4",
            "uid_1 as uid_5",
            "uid_2 as uid_6",
            "uid_3 as uid_7",
            "uid_4 as uid_8",
            "uid_5 as uid_9",
            "uid_6 as uid_10",
            "uid_7 as uid_11",
            "uid_8 as uid_12",
            "uid_9 as uid_13",
            "uid_10 as uid_14",
            "uid_11 as uid_15",
            "insert_date",
            "supv_uid",
            "update_date",
            "reason"
        )
        initial_load = initial_load.withColumn('insert_date', F.to_date(initial_load['insert_date']))
        initial_load = initial_load.withColumn('update_date', F.to_date(initial_load['update_date']))
        out.set_mode('replace')
        out.write_dataframe(initial_load)
