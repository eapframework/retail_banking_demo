from transforms.api import transform, Input, Output, incremental, configure
from utility.incremental.update_insert import update_insert_core
import logging
from transforms.api import transform, Input, Output, incremental
from utility.column_clean import clean_columns, lowercase_columns, remove_prefix
logger = logging.getLogger(__name__)


@configure(profile=["EXECUTOR_MEMORY_MEDIUM", "NUM_EXECUTORS_16"])
@incremental(semantic_version=11)
@transform(
   out=Output("/Innovation Lab/[Source] Oracle ESAR/data/clean/ticket_2"),
   #updates=Input("/Innovation Lab/[Source] Oracle ESAR/data/raw/Prod/snowflake/Ticket_2_snowflake_fullreload_1202"),
   updates=Input("/Innovation Lab/[Source] Oracle ESAR/data/raw/Prod/snowflake/Ticket_2_snowflake_fullreload_05242023"),
   backfill=Input("/Innovation Lab/[Source] Oracle ESAR/data/raw/Prod/esaar_tmviews.ticket_2"),
   )
def my_compute_function(ctx, out, updates, backfill):
    #updates = updates.dataframe()
    backfill = backfill.dataframe()
    updates = updates.dataframe()
    updates = backfill.unionByName(updates)
    updates_df = clean_columns(
        updates,#.dataframe()
        strip_columns=strip_columns,
        integer_columns=cast_to_integer_columns,
        double_columns=cast_to_double_columns,
        decimal_columns=cast_to_decimal_columns,
        timestamp_columns=cast_to_timestamp_from_long_columns,
        datetime_columns=cast_to_timestamp_columns,
        datetime_format=datetime_format,
        date_columns=cast_to_date_columns,
        date_format=date_format,
        id_columns=cast_to_string_columns,
        integer_from_num_columns=cast_to_integer_from_decimal_columns
    )

    updates_df = lowercase_columns(updates_df)
    for c in cast_to_short_columns:
        updates_df = updates_df.withColumn(c, updates_df[c].cast('short'))
    for column in decimal_columns:
        updates_df = updates_df.withColumn(column, updates_df[column].cast("decimal").alias(column))
    for column in cast_to_integer_columns:
        updates_df = updates_df.withColumn(column, updates_df[column].cast("integer").alias(column))
    keys = ["ticket"]
    # logger.info(f"{dir(out)}")
    # update_insert_core(ctx, output, updates_df, keys, ["node_record_added"], num_partitions=200)
    update_insert_core(ctx, out, updates_df, primary_keys=keys, order_cols=["last_modified_date","load_ts"])

cast_to_short_columns=[]
date_format = 'yyyy-MM-dd'
datetime_format = 'yyyy-MM-dd HH:mm:ss'

cast_to_date_columns = []
cast_to_timestamp_columns = []
cast_to_timestamp_from_long_columns = [
    "LAST_MODIFIED_DATE","ALARM_DATE",
"ALARM_SUPPRESSION_END_TIME",
"ALARM_SUPPRESSION_START_TIME",
"CURRENT_STATUS_TIME",
"DIAGNOSE_EXPIRATION_TIME",
"EXPECTED_RESPONSE_DATE",
"EXPECTED_RESTORE_DATE",
"FMS_DUE_DATE",
"IN_WIRE_DATE",
"PLANNED_RESTORAL_TIME",
"REPAIR_NOTIFY_DUE_DATE",
"RESOLVED_DATE",
"SERVICE_ACTIVE_DATE",
"SLA_START_DATE",
"STATUS_DATE",
"TECH_COMPLETION_DATE",
"TECH_DISPATCH_DATE",
"TICKET_DUE_DATE",
"VENDOR_REFER_DATE",
"VERIFY_EXPIRATION_TIME",
"WARRANY_DATE"]
cast_to_integer_columns = []
cast_to_double_columns = []
cast_to_decimal_columns = ["ALARM_SUPPRESSION_FLAG",
"ASEOBB_INDICATOR",
"ATUP_SUMMARY_CODE",
"BILLING_AUTH",
"CLFI_SPEED",
"CUBE_LICENSE",
"CUSTOMER_ATTITUDE",
"CUSTOMER_CHRONIC_COUNT",
"DIAGNOSE_TRIGGER",
"DISPATCH_AUTHORIZED_CALNET",
"DSL_IMPACT",
"EBM_INDICATOR",
"ENTRY_TYPE",
"EXCLUDE_TICKET_FROM_REPORTING",
"FMS_ACTION",
"FMS_ALARM_GROUP_ID",
"FMS_ALARM_SEVERITY",
"FMS_IS_911_AFFECTED",
"FMS_QUANTITY",
"FMS_SERIAL",
"FMS_SERVER_SERIAL",
"GRANITE_INSTANCE_ID",
"IS_AVOICS",
"IS_MEN",
"IVR_PROG_REMAIN",
"LOCAL_LATA",
"LOCK_COUNT",
"ML_OVERRIDE_FLAG",
"MOD_PHASE",
"MOW_CONSENT_FOR_PI",
"NETWORK_TYPE",
"NO_LINES_OOS",
"NO_OF_LINES",
"NUM_RPTDPVCS_AFFECTED",
"ORIG_RSL_CD",
"ORIG_SYS_DETM_RSL_CD",
"OVERTIME_APPROVAL",
"POINTSOUT1",
"POINTSOUT2",
"POINTSOUT3",
"REMOTE_LATA",
"REPEAT_CHRONIC",
"RESPONSE_MISSED_MET",
"RESTORE_MISSED_MET",
"SA_REQUEST_IND",
"SCRUB_COUNT",
"SHADOW_NADM",
"TICKET_CHRONIC_COUNT",
"TIMEOUT1",
"TIMEOUT2",
"TIMEOUT3",
"TOTAL_DEFERRAL_DURATION",
"TOTAL_RETRY_COUNT",
"TROUBLE_REPORT_STATUS",
"TROUBLE_TYPE_CODE","UPDATE_COUNT",
"URGENCY_ID",
"VALIDATE_CONTACT_INFO",
"VALIDATE_DISPATCH_AUTH",
"VALIDATE_LCON_INFO",
"VALIDATE_LOCATION_ACCESS_HOURS",
"VALIDATE_POWER_TO_CPE",
"VALIDATE_TEST_AUTH",
"VENDOR_TICKET_STATE",
"VERIFY_TRIGGERED_BY",
"WHEN_TO_NOTIFY",
"BMD_TEST_STATUS",
"CHANGEFLAG",
"CHILD_TICKET_COUNT",
"COS",
"INTERFACE",
"INTERFACE_UNREACH",
"LANRC",
"LINK",
"NODE",
"QTATY",
"RESOLUTIONBYPASSLEVEL",
"RETCD",
"SERVICE_CONFIGURATION",
"STATE",
"TICKET_MASS_CLOSED",
"TUNNEL_OPTION",
"VENDOR_MEET_FLAG",
"VERIFY_TRIGGER"]
cast_to_string_columns = []
cast_to_integer_from_decimal_columns = []
strip_columns = []
decimal_columns = []