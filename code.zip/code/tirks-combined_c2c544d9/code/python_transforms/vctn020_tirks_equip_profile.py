from transforms.api import transform, Input, Output, incremental
from utility.column_clean import clean_columns, lowercase_columns, remove_prefix
from pyspark.sql.functions import col


@transform(
    out=Output(
        "/Innovation Lab/[Source] Teradata EDW - ACCESS_VIEWS/data/prod_clean/vctn020_tirks_equip_profile"
    ),
    df=Input(
        "/Innovation Lab/[Source] Teradata EDW - ACCESS_VIEWS/data/raw/snowflake/ACCESS_VIEWS.VCTN020_TIRKS_EQUIP_PROFILE"
    ),
)
def my_compute_function(df, out):
    df = clean_columns(
        df.dataframe(),
        date_format=date_format,
        date_columns=string_to_date,
        datetime_format=datetime_format,
        datetime_columns=long_unixtime_to_timestamp,
        timestamp_from_string_format=string_unixtime_format,
        timestamp_from_string_columns=string_unixtime_to_timestamp,
        timestamp_format=long_unixtime_format,
        timestamp_columns=long_unixtime_to_timestamp,
        integer_columns=string_to_integer_columns,
        double_columns=string_to_double_columns,
        decimal_columns=string_to_decimal_columns,
        id_columns=numeric_to_string_columns,
        integer_from_num_columns=decimal_to_integer,
        strip_columns=strip_string_columns,
    )
    # df = df.drop(*drop_columns)
    # df = remove_prefix(df, 'example_prefix')
    df = lowercase_columns(df)
    df = df.select(
        [
            col(c).cast("short") if c in columns_to_convert else col(c)
            for c in df.columns
        ]
    )
    out.write_dataframe(df)


drop_columns = []

date_format = "yyyy-MM-dd"
string_to_date = []
datetime_format = "yyyy-MM-dd HH:mm:ss"
string_to_timestamp = []
columns_to_convert = [
    "diverse_units_qty",
    "drop_limit_qty",
    "equipment_unit_qty",
    "equipment_unit_true_spare_qty",
]
string_unixtime_format = None
string_unixtime_to_timestamp = []
long_unixtime_format = None
long_unixtime_to_timestamp = []

string_to_integer_columns = []
string_to_double_columns = []
string_to_decimal_columns = []

numeric_to_string_columns = []
decimal_to_integer = []

strip_string_columns = [
    "SBC_COMPANY_CD",
    "SBC_SYSTEM_CD",
    "SBC_STATE_CD",
    "EQUIPMENT_LOCATION_CLLI_CD",
    "HUMAN_EQUIP_CATALOG_ITEM_CD",
    "RELAY_RACK_CD",
    "LOCATION_PROCESSING_CD",
    "EQUIPMENT_CATALOG_ITEM_NBR",
    "ASSIGNMENT_RESPONSIBILITY_CD",
    "MAINTENANCE_RESPONSIBILITY_CD",
    "INVENTORY_AUTHORIZATION_CD",
    "PLUG_LOCATION_CLLI_CD",
    "HIERARCHICAL_DATA_CD",
    "LEAVE_PLUGS_CD",
    "EQUIPMENT_TYPE_CD",
    "SCHED_COORDNT_SYS_COMMTN_CD",
    "EQUIPMENT_MODIFIER_CD",
    "EQUIPMENT_UNIT_RECORD_TYPE_CD",
    "DRAWING_NBR",
    "EQUIPMENT_CATEGORY_NBR",
    "ADMINISTRATIVE_AREA_CD",
    "DETAILED_RGLTY_EQUIP_CLASS_CD",
]
