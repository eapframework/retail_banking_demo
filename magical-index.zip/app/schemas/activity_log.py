from __future__ import annotations

import uuid
from datetime import datetime
from enum import Enum
from typing import Optional

from pydantic import BaseModel, Field

from app.schemas.resource import ActorType


class ActionType(str, Enum):
    RESOURCE_CREATED = "RESOURCE_CREATED"
    RESOURCE_UPDATED = "RESOURCE_UPDATED"
    RESOURCE_DELETED = "RESOURCE_DELETED"
    RELATIONSHIP_CREATED = "RELATIONSHIP_CREATED"
    RELATIONSHIP_DELETED = "RELATIONSHIP_DELETED"


def generate_log_id() -> str:
    """Generate a unique log_id using UUID4 hex."""
    return f"log-{uuid.uuid4().hex[:12]}"


class ActivityLogCreate(BaseModel):
    resource_id: str = Field(min_length=1)
    action: ActionType
    actor_type: ActorType
    actor_name: str = Field(min_length=1)
    details: Optional[str] = None


class ActivityLogRead(BaseModel):
    log_id: str
    resource_id: str
    action: ActionType
    actor_type: ActorType
    actor_name: str
    details: Optional[str] = None
    timestamp: datetime
