from transforms.api import transform, Input, Output
from pyspark.sql import functions as F

# Spark utils
from pyspark.sql import functions as F
from myproject.utils.global_code import PARENT_FOLDER


@transform(
    all_platform_data_with_lineage=Output(
        "/Innovation Lab/Data Governance/workbook-output/api_code/all_platform_data_with_lineage",
        sever_permissions=True,
    ),
    datasets_parents_and_children=Input(
        "/Innovation Lab/Data Governance/workbook-output/api_code/datasets_parents_and_children"
    ),
    all_platform_data=Input(f"{PARENT_FOLDER}/all_platform_data"),
    metrics=Input(
        "/Innovation Lab/Metrics/Group Shared Data & Code/data/ontology/raw/LAST_30_DAYS_METRICS"
    ),
)
def all_platform_data_with_lineage(
    datasets_parents_and_children,
    all_platform_data,
    all_platform_data_with_lineage,
    metrics,
):
    df = all_platform_data.dataframe().join(
        datasets_parents_and_children.dataframe(), ["dataset_rid"], "left"
    )
    df = df.withColumn("has_children", F.size(F.col("children")) > 0)
    df = df.withColumn("has_parents", F.size(F.col("parents")) > 0)
    metrics = metrics.dataframe().select("dataset_rid", "current_disk_space")
    df = df.join(metrics, "dataset_rid", "left")
    all_platform_data_with_lineage.write_dataframe(df)
