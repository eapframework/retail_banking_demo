
from transforms.api import transform, Input, Output, incremental
from utility.column_clean import clean_columns, lowercase_columns, remove_prefix

@incremental(semantic_version=2)
@transform(
    out=Output("/Innovation Lab/[Source] Vertica IQI/data/clean/iqi_ecgi_mgrs100m_monthly_summary"),
    hist=Input("/Innovation Lab/[Source] Vertica IQI/data/raw/iqi_ecgi_mgrs100m_monthly_summary"),
    incre = Input("/Innovation Lab/[Source] Vertica IQI/data/raw/IQI Snowflake/iqi_ecgi_mgrs100m_monthly_summary")
)
def my_compute_function(hist,incre, out):
    hist= hist.dataframe()
    incre= incre.dataframe()
    incre = lowercase_columns(incre)
    df=hist.unionByName(incre)
    df = clean_columns(
        df,
        date_format=date_format, 
        date_columns=string_to_date,
        datetime_format=datetime_format, 
        datetime_columns=long_unixtime_to_timestamp,
        timestamp_from_string_format=string_unixtime_format,
        timestamp_from_string_columns=string_unixtime_to_timestamp,
        timestamp_format=long_unixtime_format, 
        timestamp_columns=long_unixtime_to_timestamp,
        integer_columns=string_to_integer_columns,
        double_columns=string_to_double_columns,
        decimal_columns=string_to_decimal_columns,
        id_columns=numeric_to_string_columns,
        integer_from_num_columns=decimal_to_integer,
        strip_columns=strip_string_columns,
    )
    # df = df.drop(*drop_columns)
    # df = remove_prefix(df, 'example_prefix')
    #df = lowercase_columns(df)
    out.write_dataframe(df)


drop_columns = []

date_format = 'yyyy-MM-dd'
string_to_date = []
datetime_format = 'yyyy-MM-dd HH:mm:ss'
string_to_timestamp = []

string_unixtime_format = None
string_unixtime_to_timestamp = []
long_unixtime_format = []
long_unixtime_to_timestamp = []
string_to_integer_columns = []
string_to_double_columns = []
string_to_decimal_columns = []
numeric_to_string_columns = []
decimal_to_integer = []
strip_string_columns = []