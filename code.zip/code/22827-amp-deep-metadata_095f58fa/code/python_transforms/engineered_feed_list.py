from transforms.api import transform_df, Input, Output
from pyspark.sql import functions as F


@transform_df(
    Output("/Innovation Lab/Data Governance/Code & Data/data/engineered_feed_list"),
    my_input=Input("/Innovation Lab/Data Governance/Code & Data/data/raw_datasets"),
)
def my_compute_function(my_input):
    df = my_input.filter(F.col("engineered_vs_snapshot") == "engineered")

    df = df.select(
        F.explode(F.col("clean_children")).alias("dataset_rid"),
        "engineered_vs_snapshot",
    ).distinct()

    return df
