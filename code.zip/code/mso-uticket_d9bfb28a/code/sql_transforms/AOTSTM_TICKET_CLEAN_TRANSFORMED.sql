CREATE TABLE `/Innovation Lab/[ETL] Ticketing/data/clean/AOTSTM_TICKET_CLEAN_TRANSFORMED` TBLPROPERTIES (foundry_transform_profile = 'EXECUTOR_MEMORY_MEDIUM') AS
    SELECT distinct STAGE.*
    , LK_TOPIC.Entity_Type entity_type
    , LK_TOPIC.Entity_Subtype entity_subtype
    , ie_distinct_active_org
    , ie_distinct_ticket
    , ie_human_pathway
    , ie_distinct_humans
    , ie_distinct_supervisor_name
    , ie_distinct_director_name
    , ie_distinct_avp_name
    , ie_distinct_vp_name
    , ie_distinct_svp_name
    , ie_distinct_vp_org_name
    , ie_distinct_first_human_touch
    , ie_distinct_last_human_touch
    , ie_total_human_touches
    , TICKET_2.child_ticket_count
    , to_timestamp(from_utc_timestamp(wfa_start_dt, 'America/New_York')) as wfa_start_dt_eastern
, to_timestamp(from_utc_timestamp(wfa_finish_dt, 'America/New_York')) as wfa_finish_dt_eastern
, to_timestamp(from_utc_timestamp(force_start_dt, 'America/New_York')) as force_start_dt_eastern
, to_timestamp(from_utc_timestamp(max_event_date, 'America/New_York')) as max_event_date_eastern
, to_timestamp(from_utc_timestamp(next_check_time, 'America/New_York')) as next_check_time_eastern
, to_timestamp(from_utc_timestamp(last_auto_touch, 'America/New_York')) as last_auto_touch_eastern
, to_timestamp(from_utc_timestamp(force_finish_dt, 'America/New_York')) as force_finish_dt_eastern
, to_timestamp(from_utc_timestamp(last_human_touch, 'America/New_York')) as last_human_touch_eastern
, to_timestamp(from_utc_timestamp(first_auto_touch, 'America/New_York')) as first_auto_touch_eastern
, to_timestamp(from_utc_timestamp(first_human_touch, 'America/New_York')) as first_human_touch_eastern
, to_timestamp(from_utc_timestamp(STAGE.last_modified_date, 'America/New_York')) as last_modified_date_eastern
, to_timestamp(from_utc_timestamp(ticket_cleared_date, 'America/New_York')) as ticket_cleared_date_eastern
, to_timestamp(from_utc_timestamp(service_restored_date, 'America/New_York')) as service_restored_date_eastern
, to_timestamp(from_utc_timestamp(cleared_deferred_time, 'America/New_York')) as cleared_deferred_time_eastern
, to_timestamp(from_utc_timestamp(ticket_opened_date_utc, 'America/New_York')) as ticket_opened_date_utc_eastern
, to_timestamp(from_utc_timestamp(ticket_closed_date_utc, 'America/New_York')) as ticket_closed_date_utc_eastern
, to_timestamp(from_utc_timestamp(force_dispatch_last_dt, 'America/New_York')) as force_dispatch_last_dt_eastern
, to_timestamp(from_utc_timestamp(force_dispatch_first_dt, 'America/New_York')) as force_dispatch_first_dt_eastern
, to_timestamp(from_utc_timestamp(trouble_reported_date_utc, 'America/New_York')) as trouble_reported_date_utc_eastern
, to_timestamp(from_utc_timestamp(requested_completion_date, 'America/New_York')) as requested_completion_date_eastern
, to_timestamp(from_utc_timestamp(force_first_human_touch_dt, 'America/New_York')) as force_first_human_touch_dt_eastern
, to_timestamp(from_utc_timestamp(from_unixtime(client_first_notified/1000), 'America/New_York')) as client_first_notified_dt_eastern
    , to_timestamp(from_utc_timestamp(wfa_start_dt, 'America/Chicago')) as wfa_start_dt_central
, to_timestamp(from_utc_timestamp(wfa_finish_dt, 'America/Chicago')) as wfa_finish_dt_central
, to_timestamp(from_utc_timestamp(force_start_dt, 'America/Chicago')) as force_start_dt_central
, to_timestamp(from_utc_timestamp(max_event_date, 'America/Chicago')) as max_event_date_central
, to_timestamp(from_utc_timestamp(next_check_time, 'America/Chicago')) as next_check_time_central
, to_timestamp(from_utc_timestamp(last_auto_touch, 'America/Chicago')) as last_auto_touch_central
, to_timestamp(from_utc_timestamp(force_finish_dt, 'America/Chicago')) as force_finish_dt_central
, to_timestamp(from_utc_timestamp(last_human_touch, 'America/Chicago')) as last_human_touch_central
, to_timestamp(from_utc_timestamp(first_auto_touch, 'America/Chicago')) as first_auto_touch_central
, to_timestamp(from_utc_timestamp(first_human_touch, 'America/Chicago')) as first_human_touch_central
, to_timestamp(from_utc_timestamp(STAGE.last_modified_date, 'America/Chicago')) as last_modified_date_central
, to_timestamp(from_utc_timestamp(ticket_cleared_date, 'America/Chicago')) as ticket_cleared_date_central
, to_timestamp(from_utc_timestamp(service_restored_date, 'America/Chicago')) as service_restored_date_central
, to_timestamp(from_utc_timestamp(cleared_deferred_time, 'America/Chicago')) as cleared_deferred_time_central
, to_timestamp(from_utc_timestamp(ticket_opened_date_utc, 'America/Chicago')) as ticket_opened_date_utc_central
, to_timestamp(from_utc_timestamp(ticket_closed_date_utc, 'America/Chicago')) as ticket_closed_date_utc_central
, to_timestamp(from_utc_timestamp(force_dispatch_last_dt, 'America/Chicago')) as force_dispatch_last_dt_central
, to_timestamp(from_utc_timestamp(force_dispatch_first_dt, 'America/Chicago')) as force_dispatch_first_dt_central
, to_timestamp(from_utc_timestamp(trouble_reported_date_utc, 'America/Chicago')) as trouble_reported_date_utc_central
, to_timestamp(from_utc_timestamp(requested_completion_date, 'America/Chicago')) as requested_completion_date_central
, to_timestamp(from_utc_timestamp(force_first_human_touch_dt, 'America/Chicago')) as force_first_human_touch_dt_central
, to_timestamp(from_utc_timestamp(from_unixtime(client_first_notified/1000), 'America/Chicago')) as client_first_notified_dt_central
, ie_distinct_work_queue
, handover_flag
, ie_distinct_ticket_state
     FROM `/Innovation Lab/[ETL] Ticketing/data/clean/AOTSTM_TICKET_CLEAN_STAGE` STAGE
    LEFT JOIN `/Innovation Lab/[ETL] Ticketing/data/clean/aotstm_lk_agg_main2ie` LK_AGG_IE
ON STAGE.ticket = LK_AGG_IE.ticket
    LEFT JOIN `/Innovation Lab/[ETL] Ticketing/logic/workbook-output/AOTS/AOTS-tm_topics` LK_TOPIC
    ON STAGE.ticket = LK_TOPIC.ticket
    LEFT JOIN `/Innovation Lab/[Source] Oracle ESAR/data/clean/ticket_2` TICKET_2
    ON STAGE.ticket=TICKET_2.ticket