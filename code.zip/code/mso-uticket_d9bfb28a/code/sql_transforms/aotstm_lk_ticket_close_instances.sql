CREATE TABLE `/Innovation Lab/[ETL] Ticketing/logic/aotstm/aotstm_lk_ticket_close_instances` AS
SELECT ticket, max(is_auto_closed) is_auto_closed
FROM
( SELECT gems_ticket AS ticket
, date_trunc('minute',activity_time) Modified_Time_1M
, active_org
, last_modified_by
, last_user
, last_mod_by
, CASE WHEN last_modified_by REGEXP '^[a-z][a-z][0-9][0-9][0-9][0-9a-z]' THEN last_modified_by
       WHEN last_user REGEXP '^[a-z][a-z][0-9][0-9][0-9][0-9a-z]' THEN last_user
       WHEN last_mod_by REGEXP '^[a-z][a-z][0-9][0-9][0-9][0-9a-z]' THEN last_mod_by
       WHEN last_user is not null then last_user
       WHEN last_modified_by is not null then last_modified_by
       WHEN last_mod_by is not null then last_mod_by
     ELSE 'Nobody' END as adj_mod_user 
, CASE WHEN last_modified_by REGEXP '^[a-z][a-z][0-9][0-9][0-9][0-9a-z]' THEN 0
       WHEN last_user REGEXP '^[a-z][a-z][0-9][0-9][0-9][0-9a-z]' THEN 0
       WHEN last_mod_by REGEXP '^[a-z][a-z][0-9][0-9][0-9][0-9a-z]' THEN 0
     ELSE 1 END is_auto_closed
FROM `/Innovation Lab/[Source] Oracle ESAR/data/clean/ticket_transfer` M
WHERE ticket_state='Closed'
GROUP BY gems_ticket, active_org, last_modified_by, last_user, last_mod_by, CASE WHEN last_modified_by REGEXP '^[a-z][a-z][0-9][0-9][0-9][0-9a-z]' THEN last_modified_by
       WHEN last_user REGEXP '^[a-z][a-z][0-9][0-9][0-9][0-9a-z]' THEN last_user
       WHEN last_mod_by REGEXP '^[a-z][a-z][0-9][0-9][0-9][0-9a-z]' THEN last_mod_by
       WHEN last_user is not null then last_user
       WHEN last_modified_by is not null then last_modified_by
       WHEN last_mod_by is not null then last_mod_by
     ELSE 'Nobody' END, date_trunc('minute',activity_time)
ORDER BY gems_ticket, date_trunc('minute',activity_time))
GROUP BY ticket