from __future__ import annotations

import os
from fastapi import APIRouter, Query

from app.core.config import settings
from app.services.store import store

router = APIRouter()


@router.get("/config")
def get_config():
    backend = settings.STORAGE_BACKEND
    resp = {
        "storage_backend": backend,
        "uc_catalog": os.getenv("UC_CATALOG"),
        "uc_schema": os.getenv("UC_SCHEMA"),
        "rid_table": os.getenv("MAGICAL_INDEX_RID_TABLE", "gandalf-magical-index-rid"),
        "rel_table": os.getenv("MAGICAL_INDEX_REL_TABLE", "gandalf-magical-index-rel"),
        "log_table": os.getenv("MAGICAL_INDEX_LOG_TABLE", "gandalf-magical-index-log"),
    }
    for attr in ("_rid_fqn", "_rel_fqn", "_log_fqn"):
        val = getattr(store, attr, None)
        if val:
            resp[attr.strip("_")] = val
    return resp


@router.get("/readiness")
def readiness():
    backend = settings.STORAGE_BACKEND
    ok = getattr(store, "ping", lambda: True)()
    return {"storage_backend": backend, "ready": ok}


@router.get("/raw-resource")
def raw_resource(resource_id: str = Query(..., description="resource_id to look up")):
    """Return the raw DB row for a resource_id, bypassing Pydantic parsing.

    Useful for diagnosing why ``/resources/{id}`` returns 404 when the
    row exists in the Databricks table.
    """
    if not hasattr(store, "_connect"):
        return {"error": "raw lookup only available with DeltaStore backend"}

    with store._connect() as conn:
        with conn.cursor() as cur:
            cur.execute(
                store._select_resource_sql() + " WHERE resource_id = ?",
                (resource_id,),
            )
            row = cur.fetchone()
            if row is None:
                return {"found": False, "resource_id": resource_id}

            cols = ["resource_id", "resource_name", "location",
                    "resource_type", "resource_status", "last_by",
                    "last_update_time"]
            raw = {c: repr(v) for c, v in zip(cols, row)}

            parsed = store._row_to_resource(row)
            return {
                "found": True,
                "parsed_ok": parsed is not None,
                "raw_row": raw,
            }
