from transforms.api import transform, Input, Output
from utility.column_clean import clean_columns, lowercase_columns
from pyspark.sql import functions as F


@transform(
    out=Output("ri.foundry.main.dataset.a3ee0d5c-7903-483c-82c8-370b37eeb678"),
    stg1=Input("ri.foundry.main.dataset.6fa2412f-a487-48e7-9694-2b18b75c41a0"),
    stg2=Input("ri.foundry.main.dataset.4818892f-1eee-4c8e-9f8b-50ed4968cab7"),

)
def my_compute_function(stg1, stg2, out):
    df = stg1.dataframe().unionByName(stg2.dataframe())


    df = clean_columns(
        df,
        strip_columns=strip_columns,
        integer_columns=cast_to_integer_columns,
        double_columns=cast_to_double_columns,
        decimal_columns=cast_to_decimal_columns,
        timestamp_columns=cast_to_timestamp_from_long_columns,
        datetime_columns=cast_to_timestamp_columns,
        datetime_format=datetime_format,
        date_columns=cast_to_date_columns,
        date_format=date_format,
        id_columns=cast_to_string_columns,
        integer_from_num_columns=cast_to_integer_from_decimal_columns
    )
    df = lowercase_columns(df)
    out.write_dataframe(df)


date_format = 'yyyy-MM-dd'
datetime_format = 'yyyy-MM-dd HH:mm:ss'

cast_to_date_columns = []
cast_to_timestamp_columns = []
cast_to_timestamp_from_long_columns = []
cast_to_integer_columns = []
cast_to_double_columns = []
cast_to_decimal_columns = []
cast_to_string_columns = []
cast_to_integer_from_decimal_columns = []
strip_columns = [
]

