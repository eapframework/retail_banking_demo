from transforms.api import transform_df, Input, Output, incremental
import pyspark.sql.functions as F


@transform_df(
    Output("ri.foundry.main.dataset.cdc386bc-9bf5-4e8b-bb3d-693919fbb2ec"),
    asi=Input("ri.foundry.main.dataset.d763db40-b5c4-4188-b068-03b7b728e8e2"),
    telco=Input("ri.foundry.main.dataset.8b302124-a05d-4f7e-9f9b-a637f31a3520"),
)
def my_compute_function(telco, asi):
    telco = telco.withColumn("source", F.lit('telco'))
    asi = asi.withColumn("source", F.lit('asi'))
    df = telco.unionByName(asi)
    return df
