from pyspark.sql import functions as F
from transforms.api import transform_df, Input, Output


@transform_df(
    Output("/Innovation Lab/Palantir Admins/Quantum/extensions/data/clean/sql_server_queried_datasets"),
    parsed_logs=Input("/Innovation Lab/Palantir Admins/Quantum/extensions/data/clean/sql_server_logs_parsed"),
)
def my_compute_function(parsed_logs):
    queried_datasets = parsed_logs.filter(
        F.col('eventName') == 'com.palantir.foundry.sql.statement.completion'
    ).select(
        F.explode(F.col('inputRids')).alias('dataset_rid'),
        F.col('time')
    ).groupBy(
        F.col('dataset_rid')
    ).agg(
        F.max('time').alias('mostRecentQueryTime')
    )
    return queried_datasets
