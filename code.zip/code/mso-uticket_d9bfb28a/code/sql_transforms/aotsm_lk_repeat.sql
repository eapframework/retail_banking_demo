CREATE TABLE `/Innovation Lab/[ETL] Ticketing/logic/aotsm/aotsm_lk_repeat` AS
    SELECT ticket_number FROM `/Innovation Lab/[ETL] Ticketing/data/clean/AOTSM_ALL_TROUBLE_TICKET_CLEAN` A
    WHERE EXISTS (SELECT ticket_number
        FROM `/Innovation Lab/[ETL] Ticketing/data/clean/AOTSM_ALL_TROUBLE_TICKET_CLEAN` B
        WHERE A.common_id=B.common_id
        AND A.logic_id=B.logic_id
        AND A.create_date > B.create_date
        AND (unix_timestamp(A.create_date)-unix_timestamp(B.create_date))/3600/24 < 28)