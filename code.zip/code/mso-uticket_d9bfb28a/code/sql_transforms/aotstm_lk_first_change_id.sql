CREATE TABLE `/Innovation Lab/[ETL] Ticketing/logic/aotstm/aotstm_lk_first_change_id` AS
    SELECT ticket_nb as ticket, regexp_extract(ticket_message, '(CHG000[0-9]*)', 1) as first_change_id 
    , ticket_message
     FROM `/Innovation Lab/[Source] Oracle ESAR/data/clean/ticket_log`
    WHERE ticket_message REGEXP 'CHG000[0-9]*'
    AND NOT (ticket_message REGEXP 'Date:.*Resolution:.*CHG')