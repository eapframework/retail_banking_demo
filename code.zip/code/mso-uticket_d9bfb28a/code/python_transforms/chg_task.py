from transforms.api import transform, Input, Output
from utility.column_clean import clean_columns, lowercase_columns, remove_prefix
from ..utils import perform_timestamp_parsing


@transform(
   out=Output("/Innovation Lab/[Source] Oracle ESAR/data/clean/chg_task"),
   df=Input("/Innovation Lab/[Source] Oracle ESAR/data/raw/Prod/snowflake/esaars_dbor_cm_rviews.chg_task_snowflake"),
)
def my_compute_function(df, out):
    df = clean_columns(
        df.dataframe(),
        strip_columns=strip_columns,
        integer_columns=cast_to_integer_columns,
        double_columns=cast_to_double_columns,
        decimal_columns=cast_to_decimal_columns,
        timestamp_columns=cast_to_timestamp_from_long_columns,
        datetime_columns=cast_to_timestamp_columns,
        datetime_format=datetime_format,
        date_columns=cast_to_date_columns,
        date_format=date_format,
        id_columns=cast_to_string_columns,
        integer_from_num_columns=cast_to_integer_from_decimal_columns
    )
    df = lowercase_columns(df)
    df = perform_timestamp_parsing(df)
    for column in decimal_columns:
        df = df.withColumn(column, df[column].cast("decimal").alias(column))
    out.write_dataframe(df)

date_format = 'yyyy-MM-dd'
datetime_format = 'yyyy-MM-dd HH:mm:ss'

cast_to_date_columns = []
cast_to_timestamp_columns = []
cast_to_timestamp_from_long_columns = []
cast_to_integer_columns = [
#    "SEQNO",
#    "STATUS",
#    "REQUEST_URGENCY",
#    "CLOSURE_CODE",
#    "PENDING",
#    "SCOPE",
#    "ZTMPSUBMITASSOCIATION",
#    "REQUEST_SUPERVISOR_TO_REASSIGN",
#    "ZTEMPPREVSEQNUM",
#    "ZTMPCONFLICTSFOUND",
#    "FIRST_IN_LINE",
#    "ZTMPBUSINESSHRSSELECTION",
#    "ZCLOSEDTHISTRANSACTION",
#    "ZSCHEDULEDTHISTRANSACTION",
#    "ZWIPTHISTRANSACTION",
#    "ZCANCELEDTHISTRANSACTION",
#    "ZTMPREASSIGNMENT",
#    "PRIORITY",
#    "HOTLIST",
#    "SEQUENCE",
#    "ZTMPOTHERTASKSSAMEORDE",
#    "CBOENFORCETSKDEPENDENCY",
#    "WORK_ORDER",
#    "WEBSERVICEORDER",
#    "ZTEMPNOOFTASKS",
#    "ESCALATED",
#    "CHG_APPR_STATUS",
#    "ZTEMPSTATUS",
#    "PREVIOUS_STATUS",
#    "TASKSEQUENCE",
#    "PREVIOUSTASKSEQUENCE",
#    "VISIBLE_TO_CUSTOMER"
]
cast_to_double_columns = []
cast_to_decimal_columns = []
cast_to_string_columns = []
cast_to_integer_from_decimal_columns = []
strip_columns = []
decimal_columns = ["seqno",
"status",
"request_urgency",
"closure_code",
"pending",
"scope",
"ztmpsubmitassociation",
"request_supervisor_to_reassign",
"ztempprevseqnum",
"ztmpconflictsfound",
"first_in_line",
"ztmpbusinesshrsselection",
"planned_duration",
"actual_duration",
"zclosedthistransaction",
"zscheduledthistransaction",
"zwipthistransaction",
"zcanceledthistransaction",
"ztmpreassignment",
"priority",
"hotlist",
"sequence",
"zdependencynotification",
"ztmpothertaskssameorde",
"cboenforcetskdependency",
"work_order",
"webserviceorder",
"ztempnooftasks",
"escalated",
"chg_appr_status",
"ztempstatus",
"previous_status",
"ztempplannedend",
"ztemptotaltime",
"ztempdifftime",
"tasksequence",
"previoustasksequence",
"visible_to_customer"
]
