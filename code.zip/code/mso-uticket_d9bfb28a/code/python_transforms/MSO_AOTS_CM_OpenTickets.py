# from pyspark.sql import functions as F
from transforms.api import transform, Input, Output


@transform(
  output=Output("ri.foundry.main.dataset.0000097e-561e-451b-b7da-3466116b304a"),
  my_input=Input("ri.foundry.main.dataset.b22912bc-1f34-4a4f-85cb-1a7e87a0fbe2")
)
def my_compute_function(output, my_input):
    output.write_dataframe(my_input.dataframe().coalesce(1), output_format="csv", options={"sep":"|_|;|_|", "lineSep":"\u0177", "header": "true"})
