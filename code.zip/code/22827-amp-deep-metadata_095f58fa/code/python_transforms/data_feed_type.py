from pyspark.sql import functions as F
from transforms.api import transform_df, Input, Output


@transform_df(
    Output("/Innovation Lab/Data Governance/Code & Data/code/datasets/data_feed_type"),
    all_platform_data=Input(
        "/Innovation Lab/Data Governance/Project Lineage Tables/all_platform_data_with_lineage"
    ),
    magritte_agents=Input(
        "/Innovation Lab/Data Governance/Project Lineage Tables/magritte_agents"
    ),
)
def my_compute_function(all_platform_data, magritte_agents):
    engineered_sources = (
        magritte_agents.filter(
            (
                F.col("agentRid")
                == "ri.magritte..agent.af40eb90fa4490cd52357c344760df4d2eba5e3c2e92e34f8e31e5250806bd5a"
            )
            | (
                F.col("agentRid")
                == "ri.magritte..agent.aab172a8f1b813ce34fec33ba1cf2d5b3970502d5f25f38727cfbc1fc5ab69f2"
            )
            | (
                F.col("agentRid")
                == "ri.magritte..agent.7571698ac2a3be776ebf1019168eec95f2e9f9982ba3a0119b9eb6f0566ed847"
            )
        )
        .select(
            F.col("sourceRid").alias("magritte_source_rid"),
            F.lit("engineered").alias("engineered_vs_snapshot"),
        )
        .dropDuplicates()
    )

    df = all_platform_data.filter(F.col("magritte_source_rid").isNotNull())

    df = df.join(
        engineered_sources.select("magritte_source_rid", "engineered_vs_snapshot"),
        df["magritte_source_rid"] == engineered_sources["magritte_source_rid"],
        how="left",
    )

    df = df.groupBy("project_rid").agg(
        F.count(F.col("engineered_vs_snapshot")).alias("engineered")
    )

    df = df.withColumn(
        "data_feed_type",
        F.when(F.col("engineered") > 0, "Engineered").otherwise("Snapshot"),
    )

    return df
