CREATE TABLE `/Innovation Lab/[ETL] Ticketing/logic/aotstm/aotstm_lk_wfa_from_reference_ticket` AS
    SELECT ticket
    , regexp_extract(reference_ticket_num, '([W][A-Z][A-Z][A-Z][A-Z][0-9][0-9][0-9][0-9][0-9][0-9])', 1) as wfa_ticket 
    FROM `/Innovation Lab/[ETL] Ticketing/data/clean/AOTSTM_TICKET_CLEAN`
    WHERE upper(reference_ticket_num) REGEXP '[W][A-Z][A-Z][A-Z][A-Z][0-9][0-9][0-9][0-9][0-9][0-9]'