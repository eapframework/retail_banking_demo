from transforms.api import transform, Input, Output, incremental, Check
from utility.incremental.update_insert import update_insert_core
# from myproject.datasets.utils import update_insert
from utility.column_clean import clean_columns, lowercase_columns, remove_prefix, long_to_datetime,clean_long
from pyspark.sql import functions as F
from myproject.datasets.column_clean import strip_all_string_col
from transforms import expectations as E
from pyspark.sql.functions import col
from myproject.datasets.utils import check_integrity
from pyspark.sql.types import TimestampType
from utility.incremental.timestamp_parsing import perform_timestamp_parsing

expect_integrity = E.all(
    E.col('diff').equals(0),
    E.col('diff').non_null()
)


@incremental(semantic_version=14)
@transform(
    output=Output("ri.foundry.main.dataset.4e8ff367-a3fa-4826-b057-c48ffe78812c"),
    output_integrity=Output("ri.foundry.main.dataset.ea361d8d-b201-4920-9d7c-aba8f712fb42",
    checks=Check(expect_integrity, 'AFO Data Integrity Check', on_error='WARN')),
    updates=Input("ri.foundry.main.dataset.e8fc2882-607e-4ae9-85ff-d5e2a64ce169"),
    check_input=Input("ri.foundry.main.dataset.ebb4d910-dbd0-4e9d-bf47-dbd158a36344"),
)
def wifa_details(ctx, output, output_integrity, updates, check_input):
    updates = clean_columns(
        updates.dataframe(),
        timestamp_columns=cast_to_timestamp_from_long_columns
    )

    updates = lowercase_columns(updates)
    updates = strip_all_string_col(updates)
    #updates = perform_timestamp_parsing(updates)

    check_input = clean_columns(
        check_input.dataframe(),
        timestamp_columns=cast_to_timestamp_from_long_columns_integrity
    )
    check_input = lowercase_columns(check_input)
    #check_input = perform_timestamp_parsing(check_input)
    check_input = check_input.withColumn("checkcount", clean_long(F.col("checkcount")))
    
    changeddf = update_insert_core(ctx, output, updates, primary_keys=["tr", "site", "closed_dt"], order_cols=["tbl_load_ts", "tbl_last_updt_ts"], return_df =True)
    check_integrity(input_df=changeddf, checksum_df=check_input, date_key='tbl_load_ts', out=output, output_integrity=output_integrity)

cast_to_timestamp_from_long_columns = ["TBL_LOAD_TS", "TBL_LAST_UPDT_TS"]
cast_to_timestamp_from_long_columns_integrity=["TBL_LOAD_TS"]
