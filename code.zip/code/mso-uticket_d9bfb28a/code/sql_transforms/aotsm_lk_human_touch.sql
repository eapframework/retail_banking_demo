CREATE TABLE `ri.foundry.main.dataset.71088915-9b90-4a72-888f-58ba258736c2` AS
SELECT METRICS.*
, PATHWAY.human_pathway
 FROM (
SELECT HUMAN_TOUCH.ticket_number
, concat_ws(',', collect_set(HUMAN_TOUCH.modifying_user)) as distinct_humans
, first(HUMAN_TOUCH.modifying_user) as first_human_attuid
, last(HUMAN_TOUCH.modifying_user) as last_human_attuid
, concat_ws(',', collect_set(USER_LOOKUP.supervisor_name)) as distinct_supervisor_name
, first(USER_LOOKUP.supervisor_name) first_supervisor_name
, last(USER_LOOKUP.supervisor_name) last_supervisor_name
, concat_ws(',', collect_set(USER_LOOKUP.director_name)) as distinct_director_name
, first(USER_LOOKUP.director_name) first_director_name
, last(USER_LOOKUP.director_name) last_director_name
, concat_ws(',', collect_set(USER_LOOKUP.avp_name)) as distinct_avp_name
, first(USER_LOOKUP.avp_name) first_avp_name
, last(USER_LOOKUP.avp_name) last_avp_name
, concat_ws(',', collect_set(USER_LOOKUP.vp_name)) as distinct_vp_name
, first(USER_LOOKUP.vp_name) first_vp_name
, last(USER_LOOKUP.vp_name) last_vp_name
, concat_ws(',', collect_set(USER_LOOKUP.svp_name)) as distinct_svp_name
, first(USER_LOOKUP.svp_name) first_svp_name
, last(USER_LOOKUP.svp_name) last_svp_name
, first(cogs_1_name) first_cogs_1_name
, first(cogs_2_name) first_cogs_2_name
, first(cogs_3_name) first_cogs_3_name
, first(cogs_4_name) first_cogs_4_name
, first(cogs_5_name) first_cogs_5_name
, first(cogs_6_name) first_cogs_6_name
, first(cogs_7_name) first_cogs_7_name
, last(cogs_1_name) last_cogs_1_name
, last(cogs_2_name) last_cogs_2_name
, last(cogs_3_name) last_cogs_3_name
, last(cogs_4_name) last_cogs_4_name
, last(cogs_5_name) last_cogs_5_name
, last(cogs_6_name) last_cogs_6_name
, last(cogs_7_name) last_cogs_7_name
, concat_ws(',', collect_set(USER_LOOKUP.vp_org_name)) as distinct_vp_org_name
, MIN(HUMAN_TOUCH.Modified_Time_1M) first_human_touch
, MAX(HUMAN_TOUCH.Modified_Time_1M) last_human_touch
, COUNT(HUMAN_TOUCH.ticket_number) total_human_touches
FROM `ri.foundry.main.dataset.1925a513-933d-4e17-9bbe-becb2fbb60b3` HUMAN_TOUCH
LEFT JOIN `ri.foundry.main.dataset.eaf6b4bf-b394-415a-b879-626b920ba4f7` USER_LOOKUP
ON HUMAN_TOUCH.modifying_user=USER_LOOKUP.modifying_user
WHERE is_human=1
GROUP BY HUMAN_TOUCH.ticket_number
) METRICS
LEFT JOIN
(SELECT ticket_number, human_pathway
FROM `ri.foundry.main.dataset.85bec1b0-457b-47c4-af42-8f0fdd680e2e`) PATHWAY
ON METRICS.ticket_number=PATHWAY.ticket_number


