CREATE TABLE `ri.foundry.main.dataset.8cc5ddf9-30f5-4d15-b18f-18c116cbc5d5` TBLPROPERTIES (foundry_transform_profile = 'EXECUTOR_MEMORY_MEDIUM') AS
    SELECT master.extkey1
    , count(distinct master.wrid) as force_wo_cnt
    , collect_set(master.wrid) as force_wo_array
    , min(master.entrydatetime) force_start_dt
    , max(master.compcandatetime) force_finish_dt
    , min(case when manual_user is not null then eventdatetime else null end) force_first_human_touch_dt
    , count(distinct date_trunc('minute',eventdatetime)) force_total_touches
    , count(distinct case when manual_user is not null then date_trunc('minute',eventdatetime) else null end) force_human_touches
    , count(distinct case when worktypequalifier = 'IN' and wrstat='COMPLETE' then entrydatetime else null end) force_dispatch_in_cnt
    , count(distinct case when worktypequalifier = 'OUT' and wrstat='COMPLETE' then entrydatetime else null end) force_dispatch_out_cnt
    , count(distinct case when worktypequalifier = 'IN' and manned=0 and wrstat='COMPLETE' and dispatch_dt is not null then dispatch_dt else null end)  force_truck_roll_in
    , count(distinct case when worktypequalifier = 'OUT' and wrstat='COMPLETE' and dispatch_dt is not null then dispatch_dt else null end) force_truck_roll_out
    , concat_ws(';', collect_set(manual_user)) force_human_user_unique_list
    , count(distinct manual_user) force_human_user_unique_cnt 
    , concat_ws(';', collect_list(narrative)) force_narrative_list
    , min(dispatch_dt) force_dispatch_first_dt
    , max(dispatch_dt) force_dispatch_last_dt
    , (unix_timestamp(min(case when manual_user is not null then eventdatetime else null end))-unix_timestamp(min(master.entrydatetime)))/3600 force_start_to_first_human_hours
    , (unix_timestamp(min(dispatch_dt))-unix_timestamp(min(master.entrydatetime)))/3600 force_start_to_first_dispatch_hours
    , (unix_timestamp(max(master.compcandatetime))-unix_timestamp(min(dispatch_dt)))/3600 force_first_dipsatch_to_complete_hours
    , (unix_timestamp(max(master.compcandatetime))-unix_timestamp(min(master.entrydatetime)))/3600 as force_start_to_finish_hours
     FROM `ri.foundry.main.dataset.9114de96-abfc-4542-8d5d-6372ddacee40` master
    LEFT JOIN `ri.foundry.main.dataset.b9a726fc-9fa6-4f6c-866a-0207ef0c6cac` events
    on master.wrid=events.wrid and master.region=events.region and events.eventdatetime >= master.entrydatetime
    LEFT JOIN `ri.foundry.main.dataset.53b7bc15-3192-48b0-ab0d-d0edf64c594a` manned_unmanned
    ON master.circuitworklocclli=manned_unmanned.clli
    group by extkey1