CREATE TABLE `ri.foundry.main.dataset.d49d27ed-7b7e-4d9c-bc56-aa56796ec7f5` AS
SELECT HUMAN_TOUCH.ticket_number
, MIN(HUMAN_TOUCH.Modified_Time_1M) first_auto_touch
, MAX(HUMAN_TOUCH.Modified_Time_1M) last_auto_touch
, COUNT(HUMAN_TOUCH.ticket_number) total_auto_touches
FROM `ri.foundry.main.dataset.1925a513-933d-4e17-9bbe-becb2fbb60b3` HUMAN_TOUCH
WHERE is_human=0
GROUP BY HUMAN_TOUCH.ticket_number

