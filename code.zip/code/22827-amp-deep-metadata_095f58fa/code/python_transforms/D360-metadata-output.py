from transforms.api import transform, Input, Output
from pyspark.sql import functions as F


@transform(
    d360_csv=Output("ri.foundry.main.dataset.03c200b5-9fe2-492e-a947-1edab861d7e6"),
    d360_cleaned=Input("ri.foundry.main.dataset.f7120d06-4ac5-456b-848e-25b052856eee", branch="master"),
)
def my_compute_function(d360_cleaned, d360_csv):
    d360_cleaned = d360_cleaned.dataframe()
    d360_cleaned = d360_cleaned\
        .withColumn('project_key_contacts_name', F.col('project_key_contacts_name').cast("string"))\
        .withColumn('project_key_contacts_attuid', F.col('project_key_contacts_attuid').cast("string"))\
        .withColumn('upstart_viewer_roles', F.col('upstart_viewer_roles').cast("string"))\
        .withColumn('upstart_editor_roles', F.col('upstart_editor_roles').cast("string"))\
        .withColumn('upstart_data_roles', F.col('upstart_data_roles').cast("string"))\
        .withColumn('upstream_lineage', F.col('upstream_lineage').cast("string"))

    d360_cleaned = d360_cleaned\
        .select("dataset_name", "link_to_dataset", "project_name", "project_rid", "project_description",
                "project_key_contacts_name", "project_key_contacts_attuid", "dataset_path", "dataset_rid",
                "last_updated_date", "created_date", "ingestion_source_name", "ingestion_source_type",
                "source_application_mots_id", "dataset_description", "schema", "upstart_viewer_roles",
                "upstart_editor_roles", "data_feed_type", "upstart_data_roles", "is_in_data_catalog",
                "collection", "collection_description", "trashed", "upstream_lineage", "upstream_lineage_url")

    d360_csv.write_dataframe(
        d360_cleaned.coalesce(1),
        output_format="csv",
        options={"header": "true", "escape": "\""})
