CREATE TABLE `ri.foundry.main.dataset.479d4e44-684a-4f24-a75e-c81b0edadcfc` AS WITH

webphone_vp as (
    SELECT
        leadership_attuid,
        vp_attuid,
        vp_org_name,
        vp_org,
        handle
    FROM `ri.foundry.main.dataset.b198cfa1-d6d2-410a-a19f-8107c6ed15de`
)

SELECT
    -- Request Submission Metadata
    submitted_by_mp_id,
    requestor_email,
    requestor_username,
    submitted_at_timestamp,
    last_modified_timestamp,

    -- Request Watcher Properties
    CAST(null as Array<String>) as request_watchers_email,
    CAST(null as Array<String>) as request_watchers_name,
    SPLIT(
        REGEXP_REPLACE(
            REGEXP_REPLACE(request_watchers_initial_form_email, '^\\[', ''), '\\]$', ''
        ),
        '\\], \\['
    ) AS
    request_watchers_initial_form_email,

    -- Request Metadata
    CONCAT(initiative_name,' (',SPLIT(submitted_at_timestamp,'T')[0],')') as initiative_name,
    project_pid,
    request_type,
    is_request_associated_with_existing_use_case_project,
    associated_use_case_project_id AS associated_use_case_project_id_array,
    associated_use_case_project_rid as associated_use_case_project_rid_array,
    CAST('New Request' as String) as ingestion_status,
    CAST(null as String) as priority,
    CAST(null as String) as user_currently_processing_request_name,
    CAST(null as String) as user_currently_processing_request_email,
    CAST('DEEP' as String) as program,
    data_exists_on_platform,

    -- Compliance Metadata
    how_will_data_be_used,
    information_classification,
    cloud_governance_approval_id,
    contains_customer_pii_spi,
    contains_employee_pii_spi,
    CAST('Not Reviewed' as String) as is_privacy_approved,
    CASE
        WHEN (is_cloud_gov_approved IS NULL) THEN 'Not Reviewed'
        WHEN (is_cloud_gov_approved == 'Y') THEN "Approved"
        ELSE is_cloud_gov_approved
    END AS is_cloud_gov_approved,
    CAST(null as String) as privacy_approval_attachment,
    CAST(null as String) as is_compliance_approved,
    CAST(null as String) as compliance_approval_attachment,
    CAST(null as String) as cloud_gov_approval_attachment,
    CAST(cloud_governance_approval_id as String) as cloud_gov_approval_number,
    CAST(null as String) as cloud_governance_request_number,

    -- Deprecated
    CAST(MOTs_ID_of_source_data as STRING) as mots_id_of_source,
    CAST(null as String) as associated_use_case_project_id,
    CAST(null as String) as associated_use_case_project_rid,
    use_case,
    use_case_value,
    access_method,
    dba_contact_info,
    services_subscribed_to_target_cloud_service_provider,
    is_pci_or_sox_application,
    is_application_being_delivered_by_managed_service_delivery_vendor,
    cloud_governance_approver_email,
    cloud_governance_approval_date,
    CAST(null as String) as privacy_approval_id,
    privacy_approver_email,
    privacy_approval_date,
    CAST(null as String) as compliance_approval_id,
    compliance_approver_email,
    compliance_approval_date,
    CONCAT('[Click Here to Download Privacy Review Request](https://paloma.palantirfoundry.com/blobster/api/salt/',privacy_review_request_attachment,')') as privacy_review_request_attachment,
    cloud_data_storage_type,
    'Palantir Foundry' as cloud_service_provider,
    'SaaS' as cloud_service_model,
    'Prod' as cloud_environment_type,
    CAST(null as String) as linked_data_source,
    CAST(null as String) as linked_data_sources_array,
    snapshot_start_timezone,
    snapshot_end_timezone,
    CAST(snapshot_end_date_timestamp AS Date) as snapshot_end_date_timestamp,
    line_of_business,
    status,
    streaming_frequency,

    -- Schema Fusion Spreadsheet
    CASE
        WHEN split(link_to_dataset_schema_fusion_sheet,'/')[2] = 'paloma.palantirfoundry.com' THEN split(link_to_dataset_schema_fusion_sheet,'/')[6]
        ELSE link_to_dataset_schema_fusion_sheet
    END AS link_to_dataset_schema_fusion_sheet,

    -- Scheduling Information
    -- Time of Day the ingestion job should be run
    daily_refresh_time,
    -- If refresh frequency is monthly then the day of the month the refresh should be run
    monthly_refresh,
    -- If refresh frequency is weekly then the day of the month the refresh should be run
    refresh_dayofweek,
    -- Historical Load Start Date
    CAST(snapshot_start_date_timestamp AS Date) as snapshot_start_date_timestamp,
    -- Multiple times per day, Daily, Weekly, Monthly
    refresh_frequency,

    -- Ingestion Workflow Properties
    ingestion_in_progress_timestamp,
    CAST('Not Reviewed' as String) as mech_id_status,
    CAST('Not Reviewed' as String) as schema_review_status,
    CAST('Not Reviewed' as String) as ingestion_team_status,
    CAST(null as String) as ingestion_mech_id,

    -- Source & Connection Information
    additional_connection_information,
    CAST(null as Array<String>) as linked_data_sources_array_v2,
    CAST(null as Array<String>) as request_connection_types,
    CAST(null as String) as other_request_connection_type,
    CAST(null as Array<String>) as source_system_contacts,
    CAST(null as Array<String>) as source_system_contacts_names,
    ingestion_sources_known,
    ingestion_sources_id,
    ingestion_sources_name,
    connection_type,
    other_connection_type,
    multiple_datasets_requested,
    ingestion_details_spreadsheet,
    multiple_different_source_systems,

    -- Job Size Estimates
    CAST(null as String) as request_level_of_effort,
    CAST(null as String) as request_size_estimate,
    historical_load_job_size_estimate,
    refresh_job_size_estimate,
    CAST(null as String) as access_complexity_estimate,

    -- Ingestion Job Type Metadata
    incremental_load_delta_column,
    incremental_date_column,
    
    -- Access Management Details
    source_system_access_management,
    other_source_system_access_management,
    upstart_roles,
    sql_server_domain,
    idm_connection_details,

    -- RIM Policy
    dataset_rim_policy,
    rim_response_code,

    -- Leadership Org Details from Webphone
    leadership_attuid,
    vp_attuid,
    vp_org_name,
    vp_org,

    -- Cloud-related Responses
    Is_this_data_already_in_the_cloud as data_already_in_cloud,
    Type_of_Source as type_of_source,
    Upstart_Role_associated_with_the_Warehouse as upstart_role_associated_with_the_warehouse,
    I_attest_this_is_approved_data_to_bring_into_the_DEEP_platform as data_attestation,
    Please_attach_the_related_privacy_approval_allowing_this_data_to_be_in_the_cloud as related_privacy_approval,
    ADLS_Storage_Account as adls_storage_account,
    ADLS_Container as adls_container,
    ADLS_Resource_ID as adls_resource_id,
    Expected_Environment_Readiness_Date as expected_environment_readiness_date,
    ADLS_MOTS_ID as adls_mots_id,
    Application_Name as application_name,
    Environment as environment,
    Source_Target_Resource_ID as source_target_resource_id,
    ADLS_Sub_Type as adls_sub_type,
    Application_Owner as application_owner,
    Application_Technical_Contact as application_technical_contact,
    Ops_Team_DL_Contact as ops_team_dl_contact,
    Other_Details as other_details,
    snowflake_warehouse,
    snowflake_upstart,
    status as cloud_status,

    -- TO BE DREPRECATED?
    CAST(null as Array<String>) as sensitive_tag,
    CAST(null as String) as encryption_required
FROM `ri.foundry.main.dataset.e0edec70-13d6-4aca-9840-490e60c2c7e0`

LEFT JOIN webphone_vp
ON split(split(requestor_username, '\\(')[1], '@')[0] == webphone_vp.handle

WHERE associated_use_case_project_rid is not null