from __future__ import annotations

from enum import Enum
from typing import Optional

from pydantic import BaseModel, Field

from app.schemas.resource import ActorType


class RelationshipType(str, Enum):
    FEEDS = "FEEDS"


class RelationshipCreate(BaseModel):
    upstream_resource_id: str = Field(min_length=1)
    downstream_resource_id: str = Field(min_length=1)
    relationship_type: RelationshipType = RelationshipType.FEEDS
    notes: Optional[str] = None
    actor_type: ActorType
    actor_name: str = Field(min_length=1)


class RelationshipRead(BaseModel):
    upstream_resource_id: str
    downstream_resource_id: str
    relationship_type: RelationshipType
    notes: Optional[str] = None


class RelationshipDelete(BaseModel):
    upstream_resource_id: str = Field(min_length=1)
    downstream_resource_id: str = Field(min_length=1)
    relationship_type: Optional[RelationshipType] = None
    actor_type: ActorType = ActorType.AGENT
    actor_name: str = Field(default="system", min_length=1)
