from transforms.api import transform_df, Input, Output
from myproject.utils.global_code import PARENT_FOLDER
from pyspark.sql import functions as F


@transform_df(
    Output(f"{PARENT_FOLDER}/use_cases"),
    all_projects=Input(f"{PARENT_FOLDER}/all_projects"),
    all_platform_data=Input(
        "/Innovation Lab/Data Governance/Project Lineage Tables/all_platform_data_with_lineage"
    ),
    queried_datasets=Input(
        "/Innovation Lab/Palantir Admins/Quantum/extensions/data/clean/sql_server_queried_datasets"
    ),
)
def my_compute_function(all_projects, all_platform_data, queried_datasets):
    # 1. Filter down to use_cases type projects only, explode on reference_datasets to create a row for all (project, referenced_dataset) pairs
    use_cases = all_projects.filter(
        (F.col("project_type") == "ETL") | (F.col("project_type") == "Use Case")
    ).select(
        F.col("project_name").alias("uc_project_name"),
        F.col("project_rid").alias("uc_project_rid"),
        F.col("reference_datasets").alias("uc_reference_datasets"),
        F.explode(F.col("reference_datasets")).alias("ref_dataset_path"),
    )

    # 2. Join with all_platform_data_with_lineage to get information about children and the referenced dataset rids
    ref_all_platform_data = all_platform_data.select(
        F.col("dataset_rid").alias("ref_dataset_rid"),
        F.col("dataset_path").alias("ref_dataset_path"),
        F.col("dataset_name").alias("ref_dataset_name"),
        F.col("has_children").alias("ref_has_children"),
        F.col("children").alias("ref_children"),
    )
    use_cases = use_cases.join(ref_all_platform_data, "ref_dataset_path", "left")

    # 2.a) Group the rids of all referenced datasets
    all_referenced_datasets = use_cases.groupBy("uc_project_name").agg(
        F.collect_set("ref_dataset_rid").alias("all_ref_datasets")
    )

    # 2.b) Explode on the children of the references
    use_cases = use_cases.select(
        F.col("uc_project_name"),
        F.col("uc_project_rid"),
        F.col("ref_dataset_rid"),
        F.col("ref_dataset_name"),
        F.col("ref_dataset_path"),
        F.col("ref_has_children"),
        F.explode(F.col("ref_children")).alias("child_dataset_rid"),
    )

    # 3. Determine used referenced datasets, and clean + used referenced datasets
    child_all_platform_data = all_platform_data.select(
        F.col("dataset_rid").alias("child_dataset_rid"),
        F.col("dataset_path").alias("child_dataset_path"),
        F.col("project_name").alias("child_project_name"),
    )
    use_cases = use_cases.join(
        child_all_platform_data, "child_dataset_rid", "left"
    ).join(
        queried_datasets,
        use_cases.ref_dataset_rid == queried_datasets.dataset_rid,
        "left",
    )
    used_referenced_datasets = (
        use_cases.filter(
            (F.col("uc_project_name") == F.col("child_project_name"))
            | (F.col("mostRecentQueryTime").isNotNull())
        )
        .groupBy("uc_project_name")
        .agg(F.collect_set("ref_dataset_rid").alias("used_ref_datasets"))
    )
    used_raw_referenced_datasets = (
        use_cases.filter(
            (
                (F.col("uc_project_name") == F.col("child_project_name"))
                | (F.col("mostRecentQueryTime").isNotNull())
            )
            & (use_cases.ref_dataset_path.contains("raw/"))
        )
        .groupBy("uc_project_name")
        .agg(F.collect_set("ref_dataset_rid").alias("used_raw_ref_datasets"))
    )
    used_clean_referenced_datasets = (
        use_cases.filter(
            (
                (F.col("uc_project_name") == F.col("child_project_name"))
                | (F.col("mostRecentQueryTime").isNotNull())
            )
            & (use_cases.ref_dataset_path.contains("clean/"))
        )
        .groupBy("uc_project_name")
        .agg(F.collect_set("ref_dataset_rid").alias("used_cleaned_ref_datasets"))
    )

    # 4. Determine unused referenced datasets, and join our four new columns with use case information
    use_cases_info = (
        all_projects.filter(
            (F.col("project_type") == "ETL") | (F.col("project_type") == "Use Case")
        )
        .select(
            F.col("project_name").alias("uc_project_name"),
            F.col("project_rid").alias("uc_project_rid"),
        )
        .join(all_referenced_datasets, "uc_project_name", "left")
        .withColumn(
            "all_ref_datasets",
            F.when(F.col("all_ref_datasets").isNull(), F.array([])).otherwise(
                F.col("all_ref_datasets")
            ),
        )
        .join(used_referenced_datasets, "uc_project_name", "left")
        .withColumn(
            "used_ref_datasets",
            F.when(F.col("used_ref_datasets").isNull(), F.array([])).otherwise(
                F.col("used_ref_datasets")
            ),
        )
        .withColumn(
            "unused_ref_datasets",
            F.array_except("all_ref_datasets", "used_ref_datasets"),
        )
        .join(used_raw_referenced_datasets, "uc_project_name", "left")
        .withColumn(
            "used_raw_ref_datasets",
            F.when(F.col("used_raw_ref_datasets").isNull(), F.array([])).otherwise(
                F.col("used_raw_ref_datasets")
            ),
        )
        .join(used_clean_referenced_datasets, "uc_project_name", "left")
        .withColumn(
            "used_cleaned_ref_datasets",
            F.when(F.col("used_cleaned_ref_datasets").isNull(), F.array([])).otherwise(
                F.col("used_cleaned_ref_datasets")
            ),
        )
    )

    # 4.a) Determine clean + unused referenced datasets, join with use_cases_info
    unused_clean_referenced_datasets = use_cases_info.select(
        F.col("uc_project_name"),
        F.explode(F.col("unused_ref_datasets")).alias("ref_dataset_rid"),
    ).join(ref_all_platform_data, "ref_dataset_rid", "left")
    unused_clean_referenced_datasets = (
        unused_clean_referenced_datasets.filter(
            unused_clean_referenced_datasets.ref_dataset_path.contains("clean/")
        )
        .groupBy("uc_project_name")
        .agg(F.collect_set("ref_dataset_rid").alias("unused_cleaned_ref_datasets"))
    )
    use_cases_info = use_cases_info.join(
        unused_clean_referenced_datasets, "uc_project_name", "left"
    ).withColumn(
        "unused_cleaned_ref_datasets",
        F.when(F.col("unused_cleaned_ref_datasets").isNull(), F.array([])).otherwise(
            F.col("unused_cleaned_ref_datasets")
        ),
    )

    return use_cases_info
