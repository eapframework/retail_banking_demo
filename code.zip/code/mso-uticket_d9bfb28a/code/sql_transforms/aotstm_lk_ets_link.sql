CREATE TABLE `ri.foundry.main.dataset.c399377e-0aee-47af-9bd7-710febb4e552` AS
    SELECT ticket,
    last(ets_link) ets_link
    FROM (
    SELECT ticket_nb as ticket, regexp_extract(ticket_message, 'For details go to *([^\\s]+)', 1) as ets_link 
     FROM `ri.foundry.main.dataset.bc1e7b50-f481-4a5a-9450-e1a6a6706def`
    WHERE ticket_message REGEXP 'For details go to *([^\s]+)'
    ) A
    GROUP BY ticket