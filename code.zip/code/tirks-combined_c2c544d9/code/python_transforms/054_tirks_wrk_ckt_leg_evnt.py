from transforms.api import transform_df, Input, Output, incremental
import pyspark.sql.functions as F


@transform_df(
    Output("ri.foundry.main.dataset.983538d6-9a08-4926-bb66-1ae6acfda263"),
    asi=Input("ri.foundry.main.dataset.d8c5a98c-8174-4100-b944-0a2c0a6e8f65"),
    telco=Input("ri.foundry.main.dataset.02b27aea-22a8-4b76-9632-4ff3816b66cc"),
)
def my_compute_function(telco, asi):
    telco = telco.withColumn("source", F.lit('telco'))
    asi = asi.withColumn("source", F.lit('asi'))
    df = telco.unionByName(asi)
    return df