import json
import requests
import pandas as pd
import numpy as np
from collections import Counter
from datetime import datetime
from transforms.api import Input, Output, transform, incremental
from pyspark.sql import functions as F, types as T
from myproject.datasets.utils import get_header, getAllObjectTypes, agg_usage, get_usage, \
    getCurrentOntologyVersion, getEntityDatasources, get_date_range


TYPE_CLASSES_TO_RECORD = [
    "oe_home_page_object_type_group"
]


ONTOLOGY_OBJECT_PANDAS_SCHEMA = T.StructType([
    T.StructField('objectType.displayMetadata.description', T.StringType()),
    T.StructField('objectType.displayMetadata.displayName', T.StringType()),
    T.StructField('objectType.displayMetadata.groupDisplayName', T.StringType()),
    T.StructField('objectType.displayMetadata.icon.type', T.StringType()),
    T.StructField('objectType.displayMetadata.icon.blueprint.color', T.StringType()),
    T.StructField('objectType.displayMetadata.icon.blueprint.locator', T.StringType()),
    T.StructField('objectType.displayMetadata.pluralDisplayName', T.StringType()),
    T.StructField('objectType.displayMetadata.visibility', T.StringType()),
    T.StructField('objectType.id', T.StringType()),
    T.StructField('objectType.primaryKeys', T.ArrayType(T.StringType())),
    T.StructField('objectType.rid', T.StringType()),
    T.StructField('objectType.titlePropertyTypeRid', T.StringType()),
    T.StructField('objectType.apiName', T.StringType()),
    T.StructField('objectType.status.type', T.StringType()),
    T.StructField('objectType.redacted', T.StringType()),
    T.StructField('objectType.implementsInterfaces', T.ArrayType(T.StringType())),
    T.StructField('objectType.typeClasses.oe_home_page_object_type_group.names', T.ArrayType(T.StringType())),
    T.StructField('objectType.typeClasses.oe_home_page_object_type_group.propertyIds', T.ArrayType(T.StringType())),
    T.StructField('objectType.status.deprecated.message', T.StringType()),
    T.StructField('objectType.status.deprecated.deadline', T.StringType()),
    T.StructField('objectType.status.deprecated.replacedBy', T.StringType()),
    T.StructField('objectType.properties', T.StringType()),
    T.StructField('READ', T.LongType()),
    T.StructField('WRITE', T.LongType()),
    T.StructField('METADATA', T.LongType()),
    T.StructField('REGISTRATION', T.LongType()),
    T.StructField('UserAgents', T.ArrayType(T.StringType())),
    T.StructField('backing_dataset_rid', T.StringType()),
    T.StructField('backing_dataset_branch', T.StringType()),
    T.StructField('is_mdo', T.StringType()),
    T.StructField('is_timeseries_enabled', T.StringType())
])

ONTOLOGY_OBJECT_USAGE_PANDAS_SCHEMA = T.StructType([
    T.StructField('uniqueUsersCount', T.FloatType()),
    T.StructField('timestamp', T.TimestampType()),
    T.StructField('usageByType.READ', T.FloatType()),
    T.StructField('usageByType.REGISTRATION', T.FloatType()),
    T.StructField('usageByType.METADATA', T.FloatType()),
    T.StructField('usageByType.WRITE', T.FloatType()),
    T.StructField('objectType.rid', T.StringType())
])


@incremental(snapshot_inputs=["config"], semantic_version=5)
@transform(
    ontology_objects_usage=Output("ri.foundry.main.dataset.625c91a3-0ec1-4b3c-b6f8-8579acb663c2"),
    ontology_objects=Output("ri.foundry.main.dataset.647d10f8-ba88-4875-ae2c-48d88f8a7701"),
    last_run=Output("ri.foundry.main.dataset.78a60efa-a7c4-4830-93d7-6bc21b800a7d"),
    config=Input("ri.foundry.main.dataset.b5cb343e-1109-4401-b3fb-5137c32cb781")
)
def compute(ctx, config, ontology_objects, ontology_objects_usage, last_run):
    # check if there is new data
    start, end = get_date_range(ctx, last_run, [ontology_objects, ontology_objects_usage, last_run])
    if start is None or end is None:
        return

    session = requests.Session()
    session.headers.update(get_header(config.dataframe()))
    allObjectTypes = getAllObjectTypes(session)
    curOntologyVersion = getCurrentOntologyVersion(session)
    objectTypes = []
    for obj in allObjectTypes:
        # Add desired type classes to output.
        type_class_to_property_ids = {
            type_class: {"names": [], "propertyIds": []}
            for type_class in TYPE_CLASSES_TO_RECORD
        }
        for property_type in obj["objectType"]["propertyTypes"].values():
            for type_class in property_type["typeClasses"]:
                kind = type_class["kind"]
                if kind in TYPE_CLASSES_TO_RECORD:
                    type_class_to_property_ids[kind]["names"].append(type_class["name"])
                    type_class_to_property_ids[kind]["propertyIds"].append(property_type["id"])

        # Add type classes back into object metadata.
        obj["objectType"]["typeClasses"] = type_class_to_property_ids
        props_all = obj["objectType"]["propertyTypes"]
        condensed_props = []
        for rid, prop in props_all.items():
            condensed_props.append({
                "rid": rid,
                "api_name": prop["apiName"],
                "id": prop["id"],
                "type": prop["type"]["type"],
                "name": prop["displayMetadata"]["displayName"],
                "visibility": prop["displayMetadata"]["visibility"],
                "description": prop["displayMetadata"]["description"],
                "typeclasses": prop['typeClasses']
            })
        obj["objectType"]["properties"] = json.dumps(condensed_props)
        del obj["objectType"]["propertyTypes"]
        del obj["objectType"]["traits"]
        objectTypes.append(obj)

    pandas_df = pd.json_normalize(objectTypes).fillna('')
    usage_df = pandas_df[["objectType.rid"]].copy()

    new_colms = ["READ", "WRITE", "METADATA", "REGISTRATION"]
    for colm in new_colms:
        pandas_df[colm] = 0
    pandas_df["UserAgents"] = np.empty((len(pandas_df), 0)).tolist()

    deprecated_colms = ["objectType.status.deprecated.message", "objectType.status.deprecated.deadline", "objectType.status.deprecated.replacedBy"]
    for colm in deprecated_colms:
        pandas_df[colm] = ""

    pandas_df['backing_dataset_rid'] = ''
    pandas_df['backing_dataset_branch'] = ''
    pandas_df['is_mdo'] = ''
    pandas_df['is_timeseries_enabled'] = ''
    usage_dataframes = []
    latest = None
    for i in range(len(pandas_df)):
        all_usage = get_usage(session, pandas_df["objectType.rid"].iloc[i], start, end)
        if latest is None:
            latest = datetime.strptime(all_usage["latestUsageEventIndexed"], '%Y-%m-%dT%H:%M:%SZ')
        else:
            latest = max(latest, datetime.strptime(all_usage["latestUsageEventIndexed"], '%Y-%m-%dT%H:%M:%SZ'))
        usage = agg_usage(all_usage)
        for colm in new_colms:
            pandas_df[colm].iloc[i] = usage[colm]
        pandas_df['UserAgents'].iloc[i] = usage['UserAgents']
        object_datasource = getEntityDatasources(session, curOntologyVersion,
                                                 object_rids=[pandas_df["objectType.rid"].iloc[i]])
        if (len(object_datasource['objectTypes'][pandas_df["objectType.rid"].iloc[i]])):
            types = Counter([item['datasource']['type'] for item in object_datasource['objectTypes'][pandas_df["objectType.rid"].iloc[i]]])
            pandas_df['is_timeseries_enabled'].iloc[i] = 'timeSeries' in types
            pandas_df['is_mdo'].iloc[i] = (types.get('dataset', 0) + types.get('restrictedView', 0) + types.get('stream', 0)) > 1
            temp = object_datasource['objectTypes'][pandas_df["objectType.rid"].iloc[i]][0]["datasource"]

            if "dataset" in temp:
                pandas_df['backing_dataset_rid'].iloc[i] = temp["dataset"]["datasetRid"]
                pandas_df['backing_dataset_branch'].iloc[i] = temp['dataset']['branchId']
            if "datasetV2" in temp:
                pandas_df['backing_dataset_rid'].iloc[i] = temp["datasetV2"]["datasetRid"]
                pandas_df['backing_dataset_branch'].iloc[i] = temp['datasetV2']['branchId']
            elif "restrictedView" in temp:
                pandas_df['backing_dataset_rid'].iloc[i] = temp["restrictedView"]["restrictedViewRid"]
                pandas_df['backing_dataset_branch'].iloc[i] = None
            elif "restrictedViewV2" in temp:
                pandas_df['backing_dataset_rid'].iloc[i] = temp["restrictedViewV2"]["restrictedViewRid"]
                pandas_df['backing_dataset_branch'].iloc[i] = None
            elif "restrictedStream" in temp:
                pandas_df['backing_dataset_rid'].iloc[i] = temp["restrictedStream"]["streamLocator"]["streamLocatorRid"]
                pandas_df['backing_dataset_branch'].iloc[i] = temp["restrictedStream"]["streamLocator"]["branchId"]
            elif "stream" in temp:
                pandas_df['backing_dataset_rid'].iloc[i] = temp["stream"]["streamLocator"]["streamLocatorRid"]
                pandas_df['backing_dataset_branch'].iloc[i] = temp["stream"]["streamLocator"]["branchId"]

        daily_usage = []
        for key in all_usage['usagePerDay']:
            obj = all_usage['usagePerDay'][key]
            obj['timestamp'] = key
            daily_usage.append(obj)

        usage_df = pd.json_normalize(daily_usage).fillna('')
        if 'timestamp' not in usage_df:
            usage_df['timestamp'] = ''
        usage_df["objectType.rid"] = pandas_df["objectType.rid"].iloc[i]
        usage_df['timestamp'] = pd.to_datetime(usage_df['timestamp'], format='%Y-%m-%dT%H:%MZ')
        usage_dataframes.append(usage_df)

    object_spark_df = ctx.spark_session.createDataFrame(
        pandas_df[[*ONTOLOGY_OBJECT_PANDAS_SCHEMA.fieldNames()]],
        schema=ONTOLOGY_OBJECT_PANDAS_SCHEMA
    )

    if (len(pd.concat(usage_dataframes)) > 0):
        object_usage_spark_df = ctx.spark_session.createDataFrame(
            pd.concat(usage_dataframes)[[*ONTOLOGY_OBJECT_USAGE_PANDAS_SCHEMA.fieldNames()]],
            schema=ONTOLOGY_OBJECT_USAGE_PANDAS_SCHEMA
        )
        object_usage_spark_df = (
            object_usage_spark_df
            .withColumn("uniqueUsersCount", F.col("uniqueUsersCount").cast("int"))
            .withColumn("usageByType.READ", F.col("`usageByType.READ`").cast("int"))
            .withColumn("usageByType.REGISTRATION", F.col("`usageByType.REGISTRATION`").cast("int"))
            .withColumn("usageByType.METADATA", F.col("`usageByType.METADATA`").cast("int"))
            .withColumn("usageByType.WRITE", F.col("`usageByType.WRITE`").cast("int"))
        )

        ontology_objects_usage.write_dataframe(object_usage_spark_df)

    last_run.set_mode("replace")
    end = min(latest, end)
    timestamp_df = ctx.spark_session.createDataFrame([(end)], "timestamp")
    last_run.write_dataframe(timestamp_df)
    ontology_objects.set_mode("replace")
    ontology_objects.write_dataframe(object_spark_df)


def convert_single_object_per_line(json_list):
    json_string = ""
    for line in json_list:
        json_string += json.dumps(line) + "\n"
    return json_string


def parse_dataframe(ctx, json_data):
    r = convert_single_object_per_line(json_data)
    mylist = []
    for line in r.splitlines():
        mylist.append(line)
    rdd = ctx.spark_session.sparkContext.parallelize(mylist)
    df = ctx.spark_session.jsonRDD(rdd)
    return df
