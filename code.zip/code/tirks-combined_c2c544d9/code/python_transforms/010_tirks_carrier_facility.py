from transforms.api import transform_df, Input, Output
import pyspark.sql.functions as F


@transform_df(
    Output("ri.foundry.main.dataset.4842d182-bb1a-4bf1-a89f-f7cb6d0e8ad1"),
    asi=Input("ri.foundry.main.dataset.bb89861a-7092-4437-82ab-fde5543990c1"),
    telco=Input("ri.foundry.main.dataset.209c8fa0-9175-4599-8ca4-cc54c14cb559"),
)
def my_compute_function(telco, asi):
    telco = telco.withColumn("source", F.lit('telco'))
    asi = asi.withColumn("source", F.lit('asi'))
    union = telco.unionByName(asi)
    return union
