from transforms.api import transform, Input, Output, configure

from myproject.utils.global_code import *

import json

# Spark utils
import pyspark.sql.types as T
from pyspark.sql import Window as W
from pyspark.sql import Row
import math
import logging

log = logging.getLogger(__name__)


@configure(
    profile=["EXECUTOR_MEMORY_MEDIUM", "NUM_EXECUTORS_32", "DRIVER_MEMORY_MEDIUM"]
)
@transform(
    all_platform_data=Output(
        f"{PARENT_FOLDER}/all_platform_data", sever_permissions=True
    ),
    all_projects=Input(f"{PARENT_FOLDER}/all_projects"),
    config=Input("ri.foundry.main.dataset.b5cb343e-1109-4401-b3fb-5137c32cb781"),
)
def all_platform_data(ctx, all_projects, config, all_platform_data):
    headers = get_header(config)

    log.info("Line 24")

    # Call to get Magritte extracts
    get_all_extracts = session.get(
        "{}/extract-store/extracts".format(MAGRITTE_URI), headers=headers
    )

    log.info("Line 29")

    # Call to get Magritte source names
    get_all_sources = session.get(
        "{}/source-store/sources/descriptions".format(MAGRITTE_URI), headers=headers
    )

    log.info("Line 34")

    # Parse Magritte extract into dataset RID to Magritte RID map
    dataset_to_magritte_map = convert_magritte_to_dataset(
        get_all_extracts.json(), get_all_sources.json()
    )

    log.info("Line 39")

    dataset_to_magritte_df = ctx.spark_session.createDataFrame(
        [
            [
                dataset_rid,
                data["magritte_rid"],
                data["magritte_name"],
                data["magritte_source_name"],
                data["magritte_source_type"],
                data["magritte_source_rid"],
                data["magritte_subfolder"],
                data["magritte_transaction_type"],
            ]
            for dataset_rid, data in dataset_to_magritte_map.items()
        ],
        [
            "dataset_rid",
            "magritte_rid",
            "magritte_name",
            "magritte_source_name",
            "magritte_source_type",
            "magritte_source_rid",
            "magritte_subfolder",
            "magritte_transaction_type",
        ],
    )

    log.info("Line 67")

    # legacy naming
    dataset_to_magritte_df = dataset_to_magritte_df.withColumnRenamed(
        "magritte_name", "magritte_extract_name"
    ).withColumnRenamed("magritte_rid", "magritte_extract_rid")

    log.info("Line 76")

    # Call to get Compass dataset RIDs
    dataset_rid_list = []

    page_request = "{}"
    next_page = True
    while next_page:
        get_all_datasets_page = session.post(
            "{}/datasets/paged".format(CATALOG_URI),
            data=page_request,
            headers=headers,
            timeout=120,
        )

        # log.info("Line 86")

        get_all_datasets_page_json = get_all_datasets_page.json()
        # Parse dataset RIDs into list to be used as body for Compass call
        dataset_rid_list.extend(
            list(map(lambda x: x["rid"], get_all_datasets_page_json["datasetsPage"]))
        )
        dataset_rid_list = list(set(dataset_rid_list))

        # log.info("Line 92")
        if get_all_datasets_page_json["nextPageToken"] != None:
            page_request = '{{"pageToken" : "{}"}}'.format(
                get_all_datasets_page_json["nextPageToken"]
            )
        else:
            next_page = False

    # Get schemas for all RIDs

    log.info("Line 100")

    rids_partitioned = (
        ctx.spark_session.createDataFrame([[r] for r in dataset_rid_list], ["rid"])
        .withColumn(
            "partition",
            F.row_number().over(W.partitionBy().orderBy("rid"))
            % math.ceil(len(dataset_rid_list) / 1000),
        )
        .groupBy("partition")
        .agg(F.collect_set("rid").alias("rids"))
        .drop("partition")
        .repartition(128)
    )

    log.info("Line 113")

    schema_df = ctx.spark_session.createDataFrame(
        rids_partitioned.rdd.flatMap(
            lambda row: get_schemas_for_rids(row, session, headers)
        ),
        schema=T.StructType(
            [
                T.StructField("dataset_rid", T.StringType(), True),
                T.StructField("schema", T.StringType(), True),
            ]
        ),
    )

    log.info("Line 129")

    dataset_details = ctx.spark_session.createDataFrame(
        rids_partitioned.rdd.flatMap(
            lambda row: get_dataset_info(row, session, headers)
        ),
        schema=T.StructType(
            [
                T.StructField("dataset_rid", T.StringType(), True),
                T.StructField("dataset_path", T.StringType(), True),
                T.StructField("dataset_name", T.StringType(), True),
                T.StructField("last_modified_date", T.StringType(), True),
                T.StructField("created_date", T.StringType(), True),
                T.StructField("project_name", T.StringType(), True),
                T.StructField("description", T.StringType(), True),
                T.StructField("created_by_user_id", T.StringType(), True),
                T.StructField("marking_list", T.ArrayType(T.StringType()), True),
                T.StructField("trashed", T.StringType(), True),
                T.StructField("collection", T.StringType(), True),
                T.StructField("collection_rid", T.StringType(), True),
            ]
        ),
    )

    log.info("Line 155")

    dataset_stats = ctx.spark_session.createDataFrame(
        ctx.spark_session.createDataFrame([[r] for r in dataset_rid_list], ["rid"])
        .rdd.repartition(128)
        .flatMap(lambda row: get_foundry_stats(row, session, headers)),
        schema=T.StructType(
            [
                T.StructField("dataset_rid", T.StringType(), True),
                T.StructField("row_count", T.StringType(), True),
                T.StructField("size_in_bytes_stats", T.StringType(), True),
                T.StructField("column_stats", T.StringType(), True),
            ]
        ),
    )

    log.info("Line 174")

    all_collection_rids = (
        dataset_details.select("collection_rid")
        .distinct()
        .filter(F.col("collection_rid").isNotNull())
        .collect()
    )

    log.info("Line 184")

    all_collection_rids = [row[0] for row in all_collection_rids]

    log.info("Line 188")
    log.info("Size Log: " + str(len(all_collection_rids)))
    all_collections_info = {}
    for rid in all_collection_rids:
        log.info("crid" + str(rid))
        try:
            temp = session.post(
                "{}/batch/collections".format(COMPASS_URI),
                headers=headers,
                json=[rid],
                timeout=1000,
            ).json()

            all_collections_info[rid] = temp[rid]
            log.info(str(type(all_collections_info)))
            log.info(all_collections_info)
        except Exception as e:
            log.error("RID: " + str(rid))
            log.error("Error in the try: " + str(e))

    log.info("Line 196")

    collection_descriptions = ctx.spark_session.createDataFrame(
        [
            (k, v["securedProperties"]["shortDescription"])
            for k, v in all_collections_info.items()
        ],
        schema=T.StructType(
            [
                T.StructField("collection_rid", T.StringType(), True),
                T.StructField("collection_description", T.StringType(), True),
            ]
        ),
    )

    log.info("Line 206")

    all_projects = (
        all_projects.dataframe()
        .withColumnRenamed("name", "project_name")
        .withColumnRenamed("rid", "project_rid")
    )

    log.info("Line 215")

    df = dataset_details.join(
        all_projects.select(
            "project_name",
            "project_rid",
            "project_description",
            "project_type",
            "project_allowed_by_everyone",
        ),
        ["project_name"],
        how="left",
    )

    log.info("Line 232")

    df = df.join(dataset_stats, ["dataset_rid"], "left")
    df = df.join(schema_df, ["dataset_rid"], "left")
    df = df.join(dataset_to_magritte_df, ["dataset_rid"], "left")
    df = df.join(collection_descriptions, ["collection_rid"], "left").drop(
        "collection_rid"
    )

    log.info("Line 239")

    all_platform_data.write_dataframe(df)

    log.info("Line 243")


def get_foundry_stats(dataset, session, headers):
    resp = session.post(
        f"{STATS_URI}/computed-stats-v2/get",
        headers=headers,
        json={"datasetRid": dataset.rid, "branch": "master"},
        timeout=120,
    ).json()
    if resp.get("computedDatasetStats", None) is None:
        return []
    return [
        (
            resp["datasetRid"],
            resp["computedDatasetStats"]["rowCount"],
            resp["computedDatasetStats"]["sizeInBytes"],
            json.dumps(resp["computedDatasetStats"]["columnStats"]),
        )
    ]


def get_schemas_for_rids(row, session, headers):
    rids_with_branch = []
    dataset_rid_list = row["rids"]
    for rid in dataset_rid_list:
        rids_with_branch.append(
            {"datasetAndBranchId": {"datasetRid": rid, "branchId": "master"}}
        )

    schema_dict = parse_schemas(
        session.post(
            "{}/schemas/batch/schemas?filterResults=true".format(METADATA_URI),
            headers=headers,
            json=rids_with_branch,
            timeout=120,
        ).json()
    )

    return [
        Row(dataset_rid=rid, schema=schema["tables"][0][rid])
        for rid, schema in schema_dict.items()
    ]


def get_dataset_info(row, session, headers):
    rids_with_branch = []
    dataset_rid_list = row["rids"]

    dataset_infos = (
        session.post(
            "{}/batch/resources?decoration=path&decoration=description&decoration=tags&decoration=inTrash&decoration=namedCollections&decoration=defaultBranchWithMarkings".format(
                COMPASS_URI
            ),
            headers=headers,
            json=dataset_rid_list,
            timeout=120,
        )
        .json()
        .items()
    )

    # Set list variable to collect rows
    rows = []
    # Iterate over all datasets and prase information for each dataset (store in rows)
    for key, value in dataset_infos:
        if "namedCollections" in value and len(value["namedCollections"]) > 0:
            collection_name = value["namedCollections"][0]["name"]
            collection_rid = value["namedCollections"][0]["rid"]
        else:
            collection_name = None
            collection_rid = None

        if value["modified"] is None:
            last_modified_date = None
        else:
            last_modified_date = value["modified"]["time"]

        if value["created"] is None:
            created_date = None
            created_by = None
        else:
            created_date = value["created"]["time"]
            created_by = value["created"]["userId"]
        # print(created_by)
        # Parse path where available
        if "inTrash" in value:
            trashed = value["inTrash"]
        else:
            trashed = None
        if "path" in value:
            path = value["path"]
            split_path = path.split("/")
            project_name = split_path[2]
        else:
            path = None
            project_name = None
        if "description" in value:
            description = value["description"]
        else:
            description = None

        if (
            "defaultBranchWithMarkings" in value
            and value["defaultBranchWithMarkings"]
            and "markings" in value["defaultBranchWithMarkings"]
        ):
            marking_list = [
                x.get("markingId", "")
                for x in value["defaultBranchWithMarkings"]["markings"]
            ]
        else:
            marking_list = None
        if(str(value["name"]).startswith('ri.data-health.main.check')):
            continue
        rows.append(
            Row(
                dataset_rid=key,
                dataset_path=path,
                dataset_name=value["name"],
                last_modified_date=last_modified_date,
                created_date=created_date,
                project_name=project_name,
                description=description,
                created_by_user_id=created_by,
                marking_list=marking_list,
                trashed=trashed,
                collection=collection_name,
                collection_rid=collection_rid,
            )
        )

    return rows
