
from transforms.api import transform, Input, Output
from myproject.datasets import utils
import pyspark.sql.types as T
from utility.column_clean import lowercase_columns


@transform(
    output=Output("/Innovation Lab/[Source] AOR/data/clean/all_locations"),
    my_input=Input("/Innovation Lab/[Source] AOR/data/raw/all_locations"),
)
def my_compute_function(ctx, output, my_input):
    hadoop_path = my_input.filesystem().hadoop_path
    schema = T.StructType([
  T.StructField('CLLI', T.StringType()),
  T.StructField('ST_NM', T.StringType()),
  T.StructField('REGION', T.StringType()),
  T.StructField('MGR_1_DAY', T.StringType()),
  T.StructField('MGR_1_EVE', T.StringType()),
  T.StructField('MGR_1_NGT', T.StringType()),
  T.StructField('COMN_NM', T.StringType()),
  T.StructField('HOST_LOC', T.StringType()),
  T.StructField('FRAME_NUM', T.StringType()),
  T.StructField('POLICE_NUM', T.StringType()),
  T.StructField('FIRE_NUM', T.StringType()),
  T.StructField('POWER_NUM', T.StringType()),
  T.StructField('FIRE_DEPT', T.StringType()),
  T.StructField('POLICE_DEPT', T.StringType()),
  T.StructField('ADDR', T.StringType()),
  T.StructField('CITY', T.StringType()),
  T.StructField('ZIP', T.StringType()),
  T.StructField('EQUIP_TYPE', T.StringType()),
  T.StructField('BLDG_LOC', T.StringType()),
  T.StructField('HR_STRT', T.StringType()),
  T.StructField('HR_FNSH', T.StringType()),
  T.StructField('TMZN', T.StringType()),
  T.StructField('HOSPITAL_NM', T.StringType()),
  T.StructField('HOSPITAL_NUM', T.StringType()),
  T.StructField('NPA', T.StringType()),
  T.StructField('NXX', T.StringType()),
  T.StructField('CARRIER_NUM', T.StringType()),
  T.StructField('SWNG_NUM', T.StringType()),
  T.StructField('UNION_NM', T.StringType()),
  T.StructField('POTS_NUM', T.StringType()),
  T.StructField('TOLL_NUM', T.StringType()),
  T.StructField('FX_NUM', T.StringType()),
  T.StructField('EMS_NUM', T.StringType()),
  T.StructField('FAX_NUM', T.StringType()),
  T.StructField('CHC_NUM', T.StringType()),
  T.StructField('ANAC_NUM', T.StringType()),
  T.StructField('ADDR2', T.StringType()),
  T.StructField('CITY2', T.StringType()),
  T.StructField('ZIP2', T.StringType()),
  T.StructField('COUNTY', T.StringType()),
  T.StructField('BATT_HRS', T.StringType()),
  T.StructField('ENGINE', T.StringType()),
  T.StructField('VOLTS', T.StringType()),
  T.StructField('PHASE', T.StringType()),
  T.StructField('KW', T.StringType()),
  T.StructField('EQUIP_TYPE_ID', T.StringType()),
  T.StructField('SWTCH', T.StringType()),
  T.StructField('SS7PC', T.StringType()),
  T.StructField('BLDG_LOC2', T.StringType()),
  T.StructField('FRAME_HORN', T.StringType()),
  T.StructField('SPCLS_NUM', T.StringType()),
  T.StructField('MANNED', T.StringType()),
  T.StructField('HR_STRT2', T.StringType()),
  T.StructField('TM_ZN', T.StringType()),
  T.StructField('PWR_CMPNY', T.StringType()),
  T.StructField('PWR_ACCT_NUM', T.StringType()),
  T.StructField('ENG_LOCN', T.StringType()),
  T.StructField('IN_LPC', T.StringType()),
  T.StructField('CUSER_ID', T.StringType()),
  T.StructField('MUSER_ID', T.StringType()),
  T.StructField('CRTCL', T.StringType()),
T.StructField('EXCL', T.StringType()),
T.StructField('LOC_TYPE'             , T.StringType()),
T.StructField('FACS_ENTITY'         , T.StringType()),
T.StructField('ADDR_FLR'             , T.StringType()),
T.StructField('FRAME_HORN_NUM' , T.StringType()),
T.StructField('INVAL_MGR'      , T.StringType()),
T.StructField('CDT'                  , T.StringType()),
T.StructField('MDT'                  , T.StringType()),
T.StructField('BKUP_TAPE_LOC'         , T.StringType()),
T.StructField('ENG_CNT'        , T.StringType()),
T.StructField('PWR_NOTES'              , T.StringType()),
T.StructField('EQUIP_VNDR_ID'  , T.StringType()),
T.StructField('TRNSPRT_VNDR_ID', T.StringType()),
T.StructField('COESM_BLDG_CHARSTC'   , T.StringType()),
T.StructField('SWITCH_IND'           , T.StringType()),
T.StructField('SWITCH_TYPE'           , T.StringType()),
T.StructField('CENTRAL_OFFICE'       , T.StringType()),
T.StructField('OWNER'                , T.StringType()),
T.StructField('UDF_PRMY_FUNC'  , T.StringType()),
T.StructField('UDF_MTSO'        , T.StringType()),
T.StructField('UDF_OPS_MGR_ATTUID'  , T.StringType()),
T.StructField('UDF_CORVW'           , T.StringType()),
])

    df_with_schema = None
    for fstatus in my_input.filesystem().ls("**/*.csv"):
        absolute_path = "{hadoop_path}/{fpath}".format(hadoop_path=hadoop_path, fpath=fstatus.path)
        df_with_schema = ctx.spark_session.read.format("csv").option("header", True).option("delimiter", "|").schema(schema).load(absolute_path)

    df = lowercase_columns(df_with_schema)
    output.write_dataframe(df)
