from transforms.api import transform, Input, Output, incremental
from utility.column_clean import clean_columns, lowercase_columns, remove_prefix


@transform(
    out=Output("/Innovation Lab/[Source] Teradata EDW - ASI_VIEWS/data/clean/vcan026_tirks_location"),
    df=Input("/Innovation Lab/[Source] Teradata EDW - ASI_VIEWS/data/raw/snowflake/SDW_AEDW_ASI_VIEWS.vcan026_tirks_location"),
)
def my_compute_function(df, out):
    df = clean_columns(
        df.dataframe(),
        date_format=date_format, 
        date_columns=string_to_date,
        datetime_format=datetime_format, 
        datetime_columns=long_unixtime_to_timestamp,
        timestamp_from_string_format=string_unixtime_format,
        timestamp_from_string_columns=string_unixtime_to_timestamp,
        timestamp_format=long_unixtime_format, 
        timestamp_columns=long_unixtime_to_timestamp,
        integer_columns=string_to_integer_columns,
        double_columns=string_to_double_columns,
        decimal_columns=string_to_decimal_columns,
        id_columns=numeric_to_string_columns,
        integer_from_num_columns=decimal_to_integer,
        strip_columns=strip_string_columns,
    )
    # df = df.drop(*drop_columns)
    # df = remove_prefix(df, 'example_prefix')
    df = lowercase_columns(df)
    out.write_dataframe(df)


drop_columns = []

date_format = 'yyyy-MM-dd'
string_to_date = []
datetime_format = 'yyyy-MM-dd HH:mm:ss'
string_to_timestamp = []

string_unixtime_format = None
string_unixtime_to_timestamp = []
long_unixtime_format = None
long_unixtime_to_timestamp = []

string_to_integer_columns = []
string_to_double_columns = []
string_to_decimal_columns = []

numeric_to_string_columns = []
decimal_to_integer = []

strip_string_columns = [
    "SBC_COMPANY_CD",
    "SBC_SYSTEM_CD",
    "SBC_STATE_CD",
    "LOCATION_CD",
    "ADMINISTRATIVE_AREA_CD",
    "PLANNING_ADMNSTV_AREA_CD",
    "DETAILED_RGLTY_STUDY_AREA_CD",
    "LOCATION_OWNER_CD",
    "LOCATION_DESC",
    "LOCATION_TYPE_ID",
    "LOCATION_NM",
    "LOCATION_STREET_ADDR",
    "LOCATION_CITY_NM",
    "LOCATION_COUNTY_NM",
    "LOCATION_STATE_NM",
    "LOCATION_POSTAL_ZIP_CD",
    "LOC_MANAGER_JOB_TITLE_DESC",
    "LOC_MANAGER_TELEPHONE_NBR",
    "LOC_MGR_TELEPHONE_EXTNSN_NBR",
    "SWITCHING_SYSTEM_CD",
    "SWNG_SYS_STD_TRUNK_TRNSMSN_CD",
    "TRUNK_ADMIN_SYSTEM_UNIVERSE_CD",
    "SWNG_SYSTEM_OFFICE_LOSS_MSRMT",
    "SWNG_SYS_OFC_PULSG_RNGE_MSRMT",
    "SWNG_SYS_OFC_IMPEDANCE_MSRMT",
    "MASTER_LOCATION_IND",
    "MASTER_LOCATION_CLLI_CD",
    "TELCO_CD",
    "OFFICE_BASE_CONTROL_GROUP_CD",
    "LOC_MARKER_CONTROL_GROUP_CD",
    "SWNG_SYS_OFFICE_CLASS_CD",
    "SWNG_SYSTEM_WATS_METERING_IND",
    "TRNK_ADMIN_SYS_INTRFC_OPTN_CD",
    "MASTER_LOC_NETWORK_POINT_CD",
    "MASTER_LOC_CLUSTER_POINT_CD",
    "MASTER_LOCATION_POINT_CD",
    "LATA_STATE_CD",
    "LATA_CD",
    "POP_CD",
    "LOCATION_PROCESSING_CD",
    "LOCATION_IDENTIFIER_TYPE_CD",
    "LOCATION_IDENTIFIER_STATUS_CD",
    "SERVING_WIRE_CENTER_CLLI_CD",
    "LOCATION_ORIGIN_FORMAT_CD",
    "LOCATION_REDESIGNATION_IND",
    "LOCATION_DELETION_IND",
    "MSTR_LOC_PT_CD_CIC_CMPLMT_CNT",
    "LOCATION_HOST_REMOTE_CD",
    "HOST_LOCATION_CLLI_CD",
    "DETL_RGLTY_CORRIDOR_TRMNTG_IND",
    "DETL_RGLTY_EXCHANGE_AREA_CD",
    "LOCATION_REMARKS_TXT",
    "MAINT_CTRL_OFC_TELEPHONE_NBR",
]