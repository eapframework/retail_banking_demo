from transforms.api import transform_df, Input, Output
from myproject.utils.global_code import PARENT_FOLDER, session, get_header, partition
from pyspark.sql import functions as F
from pyspark.sql import types as T


@transform_df(
    Output(f"{PARENT_FOLDER}/raw_datasets"),
    raw_dataset_input=Input(
        "/Innovation Lab/Data Governance/AT&T Internal Shareable Resources/raw_dataset_object"
    ),
    all_platform_data=Input(
        "/Innovation Lab/Data Governance/Project Lineage Tables/all_platform_data_with_lineage"
    ),
    use_cases=Input(f"{PARENT_FOLDER}/use_cases"),
    magritte_agents=Input(
        "/Innovation Lab/Data Governance/Project Lineage Tables/magritte_agents"
    ),
    projects=Input(
        "/Innovation Lab/Data Governance/DEEP Project Object/platform_projects_cleaned_edited"
    ),
    config=Input("/Innovation Lab/Palantir Admins/Quantum/inputs/config"),
    schedules=Input(
        "/Innovation Lab/Metrics/Group Shared Data & Code/data/ontology/raw/SCHEDULES"
    ),
)
def my_compute_function(
    ctx,
    raw_dataset_input,
    all_platform_data,
    use_cases,
    magritte_agents,
    projects,
    config,
    schedules,
):
    # 1. Join raw_datasets with all_platform_data_with_lineage to retrieve children data, explode on children
    raw_all_platform_data = all_platform_data.select(
        F.col("dataset_rid"),
        F.col("children"),
        F.col("has_children"),
    )
    raw_dataset = raw_dataset_input.join(raw_all_platform_data, "dataset_rid", "left")
    raw_dataset_children = raw_dataset.select(
        F.col("dataset_rid"),
        F.explode(F.col("children")).alias("child_dataset_rid"),
    )

    # 2. Find clean_children and not_clean_children for each raw dataset
    # 2.a) Join with all_platform_data_with_lineage to get information on each child dataset
    child_all_platform_data = all_platform_data.select(
        F.col("dataset_rid").alias("child_dataset_rid"),
        F.col("dataset_path").alias("child_dataset_path"),
        "size_in_bytes_stats",
        "row_count",
    )
    raw_dataset_children = raw_dataset_children.join(
        child_all_platform_data, "child_dataset_rid", "left"
    )
    # 2.b) Determine the clean children of the raw_dataset
    raw_dataset_clean_children = (
        raw_dataset_children.filter(
            raw_dataset_children.child_dataset_path.contains("clean/")
        )
        .groupBy("dataset_rid")
        .agg(
            F.collect_set("child_dataset_rid").alias("clean_children"),
            F.max("size_in_bytes_stats").alias("max_size_in_bytes"),
            F.max("row_count").alias("max_row_count"),
        )
    )
    # 2.c) Join with the clean children, and then use array_except to calculate the non_clean children
    raw_dataset = (
        raw_dataset.join(raw_dataset_clean_children, "dataset_rid", "left")
        .withColumn(
            "clean_children",
            F.when(F.col("clean_children").isNull(), F.array([])).otherwise(
                F.col("clean_children")
            ),
        )
        .withColumn("non_clean_children", F.array_except("children", "clean_children"))
        .withColumn("has_clean_children", F.size(F.col("clean_children")) > 0)
        .withColumn("has_non_clean_children", F.size(F.col("non_clean_children")) > 0)
    )
    # Join use case contacts with use case dataset
    projects = projects.withColumnRenamed("project_rid", "uc_project_rid").select(
        "uc_project_rid", "use_case_sponsors", "use_case_owners"
    )
    use_cases = use_cases.join(projects, "uc_project_rid", "left")

    # 3. Join raw_dataset with a set of use_cases that are using the clean children
    #    and set of use_cases that are referencing but not using the cleanchildren
    # 3.a) Aggregate use_cases by cleaned_dataset_rid
    used_raw_datasets = (
        use_cases.select(
            "uc_project_name",
            "use_case_sponsors",
            "use_case_owners",
            F.explode(F.col("used_raw_ref_datasets")).alias("dataset_rid"),
        )
        .groupBy("dataset_rid")
        .agg(
            F.collect_set("uc_project_name").alias("use_cases_using_raw_dataset"),
            F.collect_set("use_case_sponsors").alias(
                "use_case_sponsors_using_raw_dataset"
            ),
            F.collect_set("use_case_owners").alias("use_case_owners_using_raw_dataset"),
        )
    )
    used_clean_datasets = (
        use_cases.select(
            "uc_project_name",
            "use_case_sponsors",
            "use_case_owners",
            F.explode(F.col("used_cleaned_ref_datasets")).alias("cleaned_dataset_rid"),
        )
        .groupBy("cleaned_dataset_rid")
        .agg(
            F.collect_set("uc_project_name").alias("use_cases_using_clean_dataset"),
            F.collect_set("use_case_sponsors").alias(
                "use_case_sponsors_using_clean_dataset"
            ),
            F.collect_set("use_case_owners").alias(
                "use_case_owners_using_clean_dataset"
            ),
        )
    )
    unused_clean_datasets = (
        use_cases.select(
            "uc_project_name",
            "use_case_sponsors",
            "use_case_owners",
            F.explode(F.col("unused_cleaned_ref_datasets")).alias(
                "cleaned_dataset_rid"
            ),
        )
        .groupBy("cleaned_dataset_rid")
        .agg(
            F.collect_set("uc_project_name").alias(
                "use_cases_ref_but_not_using_clean_dataset"
            ),
            F.collect_set("use_case_sponsors").alias(
                "use_case_sponsors_ref_but_not_using_clean_dataset"
            ),
            F.collect_set("use_case_owners").alias(
                "use_case_owners_ref_but_not_using_clean_dataset"
            ),
        )
    )

    # 3.b) Join use cases with the clean children of our raw datasets
    exploded_clean_datasets = (
        raw_dataset.select(
            F.col("dataset_rid"),
            F.explode(F.col("clean_children")).alias("cleaned_dataset_rid"),
        )
        .join(used_clean_datasets, "cleaned_dataset_rid", "left")
        .join(unused_clean_datasets, "cleaned_dataset_rid", "left")
    )

    # 3.c) Collect the set of use cases over the raw dataset_rid
    use_case_metadata = (
        exploded_clean_datasets.groupBy(F.col("dataset_rid"))
        .agg(
            F.collect_set("use_cases_using_clean_dataset").alias(
                "use_cases_using_clean_dataset"
            ),
            F.collect_set("use_case_sponsors_using_clean_dataset").alias(
                "use_case_sponsors_using_clean_dataset"
            ),
            F.collect_set("use_case_owners_using_clean_dataset").alias(
                "use_case_owners_using_clean_dataset"
            ),
            F.collect_set("use_cases_ref_but_not_using_clean_dataset").alias(
                "use_cases_ref_but_not_using_clean_dataset"
            ),
            F.collect_set("use_case_sponsors_ref_but_not_using_clean_dataset").alias(
                "use_case_sponsors_ref_but_not_using_clean_dataset"
            ),
            F.collect_set("use_case_owners_ref_but_not_using_clean_dataset").alias(
                "use_case_owners_ref_but_not_using_clean_dataset"
            ),
        )
        .select(
            "dataset_rid",
            F.array_distinct(F.flatten("use_cases_using_clean_dataset")).alias(
                "use_cases_using_clean_dataset"
            ),
            F.array_distinct(F.flatten("use_case_sponsors_using_clean_dataset")).alias(
                "use_case_sponsors_using_clean_dataset"
            ),
            F.array_distinct(F.flatten("use_case_owners_using_clean_dataset")).alias(
                "use_case_owners_using_clean_dataset"
            ),
            F.array_distinct(
                F.flatten("use_cases_ref_but_not_using_clean_dataset")
            ).alias("use_cases_ref_but_not_using_clean_dataset"),
            F.array_distinct(
                F.flatten("use_case_sponsors_ref_but_not_using_clean_dataset")
            ).alias("use_case_sponsors_ref_but_not_using_clean_dataset"),
            F.array_distinct(
                F.flatten("use_case_owners_ref_but_not_using_clean_dataset")
            ).alias("use_case_owners_ref_but_not_using_clean_dataset"),
        )
    )

    raw_dataset = raw_dataset.join(used_raw_datasets, "dataset_rid", "left").join(
        use_case_metadata, "dataset_rid", "left"
    )

    # 4. Add column for snapshot vs engineered
    engineered_sources = (
        magritte_agents.filter(
            (
                F.col("agentRid")
                == "ri.magritte..agent.af40eb90fa4490cd52357c344760df4d2eba5e3c2e92e34f8e31e5250806bd5a"
            )
            | (
                F.col("agentRid")
                == "ri.magritte..agent.aab172a8f1b813ce34fec33ba1cf2d5b3970502d5f25f38727cfbc1fc5ab69f2"
            )
            | (
                F.col("agentRid")
                == "ri.magritte..agent.7571698ac2a3be776ebf1019168eec95f2e9f9982ba3a0119b9eb6f0566ed847"
            )
        )
        .select(
            F.col("sourceRid").alias("magritte_source_rid"),
            F.lit("engineered").alias("engineered_vs_snapshot"),
        )
        .dropDuplicates()
    )

    raw_dataset = raw_dataset.join(engineered_sources, "magritte_source_rid", "left")
    raw_dataset = raw_dataset.withColumn(
        "engineered_vs_snapshot",
        F.when(
            raw_dataset.engineered_vs_snapshot == "engineered", "engineered"
        ).otherwise("snapshot"),
    )

    # Add in schedules
    schedules = (
        schedules.filter(F.col("enabled") == True)
        .filter(F.col("branch") == "master")
        .select(
            F.lit(True).alias("has_schedule"),
            F.explode(F.col("datasets")).alias("dataset_rid"),
        )
        .distinct()
    )
    raw_dataset = raw_dataset.join(schedules, ["dataset_rid"], "left").withColumn(
        "has_schedule", F.coalesce(F.col("has_schedule"), F.lit(False))
    )

    # 5. Get tags of raw_datasets and join
    BATCH_SIZE = 100
    headers = get_header(config)
    tags_url = "https://paloma.palantirfoundry.com/compass/api/batch/resources?decoration=namedTags&decoration=tags&decoration=markings"
    raw_rids = [
        row["dataset_rid"] for row in raw_dataset.select("dataset_rid").collect()
    ]  # noqa

    dataset_tags = []
    for batch in partition(raw_rids, BATCH_SIZE):
        resp = session.post(tags_url, headers=headers, json=batch)
        resp_dict = resp.json()
        for key in resp_dict:
            dataset_tags.append([key, resp_dict[key]["namedTags"]])

    schema = T.StructType([T.StructField(*col) for col in TAG_COLUMNS])
    tags = ctx.spark_session.createDataFrame(dataset_tags, schema=schema)

    raw_dataset = raw_dataset.join(tags, "dataset_rid", "left")

    return raw_dataset


TAG_COLUMNS = [
    ("dataset_rid", T.StringType()),
    (
        "tag_array",
        T.ArrayType(
            T.StructType(
                [
                    T.StructField("rid", T.StringType(), True),
                    T.StructField("name", T.StringType(), True),
                ]
            )
        ),
    ),
]
