from transforms.api import transform_df, Input, Output, incremental
import pyspark.sql.functions as F


@transform_df(
    Output("/Innovation Lab/[ETL] Tirks Combined/data/052_tirks_work_item"),
    asi=Input("ri.foundry.main.dataset.4cbe3964-6e5b-4c56-9067-04e3a7ffc0fb"),
    telco=Input("ri.foundry.main.dataset.7d1551f2-36de-457c-b348-148f7e02de95"),
)
def my_compute_function(telco, asi):
    telco = telco.withColumn("source", F.lit('telco'))
    asi = asi.withColumn("source", F.lit('asi'))
    df = telco.unionByName(asi)
    return df