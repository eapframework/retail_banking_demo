from transforms.api import transform, Input, Output, incremental
from pyspark.sql import functions as F


@incremental(semantic_version=3)
@transform(
    out=Output("/Innovation Lab/[Source] Vertica IQI/data/clean/iqi_mgrs1k_monthly_summary"),
    hist=Input("/Innovation Lab/[Source] Vertica IQI/data/raw/iqi_mgrs1k_monthly_summary"),
    incre=Input("/Innovation Lab/[Source] Vertica IQI/data/raw/IQI Snowflake/iqi_mgrs1k_monthly_summary")
)
def my_compute_function(hist, incre, out):
    hist = hist.dataframe()
    incre = incre.dataframe()
    colms = incre.columns
    incre = incre.select(
        *[F.col(colm).alias(colm.lower()) for colm in colms]
    )
    df = hist.unionByName(incre)
    out.write_dataframe(df)
