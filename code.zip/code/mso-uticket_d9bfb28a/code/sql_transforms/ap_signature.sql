CREATE TABLE `/Innovation Lab/GTOC Change Management Metrics and Reports/ontology/clean/ap_signature` AS
    SELECT
    signature_id,
    alternate_signature,
    AP_SIGNATURE.approval_id,
    approval_status,
    approver_signature,
    approvers,
    modified_date_sig,
    role,
    AP_DETAIL.request
    FROM `/Innovation Lab/[Source] Oracle ESAR/data/clean/ars_dbor_cm_r1.ap_signature` AS AP_SIGNATURE

    LEFT JOIN (
        SELECT
        request,
        approval_id
        FROM `/Innovation Lab/[Source] Oracle ESAR/data/clean/ars_dbor_cm_r1.ap_detail`) AS AP_DETAIL

    ON AP_DETAIL.approval_id == AP_SIGNATURE.approval_id

    WHERE AP_DETAIL.request IS NOT NULL
    