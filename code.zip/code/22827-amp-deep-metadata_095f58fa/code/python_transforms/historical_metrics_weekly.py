from transforms.api import transform, Input, Output, incremental, configure
from capacity_project import config, utils
from capacity_project.api.UsageAggregator import UsageAggregatorAPI
from pyspark.sql import types as T
from pyspark.sql import functions as F


OLD_SCHEMA = T.StructType([
    T.StructField('dataset_rid', T.StringType()),
    T.StructField('start_date', T.DateType()),
    T.StructField('end_date', T.DateType()),
    T.StructField('year', T.IntegerType()),
    T.StructField('month', T.IntegerType()),
    T.StructField('day', T.IntegerType()),
    T.StructField('week_num', T.IntegerType()),
    T.StructField('disk_space', T.DoubleType()),
    T.StructField('compute_time', T.DoubleType())
])


@incremental(semantic_version=2, snapshot_inputs=['datasets', 'config'])
@configure(profile=["EXECUTOR_MEMORY_MEDIUM", "DRIVER_MEMORY_MEDIUM"])
@transform(
    historical_metrics=Output(f'{config.PARENT_FOLDER}/raw/historical_metrics_weekly'),
    datasets=Input(f'{config.PARENT_FOLDER}/raw/SOURCE_DATASETS'),
    config=Input("ri.foundry.main.dataset.b5cb343e-1109-4401-b3fb-5137c32cb781")
)
def my_compute_function(ctx, datasets, config, historical_metrics):
    # get new data
    CUT_OFF = "2021-09-01T00:00Z"
    ONE_MILLION = 1_000_000
    BATCH_SIZE = 150
    token = utils.get_token(config.dataframe())
    ua_api = UsageAggregatorAPI(token)
    rids = [str(row.dataset_rid) for row in datasets.dataframe().select("dataset_rid").collect()]
    final_list = []

    for i in range(0, len(rids), BATCH_SIZE):
        cur_rids = rids[i: (i+BATCH_SIZE)]
        monthly_usage = ua_api.get_granular_batch(
            request_body={
                "period": "WEEKLY",
                "datasets": cur_rids,
                "dimensions": ["BATCH_COMPUTE", "INTERACTIVE_COMPUTE", "DISK_SIZE", "INDEXED_STORAGE"]
            }
        )['data']

        for rid in cur_rids:
            date_strings = [
                x for x in
                (monthly_usage.get(rid, {}).get("catalogStorage", {}) or {}).get("data", {}).keys()
                if x >= CUT_OFF
            ]
            final_list += [(
                rid,
                date_string[:10],
                (monthly_usage.get(rid, {}).get("batchCompute", {}) or {}).get("data", {}).get(date_string, None),
                (monthly_usage.get(rid, {}).get("interactiveCompute", {}) or {}).get("data", {}).get(date_string, None),
                (monthly_usage.get(rid, {}).get("catalogStorage", {}) or {}).get("data", {}).get(date_string, None),
                (monthly_usage.get(rid, {}).get("indexedStorage", {}) or {}).get("data", {}).get(date_string, None),
            ) for date_string in date_strings]

    df = ctx.spark_session.createDataFrame(final_list, schema=T.StructType([
        T.StructField('dataset_rid', T.StringType(), True),
        T.StructField('date_string', T.StringType(), True),
        T.StructField('compute_time', T.LongType(), True),
        T.StructField('interactive_compute', T.LongType(), True),
        T.StructField('disk_space', T.LongType(), True),
        T.StructField('indexed_storage', T.LongType(), True),
    ]))
    df = df.withColumn(
        "start_date", F.to_date(F.col("date_string"), "yyyy-MM-dd")
    ).withColumn(
        "end_date", F.date_add(F.col("start_date"), 7)
    )
    latest_df = df.select(
        "dataset_rid",
        "start_date",
        "end_date",
        F.year(F.col("start_date")).alias("year"),
        F.month(F.col("start_date")).alias("month"),
        F.weekofyear(F.col("start_date")).alias("week_num"),
        (F.col('disk_space')/ONE_MILLION).cast("double").alias("disk_space"),
        (F.col('compute_time')/60).cast("double").alias("compute_time"),
        'interactive_compute',
        'indexed_storage'
    )
    # merge with historical
    try:
        output_df = historical_metrics.dataframe(mode='previous', schema=latest_df.schema)
    except Exception:
        output_df = historical_metrics.dataframe(mode='previous', schema=OLD_SCHEMA)
        output_df = output_df.select(
            "dataset_rid",
            "start_date",
            "end_date",
            "year",
            "month",
            "week_num",
            "disk_space",
            'compute_time',
            F.lit(None).cast("long").alias('interactive_compute'),
            F.lit(None).cast("long").alias('indexed_storage'),
        )
    primary_keys = ["dataset_rid", "start_date"]

    output_df = (
        output_df
        .groupby(*primary_keys)
        .agg(
            *[F.first(F.col(c)).alias(c) for c in output_df.columns if c not in primary_keys]
        )
    )
    latest_df = (
        latest_df
        .groupby(*primary_keys)
        .agg(
            *[F.first(F.col(c)).alias(c) for c in latest_df.columns if c not in primary_keys]
        )
    )

    joined_df = output_df.join(latest_df, on=primary_keys, how="full_outer")
    result_df = joined_df.select([
        (F.col(c) if c in primary_keys else F.coalesce(latest_df[c], output_df[c])).alias(c)
        for c
        in latest_df.columns])

    historical_metrics.set_mode("replace")

    historical_metrics.write_dataframe(
        result_df,
        bucket_cols=primary_keys,
        bucket_count=200
    )