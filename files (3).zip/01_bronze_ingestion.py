"""
MSO uTicket — SDP Pipeline (Bronze Layer)
==========================================
Streaming tables ingested from Oracle ESAR via Snowflake → ADLS Gen2 → Auto Loader.
Uses: pyspark.pipelines (Lakeflow Spark Declarative Pipelines)

SDK migration from DLT:
  - import dlt              → from pyspark import pipelines as dp
  - @dlt.table (streaming)  → @dp.table()
  - dlt.read_stream()       → spark.readStream.table()

All bronze tables are STREAMING TABLES (@dp.table) fed by Auto Loader.
"""

from pyspark import pipelines as dp
from pyspark.sql import functions as F

# ---------------------------------------------------------------------------
# Configuration — adjust per environment via DABs variables or spark_conf
# ---------------------------------------------------------------------------
LANDING_ZONE = spark.conf.get("landing_zone", "abfss://landing@<storage_account>.dfs.core.windows.net/oracle_esar")


# ═══════════════════════════════════════════════════════════════════════════
# BRONZE STREAMING TABLES
# ═══════════════════════════════════════════════════════════════════════════

@dp.table(
    name="raw_chg_change_snowflake",
    comment="Raw CHG_CHANGE from Oracle ESAR via Snowflake. 756 columns. Source of all change tickets.",
    table_properties={"quality": "bronze", "pipelines.autoOptimize.managed": "true"},
)
@dp.expect_or_drop("valid_change_id", "CHANGE_ID IS NOT NULL")
def raw_chg_change_snowflake():
    """
    Foundry source: chg_change_snowflake (RID: b541996c)
    Magritte agent: ef60021d → Oracle ESAR DataSource ba31895a
    """
    return (
        spark.readStream.format("cloudFiles")
        .option("cloudFiles.format", "parquet")
        .option("cloudFiles.inferColumnTypes", "true")
        .option("cloudFiles.schemaLocation", f"{LANDING_ZONE}/chg_change/_schema")
        .load(f"{LANDING_ZONE}/chg_change/")
    )


@dp.table(
    name="raw_chg_task_snowflake",
    comment="Raw CHG_TASK from Oracle ESAR via Snowflake. 190 columns. Change management tasks.",
    table_properties={"quality": "bronze"},
)
@dp.expect_or_drop("valid_task_id", "TASK_ID IS NOT NULL")
def raw_chg_task_snowflake():
    """Foundry source: esaars_dbor_cm_rviews.chg_task_snowflake (RID: 573ddb29)"""
    return (
        spark.readStream.format("cloudFiles")
        .option("cloudFiles.format", "parquet")
        .option("cloudFiles.inferColumnTypes", "true")
        .option("cloudFiles.schemaLocation", f"{LANDING_ZONE}/chg_task/_schema")
        .load(f"{LANDING_ZONE}/chg_task/")
    )


@dp.table(
    name="raw_acmr14_affected_cllis",
    comment="Raw ACMR14 Affected CLLIs. 15 columns. CLLI location data linked to changes.",
    table_properties={"quality": "bronze"},
)
def raw_acmr14_affected_cllis():
    """Foundry source: esaars_dbor_cm_rviews.acmr14_affected_cllis"""
    return (
        spark.readStream.format("cloudFiles")
        .option("cloudFiles.format", "parquet")
        .option("cloudFiles.inferColumnTypes", "true")
        .option("cloudFiles.schemaLocation", f"{LANDING_ZONE}/acmr14_affected_cllis/_schema")
        .load(f"{LANDING_ZONE}/acmr14_affected_cllis/")
    )


@dp.table(
    name="raw_acmr14_affected_techs_snowflake",
    comment="Raw ACMR14 Affected Technologies. 19 columns.",
    table_properties={"quality": "bronze"},
)
def raw_acmr14_affected_techs_snowflake():
    """Foundry source: esaars_dbor_cm_rviews.acmr14_affected_techs_snowflake"""
    return (
        spark.readStream.format("cloudFiles")
        .option("cloudFiles.format", "parquet")
        .option("cloudFiles.inferColumnTypes", "true")
        .option("cloudFiles.schemaLocation", f"{LANDING_ZONE}/acmr14_affected_techs/_schema")
        .load(f"{LANDING_ZONE}/acmr14_affected_techs/")
    )


@dp.table(
    name="raw_acmr23_mobility_equipment_info_snowflake",
    comment="Raw ACMR23 Mobility Equipment Info. 32 columns.",
    table_properties={"quality": "bronze"},
)
@dp.expect_or_drop("valid_med_id", "MED_RECORD_ID IS NOT NULL")
def raw_acmr23_mobility_equipment_info_snowflake():
    """Foundry source: esaars_dbor_cm_rviews.acmr23_mobility_equipment_info_snowflake (RID: 19b1503a)"""
    return (
        spark.readStream.format("cloudFiles")
        .option("cloudFiles.format", "parquet")
        .option("cloudFiles.inferColumnTypes", "true")
        .option("cloudFiles.schemaLocation", f"{LANDING_ZONE}/acmr23_mobility_equipment_info/_schema")
        .load(f"{LANDING_ZONE}/acmr23_mobility_equipment_info/")
    )


@dp.table(
    name="raw_ap_signature",
    comment="Raw AP_SIGNATURE. 52 columns. Approval signatures.",
    table_properties={"quality": "bronze"},
)
def raw_ap_signature():
    """Foundry source: esaars_dbor_cm_rviews.ap_signature"""
    return (
        spark.readStream.format("cloudFiles")
        .option("cloudFiles.format", "parquet")
        .option("cloudFiles.inferColumnTypes", "true")
        .option("cloudFiles.schemaLocation", f"{LANDING_ZONE}/ap_signature/_schema")
        .load(f"{LANDING_ZONE}/ap_signature/")
    )


@dp.table(
    name="raw_ap_detail_snowflake",
    comment="Raw AP_DETAIL. 40 columns. Approval process details.",
    table_properties={"quality": "bronze"},
)
def raw_ap_detail_snowflake():
    """Foundry source: esaars_dbor_cm_rviews.ap_detail_snowflake"""
    return (
        spark.readStream.format("cloudFiles")
        .option("cloudFiles.format", "parquet")
        .option("cloudFiles.inferColumnTypes", "true")
        .option("cloudFiles.schemaLocation", f"{LANDING_ZONE}/ap_detail/_schema")
        .load(f"{LANDING_ZONE}/ap_detail/")
    )
