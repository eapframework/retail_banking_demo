from __future__ import annotations

from typing import List

from fastapi import APIRouter, Depends, HTTPException, Path, Query, status

from app.schemas.pagination import PaginatedResponse, PaginationParams
from app.schemas.prep_extraction import (
    PrepareExtractionRequest,
    PrepareExtractionResponse,
)
from app.schemas.resource import (
    ResourceRead,
)
from app.services.store import store


router = APIRouter()


@router.get("/upstream-ids", response_model=List[str])
def get_shared_upstream_resource_ids(resource_ids: list[str] = Query(..., min_items=1)) -> List[str]:
    """Return all upstream resource IDs using an efficient DFS traversal.

    The previous implementation returned a nested tree structure and performed
    a recursive walk, which could be extremely slow for resources with large
    upstream feeds.  This version constructs a simple adjacency map and iterates
    through the graph, collecting unique IDs only.  The response is a flat list
    of IDs which serializes quickly and keeps runtime proportional to the
    number of relationships rather than the size of the entire tree.

    Args:
        resource_id: the ID of the resource to inspect (path param)

    Returns:
        List of upstream resource_id strings. May be empty if there are none.

    Raises:
        HTTPException 400: if the supplied ID is empty or whitespace
        HTTPException 404: if the resource does not exist at all
    """
    # Validate input
    for rid in resource_ids:
        if not rid or not rid.strip():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Resources not found",
            )
        
        # Ensure the resource exists before attempting traversal
        if store.get_resource(rid) is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="Resources not found",
            )

    # delegate to store; returns empty list when there are no upstreams
    return store.list_upstream_resource_ids(resource_ids)


@router.post(
    "/prepare-extraction",
    response_model=PrepareExtractionResponse,
    status_code=status.HTTP_200_OK,
)
def prepare_upstream_resource_extraction(payload: PrepareExtractionRequest,) -> PrepareExtractionResponse:
    """
    Identify shared upstream resources for the given resource_ids and
    transition any DISCOVERED resources to PLANNED.
    """
    try:
        return store.prepare_upstream_resource_extraction(
            payload
        )
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(exc),
        )


@router.get("/{resource_id}/upstream", response_model=PaginatedResponse[ResourceRead])
def list_upstream_resources(
    resource_id: str,
    pagination: PaginationParams = Depends(),
) -> PaginatedResponse[ResourceRead]:
    """List upstream resources (resources that feed into this resource) with pagination."""
    items, total = store.list_upstream_resources(
        resource_id,
        offset=pagination.offset,
        limit=pagination.limit,
    )
    return PaginatedResponse.create(
        items=items,
        total=total,
        offset=pagination.offset,
        limit=pagination.limit,
    )


@router.get("/{resource_id}/downstream", response_model=PaginatedResponse[ResourceRead])
def list_downstream_resources(
    resource_id: str,
    pagination: PaginationParams = Depends(),
) -> PaginatedResponse[ResourceRead]:
    """List downstream resources (resources that depend on this resource) with pagination."""
    items, total = store.list_downstream_resources(
        resource_id,
        offset=pagination.offset,
        limit=pagination.limit,
    )
    return PaginatedResponse.create(
        items=items,
        total=total,
        offset=pagination.offset,
        limit=pagination.limit,
    )


@router.get("/{resource_id}/upstream-ids", response_model=List[str])
def get_upstream_resource_ids(resource_id: str = Path(..., min_length=1)) -> List[str]:
    """Return all upstream resource IDs using an efficient DFS traversal.

    The previous implementation returned a nested tree structure and performed
    a recursive walk, which could be extremely slow for resources with large
    upstream feeds.  This version constructs a simple adjacency map and iterates
    through the graph, collecting unique IDs only.  The response is a flat list
    of IDs which serializes quickly and keeps runtime proportional to the
    number of relationships rather than the size of the entire tree.

    Args:
        resource_id: the ID of the resource to inspect (path param)

    Returns:
        List of upstream resource_id strings. May be empty if there are none.

    Raises:
        HTTPException 400: if the supplied ID is empty or whitespace
        HTTPException 404: if the resource does not exist at all
    """
    # Validate input
    if not resource_id or not resource_id.strip():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Resources not found",
        )

    # Ensure the resource exists before attempting traversal
    if store.get_resource(resource_id) is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Resources not found",
        )

    # delegate to store; returns empty list when there are no upstreams
    return store.list_upstream_resource_ids([resource_id])
