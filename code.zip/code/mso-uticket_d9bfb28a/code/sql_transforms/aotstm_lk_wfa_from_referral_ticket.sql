CREATE TABLE `/Innovation Lab/[ETL] Ticketing/logic/aotstm/aotstm_lk_wfa_from_referral_ticket` AS
    SELECT main_ticket as ticket
    , provider_ticket as wfa_ticket
     FROM `/Innovation Lab/[Source] Oracle ESAR/data/clean/referral_ticket`
     WHERE upper(provider_ticket) REGEXP '[W][A-Z][A-Z][A-Z][A-Z][0-9][0-9][0-9][0-9][0-9][0-9]'