CREATE TABLE `ri.foundry.main.dataset.a1456228-c6e8-4bc2-9c70-d2f50a966524` AS
    select ticket
    , last(mp_link) mp_link
    FROM (
    SELECT ticket_nb as ticket, regexp_extract(ticket_message, '(http[^\\s]+)', 1) as mp_link 
     FROM `ri.foundry.main.dataset.bc1e7b50-f481-4a5a-9450-e1a6a6706def`
    WHERE ticket_message REGEXP 'Procedure can be found at this link\n\n*([^\s]+)'
    ) A 
    group by ticket