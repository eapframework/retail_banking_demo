from transforms.api import transform, Input, Output, incremental
from utility.column_clean import clean_columns, lowercase_columns, remove_prefix
from pyspark.sql.functions import col


@transform(
    out=Output(
        "/Innovation Lab/[Source] Teradata EDW - ACCESS_VIEWS/data/prod_clean/vctn027_tirks_cable_facility"
    ),
    df=Input(
        "/Innovation Lab/[Source] Teradata EDW - ACCESS_VIEWS/data/raw/snowflake/ACCESS_VIEWS.VCTN027_TIRKS_CABLE_FACILITY"
    ),
)
def my_compute_function(df, out):
    df = clean_columns(
        df.dataframe(),
        date_format=date_format,
        date_columns=string_to_date,
        datetime_format=datetime_format,
        datetime_columns=long_unixtime_to_timestamp,
        timestamp_from_string_format=string_unixtime_format,
        timestamp_from_string_columns=string_unixtime_to_timestamp,
        timestamp_format=long_unixtime_format,
        timestamp_columns=long_unixtime_to_timestamp,
        integer_columns=string_to_integer_columns,
        double_columns=string_to_double_columns,
        decimal_columns=string_to_decimal_columns,
        id_columns=numeric_to_string_columns,
        integer_from_num_columns=decimal_to_integer,
        strip_columns=strip_string_columns,
    )
    df = lowercase_columns(df)
    df = df.withColumn(
        "cable_units_spare_true_qty", col("cable_units_spare_true_qty").cast("Integer")
    )
    df = df.withColumn(
        "cable_units_total_qty", col("cable_units_total_qty").cast("Integer")
    )
    df = df.withColumn("diverse_units_qty", col("diverse_units_qty").cast("short"))
    df = df.withColumn(
        "cable_header_sequence_nbr", col("cable_header_sequence_nbr").cast("short")
    )
    df = df.withColumn(
        "cable_electrical_rstnc_msrmt",
        col("cable_electrical_rstnc_msrmt").cast("Integer"),
    )
    out.write_dataframe(df)


drop_columns = []

date_format = "yyyy-MM-dd"
string_to_date = []
datetime_format = "yyyy-MM-dd HH:mm:ss"
string_to_timestamp = []

string_unixtime_format = None
string_unixtime_to_timestamp = []
long_unixtime_format = None
long_unixtime_to_timestamp = []

string_to_integer_columns = []
string_to_double_columns = []
string_to_decimal_columns = []

numeric_to_string_columns = []
decimal_to_integer = []

strip_string_columns = [
    "SBC_COMPANY_CD",
    "SBC_SYSTEM_CD",
    "CABLE_LOCATION_A_CLLI_CD",
    "CABLE_LOCATION_Z_CLLI_CD",
    "CABLE_ID",
    "CABLE_LAST_UNIT_RANGE_NBR",
    "SBC_STATE_CD",
    "CABLE_FIRST_UNIT_RANGE_NBR",
    "FACILITY_ROUTING_SUBPATH_CD",
    "FACILITY_DETAIL_CD",
    "CABLE_INVENTORY_STATUS_CD",
    "FACILTIY_LNGTH_UNIT_OF_MEAS_CD",
    "ASSIGNMENT_RESPONSIBILITY_CD",
    "CABLE_COMPLEMENT_IDNTFCN_CD",
    "FACILITY_USE_CD",
    "CABLE_FACILITY_GROUP_CD",
    "TRANSMISSION_DIRECTION_CD",
    "ADMINISTRATIVE_GROUP_CD",
    "AUTHORIZING_WORK_ORDER_CD",
    "CABLE_FACILITY_REMARKS_TXT",
    "LATTICE_INDICATOR_CD",
    "LOC_A_END_SECTION_GAUGE_MSRMT",
    "LOC_A_END_SECTION_LENGTH_MSRMT",
    "LOC_Z_END_SECTION_GAUGE_MSRMT",
    "LOC_Z_END_SECTION_LENGTH_MSRMT",
    "DETAILED_RGLTY_FACILITY_GRP_CD",
    "WIRE_PER_UNIT_QTY",
    "CABLE_MAKEUP_LINE_1_DESC",
    "CABLE_MAKEUP_LINE_2_DESC",
    "CABLE_MAKEUP_LINE_3_DESC",
    "LOCATION_A_ADMIN_AREA_CD",
    "LOC_A_PLANNING_ADMNSTV_AREA_CD",
    "LOC_A_DETL_RGLTY_STUDY_AREA_CD",
    "LOC_A_STD_TRUNKING_TRNSMSN_CD",
    "LOCATION_Z_ADMIN_AREA_CD",
    "LOC_Z_PLANNING_ADMNSTV_AREA_CD",
    "LOC_Z_DETL_RGLTY_STUDY_AREA_CD",
    "LOC_Z_STD_TRUNKING_TRNSMSN_CD",
    "LOCATION_A_FRAME_TYPE_CD",
    "LOC_A_FRAME_CONNECTOR_TYPE_CD",
    "LOC_A_EQUIPMENT_RELAY_RACK_CD",
    "LOCATION_Z_FRAME_TYPE_CD",
    "LOC_Z_FRAME_CONNECTOR_TYPE_CD",
    "LOC_Z_EQUIPMENT_RELAY_RACK_CD",
]
