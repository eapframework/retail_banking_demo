from transforms.api import transform, Input, Output
from utility.column_clean import clean_columns, lowercase_columns, remove_prefix


@transform(
   out=Output("/Innovation Lab/[Source] MAPP/data/clean/dbo.tbl_hierarchy_daily"),
   df=Input("/Innovation Lab/[Source] MAPP/data/raw/dbo.tbl_hierarchy_daily"),
)
def my_compute_function(df, out):
    df = clean_columns(
        df.dataframe(),
        strip_columns=strip_columns,
        integer_columns=cast_to_integer_columns,
        double_columns=cast_to_double_columns,
        decimal_columns=cast_to_decimal_columns,
        timestamp_columns=cast_to_timestamp_from_long_columns,
        datetime_columns=cast_to_timestamp_columns,
        datetime_format=datetime_format,
        date_columns=cast_to_date_columns,
        date_format=date_format,
        id_columns=cast_to_string_columns,
        integer_from_num_columns=cast_to_integer_from_decimal_columns
    )
    df = lowercase_columns(df)
    out.write_dataframe(df)
    # out.write_dataframe(df, partition_cols=['update_dt', 'col_2'])

date_format = 'yyyy-MM-dd'
datetime_format = 'yyyy-MM-dd HH:mm:ss'

cast_to_date_columns = []
cast_to_timestamp_columns = []
cast_to_timestamp_from_long_columns = [
    "insert_date",
    "update_date",
]
cast_to_integer_columns = [
    "position",
]
cast_to_double_columns = []
cast_to_decimal_columns = []
cast_to_string_columns = []
cast_to_integer_from_decimal_columns = []
strip_columns = [
    "uid_0",
    "rc",
    "status",
    "uid_1",
    "uid_2",
    "uid_3",
    "uid_4",
    "uid_5",
    "uid_6",
    "uid_7",
    "uid_8",
    "uid_9",
    "uid_10",
    "supv_uid",
    "reason",
    "uid_11",
]