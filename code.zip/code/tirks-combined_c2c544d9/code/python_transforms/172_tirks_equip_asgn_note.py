from transforms.api import transform_df, Input, Output, incremental
import pyspark.sql.functions as F


@transform_df(
    Output("/Innovation Lab/[ETL] Tirks Combined/data/172_tirks_equip_asgn_note"),
    asi=Input("/Innovation Lab/[Source] Teradata EDW - ASI_VIEWS/data/clean/vcan172_tirks_equip_asgn_note"),
    telco=Input("/Innovation Lab/[Source] Teradata EDW - ACCESS_VIEWS/data/prod_clean/vctn172_tirks_equip_asgn_note"),
)
def my_compute_function(telco, asi):
    telco = telco.withColumn("source", F.lit('telco'))
    asi = asi.withColumn("source", F.lit('asi'))
    df = telco.unionByName(asi)
    return df
