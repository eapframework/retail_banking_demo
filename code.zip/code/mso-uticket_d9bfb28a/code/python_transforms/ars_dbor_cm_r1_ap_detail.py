from transforms.api import transform, Input, Output
from utility.column_clean import clean_columns, lowercase_columns, remove_prefix
from ..utils import perform_timestamp_parsing


@transform(
   out=Output("/Innovation Lab/[Source] Oracle ESAR/data/clean/ars_dbor_cm_r1.ap_detail"),
   df=Input("/Innovation Lab/[Source] Oracle ESAR/data/raw/Prod/snowflake/esaars_dbor_cm_rviews.ap_detail_snowflake"),
)
def my_compute_function(df, out):
    df = clean_columns(
        df.dataframe(),
        strip_columns=strip_columns,
        integer_columns=cast_to_integer_columns,
        double_columns=cast_to_double_columns,
        decimal_columns=cast_to_decimal_columns,
        timestamp_columns=cast_to_timestamp_from_long_columns,
        datetime_columns=cast_to_timestamp_columns,
        datetime_format=datetime_format,
        date_columns=cast_to_date_columns,
        date_format=date_format,
        id_columns=cast_to_string_columns,
        integer_from_num_columns=cast_to_integer_from_decimal_columns
    )
    for column in cast_to_integer_columns:
        df = df.withColumn(column, df[column].cast("decimal").alias(column))
    for column in float_column:
        df = df.withColumn(column, df[column].cast("decimal").alias(column))
    df = lowercase_columns(df)
    df = perform_timestamp_parsing(df)
    out.write_dataframe(df)

date_format = 'yyyy-MM-dd'
datetime_format = 'yyyy-MM-dd HH:mm:ss'

cast_to_date_columns = []
cast_to_timestamp_columns = []
cast_to_timestamp_from_long_columns = ['CREATE_DATE_DTL', "MODIFIED_DATE_DTL"] #COMPLETED 
float_column = [
    "REAL_FIELD_1",
    "REAL_FIELD_2",
    "DECIMAL_FIELD_1",
    "DECIMAL_FIELD_2"
]

cast_to_integer_columns = [
    "SEQNO",
    "STATUS_DTL",
    "PRIORITY",
    "LEVEL_X",
    "APPROVAL_METHOD",
    "INTEGER_FIELD_1",
    "INTEGER_FIELD_2",
    "STATISTICAL_OVERRIDE",
    "ORDER_X"

]
cast_to_double_columns = []
cast_to_decimal_columns = []
cast_to_string_columns = []
cast_to_integer_from_decimal_columns = []
strip_columns = []
