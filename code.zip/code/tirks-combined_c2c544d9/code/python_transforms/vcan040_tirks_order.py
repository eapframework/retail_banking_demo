from transforms.api import transform, Input, Output, incremental
from utility.column_clean import clean_columns, lowercase_columns, remove_prefix


@transform(
    out=Output("/Innovation Lab/[Source] Teradata EDW - ASI_VIEWS/data/clean/vcan040_tirks_order"),
    df=Input("/Innovation Lab/[Source] Teradata EDW - ASI_VIEWS/data/raw/snowflake/VCAN040_TIRKS_ORDER"),
)
def my_compute_function(df, out):
    df = clean_columns(
        df.dataframe(),
        date_format=date_format, 
        date_columns=string_to_date,
        datetime_format=datetime_format, 
        datetime_columns=long_unixtime_to_timestamp,
        timestamp_from_string_format=string_unixtime_format,
        timestamp_from_string_columns=string_unixtime_to_timestamp,
        timestamp_format=long_unixtime_format, 
        timestamp_columns=long_unixtime_to_timestamp,
        integer_columns=string_to_integer_columns,
        double_columns=string_to_double_columns,
        decimal_columns=string_to_decimal_columns,
        id_columns=numeric_to_string_columns,
        integer_from_num_columns=decimal_to_integer,
        strip_columns=strip_string_columns,
    )
    # df = df.drop(*drop_columns)
    # df = remove_prefix(df, 'example_prefix')
    for col in convert_to_short_columns:
        df = df.withColumn(col, df[col].cast("short"))
    df = lowercase_columns(df)
    df = df.drop_duplicates()
    out.write_dataframe(df)


'''
The following columns are non-string types however their names suggest they are identifier columns. 
Consider adding these columns to the numeric_to_string_columns list below.
    "ORD_APP_DT_TO_ORD_TRID_OBJ_QTY",
    "ORD_RID_ACT_TO_ORD_DD_ACT_QTY",
    "ORD_RID_ACTL_TO_ORD_DD_OBJ_QTY",
    "ORD_RID_ACT_TO_ORD_RID_RPT_QTY",
    "ORD_RID_OBJ_TO_ORD_RID_ACT_QTY",
    "ORD_RID_OBJ_TO_ORD_RID_RPT_QTY",
    "ORD_SID_ACT_TO_ORD_SID_RCV_QTY",
    "ORD_SID_OBJ_TO_ORD_LAM_OBJ_QTY",
    "ORD_SID_OBJ_TO_ORD_RID_OBJ_QTY",
    "ORD_SID_OBJ_TO_ORD_SID_ACT_QTY",
    "ORD_SID_OBJ_TO_ORD_SID_RCV_QTY",

'''


drop_columns = []

date_format = 'yyyy-MM-dd'
string_to_date = []
datetime_format = 'yyyy-MM-dd HH:mm:ss'
string_to_timestamp = []

string_unixtime_format = None
string_unixtime_to_timestamp = []
long_unixtime_format = None
long_unixtime_to_timestamp = []

string_to_integer_columns = []
string_to_double_columns = []
string_to_decimal_columns = []

numeric_to_string_columns = []
decimal_to_integer = []

strip_string_columns = [
    "SBC_COMPANY_CD",
    "SBC_SYSTEM_CD",
    "SBC_STATE_CD",
    "CIRCUIT_LAYOUT_ORDER_BASE_NBR",
    "ORDER_NBR",
    "ORDER_SUPPLEMENT_ID",
    "ORDER_SUPPLEMENT_QTY",
    "RELATED_ORDER_NBR",
    "INTERCOMPANY_SVCS_COORDNT_CD",
    "ORDER_TYPE_CD",
    "DETAILED_IDNTFCN_BY_ORD_CLS_CD",
    "ORDER_CANCELLED_IND",
    "ORDER_IN_EFFECT_IND",
    "ORDER_STATUS_CD",
    "ORDER_ORIGINATOR_CD",
    "ORDER_CUSTOMER_NM",
    "CIRCUIT_CONTROL_OFFICE_CD",
    "ENGINEERING_CONTROL_OFFICE_CD",
    "OVERALL_CONTROL_OFFICE_CD",
    "TRAFFIC_REPORTING_OFFICE_CD",
    "WRITING_CONTROL_OFFICE_CD",
    "REPORT_ACCESS_CD",
    "MULTIPLE_RPTG_OFFICE_NBR_1_CD",
    "MULTIPLE_RPTG_OFFICE_NBR_2_CD",
    "MULTIPLE_RPTG_OFFICE_NBR_3_CD",
    "WORK_GROUP_CD",
    "CIRCUIT_GROUP_ACCESS_CD",
    "ENGINEERING_COORDINATION_CD",
    "PLANT_COORDINATOR_CD",
    "EXTERNAL_SYSTEM_SWITCH_CD",
    "NO_DSGN_NO_FIELD_WORK_RQRD_CD",
    "NPA_CD",
    "ORDER_REMARKS_TXT",
    "LATA_STATE_CD",
    "LATA_CD",
    "ACNA_CD",
    "EXACT_ACCESS_SERVICE_REQ_ID",
    "CUST_CARRIER_NAME_ABRVTN_CD",
    "PURCHASE_ORDER_NBR",
    "PLUGIN_INVEN_CTRL_SYS_JOB_ID",
    "TIRKS_PROJECT_NBR",
    "ORDER_LOGGING_SYSTEM_SOURCE_CD",
    "DISCONNECT_ORDER_PROCESSING_CD",
    "PROCESS_CTRL_FEATURE_OVRD_CD",
    "ORDER_ISSUE_MISSED_FUNCTION_CD",
    "ORD_ISSUE_DATE_INIT_JPRDY_1_CD",
    "ORD_ISSUE_DATE_INIT_JPRDY_2_CD",
    "ORD_ISSUE_DATE_INIT_JPRDY_3_CD",
    "ORD_REC_ISS_MISSED_FUNCTION_CD",
    "ORD_REC_ISS_DT_INIT_JPRDY_1_CD",
    "ORD_REC_ISS_DT_INIT_JPRDY_2_CD",
    "ORD_REC_ISS_DT_INIT_JPRDY_3_CD",
    "ORDER_DUE_DATE_MODIFIER_CD",
    "ORDER_DUE_DATE_MISSED_FUNC_CD",
    "ORDER_DUE_DATE_INIT_JPRDY_1_CD",
    "ORDER_DUE_DATE_INIT_JPRDY_2_CD",
    "ORDER_DUE_DATE_INIT_JPRDY_3_CD",
    "ORDER_DUE_DT_COMPLTN_INTLS_NM",
]

convert_to_short_columns = ["ITEM_QTY",
"ITEMS_PENDING_COMPLETION_QTY",
"ORD_APP_DT_TO_ORD_TRID_OBJ_QTY",
"ORD_APPL_DT_TO_ORD_DD_ACTL_QTY",
"ORD_APPL_DT_TO_ORD_DD_OBJ_QTY",
"ORD_APPL_DT_TO_ORD_DD_RPTD_QTY",
"ORD_APPL_DT_TO_ORD_DVA_OBJ_QTY",
"ORD_APPL_DT_TO_ORD_LAM_OBJ_QTY",
"ORD_APPL_DT_TO_ORD_WOT_OBJ_QTY",
"ORD_DD_OBJ_TO_ORD_DD_ACTL_QTY",
"ORD_RID_ACT_TO_ORD_DD_ACT_QTY",
"ORD_RID_ACT_TO_ORD_RID_RPT_QTY",
"ORD_RID_ACTL_TO_ORD_DD_OBJ_QTY",
"ORD_RID_OBJ_TO_ORD_RID_ACT_QTY",
"ORD_RID_OBJ_TO_ORD_RID_RPT_QTY",
"ORD_SID_ACT_TO_ORD_SID_RCV_QTY",
"ORD_SID_OBJ_TO_ORD_LAM_OBJ_QTY",
"ORD_SID_OBJ_TO_ORD_RID_OBJ_QTY",
"ORD_SID_OBJ_TO_ORD_SID_ACT_QTY",
"ORD_SID_OBJ_TO_ORD_SID_RCV_QTY"]