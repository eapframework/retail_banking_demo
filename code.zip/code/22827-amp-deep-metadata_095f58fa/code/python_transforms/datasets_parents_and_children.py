from transforms.api import transform, Input, Output

# Imports from other files in this repo
from myproject.utils.global_code import *

# Spark utils
from pyspark.sql import functions as F
import pyspark.sql.types as T


@transform(
    datasets_parents_and_children=Output(
        "ri.foundry.main.dataset.eab7db73-feae-414d-9066-c4d0db6b864c",
        sever_permissions=True,
    ),
    all_platform_data=Input(f"{PARENT_FOLDER}/all_platform_data"),
    config=Input("ri.foundry.main.dataset.b5cb343e-1109-4401-b3fb-5137c32cb781"),
)
def datasets_parents_and_children(
    ctx, all_platform_data, config, datasets_parents_and_children
):
    headers = get_header(config)
    BATCH_SIZE = 1000

    output = []
    all_platform_data = (
        all_platform_data.dataframe()
        .filter(F.col("trashed") == False)
        .filter(~(F.col("dataset_path").contains("/Users/")))
    )
    rids = [
        row["dataset_rid"] for row in all_platform_data.select("dataset_rid").collect()
    ]  # noqa

    all_parents = {}
    all_children = {}
    for batch in partition(rids, BATCH_SIZE):
        body = {
            "datasetRids": batch,
            "branchFallbacks": {"branches": []},
            "datasetRidsToIgnore": [],
            "depth": 1,
        }
        get_parents = session.post(
            "{}/jobspecs/branches/master/upstream-jobspec-nodes".format(BUILD2_URI),
            headers=headers,
            json=body,
        ).json()
        get_children = session.post(
            "{}/jobspecs/branches/master/downstream-jobspecs".format(BUILD2_URI),
            headers=headers,
            json=body,
        ).json()

        for obj in get_parents:
            parents = [inp for inp in obj["inputs"] if DATASET_RID_REGEX_OBJ.match(inp)]
            job_output_dataset_rids_only = [
                out for out in obj["outputs"] if DATASET_RID_REGEX_OBJ.match(out)
            ]
            """
            Note that a job may have multiple output datasets. Set all outputs of a job to have all parents here.
            Alternative would be to check whether we've already written the parents for a particular dataset rid
            in a previous API call, and ignore it here
            TODO(ddavies): this should probably use the links API
            """
            for output_dataset_rid in job_output_dataset_rids_only:
                all_parents[output_dataset_rid] = parents

        for job in get_children:
            is_valid = True
            try:
                maybe_root_application = job["jobSpec"]["computationParameters"].get(
                    "rootApplication", None
                )
                is_valid = not (
                    maybe_root_application and maybe_root_application == "data-health"
                )
            except:
                is_valid = False

            if not is_valid:
                continue

            for inp in job["jobSpec"]["inputSpecs"]:
                inp_rid = inp["datasetLocator"]["datasetRid"]
                if inp_rid.startswith("ri.foundry.main.dataset"):
                    outputs = []
                    for output_dict in job["jobSpec"]["outputSpecs"]:
                        output_rid = output_dict["datasetLocator"]["datasetRid"]
                        if output_rid.startswith("ri.foundry.main.dataset"):
                            outputs.append(output_rid)
                    if inp_rid in all_children:
                        all_children[inp_rid].update(set(outputs))
                    else:
                        all_children[inp_rid] = set(outputs)

    for rid in rids:
        output.append(
            {
                "dataset_rid": rid,
                "parents": all_parents[rid] if rid in all_parents else [],
                "children": list(all_children[rid]) if rid in all_children else [],
            }
        )

    schema = T.StructType(
        [
            T.StructField("dataset_rid", T.StringType()),
            T.StructField("children", T.ArrayType(T.StringType())),
            T.StructField("parents", T.ArrayType(T.StringType())),
        ]
    )
    df = ctx.spark_session.createDataFrame(output, schema=schema)
    datasets_parents_and_children.write_dataframe(df)
