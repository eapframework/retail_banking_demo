from pydantic_settings import BaseSettings, SettingsConfigDict
import os

# For local development, load .env if present
# In Databricks Apps, environment variables come from app.yaml
if os.path.exists(".env"):
    from dotenv import load_dotenv
    load_dotenv()


class Settings(BaseSettings):
    """Application configuration loaded from environment variables.

    In Databricks Apps deployment, these come from app.yaml.
    For local development, they can be set in .env file.

    - PROJECT_NAME: Title shown in the OpenAPI/Swagger docs.
    - API_V1_STR: API base path prefix.
    - ALLOWED_ORIGINS: List of origins allowed by CORS.
    - STORAGE_BACKEND: "delta" or "inmemory".
    """

    PROJECT_NAME: str = "Magical Index"
    API_V1_STR: str = "/api/v1"
    ALLOWED_ORIGINS: list[str] = ["*"]
    STORAGE_BACKEND: str = "delta"

    # Pydantic v2 settings config: read from environment, ignore unknown vars
    # No longer requires .env file - works with app.yaml env vars
    model_config = SettingsConfigDict(extra="ignore")


settings = Settings()
