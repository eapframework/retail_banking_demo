from os import path

from pyspark.sql import functions as F
from pyspark.sql import types as T
from transforms.api import Input, Output, incremental, transform

from metrics.foundry.files import read_files


def extract_sql_server_logs_from_files(metrics_folder, raw_event_log_folder):
    @incremental(semantic_version=1, require_incremental=True)
    @transform(
        sql_server_logs=Output(path.join(metrics_folder, "raw/foundry_sql_server/sql_server_event_logs")),
        sql_server_files=Input(path.join(raw_event_log_folder, "foundry_sql_server_event_logs")),
        fit_sql_server_logs=Input("ri.foundry.main.dataset.c1633f0d-2029-494e-8b47-23ac1bc7893f"),
    )
    def compute(ctx, sql_server_logs, sql_server_files, fit_sql_server_logs):
        sql_server_logs_df = sql_server_logs.dataframe("previous", schema=logs_schema)
        max_time = (
            sql_server_logs_df.withColumn(
                "time",
                F.from_json(
                    F.col("row"),
                    schema=T.StructType([
                        T.StructField("values", T.StringType()),
                        T.StructField("type", T.StringType()),
                        T.StructField("eventName", T.StringType()),
                        T.StructField("time", T.StringType()),
                        T.StructField("uid", T.StringType()),
                        T.StructField("tokenId", T.StringType()),
                        T.StructField("traceId", T.StringType()),
                        T.StructField("unsafeParams", T.StringType()),
                        T.StructField("tags", T.StringType())
                    ]),
                ).getField("time"),
            )
            .agg(F.max(F.col("time")).alias("time"))
            .collect()[0]["time"]
        )
        df = read_files(sql_server_files, compression="gzip", catch_decoding_errors=True)
        sql_server_logs.write_dataframe(
            (
                df.filter(F.col("error").isNull())
                .drop("error")
                .unionByName(
                    fit_sql_server_logs.dataframe()
                    .withColumn("filename", F.lit(None).cast(T.StringType()))
                    .filter(F.col("time") > max_time)
                    .drop("time", "event_name")
                    .withColumnRenamed("values", "row")
                )
            )
        )

    return compute


logs_schema = T.StructType([T.StructField("filename", T.StringType()), T.StructField("row", T.StringType())])
