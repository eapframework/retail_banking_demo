from transforms.api import transform, Input, Output, incremental, configure
import pyspark.sql.functions as func
from pyspark.sql.types import StructType, StructField, StringType, DateType, IntegerType, LongType, DoubleType, TimestampType
from pyspark.sql.functions import max as pymax
import logging
from pyspark.sql import DataFrame
from functools import reduce
from pyspark.sql import types as T

log = logging.getLogger(__name__)
# Defining the schema for target dataset
schema = T.StructType([
    T.StructField('uid', T.StringType(), True),
    T.StructField('f_name', T.StringType(), True),
    T.StructField('u_f_name',  T.StringType(), True),
    T.StructField('m_name',  T.StringType(), True),
    T.StructField('l_name',  T.StringType(), True),
    T.StructField('company_code',  T.StringType(), True),
    T.StructField('work_addr1',  T.StringType(), True),
    T.StructField('work_addr2',  T.StringType(), True),
    T.StructField('work_city',  T.StringType(), True),
    T.StructField('work_state',  T.StringType(), True),
    T.StructField('work_zip',  T.StringType(), True),
    T.StructField('work_zip_plus4',  T.StringType(), True),
    T.StructField('work_country',  T.StringType(), True),
    T.StructField('work_bldg_code',  T.StringType(), True),
    T.StructField('work_county_code',  T.StringType(), True),
    T.StructField('work_phone',  T.StringType(), True),
    T.StructField('hire_date',  T.DateType(), True),
    T.StructField('ncs_date',  T.DateType(), True),
    T.StructField('emp_status_code',  T.StringType(), True),
    T.StructField('mgmt_level',  T.StringType(), True),
    T.StructField('bus_unit_id',  T.StringType(), True),
    T.StructField('bus_unit_desc',  T.StringType(), True),
    T.StructField('dept_id',  T.StringType(), True),
    T.StructField('dept_desc',  T.StringType(), True),
    T.StructField('org_id',  T.StringType(), True),
    T.StructField('org_desc',  T.StringType(), True),
    T.StructField('job_id',  T.StringType(), True),
    T.StructField('job_desc',  T.StringType(), True),
    T.StructField('rc',  T.StringType(), True),
    T.StructField('last_update_user_phone',  T.StringType(), True),
    T.StructField('last_update_date_phone',  T.TimestampType(), True),
    T.StructField('supv_uid',  T.StringType(), True),
    T.StructField('smtp',  T.StringType(), True),
    T.StructField('emp_classification',  T.StringType(), True),
    T.StructField('position_id',  T.StringType(), True),
    T.StructField('position_desc',  T.StringType(), True),
    T.StructField('location_code',  T.StringType(), True),
    T.StructField('vacant_supv_uid',  T.StringType(), True),
    T.StructField('bargained_indicator',  T.StringType(), True),
    T.StructField('bargained_unit',  T.StringType(), True),
    T.StructField('home_city',  T.StringType(), True),
    T.StructField('home_state',  T.StringType(), True),
    T.StructField('home_zip',  T.StringType(), True),
    T.StructField('job_function_code',  T.StringType(), True),
    T.StructField('hrid',  T.StringType(), True),
    T.StructField('datestamp',  T.DateType(), True),
    T.StructField('active',  T.StringType(), True),
    T.StructField('work_phone_cellular',  T.StringType(), True),
    T.StructField('pager_number',  T.StringType(), True),
    T.StructField('pager_pin',  T.StringType(), True),
    T.StructField('contractor',  T.StringType(), True)
    ])
# Change everything to fit the --transform decorator instead of the transform_df decorator, this should allow us to use the previous mode property to update an existing dataset


@configure(profile='rubix-sixteen-executors')
@incremental(snapshot_inputs=['cenet_stg', 'initial_load'])
@transform(
    cenet_stg=Input("ri.foundry.main.dataset.45561096-25ab-4e93-b01b-8f5077a5805b"),
    initial_load=Input("ri.foundry.main.dataset.f6e0ccf0-30fb-4ea3-b087-339070c1216a"),
    out=Output("ri.foundry.main.dataset.293d7d73-8e66-4221-89d6-a05b61aa34b6"),
)
def create(ctx, cenet_stg, initial_load, out):
    # create initial schema
    # set flag to false when doing initial load and set flag to true when doing incremental process
    # change to false when doing initial_load
    flag = True
    if flag:
        # Get source as is
        in_df = cenet_stg.dataframe("current")
        in_df = in_df.filter(func.isnull(in_df.attuid) == False)
        # Get the target dataset as of previous load 
        out_prev = out.dataframe(mode="previous", schema=schema)

        # Create a temporary view on I/P dataframe - to be used in SQL code
        in_df.createOrReplaceTempView("cenet_data")
        # Create a temporary view on O/P dataframe - to be used in SQL code
        out_prev.createOrReplaceTempView("current_scd2")

        # Brand new records coming in source
        df_new = ctx.spark_session.sql("""
        SELECT
            s.attuid as uid,
            s.first_name as f_name,
            s.unofficial_first_name as u_f_name,
            s.middle_name as m_name,
            s.last_name as l_name,
            s.company_code as company_code,
            s.work_street_addr_1 as work_addr1,
            s.work_street_addr_2 as work_addr2,
            s.work_city as work_city,
            s.work_state as work_state,
            s.work_zip as work_zip,
            s.work_zip_plus_4 as work_zip_plus4,
            s.work_country as work_country,
            s.work_building_code as work_bldg_code,
            s.work_county_code as work_county_code,
            s.work_phone as work_phone,
            s.hire_date as hire_date,
            s.ncs_date as ncs_date,
            s.emp_status_code as emp_status_code,
            s.mgt_level_indicator as mgmt_level,
            s.business_unit_id as bus_unit_id,
            s.business_unit_description as bus_unit_desc,
            s.department_id as dept_id,
            s.department_description as dept_desc,
            s.organization_id as org_id,
            s.organization_description as org_desc,
            s.job_key as job_id,
            s.job_description as job_desc,
            s.responsibility_code as rc,
            s.last_update_user_phone as last_update_user_phone,
            s.last_update_date_phone as last_update_date_phone,
            s.supervisor_attuid as supv_uid,
            s.smtp_address as smtp,
            s.emp_classification as emp_classification,
            s.position_id as position_id,
            s.position_description as position_desc,
            s.location_code as location_code,
            s.vacant_supervisor_ind as vacant_supv_uid,
            s.bargained_indicator as bargained_indicator,
            s.bargaining_unit as bargained_unit,
            s.home_city as home_city,
            s.home_state as home_state,
            s.home_zip as home_zip,
            s.dominant_job_function_code as job_function_code,
            s.hrid as hrid,
            CAST(from_utc_timestamp(current_timestamp(), 'PST') as DATE)  as datestamp,
            'Y' as active,
            s.work_phone_cellular as work_phone_cellular,
            s.pager_number as pager_number,
            s.pager_pin as pager_pin,
            s.consultant as contractor

        FROM     cenet_data s
                LEFT OUTER JOIN current_scd2 t
                    ON s.attuid = t.uid
        WHERE    t.uid IS NULL
        """
        )

        # Updated records coming from source
        df_updates_src = ctx.spark_session.sql("""
            SELECT
            s.attuid as uid,
            s.first_name as f_name,
            s.unofficial_first_name as u_f_name,
            s.middle_name as m_name,
            s.last_name as l_name,
            s.company_code as company_code,
            s.work_street_addr_1 as work_addr1,
            s.work_street_addr_2 as work_addr2,
            s.work_city as work_city,
            s.work_state as work_state,
            s.work_zip as work_zip,
            s.work_zip_plus_4 as work_zip_plus4,
            s.work_country as work_country,
            s.work_building_code as work_bldg_code,
            s.work_county_code as work_county_code,
            s.work_phone as work_phone,
            s.hire_date as hire_date,
            s.ncs_date as ncs_date,
            s.emp_status_code as emp_status_code,
            s.mgt_level_indicator as mgmt_level,
            s.business_unit_id as bus_unit_id,
            s.business_unit_description as bus_unit_desc,
            s.department_id as dept_id,
            s.department_description as dept_desc,
            s.organization_id as org_id,
            s.organization_description as org_desc,
            s.job_key as job_id,
            s.job_description as job_desc,
            s.responsibility_code as rc,
            s.last_update_user_phone as last_update_user_phone,
            s.last_update_date_phone as last_update_date_phone,
            s.supervisor_attuid as supv_uid,
            s.smtp_address as smtp,
            s.emp_classification as emp_classification,
            s.position_id as position_id,
            s.position_description as position_desc,
            s.location_code as location_code,
            s.vacant_supervisor_ind as vacant_supv_uid,
            s.bargained_indicator as bargained_indicator,
            s.bargaining_unit as bargained_unit,
            s.home_city as home_city,
            s.home_state as home_state,
            s.home_zip as home_zip,
            s.dominant_job_function_code as job_function_code,
            s.hrid as hrid,
            CAST(from_utc_timestamp(current_timestamp(), 'PST') as DATE)  as datestamp,
            CASE WHEN s.emp_status_code IN ('A', 'H', 'L') THEN 'Y' ELSE 'N' END as active,
            s.work_phone_cellular as work_phone_cellular,
            s.pager_number as pager_number,
            s.pager_pin as pager_pin,
            s.consultant as contractor

        FROM    cenet_data s
                INNER JOIN current_scd2 t
                ON s.attuid = t.uid
        WHERE
            NVL(s.first_name,  '') <>  NVL(t.f_name ,  '')
            OR NVL(s.unofficial_first_name,  '') <>  NVL(t.u_f_name ,  '')
            OR NVL(s.middle_name,  '') <>  NVL(t.m_name ,  '')
            OR NVL(s.last_name,  '') <>  NVL(t.l_name ,  '')
            OR NVL(s.company_code,  '') <>  NVL(t.company_code ,  '')
            OR NVL(s.work_street_addr_1,  '') <>  NVL(t.work_addr1 ,  '')
            OR NVL(s.work_street_addr_2,  '') <>  NVL(t.work_addr2 ,  '')
            OR NVL(s.work_city,  '') <>  NVL(t.work_city ,  '')
            OR NVL(s.work_state,  '') <>  NVL(t.work_state ,  '')
            OR NVL(s.work_zip,  '') <>  NVL(t.work_zip ,  '')
            OR NVL(s.work_zip_plus_4,  '') <>  NVL(t.work_zip_plus4 ,  '')
            OR NVL(s.work_country,  '') <>  NVL(t.work_country ,  '')
            OR NVL(s.work_building_code,  '') <>  NVL(t.work_bldg_code ,  '')
            OR NVL(s.work_county_code,  '') <>  NVL(t.work_county_code ,  '')
            OR NVL(s.work_phone,  '') <>  NVL(t.work_phone ,  '')
            OR NVL(s.hire_date,  '') <>  NVL(t.hire_date ,  '')
            OR NVL(s.ncs_date,  '') <>  NVL(t.ncs_date ,  '')
            OR NVL(s.emp_status_code,  '') <>  NVL(t.emp_status_code ,  '')
            OR NVL(s.mgt_level_indicator,  '') <>  NVL(t.mgmt_level ,  '')
            OR NVL(s.business_unit_id,  '') <>  NVL(t.bus_unit_id ,  '')
            OR NVL(s.business_unit_description,  '') <>  NVL(t.bus_unit_desc ,  '')
            OR NVL(s.department_id,  '') <>  NVL(t.dept_id ,  '')
            OR NVL(s.department_description,  '') <>  NVL(t.dept_desc ,  '')
            OR NVL(s.organization_id,  '') <>  NVL(t.org_id ,  '')
            OR NVL(s.organization_description,  '') <>  NVL(t.org_desc ,  '')
            OR NVL(s.job_key,  '') <>  NVL(t.job_id ,  '')
            OR NVL(s.job_description,  '') <>  NVL(t.job_desc ,  '')
            OR NVL(s.responsibility_code,  '') <>  NVL(t.rc ,  '')
            OR NVL(s.last_update_user_phone,  '') <>  NVL(t.last_update_user_phone ,  '')
            OR NVL(s.last_update_date_phone,  '') <>  NVL(t.last_update_date_phone ,  '')
            OR NVL(s.supervisor_attuid,  '') <>  NVL(t.supv_uid ,  '')
            OR NVL(s.smtp_address,  '') <>  NVL(t.smtp ,  '')
            OR NVL(s.emp_classification,  '') <>  NVL(t.emp_classification ,  '')
            OR NVL(s.position_id,  '') <>  NVL(t.position_id ,  '')
            OR NVL(s.position_description,  '') <>  NVL(t.position_desc ,  '')
            OR NVL(s.location_code,  '') <>  NVL(t.location_code ,  '')
            OR NVL(s.vacant_supervisor_ind,  '') <>  NVL(t.vacant_supv_uid ,  '')
            OR NVL(s.bargained_indicator,  '') <>  NVL(t.bargained_indicator ,  '')
            OR NVL(s.bargaining_unit,  '') <>  NVL(t.bargained_unit ,  '')
            OR NVL(s.home_city,  '') <>  NVL(t.home_city ,  '')
            OR NVL(s.home_state,  '') <>  NVL(t.home_state ,  '')
            OR NVL(s.home_zip,  '') <>  NVL(t.home_zip ,  '')
            OR NVL(s.dominant_job_function_code,  '') <>  NVL(t.job_function_code ,  '')
            OR NVL(s.hrid,  '') <>  NVL(t.hrid ,  '')
            OR NVL(CASE WHEN s.emp_status_code IN ('A', 'H', 'L') THEN 'Y' ELSE 'N' END ,  '') <>  NVL(t.active ,  '')
            OR NVL(s.work_phone_cellular,  '') <>  NVL(t.work_phone_cellular ,  '')
            OR NVL(s.pager_number,  '') <>  NVL(t.pager_number ,  '')
            OR NVL(s.pager_pin,  '') <>  NVL(t.pager_pin ,  '')
            OR NVL(s.consultant,  '') <>  NVL(t.contractor,  '')
        """
        )

        # Records with no changes
        df_no_updates_tgt = ctx.spark_session.sql("""
        SELECT
        t.uid,
        t.f_name,
        t.u_f_name,
        t.m_name,
        t.l_name,
        t.company_code,
        t.work_addr1,
        t.work_addr2,
        t.work_city,
        t.work_state,
        t.work_zip,
        t.work_zip_plus4,
        t.work_country,
        t.work_bldg_code,
        t.work_county_code,
        t.work_phone,
        t.hire_date,
        t.ncs_date,
        t.emp_status_code,
        t.mgmt_level,
        t.bus_unit_id,
        t.bus_unit_desc,
        t.dept_id,
        t.dept_desc,
        t.org_id,
        t.org_desc,
        t.job_id,
        t.job_desc,
        t.rc,
        t.last_update_user_phone,
        t.last_update_date_phone,
        t.supv_uid,
        t.smtp,
        t.emp_classification,
        t.position_id,
        t.position_desc,
        t.location_code,
        t.vacant_supv_uid,
        t.bargained_indicator,
        t.bargained_unit,
        t.home_city,
        t.home_state,
        t.home_zip,
        t.job_function_code,
        t.hrid,
        t.datestamp,
        t.active,
        t.work_phone_cellular,
        t.pager_number,
        t.pager_pin,
        t.contractor
        FROM    cenet_data s
                INNER JOIN current_scd2 t
                ON s.attuid = t.uid
        WHERE
                NVL(s.first_name,  '') =  NVL(t.f_name ,  '')
            AND NVL(s.unofficial_first_name,  '') =  NVL(t.u_f_name ,  '')
            AND NVL(s.middle_name,  '') =  NVL(t.m_name ,  '')
            AND NVL(s.last_name,  '') =  NVL(t.l_name ,  '')
            AND NVL(s.company_code,  '') =  NVL(t.company_code ,  '')
            AND NVL(s.work_street_addr_1,  '') =  NVL(t.work_addr1 ,  '')
            AND NVL(s.work_street_addr_2,  '') =  NVL(t.work_addr2 ,  '')
            AND NVL(s.work_city,  '') =  NVL(t.work_city ,  '')
            AND NVL(s.work_state,  '') =  NVL(t.work_state ,  '')
            AND NVL(s.work_zip,  '') =  NVL(t.work_zip ,  '')
            AND NVL(s.work_zip_plus_4,  '') =  NVL(t.work_zip_plus4 ,  '')
            AND NVL(s.work_country,  '') =  NVL(t.work_country ,  '')
            AND NVL(s.work_building_code,  '') =  NVL(t.work_bldg_code ,  '')
            AND NVL(s.work_county_code,  '') =  NVL(t.work_county_code ,  '')
            AND NVL(s.work_phone,  '') =  NVL(t.work_phone ,  '')
            AND NVL(s.hire_date,  '') =  NVL(t.hire_date ,  '')
            AND NVL(s.ncs_date,  '') =  NVL(t.ncs_date ,  '')
            AND NVL(s.emp_status_code,  '') =  NVL(t.emp_status_code ,  '')
            AND NVL(s.mgt_level_indicator,  '') =  NVL(t.mgmt_level ,  '')
            AND NVL(s.business_unit_id,  '') =  NVL(t.bus_unit_id ,  '')
            AND NVL(s.business_unit_description,  '') =  NVL(t.bus_unit_desc ,  '')
            AND NVL(s.department_id,  '') =  NVL(t.dept_id ,  '')
            AND NVL(s.department_description,  '') =  NVL(t.dept_desc ,  '')
            AND NVL(s.organization_id,  '') =  NVL(t.org_id ,  '')
            AND NVL(s.organization_description,  '') =  NVL(t.org_desc ,  '')
            AND NVL(s.job_key,  '') =  NVL(t.job_id ,  '')
            AND NVL(s.job_description,  '') =  NVL(t.job_desc ,  '')
            AND NVL(s.responsibility_code,  '') =  NVL(t.rc ,  '')
            AND NVL(s.last_update_user_phone,  '') =  NVL(t.last_update_user_phone ,  '')
            AND NVL(s.last_update_date_phone,  '') =  NVL(t.last_update_date_phone ,  '')
            AND NVL(s.supervisor_attuid,  '') =  NVL(t.supv_uid ,  '')
            AND NVL(s.smtp_address,  '') =  NVL(t.smtp ,  '')
            AND NVL(s.emp_classification,  '') =  NVL(t.emp_classification ,  '')
            AND NVL(s.position_id,  '') =  NVL(t.position_id ,  '')
            AND NVL(s.position_description,  '') =  NVL(t.position_desc ,  '')
            AND NVL(s.location_code,  '') =  NVL(t.location_code ,  '')
            AND NVL(s.vacant_supervisor_ind,  '') =  NVL(t.vacant_supv_uid ,  '')
            AND NVL(s.bargained_indicator,  '') =  NVL(t.bargained_indicator ,  '')
            AND NVL(s.bargaining_unit,  '') =  NVL(t.bargained_unit ,  '')
            AND NVL(s.home_city,  '') =  NVL(t.home_city ,  '')
            AND NVL(s.home_state,  '') =  NVL(t.home_state ,  '')
            AND NVL(s.home_zip,  '') =  NVL(t.home_zip ,  '')
            AND NVL(s.dominant_job_function_code,  '') =  NVL(t.job_function_code ,  '')
            AND NVL(s.hrid,  '') =  NVL(t.hrid ,  '')
            AND NVL(CASE WHEN s.emp_status_code IN ('A', 'H', 'L') THEN 'Y' ELSE 'N' END ,  '') =  NVL(t.active ,  '')
            AND NVL(s.work_phone_cellular,  '') =  NVL(t.work_phone_cellular ,  '')
            AND NVL(s.pager_number,  '') =  NVL(t.pager_number ,  '')
            AND NVL(s.pager_pin,  '') =  NVL(t.pager_pin ,  '')
            AND NVL(s.consultant,  '') =  NVL(t.contractor,  '')
        """
        )

        # Records in target but not in source
        df_tgt_no_src = ctx.spark_session.sql("""
        SELECT
        t.uid,
        t.f_name,
        t.u_f_name,
        t.m_name,
        t.l_name,
        t.company_code,
        t.work_addr1,
        t.work_addr2,
        t.work_city,
        t.work_state,
        t.work_zip,
        t.work_zip_plus4,
        t.work_country,
        t.work_bldg_code,
        t.work_county_code,
        t.work_phone,
        t.hire_date,
        t.ncs_date,
        t.emp_status_code,
        t.mgmt_level,
        t.bus_unit_id,
        t.bus_unit_desc,
        t.dept_id,
        t.dept_desc,
        t.org_id,
        t.org_desc,
        t.job_id,
        t.job_desc,
        t.rc,
        t.last_update_user_phone,
        t.last_update_date_phone,
        t.supv_uid,
        t.smtp,
        t.emp_classification,
        t.position_id,
        t.position_desc,
        t.location_code,
        t.vacant_supv_uid,
        t.bargained_indicator,
        t.bargained_unit,
        t.home_city,
        t.home_state,
        t.home_zip,
        t.job_function_code,
        t.hrid,
        CURRENT_DATE as datestamp,
        'N' as active,
        t.work_phone_cellular,
        t.pager_number,
        t.pager_pin,
        t.contractor
        FROM    current_scd2 t
                LEFT OUTER JOIN cenet_data s
                ON s.attuid = t.uid
        WHERE
        s.attuid IS NULL
        """
        )

        df_tgt_no_src = df_tgt_no_src.withColumn("datestamp", func.date_sub(func.current_date(), 1))


        # Combine all the data sets created above
        dfs = [df_new, df_updates_src, df_no_updates_tgt, df_tgt_no_src]
        df_tgt_final = reduce(DataFrame.unionAll, dfs)
        df_tgt_final = df_tgt_final.filter(func.isnull(df_tgt_final.uid) == False)
        out.set_mode("replace")
        out.write_dataframe(df_tgt_final)
    else:
        initial_load = initial_load.dataframe('current')
        # initial_load = initial_load.withColumn('last_update_date_phone', initial_load.last_update_date_phone.cast('Date'))
        out.set_mode("replace")
        out.write_dataframe(initial_load)
