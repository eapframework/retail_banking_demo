from transforms.api import transform, Input, Output,incremental,configure
from utility.column_clean import clean_columns, lowercase_columns, remove_prefix
from utility.incremental.update_insert import update_insert_core
from pyspark.sql import functions as F
from utility.incremental.timestamp_parsing import perform_timestamp_parsing
from myproject.datasets.utils import process_update_insert_core


@incremental(semantic_version=5)
@transform(
   out=Output("ri.foundry.main.dataset.ae0545f5-c03b-4292-961d-2e7459397e95"),
   updates=Input("ri.foundry.main.dataset.19b1503a-ffbf-4c9d-8381-b65db7da23dd"),
)
def my_compute_function(ctx, out, updates):
    updates = clean_columns(
        updates.dataframe(),
        timestamp_columns=cast_to_timestamp_from_long_columns,
        integer_columns=cast_to_integer_columns,
        datetime_format=datetime_format,
    )
    updates_df = perform_timestamp_parsing(updates)
    updates_df = lowercase_columns(updates_df)
    keys = ["med_record_id"]
    df = process_update_insert_core(ctx, out, updates_df, primary_keys=keys, order_cols=["modified_date"], return_df=True)
    out.write_dataframe(df)

date_format = 'yyyy-MM-dd'
datetime_format = 'yyyy-MM-dd HH:mm:ss'

cast_to_date_columns = []
cast_to_timestamp_columns = []
cast_to_timestamp_from_long_columns = ['CREATE_DATE', 'MODIFIED_DATE', 'PLANNED_START_DATE', 'PLANNED_END_DATE']
cast_to_integer_columns = []
cast_to_double_columns = []
cast_to_decimal_columns = []
cast_to_string_columns = []
cast_to_integer_from_decimal_columns = []
strip_columns = []
