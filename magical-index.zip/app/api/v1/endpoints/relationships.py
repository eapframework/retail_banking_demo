from __future__ import annotations

from typing import List

from fastapi import APIRouter, HTTPException, status

from app.schemas.relationship import (
    RelationshipCreate,
    RelationshipDelete,
    RelationshipRead,
)
from app.services.store import store


router = APIRouter()


@router.post("/", response_model=RelationshipRead, status_code=status.HTTP_201_CREATED)
def create_relationship(payload: RelationshipCreate) -> RelationshipRead:
    """Create a relationship (edge) between two resources, e.g., ``A FEEDS B``.

    Both resources must already exist; returns 422 if either is missing.
    Activity is recorded in the activity log via ``actor_type`` / ``actor_name``.
    """
    try:
        return store.create_relationship(payload)
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(exc)
        )


@router.post("/bidirectional", response_model=List[RelationshipRead], status_code=status.HTTP_201_CREATED)
def create_bidirectional_relationship(payload: RelationshipCreate) -> list[RelationshipRead]:
    """Create two FEEDS edges: upstream->downstream AND downstream->upstream.

    Both resources must already exist; returns 422 if either is missing.
    """
    try:
        forward = store.create_relationship(payload)
        reverse_payload = RelationshipCreate(
            upstream_resource_id=payload.downstream_resource_id,
            downstream_resource_id=payload.upstream_resource_id,
            relationship_type=payload.relationship_type,
            notes=payload.notes,
            actor_type=payload.actor_type,
            actor_name=payload.actor_name,
        )
        reverse = store.create_relationship(reverse_payload)
        return [forward, reverse]
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(exc)
        )


@router.delete("/", status_code=status.HTTP_200_OK)
def delete_relationship(payload: RelationshipDelete) -> dict[str, int]:
    """Delete a relationship by upstream/downstream (and optional type). Returns count."""
    deleted_count = store.delete_relationship(payload)
    if deleted_count == 0:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Relationship not found")
    return {"deleted": deleted_count}
