# from pyspark.sql import functions as F
from transforms.api import transform_df, Input, Output, configure
from .yr_oc_bin_usid_2to7 import bin_oc


@configure(profile=['EXECUTOR_MEMORY_LARGE', 'NUM_EXECUTORS_16'])
@transform_df(
    Output("ri.foundry.main.dataset.7633d27a-d6d7-474a-bf0f-a78b7bf94a5a"),
    summary1=Input("ri.foundry.main.dataset.5dbda0fe-8deb-482f-b454-6d3b38100be6"),
    summary8to12=Input("ri.foundry.main.dataset.73464244-edac-4ca8-8294-9e27575a2efd"),
    generator=Input('ri.foundry.main.dataset.9c457ebd-3eb9-4fb6-9acf-7bec66164458'), #contact: rf2635
)
def bin_oc_other(summary1, summary8to12, generator):
    summary = summary1.unionByName(summary8to12)
    return bin_oc(summary, generator)
