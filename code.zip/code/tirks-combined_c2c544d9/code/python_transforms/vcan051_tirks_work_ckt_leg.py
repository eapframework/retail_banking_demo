from transforms.api import transform, Input, Output, incremental
from utility.column_clean import clean_columns, lowercase_columns, remove_prefix


@transform(
    out=Output("/Innovation Lab/[Source] Teradata EDW - ASI_VIEWS/data/clean/vcan051_tirks_work_ckt_leg"),
    df=Input("/Innovation Lab/[Source] Teradata EDW - ASI_VIEWS/data/raw/snowflake/VCAN051_TIRKS_WORK_CKT_LEG"),
)
def my_compute_function(df, out):
    df = clean_columns(
        df.dataframe(),
        date_format=date_format, 
        date_columns=string_to_date,
        datetime_format=datetime_format, 
        datetime_columns=long_unixtime_to_timestamp,
        timestamp_from_string_format=string_unixtime_format,
        timestamp_from_string_columns=string_unixtime_to_timestamp,
        timestamp_format=long_unixtime_format, 
        timestamp_columns=long_unixtime_to_timestamp,
        integer_columns=string_to_integer_columns,
        double_columns=string_to_double_columns,
        decimal_columns=string_to_decimal_columns,
        id_columns=numeric_to_string_columns,
        integer_from_num_columns=decimal_to_integer,
        strip_columns=strip_string_columns,
    )
    # df = remove_prefix(df, 'example_prefix')
    for col in convert_to_short_columns:
        df = df.withColumn(col, df[col].cast("short"))
    df = lowercase_columns(df)
    df = df.drop(*drop_columns)
    out.write_dataframe(df)


drop_columns = ["dw_load_dt", "dw_load_tm", "dw_load_user", "dw_updt_ts", "dw_updt_user"]

date_format = 'yyyy-MM-dd'
string_to_date = []
datetime_format = 'yyyy-MM-dd HH:mm:ss'
string_to_timestamp = []

string_unixtime_format = None
string_unixtime_to_timestamp = []
long_unixtime_format = None
long_unixtime_to_timestamp = []

string_to_integer_columns = []
string_to_double_columns = []
string_to_decimal_columns = []

numeric_to_string_columns = []
decimal_to_integer = []

strip_string_columns = [
    "SBC_COMPANY_CD",
    "SBC_SYSTEM_CD",
    "SBC_STATE_CD",
    "CIRCUIT_LAYOUT_ORDER_BASE_NBR",
    "ITEM_NBR",
    "WORK_LOCATION_NBR",
    "CIRCUIT_IDENTIFICATION_CD",
    "ORDER_NBR",
    "ORDER_CUSTOMER_NM",
    "BULK_ITEM_TRACKING_IND",
    "DISCONNECT_ORDER_PROCESSING_CD",
    "WORK_LOCATION_CLLI_CD",
    "RELATED_ORDER_NBR",
    "TIRKS_PROJECT_NBR",
    "FLOW_THRU_SCRIPT_CD",
    "ORDER_LOGGING_SYSTEM_SOURCE_CD",
    "MECHANIZED_CUT_SHEET_CD",
    "FLOW_THRU_ATTEMPTED_CD",
    "FLOW_THRU_SUCCESS_CD",
    "FLOW_THRU_RQR_MAN_ASSTNC_CD",
    "FLOW_THRU_STATUS_CD",
    "RECORD_ISSUE_STATUS_CD",
    "DOC_LYT_REC_ISSUE_STATUS_CD",
    "RECORD_ISSUE_ATTEMPTED_CD",
    "RECORD_ISSUE_SUCCESS_CD",
    "RECORD_ISSUE_RQR_MAN_ASSTNC_CD",
    "DOC_LYT_REC_ISSUE_ATTEMPTED_CD",
    "DOC_LYT_REC_ISSUE_SUCCESS_CD",
    "DOC_LYT_ISS_RQR_MAN_ASSTNC_CD",
    "PROCESS_CTRL_FEATURE_RMKS_TXT",
]

convert_to_short_columns = ["DOC_LYT_REC_RQR_MAN_ASSTNC_QTY",
"FLOW_THRU_RQR_MAN_ASSTNC_QTY", "RECORD_ISS_RQR_MAN_ASSTNC_QTY"]