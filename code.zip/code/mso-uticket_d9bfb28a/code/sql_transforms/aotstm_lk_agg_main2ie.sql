CREATE TABLE `/Innovation Lab/[ETL] Ticketing/data/clean/aotstm_lk_agg_main2ie` AS
    SELECT ticket
    , concat_ws(',', collect_set(ie_distinct_active_org)) as ie_distinct_active_org
    , concat_ws(',', collect_set(ie_ticket)) as ie_distinct_ticket
    , concat_ws(',', collect_list(ie_human_pathway)) as ie_human_pathway
    , concat_ws(',', collect_set(ie_distinct_humans)) as ie_distinct_humans
    , concat_ws(',', collect_set(ie_distinct_supervisor_name)) as ie_distinct_supervisor_name
    , concat_ws(',', collect_set(ie_distinct_director_name)) as ie_distinct_director_name
    , concat_ws(',', collect_set(ie_distinct_avp_name)) as ie_distinct_avp_name
    , concat_ws(',', collect_set(ie_distinct_vp_name)) as ie_distinct_vp_name
    , concat_ws(',', collect_set(ie_distinct_svp_name)) as ie_distinct_svp_name
    , concat_ws(',', collect_set(ie_vp_org_name)) as ie_distinct_vp_org_name
    , concat_ws(',', collect_set(ie_first_human_touch)) as ie_distinct_first_human_touch
    , concat_ws(',', collect_set(ie_last_human_touch)) as ie_distinct_last_human_touch
    , sum(ie_total_human_touches) as ie_total_human_touches
    , concat_ws(',', collect_set(ie_work_queue)) as ie_distinct_work_queue
    , concat_ws(',', collect_set(ie_ticket_state)) as ie_distinct_ticket_state
    FROM `/Innovation Lab/[ETL] Ticketing/data/clean/aotstm_parent_ie_duplicate_view`
    GROUP BY ticket