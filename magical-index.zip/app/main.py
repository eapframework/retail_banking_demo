from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.api.v1 import api_router
from app.core.config import settings


app = FastAPI(
    title=settings.PROJECT_NAME,
    version="1.0.0",
    description=(
        "Magical Index: track resource lifecycle (discovered → extracted → transformed → "
        "deployed) and relationships (e.g., A FEEDS B). Designed for agents + humans."
    ),
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.ALLOWED_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(api_router, prefix=settings.API_V1_STR)


@app.get("/health")
def health_check() -> dict[str, str]:
    """Lightweight liveness probe used by local dev and app hosting."""
    return {"status": "healthy"}
