CREATE TABLE `/Innovation Lab/Data Governance/HaloE Upstart Role Mapping/all_haloe_upstart_groups` AS WITH

admin_roles as (
    SELECT
        Upstart_Role,
        Confirmed_Owner as Owner,
        Approver1,
        Approver2,
        Approver3,
        HaloE_Group,
        Role_Description
    FROM `/Innovation Lab/Data Governance/HaloE Upstart Role Mapping/HaloE Upstart Group Mappings - Administration Roles`
),

data_source_roles as (
    SELECT
        Upstart_Role,
        Confirmed_Owner as Owner,
        Approver1,
        Approver2,
        Approver3,
        HaloE_Group,
        Role_Description
    FROM `/Innovation Lab/Data Governance/HaloE Upstart Role Mapping/HaloE Upstart Group Mappings - Data Source Roles`
)

SELECT
    Upstart_Role,
    Confirmed_Owner as Owner,
    Approver1,
    Approver2,
    Approver3,
    HaloE_Group,
    Role_Description
FROM `/Innovation Lab/Data Governance/HaloE Upstart Role Mapping/HaloE Upstart Group Mappings - Use Cases`

UNION

SELECT * FROM admin_roles

UNION

SELECT * FROM data_source_roles