from transforms.api import transform, Input, Output, incremental
from utility.column_clean import clean_columns, lowercase_columns, remove_prefix


@transform(
    out=Output("/Innovation Lab/[Source] Teradata EDW - ASI_VIEWS/data/clean/vcan010_tirks_carrier_facility"),
    df=Input("/Innovation Lab/[Source] Teradata EDW - ASI_VIEWS/data/raw/snowflake/vcan010_tirks_carrier_facility"),
)
def my_compute_function(df, out):
    df = clean_columns(
        df.dataframe(),
        date_format=date_format, 
        date_columns=string_to_date,
        datetime_format=datetime_format, 
        datetime_columns=long_unixtime_to_timestamp,
        timestamp_from_string_format=string_unixtime_format,
        timestamp_from_string_columns=string_unixtime_to_timestamp,
        timestamp_format=long_unixtime_format, 
        timestamp_columns=long_unixtime_to_timestamp,
        integer_columns=string_to_integer_columns,
        double_columns=string_to_double_columns,
        decimal_columns=string_to_decimal_columns,
        id_columns=numeric_to_string_columns,
        integer_from_num_columns=decimal_to_integer,
        strip_columns=strip_string_columns,
    )
    # df = remove_prefix(df, 'example_prefix')
    for col in convert_to_short_columns:
        df = df.withColumn(col, df[col].cast("short"))
    df = lowercase_columns(df)
    # df = df.drop(*drop_columns)
    out.write_dataframe(df)


drop_columns = []

date_format = 'yyyy-MM-dd'
string_to_date = []
datetime_format = 'yyyy-MM-dd HH:mm:ss'
string_to_timestamp = []

string_unixtime_format = None
string_unixtime_to_timestamp = []
long_unixtime_format = None
long_unixtime_to_timestamp = []

string_to_integer_columns = []
string_to_double_columns = []
string_to_decimal_columns = []

numeric_to_string_columns = []
decimal_to_integer = []

strip_string_columns = [
    'ADMIN_CONTROLLING_OFFICE_CD',
    'ASSIGNMENT_RESPONSIBILITY_CD',
    'CARRIER_CIRCUIT_ACCESS_CD',
    'CARRIER_CKT_LAYOUT_ORDER_NBR',
    'CARRIER_DEDICATED_ROUTE_CD',
    'CARRIER_FACILITY_GROUP_CD',
    'CARRIER_FACILITY_VIEW_CD',
    'CARRIER_IDENTIFICATION_CD',
    'CARRIER_INVENTORY_STATUS_CD',
    'CARRIER_LOCATION_A_CLLI_CD',
    'CARRIER_LOCATION_A_Z_SWAP_IND',
    'CARRIER_LOCATION_Z_CLLI_CD',
    'CARRIER_NETWORK_IDNTFCN_CD',
    'CARRIER_RECORD_TYPE_CD',
    'CARRIER_SYSTEM_REMARKS_TXT',
    'CARRIER_SYSTEM_TYPE_CD',
    'CARRIER_TIMING_DESIGNATION_CD',
    'DETAILED_RGLTY_AREA_UPDATE_CD',
    'DETAILED_RGLTY_FACILITY_GRP_CD',
    'DIGITAL_DATA_SERVICE_IND',
    'DIGITAL_LOOP_CXR_SYS_TYPE_CD',
    'FACILITY_FUTURE_VIEW_IND',
    'FACILITY_ROUTING_SUBPATH_CD',
    'FACILITY_USE_CD',
    'FACILTIY_LNGTH_UNIT_OF_MEAS_CD',
    'FUTURE_VIEW_SEQUENCE_NBR',
    'LOC_A_EQUIP_FROM_E1_SUBSYS_IND',
    'LOC_A_EQUIPMENT_RELAY_RACK_CD',
    'LOC_A_FRAME_DATA_GENERATION_CD',
    'LOC_A_HUMAN_EQUIP_CTLG_ITEM_CD',
    'LOC_A_PACKAGE_BAY_EQUIPMENT_CD',
    'LOC_A_PKG_BAY_RELAY_RACK_CD',
    'LOC_Z_EQUIP_FROM_E1_SUBSYS_IND',
    'LOC_Z_EQUIPMENT_RELAY_RACK_CD',
    'LOC_Z_FRAME_DATA_GENERATION_CD',
    'LOC_Z_HUMAN_EQUIP_CTLG_ITEM_CD',
    'LOC_Z_PACKAGE_BAY_EQUIPMENT_CD',
    'LOC_Z_PKG_BAY_RELAY_RACK_CD',
    'LOCATION_A_ADMIN_AREA_CD',
    'LOCATION_A_CHANNEL_BANK_CD',
    'LOCATION_A_EQUIPMENT_UNIT_NBR',
    'LOCATION_A_FRAME_ID',
    'LOCATION_Z_ADMIN_AREA_CD',
    'LOCATION_Z_CHANNEL_BANK_CD',
    'LOCATION_Z_EQUIPMENT_UNIT_NBR',
    'LOCATION_Z_FRAME_ID',
    'MINIMUM_SVC_CHRG_CONTR_LEAS_CD',
    'MINIMUM_SVC_CHRG_CONTRACT_NBR',
    'OWNERSHIP_UPDATE_CD',
    'SBC_COMPANY_CD',
    'SBC_STATE_CD',
    'SBC_SYSTEM_CD',
    'SIGNALING_LINK_CD',
    'SYNCHRONIZATION_STRATUM_A_CD',
    'SYNCHRONIZATION_STRATUM_Z_CD',
    'TRANSMISSION_DIRECTION_CD',
    'TRANSMISSION_RATE_CD'
]

convert_to_short_columns = ["CARRIER_CHANNEL_RANGE_FROM_NBR",
"CARRIER_CHANNEL_RANGE_TO_NBR",
"CARRIER_CHANNEL_TOTAL_QTY",
"CARRIER_CHANNEL_TRUE_SPARE_QTY",
"CARRIER_CHANNELS_IN_USE_PCT",
"DIVERSE_CHANNEL_QTY"]