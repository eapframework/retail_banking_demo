from transforms.api import transform, Input, Output
from utility.column_clean import clean_columns, lowercase_columns


@transform(
    out=Output(
        "/Innovation Lab/[Source] Teradata EDW - ACCESS_VIEWS/data/clean/vctn174_tirks_trunk_group"
    ),
    df=Input(
        "/Innovation Lab/[Source] Teradata EDW - ACCESS_VIEWS/data/raw/snowflake/vctn174_tirks_trunk_group"
    ),
)
def my_compute_function(df, out):
    df = clean_columns(
        df.dataframe(),
        date_format=date_format,
        date_columns=string_to_date,
        datetime_format=datetime_format,
        datetime_columns=long_unixtime_to_timestamp,
        timestamp_from_string_format=string_unixtime_format,
        timestamp_from_string_columns=string_unixtime_to_timestamp,
        timestamp_format=long_unixtime_format,
        timestamp_columns=long_unixtime_to_timestamp,
        integer_columns=string_to_integer_columns,
        double_columns=string_to_double_columns,
        decimal_columns=string_to_decimal_columns,
        id_columns=numeric_to_string_columns,
        integer_from_num_columns=decimal_to_integer,
        strip_columns=strip_string_columns,
    )
    # df = df.drop(*drop_columns)
    # df = remove_prefix(df, 'example_prefix')
    df = lowercase_columns(df)
    out.write_dataframe(df)


drop_columns = []

date_format = "yyyy-MM-dd"
string_to_date = []
datetime_format = "yyyy-MM-dd HH:mm:ss"
string_to_timestamp = []

string_unixtime_format = None
string_unixtime_to_timestamp = []
long_unixtime_format = None
long_unixtime_to_timestamp = []

string_to_integer_columns = []
string_to_double_columns = []
string_to_decimal_columns = []

numeric_to_string_columns = []
decimal_to_integer = []

strip_string_columns = [
    "CIRCUIT_GROUP_ACCESS_CD",
    "CKT_GROUP_LOCATION_A_CLLI_CD",
    "CKT_GROUP_LOCATION_Z_CLLI_CD",
    "LOC_A_CLLI_TRUNK_NAME",
    "LOC_A_TRNK_GRP_CKT_LYT_ORD_NBR",
    "LOC_Z_CLLI_TRUNK_NAME",
    "LOC_Z_TRNK_GRP_CKT_LYT_ORD_NBR",
    "LOCATION_A_END_TRUNK_NBR",
    "LOCATION_A_START_TRUNK_NBR",
    "LOCATION_A_TRUNK_GROUP_NBR",
    "LOCATION_A_TRUNK_GROUP_VIEW_CD",
    "LOCATION_A_TRUNK_MEMBER_NBR",
    "LOCATION_Z_END_TRUNK_NBR",
    "LOCATION_Z_START_TRUNK_NBR",
    "LOCATION_Z_TRUNK_GROUP_NBR",
    "LOCATION_Z_TRUNK_GROUP_VIEW_CD",
    "LOCATION_Z_TRUNK_MEMBER_NBR",
    "SBC_COMPANY_CD",
    "SBC_STATE_CD",
    "SBC_SYSTEM_CD",
]
