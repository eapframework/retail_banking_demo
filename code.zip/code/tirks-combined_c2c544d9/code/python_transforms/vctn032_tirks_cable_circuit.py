from pyspark.sql import functions as F
from transforms.api import transform, Input, Output, incremental
from utility.column_clean import clean_columns, lowercase_columns, remove_prefix
from pyspark.sql.functions import col


@transform(
    out=Output(
        "/Innovation Lab/[Source] Teradata EDW - ACCESS_VIEWS/data/prod_clean/vctn032_tirks_cable_circuit"
    ),
    df=Input(
        "/Innovation Lab/[Source] Teradata EDW - ACCESS_VIEWS/data/raw/snowflake/ACCESS_VIEWS.VCTN032_TIRKS_CABLE_CIRCUIT"
    ),
)
def my_compute_function(df, out):
    df = df.dataframe().withColumn(
        "CIRCUIT_IDENTIFICATION_CD_RAW", F.col("CIRCUIT_IDENTIFICATION_CD")
    )
    df = clean_columns(
        df,
        date_format=date_format,
        date_columns=string_to_date,
        datetime_format=datetime_format,
        datetime_columns=long_unixtime_to_timestamp,
        timestamp_from_string_format=string_unixtime_format,
        timestamp_from_string_columns=string_unixtime_to_timestamp,
        timestamp_format=long_unixtime_format,
        timestamp_columns=long_unixtime_to_timestamp,
        integer_columns=string_to_integer_columns,
        double_columns=string_to_double_columns,
        decimal_columns=string_to_decimal_columns,
        id_columns=numeric_to_string_columns,
        integer_from_num_columns=decimal_to_integer,
        strip_columns=strip_string_columns,
    )
    df = lowercase_columns(df)
    df = df.withColumn(
        "cable_header_sequence_nbr", col("cable_header_sequence_nbr").cast("short")
    )
    df = df.withColumn(
        "cable_subdivision_sequence_nbr",
        col("cable_subdivision_sequence_nbr").cast("short"),
    )
    df = df.withColumn(
        "circuit_assignment_seq_nbr", col("circuit_assignment_seq_nbr").cast("short")
    )
    out.write_dataframe(df)


drop_columns = []

date_format = "yyyy-MM-dd"
string_to_date = []
datetime_format = "yyyy-MM-dd HH:mm:ss"
string_to_timestamp = []

string_unixtime_format = None
string_unixtime_to_timestamp = []
long_unixtime_format = None
long_unixtime_to_timestamp = []

string_to_integer_columns = []
string_to_double_columns = []
string_to_decimal_columns = []

numeric_to_string_columns = []
decimal_to_integer = []

strip_string_columns = [
    "SBC_COMPANY_CD",
    "SBC_SYSTEM_CD",
    "CABLE_LOCATION_A_CLLI_CD",
    "CABLE_LOCATION_Z_CLLI_CD",
    "CABLE_ID",
    "CABLE_LAST_UNIT_RANGE_NBR",
    "CABLE_UNIT_NBR",
    "SBC_STATE_CD",
    "CBL_SUBDIVISION_FROM_WIRE_NBR",
    "CBL_SUBDIVISION_THRU_WIRE_NBR",
    "PRIMARY_ALTERNATE_ASGNMT_CD",
    "CIRCUIT_ASSIGNMENT_ACTIVITY_CD",
    "CIRCUIT_LAYOUT_ORDER_NBR",
    "CKT_LYT_ORD_ACTIVITY_STATUS_CD",
    "CIRCUIT_ACCESS_CD",
    "CKT_IDENTIFICATION_FORMAT_CD",
    "CIRCUIT_IDENTIFICATION_CD",
    "CIRCUIT_LOCATION_A_CLLI_CD",
    "CIRCUIT_LOCATION_Z_CLLI_CD",
    "DETAILED_RGLTY_CKT_LYT_ORD_CD",
    "ASSIGNMENT_MISUSE_CD",
    "MULTIWIRE_CIRCUIT_CD",
    "CIRCUIT_GROUP_ACCESS_CD",
    "ASSIGNMENT_RESPONSIBILITY_CD",
    "FACILITY_DETAIL_CD",
]
