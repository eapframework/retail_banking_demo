CREATE TABLE `ri.foundry.main.dataset.7cb0fe13-0c7a-4c2c-b0d4-f7aadd75f1ae` AS
    SELECT ticket_number, last(after_hours_indicator) after_hours_indicator
    FROM (
        SELECT ticket_number, new_value after_hours_indicator, new_date_time
        FROM `ri.foundry.main.dataset.edfda3bc-b10d-4c84-8f1c-cf918094c33b`
        WHERE field_changed="After Hours Indicator"
        ORDER BY new_date_time
    ) subquery
    group by ticket_number
    