from transforms.api import transform_df, Input, Output
from pyspark.sql import functions as F
from pyspark.sql.types import StringType
from .oc_mou_sector import oc_mou_backup_level_month

@transform_df(
    Output("ri.foundry.main.dataset.561b4437-a668-4f20-9c15-8af9d3eb4af8"),
    latest_month_iqi=Input("ri.foundry.main.dataset.5dbda0fe-8deb-482f-b454-6d3b38100be6"),
)
def oc_mou_usid(latest_month_iqi):
    """
    Calculate overlapping coverage based on minute of usage at USID level
    Output only include latest month
    """
    ecgi_map = latest_month_iqi.select(
        "ecgi_full",
        F.col("usid").cast(StringType())
    ).dropDuplicates()
    return oc_mou_backup_level_month(latest_month_iqi, backup_level='usid', ecgi_map=ecgi_map, failed_backup=[])
