from transforms.api import transform, Input, Output
from quantum_api_ingest.foundry.magritte import MagritteClient
from quantum_api_ingest.foundry.get_config import get_config
from pyspark.sql.types import StringType, StructField, StructType


schema = StructType([
    StructField('sourceRid', StringType()),
    StructField('agentRid', StringType())
])


@transform(
    output=Output("ri.foundry.main.dataset.29dc30fc-6fce-45a6-90b3-740a182436fd", sever_permissions=True),
    sources=Input("ri.foundry.main.dataset.f69ab92a-fec9-4324-a3a3-ef45517d914a"),
    config=Input("ri.foundry.main.dataset.b5cb343e-1109-4401-b3fb-5137c32cb781")
)
def compute(ctx, output, sources, config):
    magritte_coordinator = MagritteClient(get_config(config))
    result = []

    rids = [row.rid for row in sources.dataframe().select("rid").collect()]

    for rid in rids:
        try:
            agents = magritte_coordinator.get_source_agents(rid)
        except:
            continue
        for agentRid in agents:
            result.append({
                'sourceRid': rid,
                'agentRid': agentRid
            })

    output.write_dataframe(ctx.spark_session.createDataFrame(result, schema))
