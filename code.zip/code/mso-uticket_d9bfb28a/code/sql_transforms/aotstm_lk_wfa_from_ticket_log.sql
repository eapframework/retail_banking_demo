CREATE TABLE `/Innovation Lab/[ETL] Ticketing/logic/aotstm/aotstm_lk_wfa_from_ticket_log` AS
    SELECT ticket_nb as ticket, regexp_extract(ticket_message, '([W][A-Z][A-Z][A-Z][A-Z][0-9][0-9][0-9][0-9][0-9][0-9])', 1) as wfa_ticket 
     FROM `/Innovation Lab/[Source] Oracle ESAR/data/clean/ticket_log`
    WHERE ticket_message REGEXP '[W][A-Z][A-Z][A-Z][A-Z][0-9][0-9][0-9][0-9][0-9][0-9]'