# Project Inventory Summary

**Project name:** 22827-AMP DEEP Metadata

**Merge timestamp:** 2026-03-17T10:31:43.468354

**Project output dir:** `22827-amp-deep-metadata_095f58fa`

**Total resources in project folder:** 2

**Total merged records:** 75

**Unresolved (project_only) resources:** 0

## Resource Counts by Type

- **datasource:** 2
- **foundrydataset:** 1
- **fusionsheet:** 4
- **networkegresspolicy:** 6
- **pythontransformation:** 42
- **rawdataset:** 14
- **sqltransformation:** 5
- **virtualtable:** 1

## Mode

Flat output — workshop subdirectories removed after merge.
