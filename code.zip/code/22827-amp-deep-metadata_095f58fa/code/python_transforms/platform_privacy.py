from transforms.api import transform_df, Input, Output
from pyspark.sql import functions as F


@transform_df(
    Output("/Innovation Lab/Data Governance/code/platform_privacy"),
    ingestion_requests=Input(
        "/Innovation Lab/Data Governance/Data Ingestion Requests/Admin/data_ingestion_request_form_writeback_dataset"
    ),
)
def platform_privacy(ingestion_requests):
    df = ingestion_requests
    df = df.select(
        F.explode(df["associated_use_case_project_rid_array"]).alias("use_case_rid"),
        df["is_privacy_approved"],
    ).distinct()
    df = df.groupBy(df["use_case_rid"]).agg(
        F.collect_list(df["is_privacy_approved"]).alias("privacy_approval_history")
    )

    df2 = ingestion_requests
    df2 = df2.select(
        F.explode(df2["associated_use_case_project_rid_array"]).alias("use_case_rid"),
        df2["privacy_approval_attachment"],
    ).distinct()
    df2 = df2.groupBy(df2["use_case_rid"]).agg(
        F.collect_list(df2["privacy_approval_attachment"]).alias(
            "privacy_approval_attachment_history"
        )
    )

    df = df.join(df2, ["use_case_rid"], how="left")

    return df
