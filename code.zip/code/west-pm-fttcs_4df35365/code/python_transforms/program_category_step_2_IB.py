from transforms.api import transform, Output, Input, configure
from pyspark.sql import functions as F
from pyspark.sql.window import Window


SPARK_PROFILES = [
        'DRIVER_MEMORY_EXTRA_EXTRA_LARGE',
        'DRIVER_CORES_LARGE',
        'EXECUTOR_MEMORY_LARGE',
        'EXECUTOR_CORES_LARGE',
        'NUM_EXECUTORS_32',
        'EXECUTOR_MEMORY_OVERHEAD_LARGE',
        'DYNAMIC_ALLOCATION_DISABLED'
]


@configure(profile=SPARK_PROFILES)
@transform(
    # replace this with your output dataset path
    ib_lvl_2_sites=Output("ri.foundry.main.dataset.34d7a6c8-332b-401d-a572-c7c1b591dd4a"),
    outinternal_lvl_1=Input("ri.foundry.main.dataset.45d4e145-6d09-4832-a86d-d1a7559f97d7"),
    tempout_IB_C=Output("ri.foundry.main.dataset.55dfb83d-41e6-4f89-8bbd-43a73ee5e570"),
    tempout_IB_PA=Output("ri.foundry.main.dataset.911215b2-dde0-47df-bffe-713a1762988d"),
    iwm=Input("ri.foundry.main.dataset.53bb3121-e1f0-4b82-b910-b540db3e1bdf"),
    )
def my_compute_function(ctx, iwm, outinternal_lvl_1, ib_lvl_2_sites,
                        tempout_IB_C, tempout_IB_PA):

    # get the necessary data from pace snapshot
    cols = [F.col("IWM_JOB_NUMBER").alias("iwm_number"),
            F.col("NATIONAL_PROGRAM").alias("national_program"),
            F.col("JOB_SCOPE").alias("job_scope"),
            F.col("JOB_STATUS").alias("status"),
            F.col("ORACLE_PTN").alias("oracle_ptn"),
            F.col("MOD_CODE").alias("mod_code"),
            F.col("SPECTRUM").alias("spectrum"),
            F.col("N_UDF4").alias("n_udf4"),
            F.col("N_UDF5").alias("n_udf5"),
            F.col("PRODUCT_GROUP").alias("product_group"),
            F.col("PRODUCT_SUB_GROUP").alias("product_subgroup"),
            F.col("PLANNING_NUMBER").alias("planning_number"),
            F.col("PLANNING_STATUS").alias("iplan_status"),
            F.col("FA_LOCATION_CODE").alias("fa_location_code"),
            F.col("ONAIR_ACTUAL_END_DATE").alias("onair_actual"),
            F.col("ONAIR_PLAN_END_DATE").alias("onair_forecast"),
            F.col("JOB_CATEGORY").alias("job_category"),
            F.col("ALLOCATION").alias("allocation"),
            F.col("SOLUTION").alias("solution"),
            F.col("NEW_SITE_BUILD").alias("new_site_build"),
            F.col("ASSOCIATED_FA").alias("associated_fa"),
            F.col("1220T_ACTUAL").alias("1220t_actual"),
            F.col("COMMITMENT_DATE").alias("commitment_date"),
            F.col("SCOPE_NAME").alias("scope_name"),
            ]

    iwm_df = iwm.dataframe().select(*cols).distinct()
    iwm_df = iwm_df.withColumn("allocation", F.when(F.col("allocation").isNull(), F.lit("NULL"))
                                              .otherwise(F.col("allocation")))

    # Catpture the Level 1 tagging required for MCA Sites tagging
    outinternal_lvl_1_df = outinternal_lvl_1.dataframe()
    outinternal_lvl_1_df = outinternal_lvl_1_df.withColumnRenamed('program', 'level1_program')
    # Filter out those Level 1 parent program used in Level 2 tagging. ** Consider add this into ALLInOne config table.
    ib_sites_filter = "level1_program in ('IB-NSB', 'IB-Nokia Swaps', 'IB-Ericsson Modernization', 'IB-BAU Mods')"
    ib_lvl_1_df = outinternal_lvl_1_df.where(ib_sites_filter)

    # Get the matching job's attributes
    ib_iwm_df = ib_lvl_1_df.join(
        iwm_df,
        "iwm_number",
        "inner"
    )

    # ----------------- Program Category IB Sites tagging STARTs here -----------------
    # Get the SmallCell Sites Tagging columns added
    df_out = prepare_IB_Sites_tagging_data(ib_iwm_df, ib_lvl_1_df, tempout_IB_C, tempout_IB_PA)
    out_df = (
        iwm_df
        .join(df_out, 'iwm_number', 'left')
        .select("iwm_number", "ib_nsb_fa_rnk_C_order", "ib_nsb_fa_rnk_PA_order",
                "ib_nokia_fa_rnk_C_order", "ib_nokia_fa_rnk_PA_order",
                "ib_mods_fa_rnk_C_order", "ib_mods_fa_rnk_PA_order",
                "ib_bau_fa_rnk_C_order", "ib_bau_fa_rnk_PA_order")
        .filter("(ib_nsb_fa_rnk_C_order is not null OR ib_nsb_fa_rnk_PA_order is not null OR \
                ib_nokia_fa_rnk_C_order is not null OR ib_nokia_fa_rnk_PA_order is not null OR \
                ib_mods_fa_rnk_C_order is not null OR ib_mods_fa_rnk_PA_order is not null OR \
                ib_bau_fa_rnk_C_order is not null OR ib_bau_fa_rnk_PA_order is not null)")
         .distinct()
    )

    cols_to_sum = ["ib_nsb_fa_rnk_C_order", "ib_nsb_fa_rnk_PA_order",
                "ib_nokia_fa_rnk_C_order", "ib_nokia_fa_rnk_PA_order",
                "ib_mods_fa_rnk_C_order", "ib_mods_fa_rnk_PA_order",
                "ib_bau_fa_rnk_C_order", "ib_bau_fa_rnk_PA_order"]

    # Use coalesce to replace nulls with 0 before summing
    out_df = out_df.groupBy("iwm_number").agg(*[F.sum(F.coalesce(F.col(c), F.lit(0))).alias(c) for c in cols_to_sum])

    # ----------------- Program Category IB Sites tagging ENDs here -----------------

    # Overall Level 1 Changes for IB
    ib_lvl_2_sites.write_dataframe(out_df)


def prepare_IB_Sites_tagging_data(iwm_df, lvl1_df, tempout_IB_C, tempout_IB_PA):

    # Filter the valid project for Sites Tagging also filter out the valid MPT jobs based on 1220T_ACTUAL
    valid_jobs = "upper(status) in ('ON_GOING','COMPLETED') \
        and year(1220t_actual) not in (1920,1950)"
    # iwm_df = iwm_df.where(valid_jobs)

    # Select the columns required for tagging
    iwm_df = (
        iwm_df
        .select(
            F.col("iwm_number"),
            F.col("fa_location_code"),
            F.col("mod_code"),
            F.year(F.coalesce(F.col("onair_actual"), F.col("onair_forecast"))).alias("plan_YR"),
            # F.left(F.col("scope_name")).alias("scope_YR"),
            F.col("scope_name"),
            F.year(F.col("commitment_date")).alias("commitment_YR"),
            F.year(F.col("onair_actual")).alias("actual_YR")
        )
        .where(valid_jobs)
    )

    # Select the required data for Sites Tagging
    IB_filter = "level1_program in ('IB-NSB', 'IB-Nokia Swaps', 'IB-Ericsson Modernization', 'IB-BAU Mods')"
    iwm_IB_df = lvl1_df.where(IB_filter)

    # Limit the Tagging dataset to small and for valid Sites jobs
    iwm_df = iwm_df.join(
        iwm_IB_df,
        "iwm_number",
        "leftsemi"
    )

    # Select the required columns for Sites Tagging
    iwm_IB_df = (
        iwm_IB_df
        .join(iwm_df, "iwm_number", "inner")
        .select(
            F.col("iwm_number"),
            F.col("level1_program"),
            F.col("plan_YR"),
            F.col("commitment_YR")
        )
    )

    nsb_filter = "level1_program = 'IB-NSB'"
    nokia_filter = "level1_program = 'IB-Nokia Swaps'"
    mods_filter = "level1_program = 'IB-Ericsson Modernization'"
    bau_filter = "level1_program = 'IB-BAU Mods'"

    iwm_nsb_sites_df = iwm_IB_df.where(nsb_filter)
    iwm_nokia_sites_df = iwm_IB_df.where(nokia_filter)
    iwm_mods_sites_df = iwm_IB_df.where(mods_filter)
    iwm_bau_sites_df = iwm_IB_df.where(bau_filter)

    # filter the Valid jobs for commitment Tagging
    # Select the required columns
    valid_IB_C_df = (
        iwm_df
        .select(
            F.col("iwm_number"),
            F.col("commitment_YR").alias("YR"),
            F.col("fa_location_code")
        )
        .where("left(scope_name,4) = commitment_YR")
    )

    # Call the function for commitment Tagging for Sites per FA and ModCode
    tempout_C, C_df = Generate_IB_tagging_C(iwm_nsb_sites_df, valid_IB_C_df, "NSB")
    # merge the MCA Temp output, to add extra tagging columns
    tempout_C_df = tempout_C
    mca_df = C_df

    # Call the function for commitment Tagging for Sites per FA and ModCode
    tempout_C, C_df = Generate_IB_tagging_C(iwm_nokia_sites_df, valid_IB_C_df, "NOKIA")
    # merge the MCA Temp output, to add extra tagging columns
    tempout_C_df = tempout_C_df.unionByName(tempout_C, allowMissingColumns=True)
    mca_df = mca_df.unionByName(C_df, allowMissingColumns=True)

    # Call the function for commitment Tagging for Sites per FA and ModCode
    tempout_C, C_df = Generate_IB_tagging_C(iwm_mods_sites_df, valid_IB_C_df, "MODS")
    # merge the MCA Temp output, to add extra tagging columns
    tempout_C_df = tempout_C_df.unionByName(tempout_C, allowMissingColumns=True)
    mca_df = mca_df.unionByName(C_df, allowMissingColumns=True)

    # Call the function for commitment Tagging for Sites per FA and ModCode
    tempout_C, C_df = Generate_IB_tagging_C(iwm_bau_sites_df, valid_IB_C_df, "BAU")
    # merge the MCA Temp output, to add extra tagging columns
    tempout_C_df = tempout_C_df.unionByName(tempout_C, allowMissingColumns=True)
    tempout_IB_C.write_dataframe(tempout_C_df)
    mca_df = mca_df.unionByName(C_df, allowMissingColumns=True)

    # filter out Valid jobs for MCA tag checking for Plan/Actual.
    # Select the required columns
    valid_IB_PA_df = (
        iwm_df
        .select(
            F.col("iwm_number"),
            F.col("plan_YR").alias("YR"),
            F.col("fa_location_code"),
            F.col("scope_name"),
            F.col("commitment_YR"),
            F.col("actual_YR")
        )
        .where("plan_YR is not null")
    )

    # Call the Function to do Plan and Actual tagging
    tempout_PA, PA_df = Generate_IB_tagging_PA(iwm_nsb_sites_df, valid_IB_PA_df, "NSB")
    # merge the MCA Temp output, to add extra tagging columns
    tempout_PA_df = tempout_PA
    mca_df = mca_df.unionByName(PA_df, allowMissingColumns=True)

    tempout_PA, PA_df = Generate_IB_tagging_PA(iwm_nokia_sites_df, valid_IB_PA_df, "NOKIA")
    # merge the MCA Temp output, to add extra tagging columns
    tempout_PA_df = tempout_PA_df.unionByName(tempout_PA, allowMissingColumns=True)
    mca_df = mca_df.unionByName(PA_df, allowMissingColumns=True)

    tempout_PA, PA_df = Generate_IB_tagging_PA(iwm_mods_sites_df, valid_IB_PA_df, "MODS")
    # merge the MCA Temp output, to add extra tagging columns
    tempout_PA_df = tempout_PA_df.unionByName(tempout_PA, allowMissingColumns=True)
    mca_df = mca_df.unionByName(PA_df, allowMissingColumns=True)

    tempout_PA, PA_df = Generate_IB_tagging_PA(iwm_bau_sites_df, valid_IB_PA_df, "BAU")
    # merge the MCA Temp output, to add extra tagging columns
    tempout_PA_df = tempout_PA_df.unionByName(tempout_PA, allowMissingColumns=True)
    tempout_IB_PA.write_dataframe(tempout_PA_df)
    mca_df = mca_df.unionByName(PA_df, allowMissingColumns=True)

    # retun the Dataset with sites Tagging columns
    return mca_df


def Generate_IB_tagging_C(lvl1_df, iwm_df, RnkType):

    # Set the tagging variable based on InputType
    if RnkType == "NSB":
        ColName = "ib_nsb_fa_rnk_C_order"
    elif RnkType == "NOKIA":
        ColName = "ib_nokia_fa_rnk_C_order"
    elif RnkType == "MODS":
        ColName = "ib_mods_fa_rnk_C_order"
    elif RnkType == "BAU":
        ColName = "ib_bau_fa_rnk_C_order"

    # filter the required jobs
    # Limit the Tagging dataset to small and for valid Sites jobs
    iwm_df = iwm_df.join(
        lvl1_df,
        "iwm_number",
        "leftsemi"
    )

    # Apply Rank() over partition logic
    partition = Window.partitionBy('YR', 'fa_location_code').orderBy('iwm_number')
    iwm_df = iwm_df.withColumn('rnk_order', F.rank().over(partition))

    # Generate temp output for validation
    outdf = iwm_df.select(F.col("*"))

    # Filter the dataframe
    iwm_df = iwm_df.filter(F.col('rnk_order') == 1)

    iwm_df = (
        iwm_df
        .select(
            F.col("iwm_number").alias("iwm_number"),
            F.col("rnk_order").alias(ColName),
        )
    )

    return outdf, iwm_df


def Generate_IB_tagging_PA(lvl1_df, iwm_df, RnkType):  # noqa: C901

    # Set the tagging variable based on InputType
    if RnkType == "NSB":
        ColName = "ib_nsb_fa_rnk_PA_order"
    elif RnkType == "NOKIA":
        ColName = "ib_nokia_fa_rnk_PA_order"
    elif RnkType == "MODS":
        ColName = "ib_mods_fa_rnk_PA_order"
    elif RnkType == "BAU":
        ColName = "ib_bau_fa_rnk_PA_order"

    # filter the required jobs
    # Limit the Tagging dataset to small and for valid Sites jobs
    iwm_df = iwm_df.join(
        lvl1_df,
        "iwm_number",
        "leftsemi"
    )

    mca_df = iwm_df.where("left(scope_name,4) = commitment_YR and actual_YR = commitment_YR")

    # Apply Rank() over partition logic
    partition = Window.partitionBy('YR', 'fa_location_code').orderBy('iwm_number')
    mca_df = mca_df.withColumn('rnk_order', F.rank().over(partition))

    # Select the required columns
    mca_df2 = iwm_df

    # exclude those FA found in Level1
    mca_df2 = mca_df2.join(mca_df, ['YR', "fa_location_code"], "left_anti")

    # Apply Rank() over partition logic
    partition = Window.partitionBy('YR', 'fa_location_code').orderBy('iwm_number')
    mca_df2 = mca_df2.withColumn('rnk_order', F.rank().over(partition))

    mca_df = mca_df2.unionByName(mca_df)

    # Generate temp output for validation
    outdf = mca_df.select(F.col("*"))

    # Filter the dataframe
    mca_df = mca_df.filter(F.col('rnk_order') == 1)

    mca_df = (
        mca_df
        .select(
            F.col("iwm_number").alias("iwm_number"),
            F.col("rnk_order").alias(ColName),
        )
    )

    return outdf, mca_df
