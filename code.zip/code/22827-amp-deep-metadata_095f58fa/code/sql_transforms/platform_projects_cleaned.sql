CREATE TABLE `/Innovation Lab/Data Governance/AT&T Internal Shareable Resources/platform_projects_pre_cleaned` TBLPROPERTIES (foundry_sever_inherited_permissions = 'true') AS WITH

object_re_roll_properties as (
    SELECT
        *
    FROM `/Innovation Lab/Data Governance/AT&T Internal Shareable Resources/platform_object_re_roll - Sheet1`
),

use_case_status_properties as (
    SELECT
        Project_Name,
        poc_pilot_production as use_case_status
    FROM `/Innovation Lab/Platform Reporting/Use Case Tracking/Use Case Tracker - Sheet1`
),

data_feed_type as (
    SELECT
        project_rid,
        data_feed_type
    FROM `/Innovation Lab/Data Governance/Code & Data/code/datasets/data_feed_type`
),

platform_privacy as (
    SELECT
        *
    FROM `/Innovation Lab/Data Governance/Code & Data/platform_privacy`
    )

SELECT
    PRO.project_rid,
    project_name,
    project_path,
    project_type,
    multipass_group_rids,
    default_role,
    organization,
    reference_project,
    most_recent_activity_time,
    most_recent_activity_type,
    CAST(object_re_roll_properties.privacy_review_attachment as String) as privacy_review_attachment,
    CAST(object_re_roll_properties.cloud_governance_approval_number as String) as cloud_governance_approval_number,
    object_re_roll_properties.use_case_sponsors,
    object_re_roll_properties.use_case_owners,
    object_re_roll_properties.use_case_key_contacts,
    object_re_roll_properties.use_case_sponsors_name,
    object_re_roll_properties.use_case_owners_name,
    object_re_roll_properties.use_case_key_contacts_name,
    platform_privacy.privacy_approval_attachment_history, 
    platform_privacy.privacy_approval_history,
    CAST(object_re_roll_properties.line_of_business as String) as line_of_business,
    CAST(object_re_roll_properties.project_description as String) as project_description,
    CAST(object_re_roll_properties.project_monocle_graph as String) as project_monocle_graph,
    CAST(object_re_roll_properties.data_source_key_contact_email as String) as data_source_key_contact_email,
    CAST(object_re_roll_properties.data_source_key_contact_name as String) as data_source_key_contact_name,
    ingestion_managers as team_managing_data_source,
    data_feed_type.data_feed_type,
    CAST(null as String) as big_win_target_quarter,
    CAST(null as int) as compute_threshold,
    use_case_status_properties.use_case_status as big_win_latest_status,
    use_case_status_properties.use_case_status as use_case_status,
    CAST(null as String) as big_win_overview,
    CAST(null as String) as source_application_mots_id,
    CAST(null as Array<String>) as data_source_sme_email,
    CAST(null as Array<String>) as data_source_sme_full_name,
    CAST(null as Array<String>) as project_categories
FROM `/Innovation Lab/Data Governance/Code & Data/data/all_projects` PRO

LEFT JOIN object_re_roll_properties
ON PRO.project_rid == object_re_roll_properties.project_rid

LEFT JOIN platform_privacy
ON PRO.project_rid == platform_privacy.use_case_rid

LEFT JOIN use_case_status_properties
ON PRO.project_name == use_case_status_properties.Project_Name

LEFT JOIN data_feed_type
ON PRO.project_rid == data_feed_type.project_rid