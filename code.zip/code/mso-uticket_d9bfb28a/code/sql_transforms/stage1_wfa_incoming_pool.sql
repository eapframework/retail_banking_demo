CREATE TABLE `ri.foundry.main.dataset.e4ccb37f-3d08-4b23-85d9-06027b30a7fa` AS
    SELECT tr ext_key1
, first(trbl_cd) wfa_trouble_code
, min(cast(from_unixtime(unix_timestamp(rcv_dt ) + (rcv_tm * 60)) as timestamp)) wfa_start_dt
, max(cast(from_unixtime(unix_timestamp(closed_dt ) + (closed_tm * 60)) as timestamp)) wfa_finish_dt
, concat_ws(';', collect_list(closeout_summary)) wfa_closeout_summary 
FROM `ri.foundry.main.dataset.4e8ff367-a3fa-4826-b057-c48ffe78812c`
WHERE lower(tr) REGEXP '^[a-z][a-z][0-9][0-9][0-9][0-9][0-9][0-9]$|[0-9a-z][0-9a-z][0-9a-z][0-9a-z][0-9a-z][0-9a-z][0-9a-z][0-9a-z][0-9a-z]'
group by tr