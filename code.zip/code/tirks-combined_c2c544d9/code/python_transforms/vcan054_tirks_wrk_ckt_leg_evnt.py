from transforms.api import transform, Input, Output, incremental
from utility.column_clean import clean_columns, lowercase_columns, remove_prefix


@transform(
    out=Output("/Innovation Lab/[Source] Teradata EDW - ASI_VIEWS/data/clean/vcan054_tirks_wrk_ckt_leg_evnt"),
    df=Input("/Innovation Lab/[Source] Teradata EDW - ASI_VIEWS/data/raw/VCAN054_TIRKS_WRK_CKT_LEG_EVNT"),
)
def my_compute_function(df, out):
    df = clean_columns(
        df.dataframe(),
        date_format=date_format, 
        date_columns=string_to_date,
        datetime_format=datetime_format, 
        datetime_columns=long_unixtime_to_timestamp,
        timestamp_from_string_format=string_unixtime_format,
        timestamp_from_string_columns=string_unixtime_to_timestamp,
        timestamp_format=long_unixtime_format, 
        timestamp_columns=long_unixtime_to_timestamp,
        integer_columns=string_to_integer_columns,
        double_columns=string_to_double_columns,
        decimal_columns=string_to_decimal_columns,
        id_columns=numeric_to_string_columns,
        integer_from_num_columns=decimal_to_integer,
        strip_columns=strip_string_columns,
    )
    # df = df.drop(*drop_columns)
    # df = remove_prefix(df, 'example_prefix')
    df = lowercase_columns(df)
    out.write_dataframe(df)


drop_columns = []

date_format = 'yyyy-MM-dd'
string_to_date = []
datetime_format = 'yyyy-MM-dd HH:mm:ss'
string_to_timestamp = []

string_unixtime_format = None
string_unixtime_to_timestamp = []
long_unixtime_format = None
long_unixtime_to_timestamp = []

string_to_integer_columns = []
string_to_double_columns = []
string_to_decimal_columns = []

numeric_to_string_columns = []
decimal_to_integer = []

strip_string_columns = [
    "SBC_COMPANY_CD",
    "SBC_SYSTEM_CD",
    "SBC_STATE_CD",
    "CIRCUIT_LAYOUT_ORDER_BASE_NBR",
    "ITEM_NBR",
    "WORK_LOCATION_NBR",
    "WORK_ITEM_EVENT_SEQUENCE_NBR",
    "ORDER_NBR",
    "PROCESS_CTRL_FEAT_DATE_NAME_CD",
    "PROCESS_CTRL_FEATURE_EVENT_CD",
    "CRITICAL_ORD_CTRL_DATE_NAME_CD",
    "CRTCL_ORD_CTRL_DT_NM_OBJTV_DT",
    "RESPONSIBLE_REPORTING_OFC_CD",
    "WORK_POSITION_CD",
    "GENERIC_ORDER_CONTROL_ALIAS_CD",
    "WORK_POSITION_DESTINATION_CD",
    "CRTCL_CTRL_DT_INIT_JPRDY_1_CD",
    "CRTCL_CTRL_DT_INIT_JPRDY_2_CD",
    "CRTCL_CTRL_DT_INIT_JPRDY_3_CD",
    "RESPONSIBLE_RPTG_OFC_DEST_CD",
    "LOGICAL_TERMINAL_CD",
    "BULK_ITEM_TRACKING_QTY",
    "ORDER_STATUS_CD",
    "EVENT_FLOW_THRU_ATTEMPTED_CD",
    "EVENT_FLOW_THRU_SUCCESS_CD",
    "EVENT_FLOW_THRU_MAN_ASSTNC_CD",
    "EVENT_FLOW_THRU_ITEM_NBR",
    "EVENT_FLOW_THRU_ERROR_MSG_TXT",
    "WORK_LIST_ITEM_ENTRY_DT",
    "WORK_LIST_ITEM_ENTRY_TM",
    "WORK_LIST_ITEM_EXIT_DT",
    "WORK_LIST_ITEM_EXIT_TM"
]
