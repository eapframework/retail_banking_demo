CREATE TABLE `ri.foundry.main.dataset.b17eea8f-0650-4dc9-a72f-59c250a86c45` AS
    SELECT distinct POOL.*
    , cause_code_list_in
    , trbl_fnd_cd_list_in
    , trbl_fnd_desc_in
    , cause_code_list_out
    , trbl_fnd_cd_list_out
    , trbl_fnd_desc_out
    FROM `ri.foundry.main.dataset.ad924c05-ca5f-488e-aa82-c71525cbd8df` POOL
    FULL OUTER JOIN `ri.foundry.main.dataset.2d138c2f-c871-45b5-b139-696eb5ab44e2` DPO
    ON POOL.join_key=DPO.join_key
    FULL OUTER JOIN `ri.foundry.main.dataset.525c0558-03a2-4e65-b371-4fefaa92d7c6` DPI
    ON DPO.join_key=DPI.join_key
    WHERE POOL.ticket_number_unique is not null