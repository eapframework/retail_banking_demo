from transforms.api import transform, Input, Output, incremental
from utility.column_clean import clean_columns, lowercase_columns, remove_prefix


@transform(
    out=Output("/Innovation Lab/[Source] Teradata EDW - ASI_VIEWS/data/clean/vcan0811$tirks_ckt_span_detail"),
    df=Input("/Innovation Lab/[Source] Teradata EDW - ASI_VIEWS/data/raw/vcan0811$tirks_ckt_span_detail"),
)
def my_compute_function(df, out):
    df = clean_columns(
        df.dataframe(),
        date_format=date_format, 
        date_columns=string_to_date,
        datetime_format=datetime_format, 
        datetime_columns=long_unixtime_to_timestamp,
        timestamp_from_string_format=string_unixtime_format,
        timestamp_from_string_columns=string_unixtime_to_timestamp,
        timestamp_format=long_unixtime_format, 
        timestamp_columns=long_unixtime_to_timestamp,
        integer_columns=string_to_integer_columns,
        double_columns=string_to_double_columns,
        decimal_columns=string_to_decimal_columns,
        id_columns=numeric_to_string_columns,
        integer_from_num_columns=decimal_to_integer,
        strip_columns=strip_string_columns,
    )
    # df = df.drop(*drop_columns)
    # df = remove_prefix(df, 'example_prefix')
    df = lowercase_columns(df)
    out.write_dataframe(df)


drop_columns = []

date_format = 'yyyy-MM-dd'
string_to_date = []
datetime_format = 'yyyy-MM-dd HH:mm:ss'
string_to_timestamp = []

string_unixtime_format = None
string_unixtime_to_timestamp = []
long_unixtime_format = None
long_unixtime_to_timestamp = []

string_to_integer_columns = []
string_to_double_columns = []
string_to_decimal_columns = []

numeric_to_string_columns = []
decimal_to_integer = []

strip_string_columns = [
    "ADMINISTRATIVE_AREA_CD",
    "CIRCUIT_ACCESS_CD",
    "CIRCUIT_DROP_CONTINUE_PATH_CD",
    "CIRCUIT_LAYOUT_ORDER_NBR",
    "FACILITY_USE_CD",
    "SBC_COMPANY_CD",
    "SBC_STATE_CD",
    "SBC_SYSTEM_CD",
    "SPAN_ASGNMNT_ACTIVITY_CD",
    "SPAN_ASSIGNMENT_ACTION_CD",
    "SPAN_CONTROL_OFFICE_LOC_CD",
    "SPAN_FACILITY_TYPE_CD",
    "SPAN_GROUP_DESIGNATION_CD",
    "SPAN_ID",
    "SPAN_LINE_TYPE_CD",
    "SPAN_LOC_A_APPARATUS_CASE_CD",
    "SPAN_LOC_A_CABLE_IN_DRCTN_CD",
    "SPAN_LOC_A_CABLE_IN_ID",
    "SPAN_LOC_A_CABLE_IN_PAIR_CD",
    "SPAN_LOC_A_CABLE_OUT_DRCTN_CD",
    "SPAN_LOC_A_CABLE_OUT_ID",
    "SPAN_LOC_A_CABLE_OUT_PAIR_CD",
    "SPAN_LOC_A_FRAME",
    "SPAN_LOC_A_FRAME_ADDRESS1",
    "SPAN_LOC_A_FRAME_ADDRESS2",
    "SPAN_LOC_A_FRAME_ADDRESS3",
    "SPAN_LOC_A_FRAME_ADDRESS4",
    "SPAN_LOC_A_TRNSMSN_LVL_MSRMT",
    "SPAN_LOC_Z_APPARATUS_CASE_CD",
    "SPAN_LOC_Z_CABLE_IN_DRCTN_CD",
    "SPAN_LOC_Z_CABLE_IN_ID",
    "SPAN_LOC_Z_CABLE_IN_PAIR_CD",
    "SPAN_LOC_Z_CABLE_OUT_DRCTN_CD",
    "SPAN_LOC_Z_CABLE_OUT_ID",
    "SPAN_LOC_Z_CABLE_OUT_PAIR_CD",
    "SPAN_LOC_Z_FRAME",
    "SPAN_LOC_Z_FRAME_ADDRESS1",
    "SPAN_LOC_Z_FRAME_ADDRESS2",
    "SPAN_LOC_Z_FRAME_ADDRESS3",
    "SPAN_LOC_Z_FRAME_ADDRESS4",
    "SPAN_LOC_Z_TRNSMSN_LVL_MSRMT",
    "SPAN_LOCATION_A_CLLI_CD",
    "SPAN_LOCATION_Z_CLLI_CD",
    "SPAN_LOCATION_Z_LINE_ALIAS_CD",
    "SPAN_MISCELLANEOUS_TXT",
    "SPAN_SIGNAL_VOICE_PATH_CD",
    "SPAN_SUBPATH_ID",
    "SPAN_UNIT_CD"
]
