from __future__ import annotations

"""Data store for Magical Index.

Three tables:
- **resources**: 7-column resource registry (resource_id, resource_name,
  location, resource_type, resource_status, last_by, last_update_time).
- **relationships**: pure graph edges (upstream_resource_id,
  downstream_resource_id, relationship_type, notes).
- **activity_logs**: immutable audit trail for every mutation.

Design intent:
- Keep endpoint functions thin; concentrate state changes here.
- Make it easy to swap the backend by keeping a small set of methods.
"""

import logging
from collections.abc import Iterable
from datetime import datetime, timezone
from typing import Dict, List, Optional
import os

logger = logging.getLogger(__name__)

from app.schemas.activity_log import (
    ActionType,
    ActivityLogCreate,
    ActivityLogRead,
    generate_log_id,
)
from app.schemas.relationship import (
    RelationshipCreate,
    RelationshipDelete,
    RelationshipRead,
    RelationshipType,
)
from app.schemas.resource import (
    ActorType,
    ResourceCreate,
    ResourceRead,
    ResourceStatus,
    ResourceUpdate,
    generate_resource_id,
)
from app.schemas.prep_extraction import (
    ExtractionTask,
    PrepareExtractionRequest,
    PrepareExtractionResponse,
)

from app.core.config import settings


def derive_target_location(upstream_resource_name: str) -> str:
    """Derive the target resource location from the upstream use case folder's resource name."""
    return upstream_resource_name.strip() if upstream_resource_name else ""


class InMemoryStore:
    """Minimal storage façade for local dev.

    Methods here mirror the needs of the API layer. A future ``DeltaStore``
    should expose the same public methods so wiring can be swapped based on
    configuration (e.g., an environment variable).
    """

    def __init__(self) -> None:
        self._resources: Dict[str, ResourceRead] = {}
        self._relationships: List[RelationshipRead] = []
        self._activity_logs: List[ActivityLogRead] = []

    # ------------------------------------------------------------------
    # Activity log helpers
    # ------------------------------------------------------------------
    def _append_log(
        self,
        resource_id: str,
        action: ActionType,
        actor_type: ActorType,
        actor_name: str,
        details: Optional[str] = None,
    ) -> ActivityLogRead:
        entry = ActivityLogRead(
            log_id=generate_log_id(),
            resource_id=resource_id,
            action=action,
            actor_type=actor_type,
            actor_name=actor_name,
            details=details,
            timestamp=datetime.now(timezone.utc),
        )
        self._activity_logs.append(entry)
        return entry

    # ------------------------------------------------------------------
    # Resource operations
    # ------------------------------------------------------------------
    def create_resource(self, data: ResourceCreate) -> ResourceRead:
        """Create a new resource. Auto-generates resource_id if not provided."""
        rid = data.resource_id or generate_resource_id(
            resource_type=data.resource_type,
            platform=data.platform or "auto"
        )

        if rid in self._resources:
            raise ValueError(f"Resource already exists: {rid}")

        now = datetime.now(timezone.utc)
        last_by = f"{data.actor_type.value}:{data.actor_name}"

        resource = ResourceRead(
            resource_id=rid,
            resource_name=data.resource_name,
            location=data.location,
            resource_type=data.resource_type,
            resource_status=data.resource_status,
            last_by=last_by,
            last_update_time=now,
        )
        self._resources[rid] = resource

        self._append_log(
            resource_id=rid,
            action=ActionType.RESOURCE_CREATED,
            actor_type=data.actor_type,
            actor_name=data.actor_name,
            details=f"Created resource '{data.resource_name}' with status {data.resource_status.value}",
        )
        return resource

    def get_resource(self, resource_id: str) -> Optional[ResourceRead]:
        """Fetch a single resource by id or return ``None`` if not found."""
        return self._resources.get(resource_id)

    def list_resources(
        self,
        resource_status: Optional[ResourceStatus] = None,
        resource_type: Optional[str] = None,
        platform: Optional[str] = None,
        offset: int = 0,
        limit: int = 100,
    ) -> tuple[list[ResourceRead], int]:
        """List resources with pagination, optionally filtering by status, type, or platform.
        
        Returns:
            Tuple of (paginated items, total count)
        """
        resources: Iterable[ResourceRead] = self._resources.values()
        if resource_status is not None:
            resources = [r for r in resources if r.resource_status == resource_status]
        if resource_type is not None:
            resources = [r for r in resources if r.resource_type.value == resource_type]
        if platform is not None:
            resources = [r for r in resources if r.resource_id.startswith(f"{platform}:")]
        sorted_resources = sorted(resources, key=lambda r: r.resource_id)
        total = len(sorted_resources)
        paginated = sorted_resources[offset:offset + limit]
        return paginated, total

    def update_resource(
        self, resource_id: str, data: ResourceUpdate
    ) -> Optional[ResourceRead]:
        """Update mutable fields on a resource. Returns None if not found."""
        existing = self._resources.get(resource_id)
        if existing is None:
            return None

        now = datetime.now(timezone.utc)
        last_by = f"{data.actor_type.value}:{data.actor_name}"

        changes: list[str] = []
        updates: dict[str, object] = {
            "last_by": last_by,
            "last_update_time": now,
        }

        if data.resource_name is not None:
            updates["resource_name"] = data.resource_name
            changes.append(f"resource_name -> '{data.resource_name}'")
        if data.location is not None:
            updates["location"] = data.location
            changes.append(f"location -> '{data.location}'")
        if data.resource_type is not None:
            updates["resource_type"] = data.resource_type
            changes.append(f"resource_type -> {data.resource_type.value}")
        if data.resource_status is not None:
            changes.append(f"resource_status -> {data.resource_status.value} (was {existing.resource_status.value})")
            updates["resource_status"] = data.resource_status

        updated = existing.model_copy(update=updates)
        self._resources[resource_id] = updated

        self._append_log(
            resource_id=resource_id,
            action=ActionType.RESOURCE_UPDATED,
            actor_type=data.actor_type,
            actor_name=data.actor_name,
            details="; ".join(changes) if changes else "no-op update",
        )
        return updated

    def delete_resource(self, resource_id: str, actor_type: ActorType, actor_name: str) -> bool:
        """Delete a resource and any relationships where it appears upstream or downstream."""
        if resource_id not in self._resources:
            return False

        del self._resources[resource_id]
        self._relationships = [
            rel
            for rel in self._relationships
            if rel.upstream_resource_id != resource_id
            and rel.downstream_resource_id != resource_id
        ]

        self._append_log(
            resource_id=resource_id,
            action=ActionType.RESOURCE_DELETED,
            actor_type=actor_type,
            actor_name=actor_name,
            details=f"Deleted resource {resource_id} and cascade-removed relationships",
        )
        return True

    # ------------------------------------------------------------------
    # Relationship operations
    # ------------------------------------------------------------------
    def create_relationship(self, data: RelationshipCreate) -> RelationshipRead:
        """Create a relationship edge; operation is idempotent for identical edges.

        Raises ``ValueError`` if either resource does not exist.
        """
        missing: list[str] = []
        if self._resources.get(data.upstream_resource_id) is None:
            missing.append(data.upstream_resource_id)
        if self._resources.get(data.downstream_resource_id) is None:
            missing.append(data.downstream_resource_id)
        if missing:
            raise ValueError(f"Resource(s) not found: {', '.join(missing)}")

        # Idempotency: return existing if same edge + type already present
        for rel in self._relationships:
            if (
                rel.upstream_resource_id == data.upstream_resource_id
                and rel.downstream_resource_id == data.downstream_resource_id
                and rel.relationship_type == data.relationship_type
            ):
                return rel

        relationship = RelationshipRead(
            upstream_resource_id=data.upstream_resource_id,
            downstream_resource_id=data.downstream_resource_id,
            relationship_type=data.relationship_type,
            notes=data.notes,
        )
        self._relationships.append(relationship)

        self._append_log(
            resource_id=data.upstream_resource_id,
            action=ActionType.RELATIONSHIP_CREATED,
            actor_type=data.actor_type,
            actor_name=data.actor_name,
            details=f"{data.upstream_resource_id} {data.relationship_type.value} {data.downstream_resource_id}",
        )
        return relationship

    def delete_relationship(self, data: RelationshipDelete) -> int:
        """Delete relationship(s) matching the criteria; returns number of rows removed."""
        before = len(self._relationships)
        self._relationships = [
            rel
            for rel in self._relationships
            if not (
                rel.upstream_resource_id == data.upstream_resource_id
                and rel.downstream_resource_id == data.downstream_resource_id
                and (
                    data.relationship_type is None
                    or rel.relationship_type == data.relationship_type
                )
            )
        ]
        deleted_count = before - len(self._relationships)
        if deleted_count > 0:
            relationship_type = data.relationship_type.value if data.relationship_type is not None else "ANY"
            self._append_log(
                resource_id=data.upstream_resource_id,
                action=ActionType.RELATIONSHIP_DELETED,
                actor_type=data.actor_type,
                actor_name=data.actor_name,
                details=(
                    f"Deleted {deleted_count} relationship(s): "
                    f"upstream={data.upstream_resource_id}, "
                    f"downstream={data.downstream_resource_id}, "
                    f"relationship_type={relationship_type}"
                ),
            )
        return deleted_count

    def list_upstream_resources(
        self, resource_id: str, offset: int = 0, limit: int = 100
    ) -> tuple[list[ResourceRead], int]:
        """Return resources that feed into ``resource_id`` (upstream set) with pagination.
        
        Returns:
            Tuple of (paginated items, total count)
        """
        upstream_ids = {
            rel.upstream_resource_id
            for rel in self._relationships
            if rel.downstream_resource_id == resource_id
        }
        resources = [
            res
            for rid, res in self._resources.items()
            if rid in upstream_ids
        ]
        sorted_resources = sorted(resources, key=lambda r: r.resource_id)
        total = len(sorted_resources)
        paginated = sorted_resources[offset:offset + limit]
        return paginated, total

    def list_downstream_resources(
        self, resource_id: str, offset: int = 0, limit: int = 100
    ) -> tuple[list[ResourceRead], int]:
        """Return resources that depend on ``resource_id`` (downstream set) with pagination.
        
        Returns:
            Tuple of (paginated items, total count)
        """
        downstream_ids = {
            rel.downstream_resource_id
            for rel in self._relationships
            if rel.upstream_resource_id == resource_id
        }
        resources = [
            res
            for rid, res in self._resources.items()
            if rid in downstream_ids
        ]
        sorted_resources = sorted(resources, key=lambda r: r.resource_id)
        total = len(sorted_resources)
        paginated = sorted_resources[offset:offset + limit]
        return paginated, total

    def list_upstream_resource_ids(self, resource_ids: list[str]) -> list[str]:
        
        """Return upstream resource IDs shared by ALL provided resource_ids (intersection) using DFS.
            Args:
                resource_ids: list of resource_id strings (must be non-empty)

            Returns:
                Sorted list of upstream resource IDs reachable from every input resource.

            Raises:
                ValueError: if resource_ids is not a list[str], is empty, contains blanks,
                            or contains ids that do not exist.
        """
        
        # Enforce list-only (no Union/back-compat)
        if not isinstance(resource_ids, list):
            raise ValueError("resource_ids must be a list of strings")

        if not resource_ids:
            raise ValueError("resource_ids must be a non-empty list of strings")

        normalized: list[str] = []
        for rid in resource_ids:
            if rid is None or not str(rid).strip():
                raise ValueError("resource_ids must contain non-empty strings only")
            normalized.append(str(rid).strip())

        # Validate existence
        missing = [rid for rid in normalized if rid not in self._resources]
        if missing:
            raise ValueError(f"Resource(s) not found: {', '.join(missing)}")

        # Build downstream->upstream adjacency map once
        upstream_map: dict[str, list[str]] = {}
        for rel in self._relationships:
            upstream_map.setdefault(rel.downstream_resource_id, []).append(rel.upstream_resource_id)
        
        # helper function to collect all upstream ids for a given resource using DFS
        def collect_upstream(start_rid: str) -> set[str]:
            visited: set[str] = set()
            stack: list[str] = [start_rid]
            while stack:
                current = stack.pop()
                for up in upstream_map.get(current, []):
                    if up not in visited:
                        visited.add(up)
                        stack.append(up)
            return visited

        shared: set[str] | None = None
        for rid in normalized:
            ups = collect_upstream(rid)
            shared = ups if shared is None else (shared & ups)
            if not shared:
                break

        return sorted(shared or set())


    
    def _find_existing_github_downstream(self, resource_id: str) -> ResourceRead | None:
        """Check if the resource already has a downstream with a GitHub location.

        Returns the first downstream resource whose location contains "github"
        (case-insensitive), or ``None`` if no such downstream exists.
        """
        downstream_ids = {
            rel.downstream_resource_id
            for rel in self._relationships
            if rel.upstream_resource_id == resource_id
        }
        for did in downstream_ids:
            res = self._resources.get(did)
            if res is not None and (res.location or "").lower().find("github") != -1:
                return res
        return None

    def prepare_upstream_resource_extraction(
        self,
        data: PrepareExtractionRequest,
    ) -> PrepareExtractionResponse:
        """
        For each input resource_id, create a paired ``-extracted`` target
        resource, establish a FEEDS relationship, and return structured
        tasks / info.

        Workflow per resource_id:
        1. Validate the resource exists (ValueError → 404 if not).
        2. Skip with info if the resource is not in DISCOVERED status.
        3. **Reuse check**: if the resource already has a downstream with a
           GitHub location, return it as a task (no new resource created).
        4. Create ``{rid}-extracted`` target resource (DISCOVERED initially).
        5. Update target status to PLANNED.
        6. Create FEEDS relationship: source → target.
        7. Classify into tasks (target has location) or info (no location).

        Args:
            data: request containing resource_ids, actor_type, actor_name

        Returns:
            PrepareExtractionResponse with tasks and info lists.

        Raises:
            ValueError: if any resource_id does not exist.
        """
        tasks: list[ExtractionTask] = []
        pending_location_count = 0

        for rid in data.resource_ids:
            # 1. Validate existence
            resource = self._resources.get(rid)
            if resource is None:
                raise ValueError(f"Resource(s) not found: {rid}")

            target_rid = f"{rid}-extracted"

            # 2. Skip if not PLANNED
            if resource.resource_status != ResourceStatus.PLANNED:
                continue

            # 3. Reuse check — existing downstream with GitHub location
            existing = self._find_existing_github_downstream(rid)
            if existing is not None:
                tasks.append(ExtractionTask(
                    source_resource_id=rid,
                    target_resource_id=existing.resource_id,
                    target_location=existing.location,
                ))
                continue

            # 4. Look up pre-existing target resource
            target = self._resources.get(target_rid)
            if target is None:
                pending_location_count += 1
                continue

            # 7. Classify
            target_location = target.location or ""
            if target_location:
                tasks.append(ExtractionTask(
                    source_resource_id=rid,
                    target_resource_id=target_rid,
                    target_location=target_location,
                ))
            else:
                pending_location_count += 1

        return PrepareExtractionResponse(tasks=tasks, pending_location_count=pending_location_count)



    # ------------------------------------------------------------------
    # Activity log operations
    # ------------------------------------------------------------------
    def list_logs(
        self, resource_id: Optional[str] = None, offset: int = 0, limit: int = 100
    ) -> tuple[list[ActivityLogRead], int]:
        """List activity logs with pagination, optionally filtered by resource_id.
        
        Returns:
            Tuple of (paginated items, total count)
        """
        logs: Iterable[ActivityLogRead] = self._activity_logs
        if resource_id is not None:
            logs = [lg for lg in logs if lg.resource_id == resource_id]
        sorted_logs = sorted(logs, key=lambda lg: lg.timestamp, reverse=True)
        total = len(sorted_logs)
        paginated = sorted_logs[offset:offset + limit]
        return paginated, total

    def ping(self) -> bool:
        """Always ready for in-memory backend."""
        return True


class DeltaStore:
    def __init__(self) -> None:
        self.host = os.getenv("DATABRICKS_HOST")
        self.http_path = os.getenv("DATABRICKS_HTTP_PATH")
        self.catalog = os.getenv("UC_CATALOG")
        self.schema = os.getenv("UC_SCHEMA")
        self.rid_table = os.getenv("MAGICAL_INDEX_RID_TABLE", "gandalf-magical-index-rid")
        self.rel_table = os.getenv("MAGICAL_INDEX_REL_TABLE", "gandalf-magical-index-rel")
        self.log_table = os.getenv("MAGICAL_INDEX_LOG_TABLE", "gandalf-magical-index-log")

        if not all([self.host, self.http_path, self.catalog, self.schema]):
            raise RuntimeError("Missing Databricks/UC environment configuration for DeltaStore")

        def q(x: str) -> str:
            return f"`{x.replace('`', '``')}`"

        self._rid_fqn = f"{q(self.catalog)}.{q(self.schema)}.{q(self.rid_table)}"
        self._rel_fqn = f"{q(self.catalog)}.{q(self.schema)}.{q(self.rel_table)}"
        self._log_fqn = f"{q(self.catalog)}.{q(self.schema)}.{q(self.log_table)}"

    def _connect(self):
        from app.services.db_auth import get_connection

        return get_connection(host=self.host, http_path=self.http_path)

    # ------------------------------------------------------------------
    # Row mappers
    # ------------------------------------------------------------------
    @staticmethod
    def _coerce_enum(v: object) -> object:
        if not isinstance(v, str):
            return v
        # Handle fully-qualified enum names like "ResourceType.OBJECT_TYPE"
        if "." in v:
            v = v.split(".")[-1]
        # Normalize human-readable labels like "Object Type" → "OBJECT_TYPE"
        if " " in v:
            v = v.replace(" ", "_").upper()
        # Normalize lowercase/mixed-case to uppercase (e.g., "object_type" → "OBJECT_TYPE")
        if v != v.upper():
            v = v.upper()
        return v

    # Base SQL filter to exclude non-MI rows in the shared UC table
    _VALID_STATUSES = "('PLANNED','DISCOVERED','EXTRACTED','TRANSFORMED','DEPLOYED','STAGED_FOR_DECOMMISSION')"
    _VALID_STATUS_LIST = ['PLANNED', 'DISCOVERED', 'EXTRACTED', 'TRANSFORMED', 'DEPLOYED', 'STAGED_FOR_DECOMMISSION']

    def _row_to_resource(self, row) -> Optional[ResourceRead]:
        try:
            return ResourceRead(
                resource_id=row[0],
                resource_name=row[1],
                location=row[2],
                resource_type=self._coerce_enum(row[3]),
                resource_status=self._coerce_enum(row[4]),
                last_by=row[5],
                last_update_time=row[6],
            )
        except Exception as exc:
            logger.warning(
                "_row_to_resource failed for row %s: %s",
                row, exc,
            )
            return None

    def _row_to_log(self, row) -> ActivityLogRead:
        return ActivityLogRead(
            log_id=row[0],
            resource_id=row[1],
            action=self._coerce_enum(row[2]),
            actor_type=self._coerce_enum(row[3]),
            actor_name=row[4],
            details=row[5],
            timestamp=row[6],
        )

    def _select_resource_sql(self) -> str:
        return (
            f"SELECT resource_id, resource_name, location, resource_type, "
            f"resource_status, last_by, last_update_time FROM {self._rid_fqn}"
        )

    def _select_log_sql(self) -> str:
        return (
            f"SELECT log_id, resource_id, action, actor_type, actor_name, "
            f"details, timestamp FROM {self._log_fqn}"
        )

    # ------------------------------------------------------------------
    # Activity log helper
    # ------------------------------------------------------------------
    def _insert_log(self, cur, resource_id: str, action: ActionType,
                    actor_type: ActorType, actor_name: str,
                    details: Optional[str] = None) -> None:
        log_id = generate_log_id()
        cur.execute(
            f"INSERT INTO {self._log_fqn} (log_id, resource_id, action, actor_type, actor_name, details, timestamp) "
            f"VALUES (?, ?, ?, ?, ?, ?, current_timestamp())",
            (log_id, resource_id, action.value, actor_type.value, actor_name, details),
        )

    # ------------------------------------------------------------------
    # Resource operations
    # ------------------------------------------------------------------
    def create_resource(self, data: ResourceCreate) -> ResourceRead:
        rid = data.resource_id or generate_resource_id(
            resource_type=data.resource_type,
            platform=data.platform or "auto"
        )
        last_by = f"{data.actor_type.value}:{data.actor_name}"

        with self._connect() as conn:
            with conn.cursor() as cur:
                cur.execute(f"SELECT 1 FROM {self._rid_fqn} WHERE resource_id = ?", (rid,))
                if cur.fetchone():
                    raise ValueError(f"Resource already exists: {rid}")

                cur.execute(
                    f"INSERT INTO {self._rid_fqn} (resource_id, resource_name, location, resource_type, "
                    f"resource_status, last_by, last_update_time) VALUES (?, ?, ?, ?, ?, ?, current_timestamp())",
                    (rid, data.resource_name, data.location, data.resource_type.value,
                     data.resource_status.value, last_by),
                )
                self._insert_log(
                    cur, rid, ActionType.RESOURCE_CREATED, data.actor_type, data.actor_name,
                    f"Created resource '{data.resource_name}' with status {data.resource_status.value}",
                )
                conn.commit()

                cur.execute(self._select_resource_sql() + " WHERE resource_id = ?", (rid,))
                row = cur.fetchone()
                return self._row_to_resource(row)

    def get_resource(self, resource_id: str) -> Optional[ResourceRead]:
        with self._connect() as conn:
            with conn.cursor() as cur:
                cur.execute(self._select_resource_sql() + " WHERE resource_id = ?", (resource_id,))
                row = cur.fetchone()
                if row is None:
                    logger.info("get_resource: no row found for resource_id=%s", resource_id)
                    return None
                result = self._row_to_resource(row)
                if result is None:
                    logger.warning(
                        "get_resource: row found but _row_to_resource returned None for resource_id=%s, raw row=%s",
                        resource_id, row,
                    )
                return result

    def _valid_status_clause(self) -> tuple[str, list[str]]:
        """Return a parameterized IN clause and corresponding param values.

        Using parameterized placeholders instead of a literal string avoids
        confusing the ``databricks-sql-connector`` parameter parser when the
        SQL also contains other ``?`` markers.
        """
        ph = ",".join(["?"] * len(self._VALID_STATUS_LIST))
        return f"resource_status IN ({ph})", list(self._VALID_STATUS_LIST)

    def list_resources(
        self,
        resource_status: Optional[ResourceStatus] = None,
        resource_type: Optional[str] = None,
        platform: Optional[str] = None,
        offset: int = 0,
        limit: int = 100,
    ) -> tuple[list[ResourceRead], int]:
        """List resources with pagination, optionally filtering by status, type, or platform.
        
        Returns:
            Tuple of (paginated items, total count)
        """
        # Always restrict to valid MI statuses (UC table may contain non-MI rows)
        status_clause, status_params = self._valid_status_clause()
        conditions: list[str] = [status_clause]
        params: list = list(status_params)
        if resource_status is not None:
            conditions.append("resource_status = ?")
            params.append(resource_status.value)
        if resource_type is not None:
            conditions.append("resource_type = ?")
            params.append(resource_type)
        if platform is not None:
            conditions.append("resource_id LIKE ? || ':%'")
            params.append(platform)
        where = " WHERE " + " AND ".join(conditions)

        with self._connect() as conn:
            with conn.cursor() as cur:
                count_sql = f"SELECT COUNT(*) FROM {self._rid_fqn}{where}"
                cur.execute(count_sql, tuple(params))
                total = cur.fetchone()[0]
                if total == 0:
                    return [], 0

                data_sql = (
                    self._select_resource_sql()
                    + f"{where} ORDER BY resource_id"
                    + f" LIMIT {int(limit)} OFFSET {int(offset)}"
                )
                cur.execute(data_sql, tuple(params))
                rows = cur.fetchall()
                resources = [r for r in (self._row_to_resource(row) for row in rows) if r is not None]
                return resources, total

    def update_resource(self, resource_id: str, data: ResourceUpdate) -> Optional[ResourceRead]:
        last_by = f"{data.actor_type.value}:{data.actor_name}"
        set_parts = ["last_by = ?", "last_update_time = current_timestamp()"]
        params: list = [last_by]
        changes: list[str] = []

        if data.resource_name is not None:
            set_parts.append("resource_name = ?")
            params.append(data.resource_name)
            changes.append(f"resource_name -> '{data.resource_name}'")
        if data.location is not None:
            set_parts.append("location = ?")
            params.append(data.location)
            changes.append(f"location -> '{data.location}'")
        if data.resource_type is not None:
            set_parts.append("resource_type = ?")
            params.append(data.resource_type.value)
            changes.append(f"resource_type -> {data.resource_type.value}")
        if data.resource_status is not None:
            set_parts.append("resource_status = ?")
            params.append(data.resource_status.value)
            changes.append(f"resource_status -> {data.resource_status.value}")

        params.append(resource_id)

        with self._connect() as conn:
            with conn.cursor() as cur:
                cur.execute(f"SELECT 1 FROM {self._rid_fqn} WHERE resource_id = ?", (resource_id,))
                if not cur.fetchone():
                    return None

                cur.execute(
                    f"UPDATE {self._rid_fqn} SET {', '.join(set_parts)} WHERE resource_id = ?",
                    tuple(params),
                )
                self._insert_log(
                    cur, resource_id, ActionType.RESOURCE_UPDATED,
                    data.actor_type, data.actor_name,
                    "; ".join(changes) if changes else "no-op update",
                )
                conn.commit()

                cur.execute(self._select_resource_sql() + " WHERE resource_id = ?", (resource_id,))
                row = cur.fetchone()
                return self._row_to_resource(row) if row else None

    def delete_resource(self, resource_id: str, actor_type: ActorType, actor_name: str) -> bool:
        with self._connect() as conn:
            with conn.cursor() as cur:
                cur.execute(f"SELECT 1 FROM {self._rid_fqn} WHERE resource_id = ?", (resource_id,))
                if not cur.fetchone():
                    return False

                cur.execute(
                    f"DELETE FROM {self._rel_fqn} WHERE upstream_resource_id = ? OR downstream_resource_id = ?",
                    (resource_id, resource_id),
                )
                cur.execute(f"DELETE FROM {self._rid_fqn} WHERE resource_id = ?", (resource_id,))
                self._insert_log(
                    cur, resource_id, ActionType.RESOURCE_DELETED,
                    actor_type, actor_name,
                    f"Deleted resource {resource_id} and cascade-removed relationships",
                )
                conn.commit()
                return True

    # ------------------------------------------------------------------
    # Relationship operations
    # ------------------------------------------------------------------
    def create_relationship(self, data: RelationshipCreate) -> RelationshipRead:
        """Raises ``ValueError`` if either resource does not exist."""
        with self._connect() as conn:
            with conn.cursor() as cur:
                missing: list[str] = []
                cur.execute(f"SELECT 1 FROM {self._rid_fqn} WHERE resource_id = ?", (data.upstream_resource_id,))
                if cur.fetchone() is None:
                    missing.append(data.upstream_resource_id)
                cur.execute(f"SELECT 1 FROM {self._rid_fqn} WHERE resource_id = ?", (data.downstream_resource_id,))
                if cur.fetchone() is None:
                    missing.append(data.downstream_resource_id)
                if missing:
                    raise ValueError(f"Resource(s) not found: {', '.join(missing)}")

                cur.execute(
                    f"SELECT upstream_resource_id, downstream_resource_id, relationship_type, notes "
                    f"FROM {self._rel_fqn} WHERE upstream_resource_id = ? AND downstream_resource_id = ? AND relationship_type = ?",
                    (data.upstream_resource_id, data.downstream_resource_id, data.relationship_type.value),
                )
                row = cur.fetchone()
                if row:
                    return RelationshipRead(
                        upstream_resource_id=row[0],
                        downstream_resource_id=row[1],
                        relationship_type=self._coerce_enum(row[2]),
                        notes=row[3],
                    )

                cur.execute(
                    f"INSERT INTO {self._rel_fqn} (upstream_resource_id, downstream_resource_id, relationship_type, notes) "
                    f"VALUES (?, ?, ?, ?)",
                    (data.upstream_resource_id, data.downstream_resource_id,
                     data.relationship_type.value, data.notes),
                )
                self._insert_log(
                    cur, data.upstream_resource_id, ActionType.RELATIONSHIP_CREATED,
                    data.actor_type, data.actor_name,
                    f"{data.upstream_resource_id} {data.relationship_type.value} {data.downstream_resource_id}",
                )
                conn.commit()

                return RelationshipRead(
                    upstream_resource_id=data.upstream_resource_id,
                    downstream_resource_id=data.downstream_resource_id,
                    relationship_type=data.relationship_type,
                    notes=data.notes,
                )

    def delete_relationship(self, data: RelationshipDelete) -> int:
        where = ["upstream_resource_id = ?", "downstream_resource_id = ?"]
        params: list = [data.upstream_resource_id, data.downstream_resource_id]
        if data.relationship_type is not None:
            where.append("relationship_type = ?")
            params.append(data.relationship_type.value)
        where_clause = " AND ".join(where)
        with self._connect() as conn:
            with conn.cursor() as cur:
                # Pre-count because Databricks SQL connector returns -1 for cur.rowcount on DML
                cur.execute(f"SELECT COUNT(*) FROM {self._rel_fqn} WHERE {where_clause}", tuple(params))
                count = cur.fetchone()[0]
                if count > 0:
                    cur.execute(f"DELETE FROM {self._rel_fqn} WHERE {where_clause}", tuple(params))
                    relationship_type = data.relationship_type.value if data.relationship_type is not None else "ANY"
                    self._insert_log(
                        cur,
                        data.upstream_resource_id,
                        ActionType.RELATIONSHIP_DELETED,
                        data.actor_type,
                        data.actor_name,
                        (
                            f"Deleted {count} relationship(s): "
                            f"upstream={data.upstream_resource_id}, "
                            f"downstream={data.downstream_resource_id}, "
                            f"relationship_type={relationship_type}"
                        ),
                    )
                    conn.commit()
                return count

    def list_upstream_resources(
        self, resource_id: str, offset: int = 0, limit: int = 100
    ) -> tuple[list[ResourceRead], int]:
        """Return resources that feed into ``resource_id`` (upstream set) with pagination.
        
        Returns:
            Tuple of (paginated items, total count)
        """
        status_clause, status_params = self._valid_status_clause()
        sub = f"SELECT upstream_resource_id FROM {self._rel_fqn} WHERE downstream_resource_id = ?"
        where = f" WHERE resource_id IN ({sub}) AND {status_clause}"
        params = [resource_id] + status_params
        with self._connect() as conn:
            with conn.cursor() as cur:
                cur.execute(f"SELECT COUNT(*) FROM {self._rid_fqn}{where}", tuple(params))
                total = cur.fetchone()[0]
                if total == 0:
                    return [], 0
                data_sql = (
                    self._select_resource_sql()
                    + f"{where} ORDER BY resource_id"
                    + f" LIMIT {int(limit)} OFFSET {int(offset)}"
                )
                cur.execute(data_sql, tuple(params))
                rows = cur.fetchall()
                resources = [r for r in (self._row_to_resource(row) for row in rows) if r is not None]
                return resources, total

    def list_downstream_resources(
        self, resource_id: str, offset: int = 0, limit: int = 100
    ) -> tuple[list[ResourceRead], int]:
        """Return resources that depend on ``resource_id`` (downstream set) with pagination.
        
        Returns:
            Tuple of (paginated items, total count)
        """
        status_clause, status_params = self._valid_status_clause()
        sub = f"SELECT downstream_resource_id FROM {self._rel_fqn} WHERE upstream_resource_id = ?"
        where = f" WHERE resource_id IN ({sub}) AND {status_clause}"
        params = [resource_id] + status_params
        with self._connect() as conn:
            with conn.cursor() as cur:
                cur.execute(f"SELECT COUNT(*) FROM {self._rid_fqn}{where}", tuple(params))
                total = cur.fetchone()[0]
                if total == 0:
                    return [], 0
                data_sql = (
                    self._select_resource_sql()
                    + f"{where} ORDER BY resource_id"
                    + f" LIMIT {int(limit)} OFFSET {int(offset)}"
                )
                cur.execute(data_sql, tuple(params))
                rows = cur.fetchall()
                resources = [r for r in (self._row_to_resource(row) for row in rows) if r is not None]
                return resources, total

    # Safety limits for graph traversal to prevent runaway queries / 504 timeouts
    _BFS_MAX_DEPTH = 50
    _BFS_MAX_NODES = 5000

    def list_upstream_resource_ids(self, resource_ids: list[str]) -> list[str]:
        """
        Return upstream resource IDs shared by ALL provided resource_ids (intersection),
        using batched BFS backed by SQL queries.

        Each BFS level is resolved in a single ``WHERE downstream_resource_id IN (...)``
        query, reducing the total number of SQL round-trips from O(nodes) to O(depth).
        Safety limits (_BFS_MAX_DEPTH, _BFS_MAX_NODES) prevent runaway traversals on
        large graphs from causing 504 upstream timeouts.

        Args:
            resource_ids: list of resource_id strings (must be non-empty)

        Returns:
            Sorted list of upstream resource IDs reachable from every input resource.

        Raises:
            ValueError: if resource_ids is empty or any resource does not exist.
        """

        # ---- Validate input (store-level, API already does this) ----
        if not isinstance(resource_ids, list) or not resource_ids:
            raise ValueError("resource_ids must be a non-empty list")

        normalized = [rid.strip() for rid in resource_ids if rid and rid.strip()]
        if len(normalized) != len(resource_ids):
            raise ValueError("resource_ids must contain non-empty strings only")

        # ---- Validate existence ----
        missing = [rid for rid in normalized if self.get_resource(rid) is None]
        if missing:
            raise ValueError(f"Resource(s) not found: {', '.join(missing)}")

        # ---- Helper: collect all upstream IDs for ONE resource via batched BFS ----
        def collect_upstream(start_rid: str) -> set[str]:
            visited: set[str] = set()
            frontier: list[str] = [start_rid]

            with self._connect() as conn:
                with conn.cursor() as cur:
                    depth = 0
                    while frontier and depth < self._BFS_MAX_DEPTH:
                        depth += 1
                        placeholders = ",".join(["?"] * len(frontier))
                        sql = (
                            f"SELECT upstream_resource_id FROM {self._rel_fqn} "
                            f"WHERE downstream_resource_id IN ({placeholders})"
                        )
                        cur.execute(sql, tuple(frontier))
                        rows = cur.fetchall()

                        next_frontier: list[str] = []
                        for (upstream_id,) in rows:
                            if upstream_id not in visited:
                                visited.add(upstream_id)
                                next_frontier.append(upstream_id)
                                if len(visited) >= self._BFS_MAX_NODES:
                                    logger.warning(
                                        "BFS node limit (%d) reached for resource %s at depth %d",
                                        self._BFS_MAX_NODES, start_rid, depth,
                                    )
                                    return visited
                        frontier = next_frontier

                    if depth >= self._BFS_MAX_DEPTH:
                        logger.warning(
                            "BFS depth limit (%d) reached for resource %s",
                            self._BFS_MAX_DEPTH, start_rid,
                        )

            return visited

        # ---- Compute intersection across all resource_ids ----
        shared_upstream: set[str] | None = None

        for rid in normalized:
            upstream_set = collect_upstream(rid)
            shared_upstream = (
                upstream_set if shared_upstream is None
                else shared_upstream & upstream_set
            )

            # Early exit if intersection is empty
            if not shared_upstream:
                break

        return sorted(shared_upstream or set())


    def _find_existing_github_downstream(self, resource_id: str) -> ResourceRead | None:
        """Check if the resource already has a downstream with a GitHub location.

        Queries the relationship + resource tables for any downstream resource
        whose location contains "github" (case-insensitive).
        Returns the first match, or ``None``.
        """
        downstream_resources, _ = self.list_downstream_resources(resource_id, offset=0, limit=1000)
        for res in downstream_resources:
            if (res.location or "").lower().find("github") != -1:
                return res
        return None

    def prepare_upstream_resource_extraction(
        self,
        data: PrepareExtractionRequest,
    ) -> PrepareExtractionResponse:
        """
        For each input resource_id, create a paired ``-extracted`` target
        resource, establish a FEEDS relationship, and return structured
        tasks / info.

        Workflow per resource_id:
        1. Validate the resource exists (ValueError → 404 if not).
        2. Skip with info if the resource is not in DISCOVERED status.
        3. **Reuse check**: if the resource already has a downstream with a
           GitHub location, return it as a task (no new resource created).
        4. Create ``{rid}-extracted`` target resource (DISCOVERED initially).
        5. Update target status to PLANNED.
        6. Create FEEDS relationship: source → target.
        7. Classify into tasks (target has location) or info (no location).

        Args:
            data: request containing resource_ids, actor_type, actor_name

        Returns:
            PrepareExtractionResponse with tasks and info lists.

        Raises:
            ValueError: if any resource_id does not exist.
        """
        tasks: list[ExtractionTask] = []
        pending_location_count = 0

        last_by = f"{data.actor_type.value}:{data.actor_name}"

        for rid in data.resource_ids:
            target_rid = f"{rid}-extracted"

            # 1. Validate existence
            resource = self.get_resource(rid)
            if resource is None:
                raise ValueError(f"Resource(s) not found: {rid}")

            # 2. Skip if not PLANNED
            if resource.resource_status != ResourceStatus.PLANNED:
                continue

            # 3. Reuse check — existing downstream with GitHub location
            existing = self._find_existing_github_downstream(rid)
            if existing is not None:
                tasks.append(ExtractionTask(
                    source_resource_id=rid,
                    target_resource_id=existing.resource_id,
                    target_location=existing.location,
                ))
                continue

            # 4. Look up pre-existing target resource
            target = self.get_resource(target_rid)
            if target is None:
                pending_location_count += 1
                continue

            # 7. Classify
            target_location = (target.location or "").strip()
            if target_location:
                tasks.append(ExtractionTask(
                    source_resource_id=rid,
                    target_resource_id=target_rid,
                    target_location=target_location,
                ))
            else:
                pending_location_count += 1

        return PrepareExtractionResponse(tasks=tasks, pending_location_count=pending_location_count)

    # ------------------------------------------------------------------
    # Activity log operations
    # ------------------------------------------------------------------
    def list_logs(
        self, resource_id: Optional[str] = None, offset: int = 0, limit: int = 100
    ) -> tuple[list[ActivityLogRead], int]:
        """List activity logs with pagination, optionally filtered by resource_id.
        
        Returns:
            Tuple of (paginated items, total count)
        """
        params: list = []
        where = ""
        if resource_id is not None:
            where = " WHERE resource_id = ?"
            params.append(resource_id)

        with self._connect() as conn:
            with conn.cursor() as cur:
                cur.execute(f"SELECT COUNT(*) FROM {self._log_fqn}{where}", tuple(params))
                total = cur.fetchone()[0]
                if total == 0:
                    return [], 0
                data_sql = (
                    self._select_log_sql()
                    + f"{where} ORDER BY timestamp DESC"
                    + f" LIMIT {int(limit)} OFFSET {int(offset)}"
                )
                cur.execute(data_sql, tuple(params))
                rows = cur.fetchall()
                logs = [self._row_to_log(r) for r in rows]
                return logs, total

    def ping(self) -> bool:
        """Simple connectivity check against Databricks SQL endpoint."""
        try:
            with self._connect() as conn:
                with conn.cursor() as cur:
                    cur.execute("SELECT 1")
                    cur.fetchone()
            return True
        except Exception:
            return False


store = DeltaStore() if settings.STORAGE_BACKEND.lower() == "delta" else InMemoryStore()
