from transforms.api import transform, Input, Output,incremental
from utility.column_clean import clean_columns, lowercase_columns, remove_prefix

@transform(
   out=Output("/Innovation Lab/[Source] Oracle AOTS-M/data/clean/BOADMIN.TT_WORK_DONE_ENTRIES_ARCHIVE"),
   df=Input("/Innovation Lab/[Source] Oracle AOTS-M/data/raw/BOADMIN.TT_WORK_DONE_ENTRIES_ARCHIVE"),
)
def my_compute_function(df, out):
    df = clean_columns(
        df.dataframe(),
        strip_columns=strip_columns,
        integer_columns=cast_to_integer_columns,
        double_columns=cast_to_double_columns,
        decimal_columns=cast_to_decimal_columns,
        timestamp_columns=cast_to_timestamp_from_long_columns,
        datetime_columns=cast_to_timestamp_columns,
        datetime_format=datetime_format,
        date_columns=cast_to_date_columns,
        date_format=date_format,
        id_columns=cast_to_string_columns,
        integer_from_num_columns=cast_to_integer_from_decimal_columns
    )
    df = lowercase_columns(df)
    out.write_dataframe(df)

date_format = 'yyyy-MM-dd'
datetime_format = 'MM/dd/yy HH:mm:ss'

cast_to_date_columns = []
cast_to_timestamp_columns = [
    "LOG_DATE_TIME",
    "ARCHIVE_DATE",
    "TICKET_CREATED_DATE"
]
cast_to_timestamp_from_long_columns = []
cast_to_integer_columns = []
cast_to_double_columns = []
cast_to_decimal_columns = []
cast_to_string_columns = []
cast_to_integer_from_decimal_columns = []
strip_columns = []