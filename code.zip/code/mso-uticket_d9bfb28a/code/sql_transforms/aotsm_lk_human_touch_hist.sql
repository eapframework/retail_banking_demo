CREATE TABLE `ri.foundry.main.dataset.b63e24e5-2d6b-4a59-afb4-d4a04925680b` AS
    SELECT STAGE.*
, WEBPHONE_HIST_FIRST.l15_name hist_first_cogs_1_name
, WEBPHONE_HIST_FIRST.l14_name hist_first_cogs_2_name
, WEBPHONE_HIST_FIRST.l13_name hist_first_cogs_3_name      
, WEBPHONE_HIST_FIRST.l12_name hist_first_cogs_4_name
, WEBPHONE_HIST_FIRST.l11_name hist_first_cogs_5_name
, WEBPHONE_HIST_FIRST.l10_name hist_first_cogs_6_name
, WEBPHONE_HIST_FIRST.l9_name  hist_first_cogs_7_name
, WEBPHONE_HIST_LAST.l15_name hist_last_cogs_1_name
, WEBPHONE_HIST_LAST.l14_name hist_last_cogs_2_name
, WEBPHONE_HIST_LAST.l13_name hist_last_cogs_3_name      
, WEBPHONE_HIST_LAST.l12_name hist_last_cogs_4_name
, WEBPHONE_HIST_LAST.l11_name hist_last_cogs_5_name
, WEBPHONE_HIST_LAST.l10_name hist_last_cogs_6_name
, WEBPHONE_HIST_LAST.l9_name  hist_last_cogs_7_name
, CASE WHEN WEBPHONE_HIST_FIRST.l15_mgt_level_indicator == '6' THEN WEBPHONE_HIST_FIRST.l15_name
       WHEN WEBPHONE_HIST_FIRST.l14_mgt_level_indicator == '6' THEN WEBPHONE_HIST_FIRST.l14_name
       WHEN WEBPHONE_HIST_FIRST.l13_mgt_level_indicator == '6' THEN WEBPHONE_HIST_FIRST.l13_name
       WHEN WEBPHONE_HIST_FIRST.l12_mgt_level_indicator == '6' THEN WEBPHONE_HIST_FIRST.l12_name
       WHEN WEBPHONE_HIST_FIRST.l11_mgt_level_indicator == '6' THEN WEBPHONE_HIST_FIRST.l11_name
       WHEN WEBPHONE_HIST_FIRST.l10_mgt_level_indicator == '6' THEN WEBPHONE_HIST_FIRST.l10_name
       WHEN WEBPHONE_HIST_FIRST.l9_mgt_level_indicator == '6' THEN WEBPHONE_HIST_FIRST.l9_name
       WHEN WEBPHONE_HIST_FIRST.l8_mgt_level_indicator == '6' THEN WEBPHONE_HIST_FIRST.l8_name
       WHEN WEBPHONE_HIST_FIRST.l7_mgt_level_indicator == '6' THEN WEBPHONE_HIST_FIRST.l7_name
       ELSE 'NO SVP' END hist_first_svp_name
, CASE WHEN WEBPHONE_HIST_FIRST.l15_mgt_level_indicator == '5' THEN WEBPHONE_HIST_FIRST.l15_name
       WHEN WEBPHONE_HIST_FIRST.l14_mgt_level_indicator == '5' THEN WEBPHONE_HIST_FIRST.l14_name
       WHEN WEBPHONE_HIST_FIRST.l13_mgt_level_indicator == '5' THEN WEBPHONE_HIST_FIRST.l13_name
       WHEN WEBPHONE_HIST_FIRST.l12_mgt_level_indicator == '5' THEN WEBPHONE_HIST_FIRST.l12_name
       WHEN WEBPHONE_HIST_FIRST.l11_mgt_level_indicator == '5' THEN WEBPHONE_HIST_FIRST.l11_name
       WHEN WEBPHONE_HIST_FIRST.l10_mgt_level_indicator == '5' THEN WEBPHONE_HIST_FIRST.l10_name
       WHEN WEBPHONE_HIST_FIRST.l9_mgt_level_indicator == '5' THEN WEBPHONE_HIST_FIRST.l9_name
       WHEN WEBPHONE_HIST_FIRST.l8_mgt_level_indicator == '5' THEN WEBPHONE_HIST_FIRST.l8_name
       WHEN WEBPHONE_HIST_FIRST.l7_mgt_level_indicator == '5' THEN WEBPHONE_HIST_FIRST.l7_name
       ELSE 'NO VP' END hist_first_vp_name
, CASE WHEN WEBPHONE_HIST_FIRST.l15_mgt_level_indicator == '4' THEN WEBPHONE_HIST_FIRST.l15_name
       WHEN WEBPHONE_HIST_FIRST.l14_mgt_level_indicator == '4' THEN WEBPHONE_HIST_FIRST.l14_name
       WHEN WEBPHONE_HIST_FIRST.l13_mgt_level_indicator == '4' THEN WEBPHONE_HIST_FIRST.l13_name
       WHEN WEBPHONE_HIST_FIRST.l12_mgt_level_indicator == '4' THEN WEBPHONE_HIST_FIRST.l12_name
       WHEN WEBPHONE_HIST_FIRST.l11_mgt_level_indicator == '4' THEN WEBPHONE_HIST_FIRST.l11_name
       WHEN WEBPHONE_HIST_FIRST.l10_mgt_level_indicator == '4' THEN WEBPHONE_HIST_FIRST.l10_name
       WHEN WEBPHONE_HIST_FIRST.l9_mgt_level_indicator == '4' THEN WEBPHONE_HIST_FIRST.l9_name
       WHEN WEBPHONE_HIST_FIRST.l8_mgt_level_indicator == '4' THEN WEBPHONE_HIST_FIRST.l8_name
       WHEN WEBPHONE_HIST_FIRST.l7_mgt_level_indicator == '4' THEN WEBPHONE_HIST_FIRST.l7_name
       ELSE 'NO AVP' END hist_first_avp_name
, CASE WHEN WEBPHONE_HIST_FIRST.l15_mgt_level_indicator == '3' THEN WEBPHONE_HIST_FIRST.l15_name
       WHEN WEBPHONE_HIST_FIRST.l14_mgt_level_indicator == '3' THEN WEBPHONE_HIST_FIRST.l14_name
       WHEN WEBPHONE_HIST_FIRST.l13_mgt_level_indicator == '3' THEN WEBPHONE_HIST_FIRST.l13_name
       WHEN WEBPHONE_HIST_FIRST.l12_mgt_level_indicator == '3' THEN WEBPHONE_HIST_FIRST.l12_name
       WHEN WEBPHONE_HIST_FIRST.l11_mgt_level_indicator == '3' THEN WEBPHONE_HIST_FIRST.l11_name
       WHEN WEBPHONE_HIST_FIRST.l10_mgt_level_indicator == '3' THEN WEBPHONE_HIST_FIRST.l10_name
       WHEN WEBPHONE_HIST_FIRST.l9_mgt_level_indicator == '3' THEN WEBPHONE_HIST_FIRST.l9_name
       WHEN WEBPHONE_HIST_FIRST.l8_mgt_level_indicator == '3' THEN WEBPHONE_HIST_FIRST.l8_name
       WHEN WEBPHONE_HIST_FIRST.l7_mgt_level_indicator == '3' THEN WEBPHONE_HIST_FIRST.l7_name
       ELSE 'NO Director' END hist_first_director_name
, CASE WHEN WEBPHONE_HIST_LAST.l15_mgt_level_indicator == '6' THEN WEBPHONE_HIST_LAST.l15_name
       WHEN WEBPHONE_HIST_LAST.l14_mgt_level_indicator == '6' THEN WEBPHONE_HIST_LAST.l14_name
       WHEN WEBPHONE_HIST_LAST.l13_mgt_level_indicator == '6' THEN WEBPHONE_HIST_LAST.l13_name
       WHEN WEBPHONE_HIST_LAST.l12_mgt_level_indicator == '6' THEN WEBPHONE_HIST_LAST.l12_name
       WHEN WEBPHONE_HIST_LAST.l11_mgt_level_indicator == '6' THEN WEBPHONE_HIST_LAST.l11_name
       WHEN WEBPHONE_HIST_LAST.l10_mgt_level_indicator== '6' THEN WEBPHONE_HIST_LAST.l10_name
       WHEN WEBPHONE_HIST_LAST.l9_mgt_level_indicator == '6' THEN WEBPHONE_HIST_LAST.l9_name
       WHEN WEBPHONE_HIST_LAST.l8_mgt_level_indicator == '6' THEN WEBPHONE_HIST_LAST.l8_name
       WHEN WEBPHONE_HIST_LAST.l7_mgt_level_indicator == '6' THEN WEBPHONE_HIST_LAST.l7_name
       ELSE 'NO SVP' END hist_last_svp_name
, CASE WHEN WEBPHONE_HIST_LAST.l15_mgt_level_indicator == '5' THEN WEBPHONE_HIST_LAST.l15_name
       WHEN WEBPHONE_HIST_LAST.l14_mgt_level_indicator == '5' THEN WEBPHONE_HIST_LAST.l14_name
       WHEN WEBPHONE_HIST_LAST.l13_mgt_level_indicator == '5' THEN WEBPHONE_HIST_LAST.l13_name
       WHEN WEBPHONE_HIST_LAST.l12_mgt_level_indicator == '5' THEN WEBPHONE_HIST_LAST.l12_name
       WHEN WEBPHONE_HIST_LAST.l11_mgt_level_indicator == '5' THEN WEBPHONE_HIST_LAST.l11_name
       WHEN WEBPHONE_HIST_LAST.l10_mgt_level_indicator == '5' THEN WEBPHONE_HIST_LAST.l10_name
       WHEN WEBPHONE_HIST_LAST.l9_mgt_level_indicator == '5' THEN WEBPHONE_HIST_LAST.l9_name
       WHEN WEBPHONE_HIST_LAST.l8_mgt_level_indicator == '5' THEN WEBPHONE_HIST_LAST.l8_name
       WHEN WEBPHONE_HIST_LAST.l7_mgt_level_indicator == '5' THEN WEBPHONE_HIST_LAST.l7_name
       ELSE 'NO VP' END hist_last_vp_name
, CASE WHEN WEBPHONE_HIST_LAST.l15_mgt_level_indicator == '4' THEN WEBPHONE_HIST_LAST.l15_name
       WHEN WEBPHONE_HIST_LAST.l14_mgt_level_indicator == '4' THEN WEBPHONE_HIST_LAST.l14_name
       WHEN WEBPHONE_HIST_LAST.l13_mgt_level_indicator == '4' THEN WEBPHONE_HIST_LAST.l13_name
       WHEN WEBPHONE_HIST_LAST.l12_mgt_level_indicator == '4' THEN WEBPHONE_HIST_LAST.l12_name
       WHEN WEBPHONE_HIST_LAST.l11_mgt_level_indicator == '4' THEN WEBPHONE_HIST_LAST.l11_name
       WHEN WEBPHONE_HIST_LAST.l10_mgt_level_indicator == '4' THEN WEBPHONE_HIST_LAST.l10_name
       WHEN WEBPHONE_HIST_LAST.l9_mgt_level_indicator == '4' THEN WEBPHONE_HIST_LAST.l9_name
       WHEN WEBPHONE_HIST_LAST.l8_mgt_level_indicator == '4' THEN WEBPHONE_HIST_LAST.l8_name
       WHEN WEBPHONE_HIST_LAST.l7_mgt_level_indicator == '4' THEN WEBPHONE_HIST_LAST.l7_name
       ELSE 'NO AVP' END hist_last_avp_name
, CASE WHEN WEBPHONE_HIST_LAST.l15_mgt_level_indicator == '3' THEN WEBPHONE_HIST_LAST.l15_name
       WHEN WEBPHONE_HIST_LAST.l14_mgt_level_indicator == '3' THEN WEBPHONE_HIST_LAST.l14_name
       WHEN WEBPHONE_HIST_LAST.l13_mgt_level_indicator == '3' THEN WEBPHONE_HIST_LAST.l13_name
       WHEN WEBPHONE_HIST_LAST.l12_mgt_level_indicator == '3' THEN WEBPHONE_HIST_LAST.l12_name
       WHEN WEBPHONE_HIST_LAST.l11_mgt_level_indicator== '3' THEN WEBPHONE_HIST_LAST.l11_name
       WHEN WEBPHONE_HIST_LAST.l10_mgt_level_indicator == '3' THEN WEBPHONE_HIST_LAST.l10_name
       WHEN WEBPHONE_HIST_LAST.l9_mgt_level_indicator == '3' THEN WEBPHONE_HIST_LAST.l9_name
       WHEN WEBPHONE_HIST_LAST.l8_mgt_level_indicator == '3' THEN WEBPHONE_HIST_LAST.l8_name
       WHEN WEBPHONE_HIST_LAST.l7_mgt_level_indicator == '3' THEN WEBPHONE_HIST_LAST.l7_name
       ELSE 'NO Director' END hist_last_director_name
     FROM `ri.foundry.main.dataset.71088915-9b90-4a72-888f-58ba258736c2` STAGE
     LEFT JOIN `ri.foundry.main.dataset.d47ad3c7-589c-45e0-ae9e-c3cbe1c27ffb` WEBPHONE_HIST_FIRST
    ON STAGE.first_human_attuid=WEBPHONE_HIST_FIRST.sbc_uid
     and STAGE.first_human_touch >= WEBPHONE_HIST_FIRST.start_date
      and STAGE.first_human_touch <= WEBPHONE_HIST_FIRST.end_date
 LEFT JOIN `ri.foundry.main.dataset.d47ad3c7-589c-45e0-ae9e-c3cbe1c27ffb` WEBPHONE_HIST_LAST
    ON STAGE.last_human_attuid=WEBPHONE_HIST_LAST.sbc_uid
     and STAGE.last_human_touch >= WEBPHONE_HIST_LAST.start_date
      and STAGE.last_human_touch <= WEBPHONE_HIST_LAST.end_date
