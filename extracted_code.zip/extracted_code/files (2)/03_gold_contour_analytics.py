"""
MSO uTicket — Databricks DLT Pipeline (Gold Layer)
====================================================
Contour analyses converted to DLT tables.
All 4 contour outputs share the same parent analysis (3c6bd964-6e80-4e34-8437-ff19cfe6272a)
but produce different filtered/shaped datasets.

Lineage recap:
  clean_chg_change ─┬─ LEFT JOIN silver_ap_signature_enriched (on change_id = request)
                     ├─ LEFT JOIN clean_acmr23_mobility_equipment_info (on change_id)
                     ├─ LEFT JOIN clean_chg_task (on change_id)  [prefix: task_]
                     ├─ LEFT JOIN clean_acmr14_affected_techs (on change_id)  [prefix: new_]
                     └─ LEFT JOIN clean_acmr14_affected_cllis (on change_id)
                           │
                     ┌─────┴──────────────────────────────┐
                     │ FILTER on requester_group / category │
                     │ FILTER on status (open vs closed)    │
                     │ CASE WHEN status/approval mappings   │
                     │ SELECT 50–62 columns                 │
                     │ Date formatting (Eastern TZ)         │
                     └──────────────────────────────────────┘
                           │
              ┌────────────┼────────────┬───────────────┐
              ▼            ▼            ▼               ▼
    mso_open_tickets  mso_closed   cmclosed_tasks  cmclosed_notasks
"""

import dlt
from pyspark.sql import functions as F
from utilities import (
    STATUS_MAP, TASK_STATUS_MAP, APPROVAL_STATUS_MAP, map_status,
    MSO_REQUESTER_GROUPS, MSO_CATEGORY_OVERRIDE,
)


# ═══════════════════════════════════════════════════════════════════════════
# Helper: Build the base joined dataset (shared across all 4 gold tables)
# ═══════════════════════════════════════════════════════════════════════════

def _build_base_joined(include_tasks: bool = True, include_apsig: bool = True,
                        include_equipment: bool = True, include_techs: bool = True,
                        include_cllis: bool = True):
    """
    Reconstruct the Contour starting dataset + 5 LEFT JOINs.
    All joins are on change_id. Prefixes match the Contour join-columns config.
    """
    chg = dlt.read("clean_chg_change")

    if include_apsig:
        # Join 1: ap_signature_enriched (prefix: apsig_) on change_id = request
        apsig = dlt.read("silver_ap_signature_enriched").select(
            F.col("request"),
            F.col("approver_signature").alias("apsig_approver_signature"),
            F.col("role").alias("apsig_role"),
            F.col("approval_status").alias("apsig_approval_status"),
        )
        chg = chg.join(apsig, chg.change_id == apsig.request, "left")
        # Rename 'request' to 'apsig_request' to match Contour prefix convention
        chg = chg.withColumnRenamed("request", "apsig_request")

    if include_equipment:
        # Join 2: acmr23_mobility_equipment_info on change_id
        equip = dlt.read("clean_acmr23_mobility_equipment_info").select(
            "change_id",
            F.col("equipment_id"),
            F.col("equipment_name"),
            F.col("equipment_type"),
        ).alias("equip")
        chg = chg.join(equip, chg.change_id == F.col("equip.change_id"), "left").drop(F.col("equip.change_id"))

    if include_tasks:
        # Join 3: chg_task (prefix: task_) on change_id
        task = dlt.read("clean_chg_task").select(
            "change_id",
            F.col("implementor_group").alias("task_implementor_group"),
            F.col("task_id").alias("task_task_id"),
            F.col("description").alias("task_description"),
            F.col("summary").alias("task_summary"),
            F.col("status").alias("task_status"),
            F.col("task_full_name").alias("task_task_full_name"),
            F.col("implementor_name_").alias("task_implementor_name_"),
            F.col("implementor_e_mail").alias("task_implementor_e_mail"),
            F.col("task_closed_by_date_rpt").alias("task_task_closed_by_date_rpt"),
            F.col("planned_start_date").alias("task_planned_start_date"),
            F.col("planned_end_date").alias("task_planned_end_date"),
            F.col("planned_end_eastern_dt").alias("task_planned_end_eastern_dt"),
            F.col("planned_start_eastern_dt").alias("task_planned_start_eastern_dt"),
            F.col("task_closed_by_date").alias("task_task_closed_by_date"),
        ).alias("task")
        chg = chg.join(task, chg.change_id == F.col("task.change_id"), "left").drop(F.col("task.change_id"))

    if include_techs:
        # Join 4: acmr14_affected_techs (prefix: new_) on change_id
        techs = dlt.read("clean_acmr14_affected_techs").select(
            "change_id",
            F.col("technology").alias("new_technology"),
        ).alias("techs")
        chg = chg.join(techs, chg.change_id == F.col("techs.change_id"), "left").drop(F.col("techs.change_id"))

    if include_cllis:
        # Join 5: acmr14_affected_cllis on change_id  (brings 'location' column)
        cllis = dlt.read("clean_acmr14_affected_cllis").select(
            "change_id",
            F.col("location"),
        ).alias("cllis")
        chg = chg.join(cllis, chg.change_id == F.col("cllis.change_id"), "left").drop(F.col("cllis.change_id"))

    return chg


def _apply_mso_requester_filter(df):
    """Filter: requester_group IN (...MSO groups...) OR category = 'Mobility-External Partner'"""
    return df.filter(
        F.col("requester_group").isin(MSO_REQUESTER_GROUPS)
        | (F.col("category") == F.lit(MSO_CATEGORY_OVERRIDE))
    )


def _apply_status_mappings(df):
    """Apply CASE WHEN mappings for status, task_status, approval_status."""
    df = df.withColumn("status", map_status("status", STATUS_MAP))

    if "task_status" in df.columns:
        df = df.withColumn("task_status", map_status("task_status", TASK_STATUS_MAP, "Status Unknown"))

    if "approval_status" in df.columns:
        df = df.withColumn("approval_status", map_status("approval_status", APPROVAL_STATUS_MAP))

    return df


def _apply_eastern_date_formatting(df, columns_utc: list, columns_raw: list = None):
    """
    Convert UTC timestamps to Eastern TZ formatted strings.
    columns_utc: columns needing from_utc_timestamp + date_format
    columns_raw: columns already in Eastern, just need date_format
    """
    fmt = "yyyy-MM-dd HH:mm:ss a"
    for c in columns_utc:
        if c in df.columns:
            df = df.withColumn(c, F.date_format(F.from_utc_timestamp(F.col(c), "America/New_York"), fmt))
    for c in (columns_raw or []):
        if c in df.columns:
            df = df.withColumn(c, F.date_format(F.col(c), fmt))
    return df


# ═══════════════════════════════════════════════════════════════════════════
# GOLD TABLE 1: mso_aotscm_open_tickets
#   Contour RID: b22912bc-1f34-4a4f-85cb-1a7e87a0fbe2
#   Filter: status NOT IN (7, 8) → Open tickets only
#   62 columns kept, supervisor_group → assignee_group rename
# ═══════════════════════════════════════════════════════════════════════════

@dlt.table(
    name="mso_aotscm_open_tickets",
    comment="Gold: MSO AOTS CM Open Tickets. Contour-derived, 62 columns. Status NOT IN (Closed, Cancelled).",
    table_properties={"quality": "gold"},
)
def mso_aotscm_open_tickets():
    """
    Converted from: Contour b22912bc → MSO_AOTS_CM_OpenTickets.py
    Foundry output path: /Innovation Lab/MSO uTicket/data/mso_aotscm_open_tickets
    
    Pipeline:
    1. Start from clean_chg_change
    2. LEFT JOIN 5 tables on change_id
    3. FILTER: requester_group IN MSO groups OR category = 'Mobility-External Partner'
    4. FILTER: status NOT IN (7=Closed, 8=Cancelled)
    5. Map status/task_status/approval_status codes → text
    6. SELECT 62 columns (rename supervisor_group → assignee_group)
    7. Format dates to Eastern TZ
    """
    df = _build_base_joined()

    # Filter: MSO requester groups
    df = _apply_mso_requester_filter(df)

    # Filter: Open tickets only (status NOT IN 7=Closed, 8=Cancelled)
    # Note: status is still numeric at this point (before mapping)
    df = df.filter(~F.col("status").isin(7, 8))

    # Apply status text mappings
    df = _apply_status_mappings(df)

    # Rename supervisor_group → assignee_group
    if "supervisor_group" in df.columns:
        df = df.withColumnRenamed("supervisor_group", "assignee_group")

    # Select the 62 kept columns
    kept_columns = [
        "change_id", "order_number", "create_date", "modified_date",
        "planned_start_date", "planned_end_date", "status", "category",
        "type", "item", "summary", "work_type", "requester_group",
        "requester_name", "requester_login_name", "assignee_login_name",
        "assignee", "service_affected_aots", "services_supported",
        "product_affected", "reason_aots", "business_risk_aots",
        "technical_risk_aots", "impact", "customer_impacted",
        "first_moved_to_pending_apprvl", "closure_code", "aots_closure_code",
        "closure_code2", "root_cause_code", "root_cause_action_plan_aots",
        "rescheduled_count", "approval_status", "description", "clli",
        "closing_comments_aots", "number_of_tasks", "assignee_group",
        "task_implementor_group", "task_task_id", "task_description",
        "task_summary", "task_status", "task_task_full_name",
        "task_implementor_name_", "task_implementor_e_mail",
        "impacted_state", "location", "new_technology",
        "equipment_id", "equipment_name", "equipment_type",
        "apsig_approval_status", "apsig_request", "apsig_role",
        "apsig_approver_signature", "emergency_",
        "supervisor_location", "change_closed_by_eastern_dt",
        "task_task_closed_by_date_rpt",
        "task_planned_start_eastern_dt", "task_planned_end_eastern_dt",
    ]
    # Only select columns that exist (defensive)
    available = [c for c in kept_columns if c in df.columns]
    df = df.select(available)

    # Format dates to Eastern TZ
    df = _apply_eastern_date_formatting(
        df,
        columns_utc=["create_date", "modified_date", "planned_start_date", "planned_end_date"],
        columns_raw=["change_closed_by_eastern_dt"],
    )

    return df


# ═══════════════════════════════════════════════════════════════════════════
# GOLD TABLE 2: mso_aotscm_closed_tickets
#   Contour RID: 42820dd4-81ca-4efa-9bab-0350946208fc
#   Filter: status IN (7, 8) AND closed within last year
#   62 columns kept (same as open)
# ═══════════════════════════════════════════════════════════════════════════

@dlt.table(
    name="mso_aotscm_closed_tickets",
    comment="Gold: MSO AOTS CM Closed Tickets. Status IN (Closed, Cancelled), last 1 year.",
    table_properties={"quality": "gold"},
)
def mso_aotscm_closed_tickets():
    """
    Converted from: Contour 42820dd4 → MSO_AOTS_CM_ClosedTickets.py
    
    Differences from open_tickets:
    - Board 7: FILTER status IN (7, 8) instead of NOT IN
    - Board 7 (extra): Year(change_closed_by_eastern_dt) >= YEAR(current_date) - 1
                        AND change_closed_by_eastern_dt <= current_date
    """
    df = _build_base_joined()
    df = _apply_mso_requester_filter(df)

    # Filter: Closed/Cancelled only
    df = df.filter(F.col("status").isin(7, 8))

    # Filter: Closed within last year
    df = df.filter(
        (F.year(F.col("change_closed_by_eastern_dt")) >= (F.year(F.current_date()) - 1))
        & (F.col("change_closed_by_eastern_dt") <= F.current_date())
    )

    df = _apply_status_mappings(df)

    if "supervisor_group" in df.columns:
        df = df.withColumnRenamed("supervisor_group", "assignee_group")

    kept_columns = [
        "change_id", "order_number", "create_date", "modified_date",
        "planned_start_date", "planned_end_date", "status", "category",
        "type", "item", "summary", "work_type", "requester_group",
        "requester_name", "requester_login_name", "assignee_login_name",
        "assignee", "service_affected_aots", "services_supported",
        "product_affected", "reason_aots", "business_risk_aots",
        "technical_risk_aots", "impact", "customer_impacted",
        "first_moved_to_pending_apprvl", "closure_code", "aots_closure_code",
        "closure_code2", "root_cause_code", "root_cause_action_plan_aots",
        "rescheduled_count", "approval_status", "description", "clli",
        "closing_comments_aots", "number_of_tasks", "assignee_group",
        "task_implementor_group", "task_task_id", "task_description",
        "task_summary", "task_status", "task_task_full_name",
        "task_implementor_name_", "task_implementor_e_mail",
        "impacted_state", "location", "new_technology",
        "equipment_id", "equipment_name", "equipment_type",
        "apsig_approval_status", "apsig_request", "apsig_role",
        "apsig_approver_signature", "emergency_",
        "supervisor_location", "change_closed_by_eastern_dt",
        "task_task_closed_by_date_rpt",
        "task_planned_start_eastern_dt", "task_planned_end_eastern_dt",
    ]
    available = [c for c in kept_columns if c in df.columns]
    df = df.select(available)

    df = _apply_eastern_date_formatting(
        df,
        columns_utc=["create_date", "planned_start_date", "planned_end_date"],
        columns_raw=["change_closed_by_eastern_dt"],
    )

    return df


# ═══════════════════════════════════════════════════════════════════════════
# GOLD TABLE 3: cmclosed_tasks
#   Contour RID: 46d229a0-80dd-484a-97b8-600e978dba7e
#   Only 1 join (chg_task), 50 columns, closed + date range filter
# ═══════════════════════════════════════════════════════════════════════════

@dlt.table(
    name="cmclosed_tasks",
    comment="Gold: CM Closed Tasks. Change+Task join only, closed last 365 days. 50 columns.",
    table_properties={"quality": "gold"},
)
def cmclosed_tasks():
    """
    Converted from: Contour 46d229a0 → cmclosed_tasks.py
    
    Simpler contour:
    - Only 1 join: chg_change + chg_task (on change_id)
    - No equipment, no techs, no cllis, no apsig joins
    - Filter: requester_group MSO + status IN (7,8) + closed last 365 days
    """
    df = _build_base_joined(
        include_tasks=True,
        include_apsig=False,
        include_equipment=False,
        include_techs=False,
        include_cllis=False,
    )
    df = _apply_mso_requester_filter(df)

    # Filter: Closed last 365 days
    df = df.filter(
        (F.col("change_closed_by_eastern_dt") >= F.date_sub(F.current_date(), 365))
        & (F.col("change_closed_by_eastern_dt") <= F.current_date())
    )

    # Filter: Closed/Cancelled only
    df = df.filter(F.col("status").isin(7, 8))

    # Apply status mappings (status + task_status only; no approval_status in this table)
    df = _apply_status_mappings(df)

    kept_columns = [
        "change_id", "task_task_id", "task_implementor_group",
        "task_description", "task_summary", "task_status",
        "task_task_full_name", "task_task_closed_by_date",
        "task_implementor_name_", "task_implementor_e_mail",
        "task_task_closed_by_date_rpt", "work_type", "reason_aots",
        "planned_start_date", "emergency_", "technical_risk_aots",
        "first_moved_to_pending_apprvl", "business_risk_aots",
        "status", "change_closed_by_eastern_dt", "requester_group",
        "category", "summary", "planned_end_date", "type", "item",
        "requester_name", "requester_login_name",
        "task_planned_start_date", "task_planned_end_date",
        "order_number", "create_date", "modified_date",
        "assignee_login_name", "assignee", "service_affected_aots",
        "services_supported", "product_affected", "impact",
        "customer_impacted", "closure_code", "closure_code2",
        "aots_closure_code", "root_cause_code",
        "root_cause_action_plan_aots", "rescheduled_count",
        "approval_status", "description",
        "planned_end_eastern_dt", "planned_start_eastern_dt",
    ]
    available = [c for c in kept_columns if c in df.columns]
    df = df.select(available)

    df = _apply_eastern_date_formatting(
        df,
        columns_utc=["planned_start_date", "planned_end_date"],
        columns_raw=["change_closed_by_eastern_dt"],
    )

    return df


# ═══════════════════════════════════════════════════════════════════════════
# GOLD TABLE 4: cmclosed_notasks
#   Contour RID: 064b7d50-842a-487a-accf-ae54cfb8abe2
#   4 joins (no chg_task), 53 columns, closed + date range filter
# ═══════════════════════════════════════════════════════════════════════════

@dlt.table(
    name="cmclosed_notasks",
    comment="Gold: CM Closed No-Tasks. Change+Equipment+Techs+CLLIs+ApSig, no tasks. 53 columns.",
    table_properties={"quality": "gold"},
)
def cmclosed_notasks():
    """
    Converted from: Contour 064b7d50 → cmclosed_notasks.py
    
    4 joins (everything except chg_task):
    - ap_signature_enriched, acmr23_equipment, acmr14_techs, acmr14_cllis
    - No task join
    - Filter: requester_group MSO + status IN (7,8) + closed last 365 days
    """
    df = _build_base_joined(
        include_tasks=False,
        include_apsig=True,
        include_equipment=True,
        include_techs=True,
        include_cllis=True,
    )
    df = _apply_mso_requester_filter(df)

    # Filter: Closed last 365 days
    df = df.filter(
        (F.col("change_closed_by_eastern_dt") >= F.date_sub(F.current_date(), 365))
        & (F.col("change_closed_by_eastern_dt") <= F.current_date())
    )

    # Filter: Closed/Cancelled only
    df = df.filter(F.col("status").isin(7, 8))

    df = _apply_status_mappings(df)

    kept_columns = [
        "change_id", "order_number", "create_date", "modified_date",
        "planned_start_date", "planned_end_date", "status", "category",
        "type", "item", "summary", "work_type", "requester_group",
        "requester_name", "requester_login_name", "assignee_login_name",
        "assignee", "service_affected_aots", "services_supported",
        "product_affected", "reason_aots", "business_risk_aots",
        "technical_risk_aots", "impact", "customer_impacted",
        "first_moved_to_pending_apprvl", "closure_code", "aots_closure_code",
        "closure_code2", "root_cause_code", "root_cause_action_plan_aots",
        "rescheduled_count", "approval_status", "description", "clli",
        "closing_comments_aots", "number_of_tasks", "supervisor_group",
        "impacted_state", "location", "new_technology",
        "equipment_id", "equipment_name", "equipment_type",
        "apsig_approval_status", "apsig_request", "apsig_role",
        "apsig_approver_signature", "emergency_",
        "change_closed_by_eastern_dt", "supervisor_location",
        "planned_end_eastern_dt", "planned_start_eastern_dt",
    ]
    available = [c for c in kept_columns if c in df.columns]
    df = df.select(available)

    df = _apply_eastern_date_formatting(
        df,
        columns_utc=["create_date", "modified_date", "planned_start_date", "planned_end_date"],
        columns_raw=["change_closed_by_eastern_dt"],
    )

    return df


# ═══════════════════════════════════════════════════════════════════════════
# CSV EXPORT TABLES
#   These replicate the Foundry Python transforms that wrote CSV with
#   custom delimiters (|_|;|_|) and line separators (ŷ / \u0177).
#   In Databricks, consumers should read directly from Delta tables.
#   If CSV export is still required, use a downstream job.
# ═══════════════════════════════════════════════════════════════════════════

# NOTE: The original Foundry pipeline had 4 CSV-export transforms:
#   - MSO_AOTS_CM_OpenTickets.py  → CSV of mso_aotscm_open_tickets
#   - MSO_AOTS_CM_ClosedTickets.py → CSV of mso_aotscm_closed_tickets
#   - cmclosed_tasks.py → CSV of cmclosed_tasks
#   - cmclosed_notasks.py → CSV of cmclosed_notasks
#
# These used custom delimiters: sep="|_|;|_|", lineSep="\u0177"
# which suggests a downstream system (possibly AOTS) reads these CSVs.
#
# In Databricks, these are NOT needed as DLT tables. If the downstream
# system still needs CSV files, create a separate Databricks Job that:
#   df.coalesce(1).write.csv(path, sep="|_|;|_|", lineSep="\u0177", header=True)
#
# For now, we create simple views as aliases:

@dlt.view(
    name="vw_mso_aotscm_open_tickets_csv",
    comment="View alias for CSV-export compatibility. Read from mso_aotscm_open_tickets.",
)
def vw_mso_aotscm_open_tickets_csv():
    return dlt.read("mso_aotscm_open_tickets")


@dlt.view(
    name="vw_mso_aotscm_closed_tickets_csv",
    comment="View alias for CSV-export compatibility. Read from mso_aotscm_closed_tickets.",
)
def vw_mso_aotscm_closed_tickets_csv():
    return dlt.read("mso_aotscm_closed_tickets")


@dlt.view(
    name="vw_cmclosed_tasks_csv",
    comment="View alias for CSV-export compatibility. Read from cmclosed_tasks.",
)
def vw_cmclosed_tasks_csv():
    return dlt.read("cmclosed_tasks")


@dlt.view(
    name="vw_cmclosed_notasks_csv",
    comment="View alias for CSV-export compatibility. Read from cmclosed_notasks.",
)
def vw_cmclosed_notasks_csv():
    return dlt.read("cmclosed_notasks")
