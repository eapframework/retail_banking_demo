from transforms.api import transform_df, Input, Output
from pyspark.sql import functions as F
from myproject.datasets.d360.constants import ADDITIONAL_DATASETS


@transform_df(
    Output("ri.foundry.main.dataset.40179437-fa16-432d-9798-777a5e208509"),
    platform_dataset_object=Input(
        "ri.foundry.main.dataset.890e7cbb-45f2-437e-8345-38029c577c54"
    ),
    platform_projects_cleaned_edited=Input(
        "ri.foundry.main.dataset.ba42495f-1768-4835-86b6-2df80af8da33"
    ),
    access_role_mapping=Input(
        "ri.foundry.main.dataset.a39fa62f-ccdb-4a7e-84db-5c4bad9932c9"
    ),
    ontology_datasets=Input(
        "ri.foundry.main.dataset.a9d2d1a0-84f8-4d72-9a64-3047498ba68f"
    ),
    dataset_parents_and_children=Input(
        "ri.foundry.main.dataset.eab7db73-feae-414d-9066-c4d0db6b864c"
    ),
)
def my_compute_function(
    platform_dataset_object,
    platform_projects_cleaned_edited,
    access_role_mapping,
    ontology_datasets,
    dataset_parents_and_children,
):
    df = platform_dataset_object.withColumn(
        "is_in_data_catalog",
        F.when(F.col("collection").isNull(), F.lit("N")).otherwise(F.lit("Y")),
    ).drop("project_description")
    df = df.join(
        platform_projects_cleaned_edited, on=["project_rid", "project_name"], how="left"
    )
    df = df.filter(df["trashed"] == "false")

    df = df.withColumn(
        "project_key_contacts_email",
        F.when(
            F.col("use_case_key_contacts").isNull()
            & F.col("data_source_key_contact_email").isNull(),
            None,
        )
        .when(
            F.col("use_case_key_contacts").isNull(),
            F.array(F.col("data_source_key_contact_email")),
        )
        .otherwise(F.col("use_case_key_contacts")),
    )

    df = df.withColumn(
        "project_key_contacts_name",
        F.when(
            F.col("use_case_key_contacts_name").isNull()
            & F.col("data_source_key_contact_name").isNull(),
            None,
        )
        .when(
            F.col("use_case_key_contacts_name").isNull(),
            F.array(F.col("data_source_key_contact_name")),
        )
        .otherwise(F.col("use_case_key_contacts_name")),
    )

    df = df.join(
        access_role_mapping,
        on=["project_rid", "project_type", "project_name"],
        how="left",
    )
    df = (
        df.join(
            ontology_datasets.select(
                F.lit(True).alias("backing_object"), F.col("backing_dataset_rid")
            ),
            df["dataset_rid"] == ontology_datasets["backing_dataset_rid"],
            "left",
        )
        .fillna(False)
        .join(dataset_parents_and_children, on=["dataset_rid"], how="left")
        .withColumn("has_children", F.size(F.coalesce("children", F.array())) > 0)
        .withColumn("has_parents", F.size(F.coalesce("parents", F.array())) > 0)
    )
    df = df.withColumn(
        "link_to_dataset",
        F.concat(
            F.lit(
                "https://paloma.palantirfoundry.com/workspace/data-integration/dataset/preview/"
            ),
            F.col("dataset_rid"),
        ),
    )

    df = (
        df.withColumnRenamed("last_modified_date", "last_updated_date")
        .withColumnRenamed("magritte_source_name", "ingestion_source_name")
        .withColumnRenamed("magritte_source_type", "ingestion_source_type")
        .withColumnRenamed("description", "dataset_description")
        .withColumnRenamed("viewer_roles_agg", "upstart_viewer_roles")
        .withColumnRenamed("editor_roles_agg", "upstart_editor_roles")
        .withColumnRenamed("data_roles_agg", "upstart_data_roles")
        .withColumnRenamed("project_key_contacts_email", "project_key_contacts_attuid")
    )

    df = df.select(
        "dataset_name",
        "link_to_dataset",
        "project_name",
        "project_rid",
        "project_description",
        "project_key_contacts_name",
        "project_key_contacts_attuid",
        "dataset_path",
        "dataset_rid",
        "last_updated_date",
        "created_date",
        "ingestion_source_name",
        "ingestion_source_type",
        "source_application_mots_id",
        "dataset_description",
        "schema",
        "upstart_viewer_roles",
        "upstart_editor_roles",
        "data_feed_type",
        "upstart_data_roles",
        "is_in_data_catalog",
        "collection",
        "collection_description",
        "trashed",
        "backing_object",
        "parents",
        "children",
        "has_parents",
        "has_children",
    )

    df = df.filter(
        (df["project_name"] != "Palantir Admins")
        & (df["project_name"] != "jhong")
        & (df["project_name"] != "aschexnayder")
        & (df["project_name"] != "jkieserman")
        & (df["project_name"] != "yifei")
        & (df["project_name"] != "Platform Logs")
    )

    df = df.filter(
        (df["dataset_path"].contains("clean/"))
        | (df["is_in_data_catalog"] == "Y")
        | (df["dataset_path"].contains("Lab/AI Net Ops"))
        | (df["backing_object"] == True)
        | F.col("dataset_rid").isin(ADDITIONAL_DATASETS)
    )
    df = df.drop("backing_object")
    df = df.filter(~(df["dataset_path"].contains("dev_clean")))
    df = df.filter(
        (df["project_name"] != "Platform Reporting")
        & (df["project_name"] != "Tutorials")
    )

    return df
