from fastapi import APIRouter

from app.api.v1.endpoints import activity_logs, operations, relationships, resources, diagnostics

api_router = APIRouter()

api_router.include_router(
    operations.router,
    prefix="/resources",
    tags=["operations"],
)

api_router.include_router(
    resources.router,
    prefix="/resources",
    tags=["resources"],
)

api_router.include_router(
    relationships.router,
    prefix="/relationships",
    tags=["relationships"],
)

api_router.include_router(
    activity_logs.router,
    prefix="/logs",
    tags=["activity_logs"],
)

api_router.include_router(
    diagnostics.router,
    prefix="/diagnostics",
    tags=["diagnostics"],
)
