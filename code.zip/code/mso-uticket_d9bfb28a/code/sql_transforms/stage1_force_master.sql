CREATE TABLE `ri.foundry.main.dataset.9114de96-abfc-4542-8d5d-6372ddacee40` AS
    SELECT *
    ,CASE 
WHEN (priority <= 84) THEN '50% or less'
WHEN (priority BETWEEN 85 AND 94 ) THEN '50% or greater'
WHEN (priority BETWEEN 95 AND 98) THEN 'demand dispatch'
WHEN (priority >= 99) THEN 'full outage'
ELSE 'other'
END AS priority_category
FROM 
    (SELECT entrydatetime
,compcandatetime
,wrid
,sourcetype
,extkey1
,worktypequalifier
,wrstat
,techassigned
,circuitworklocclli
,techloadtype
,region
,priority
FROM `ri.foundry.main.dataset.b069bee3-c840-4a18-ad50-831911818f4d`
WHERE lower(extkey1) REGEXP '^[a-z][a-z][0-9][0-9][0-9][0-9][0-9][0-9]$|[0-9a-z][0-9a-z][0-9a-z][0-9a-z][0-9a-z][0-9a-z][0-9a-z][0-9a-z][0-9a-z]'
UNION
    SELECT entrydatetime
,compcandatetime
,wrid
,sourcetype
,extkey1
,'OUT' worktypequalifier
,wrstat
,techassigned
,circuitworklocclli
,techloadtype
,'Mobility' as region
,priority
 FROM `ri.foundry.main.dataset.24a588e0-e370-4736-b45d-8cd65f482916`)