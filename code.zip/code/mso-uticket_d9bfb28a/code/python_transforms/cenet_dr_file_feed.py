from transforms.api import transform, Input, Output, incremental, Check
from utility.column_clean import clean_columns, lowercase_columns, remove_prefix
from transforms import expectations as E
 

@transform(
    out=Output("/Innovation Lab/[Source] CENET/data/clean/cenet_dr_feed",
               checks=Check(E.count().gt(0), 'Row Count', on_error='FAIL')),
    inp=Input("/Innovation Lab/[Source] CENET/data/raw/cenet_dr_feed"),
)
def my_compute_function(inp, out):
    df = clean_columns(
        inp.dataframe(),
        strip_columns=strip_columns,
        integer_columns=cast_to_integer_columns,
        double_columns=cast_to_double_columns,
        decimal_columns=cast_to_decimal_columns,
        timestamp_columns=cast_to_timestamp_from_long_columns,
        datetime_columns=cast_to_timestamp_columns,
        datetime_format=datetime_format,
        date_columns=cast_to_date_columns,
        date_format=date_format,
        id_columns=cast_to_string_columns,
        integer_from_num_columns=cast_to_integer_from_decimal_columns
    )
    df = lowercase_columns(df)
    out.write_dataframe(df)
 

date_format = 'yyyy-MM-dd'
datetime_format = 'yyyy-MM-dd HH:mm:ss'
 
cast_to_date_columns = []
cast_to_timestamp_columns = []
cast_to_timestamp_from_long_columns = []
cast_to_integer_columns = []
cast_to_double_columns = []
cast_to_decimal_columns = []
cast_to_string_columns = []
cast_to_integer_from_decimal_columns = []
strip_columns = []