"""
MSO uTicket — Databricks DLT Pipeline (Bronze Layer)
=====================================================
Reads from raw Delta tables in 31184_cerebro_poc4x.otis for testing.
These tables were created from the Oracle ESAR data source definitions.

Source: 31184_cerebro_poc4x.otis.<raw_table> (Delta)
"""

import dlt
from pyspark.sql import functions as F

# ---------------------------------------------------------------------------
# Configuration — adjust per environment
# ---------------------------------------------------------------------------
CATALOG = "31184_cerebro_poc4x"
SCHEMA = "otis"

def _source_table(table_name):
    """Read from a raw Delta table in the otis schema."""
    return f"`{CATALOG}`.`{SCHEMA}`.`{table_name}`"

# ---------------------------------------------------------------------------
# BRONZE: Raw ingestion tables (reading from Delta source tables)
# ---------------------------------------------------------------------------

@dlt.table(
    name="raw_chg_change_snowflake",
    comment="Raw CHG_CHANGE from Oracle ESAR via Snowflake. 756 columns. Source of all change tickets.",
    table_properties={"quality": "bronze", "pipelines.autoOptimize.managed": "true"},
)
def raw_chg_change_snowflake():
    """
    Foundry source: chg_change_snowflake (RID: b541996c-95a1-4b52-9753-055b78c5d2b2)
    Schema: 756 columns — CHANGE_ID (PK with SEQNO), STATUS, CATEGORY, timestamps as epoch-millis, etc.
    """
    return spark.read.table(_source_table("chg_change_snowflake"))


@dlt.table(
    name="raw_chg_task_snowflake",
    comment="Raw CHG_TASK from Oracle ESAR via Snowflake. 190 columns. Change management tasks.",
    table_properties={"quality": "bronze"},
)
def raw_chg_task_snowflake():
    """
    Foundry source: esaars_dbor_cm_rviews.chg_task_snowflake (RID: 573ddb29)
    Schema: 190 columns — TASK_ID, CHANGE_ID (FK), IMPLEMENTOR_GROUP, STATUS, timestamps, etc.
    """
    return spark.read.table(_source_table("esaars_dbor_cm_rviews_chg_task_snowflake"))


@dlt.table(
    name="raw_acmr14_affected_cllis",
    comment="Raw ACMR14 Affected CLLIs. 15 columns. CLLI location data linked to changes.",
    table_properties={"quality": "bronze"},
)
def raw_acmr14_affected_cllis():
    """
    Foundry source: esaars_dbor_cm_rviews.acmr14_affected_cllis
    Schema: 15 columns — REQUEST_ID, CHANGE_ID (FK), CLLI, CITY, LOCATION, etc.
    """
    return spark.read.table(_source_table("esaars_dbor_cm_rviews_acmr14_affected_cllis"))


@dlt.table(
    name="raw_acmr14_affected_techs_snowflake",
    comment="Raw ACMR14 Affected Technologies. 19 columns. Technology tags per change.",
    table_properties={"quality": "bronze"},
)
def raw_acmr14_affected_techs_snowflake():
    """
    Foundry source: esaars_dbor_cm_rviews.acmr14_affected_techs_snowflake
    Schema: 19 columns — REQUEST_ID, CHANGE_ID (FK), TECHNOLOGY, TECHNOLOGY_ID, etc.
    """
    return spark.read.table(_source_table("esaars_dbor_cm_rviews_acmr14_affected_techs_snowflake"))


@dlt.table(
    name="raw_acmr23_mobility_equipment_info_snowflake",
    comment="Raw ACMR23 Mobility Equipment Info. 32 columns. Equipment metadata per change.",
    table_properties={"quality": "bronze"},
)
def raw_acmr23_mobility_equipment_info_snowflake():
    """
    Foundry source: esaars_dbor_cm_rviews.acmr23_mobility_equipment_info_snowflake (RID: 19b1503a)
    Schema: 32 columns — MED_RECORD_ID (PK), CHANGE_ID (FK), EQUIPMENT_ID, EQUIPMENT_NAME, etc.
    """
    return spark.read.table(_source_table("esaars_dbor_cm_rviews_acmr23_mobility_equipment_info_snowflake"))


@dlt.table(
    name="raw_ap_signature",
    comment="Raw AP_SIGNATURE. 52 columns. Approval signatures.",
    table_properties={"quality": "bronze"},
)
def raw_ap_signature():
    """
    Foundry source: esaars_dbor_cm_rviews.ap_signature
    Schema: 52 columns — SIGNATURE_ID, APPROVAL_ID (FK), APPROVAL_STATUS, APPROVER_SIGNATURE, ROLE, etc.
    """
    return spark.read.table(_source_table("esaars_dbor_cm_rviews_ap_signature"))


@dlt.table(
    name="raw_ap_detail_snowflake",
    comment="Raw AP_DETAIL. 40 columns. Approval process details.",
    table_properties={"quality": "bronze"},
)
def raw_ap_detail_snowflake():
    """
    Foundry source: esaars_dbor_cm_rviews.ap_detail_snowflake
    Schema: 40 columns — APPROVAL_ID (PK with SEQNO), REQUEST (FK to CHANGE_ID), etc.
    """
    return spark.read.table(_source_table("esaars_dbor_cm_rviews_ap_detail_snowflake"))
