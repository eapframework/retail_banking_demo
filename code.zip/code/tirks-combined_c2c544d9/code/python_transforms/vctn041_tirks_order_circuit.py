from transforms.api import transform, Input, Output, incremental
from utility.column_clean import clean_columns, lowercase_columns, remove_prefix
from pyspark.sql.functions import col


@transform(
    out=Output(
        "/Innovation Lab/[Source] Teradata EDW - ACCESS_VIEWS/data/prod_clean/vctn041_tirks_order_circuit"
    ),
    df=Input(
        "/Innovation Lab/[Source] Teradata EDW - ACCESS_VIEWS/data/raw/snowflake/ACCESS_VIEWS.VCTN041_TIRKS_ORDER_CIRCUIT"
    ),
)
def my_compute_function(df, out):
    df = clean_columns(
        df.dataframe(),
        date_format=date_format,
        date_columns=string_to_date,
        datetime_format=datetime_format,
        datetime_columns=long_unixtime_to_timestamp,
        timestamp_from_string_format=string_unixtime_format,
        timestamp_from_string_columns=string_unixtime_to_timestamp,
        timestamp_format=long_unixtime_format,
        timestamp_columns=long_unixtime_to_timestamp,
        integer_columns=string_to_integer_columns,
        double_columns=string_to_double_columns,
        decimal_columns=string_to_decimal_columns,
        id_columns=numeric_to_string_columns,
        integer_from_num_columns=decimal_to_integer,
        strip_columns=strip_string_columns,
    )
    df = lowercase_columns(df)
    df = df.select(
        [
            col(c).cast("short") if c in columns_to_convert else col(c)
            for c in df.columns
        ]
    )
    out.write_dataframe(df)


"""
The following columns are non-string types however their names suggest they are identifier columns. 
Consider adding these columns to the numeric_to_string_columns list below.
    "ITM_ENTRY_TO_ITM_RID_ACT_QTY",
    "ITM_ENTRY_TO_ITM_TRID_ACTL_QTY",
    "ITM_ENTRY_TO_ORD_RID_OBJ_QTY",
    "ITM_ENTRY_TO_ORD_TRID_OBJ_QTY",
    "ITM_RID_ACT_TO_ITM_DD_ACT_QTY",
    "ITM_RID_ACTL_TO_ITM_DD_OBJ_QTY",
    "ITM_RID_OBJ_TO_ITM_RID_RPT_QTY",
    "ORD_APPL_TO_ITM_TRID_ACTL_QTY",
    "ORD_TRID_OBJ_ITM_TRID_ACT_QTY",

"""


drop_columns = []

date_format = "yyyy-MM-dd"
string_to_date = []
datetime_format = "yyyy-MM-dd HH:mm:ss"
string_to_timestamp = []
columns_to_convert = [
    "itm_dva_obj_to_itm_dva_rpt_qty",
    "itm_entry_to_itm_dva_act_qty",
    "itm_entry_to_itm_rid_act_qty",
    "itm_entry_to_itm_trid_actl_qty",
    "itm_entry_to_itm_wot_act_qty",
    "itm_entry_to_ord_dva_obj_qty",
    "itm_entry_to_ord_lam_obj_qty",
    "itm_entry_to_ord_rid_obj_qty",
    "itm_entry_to_ord_trid_obj_qty",
    "itm_entry_to_ord_wot_obj_qty",
    "itm_dd_obj_to_itm_dd_actl_qty",
    "itm_dd_obj_to_itm_dd_rptd_qty",
    "itm_rid_act_to_itm_dd_act_qty",
    "itm_rid_actl_to_itm_dd_obj_qty",
    "itm_rid_obj_to_itm_rid_rpt_qty",
    "ord_appl_to_itm_dd_actl_qty",
    "ord_appl_to_itm_dva_actl_qty",
    "ord_appl_to_itm_trid_actl_qty",
    "ord_appl_to_itm_wot_actl_qty",
    "ord_dva_obj_to_itm_dva_act_qty",
    "ord_trid_obj_itm_trid_act_qty",
]
string_unixtime_format = None
string_unixtime_to_timestamp = []
long_unixtime_format = None
long_unixtime_to_timestamp = []

string_to_integer_columns = []
string_to_double_columns = []
string_to_decimal_columns = []

numeric_to_string_columns = []
decimal_to_integer = []

strip_string_columns = [
    "SBC_COMPANY_CD",
    "SBC_SYSTEM_CD",
    "SBC_STATE_CD",
    "CIRCUIT_LAYOUT_ORDER_BASE_NBR",
    "ITEM_NBR",
    "LTST_ENGRG_CKT_LYT_ORD_SUPP_CD",
    "ITEM_STATUS_CD",
    "ITEM_ACTION_CD",
    "CIRCUIT_ACCESS_CD",
    "CKT_IDENTIFICATION_FORMAT_CD",
    "CIRCUIT_IDENTIFICATION_CD",
    "CIRCUIT_LOCATION_A_CLLI_CD",
    "CIRCUIT_LOCATION_Z_CLLI_CD",
    "RELATED_CIRCUIT_LAYOUT_ORD_NBR",
    "ITEM_INVENTORY_CD",
    "CIRCUIT_SEGMENT_TYPE_CD",
    "CIRCUIT_CONTROL_RECORD_NBR",
    "MECHANIZED_CUT_SHEET_CD",
    "ITEM_REMARKS_TXT",
    "OLD_CKT_IDENTIFICATION_FMT_CD",
    "OLD_CIRCUIT_IDENTIFICATION_CD",
    "ITEM_TRAFFIC_ENGINEERING_CD",
    "ITEM_DUE_DT_MISSED_FUNCTION_CD",
    "ITEM_DUE_DATE_DAILY_JPRDY_1_CD",
    "ITEM_DUE_DATE_DAILY_JPRDY_2_CD",
    "ITEM_DUE_DATE_DAILY_JPRDY_3_CD",
    "ITEM_DUE_DATE_INIT_JPRDY_1_CD",
    "ITEM_DUE_DATE_INIT_JPRDY_2_CD",
    "ITEM_DUE_DATE_INIT_JPRDY_3_CD",
    "ITEM_DUE_DATE_COMPLTN_INTLS_NM",
    "ITM_CNFIRM_DSGN_INIT_JPRDY1_CD",
    "ITM_CNFIRM_DSGN_INIT_JPRDY2_CD",
    "ITM_CNFIRM_DSGN_INIT_JPRDY3_CD",
    "ITEM_DESIGN_LYT_MISSED_FUNC_CD",
    "ITEM_DESIGN_LYT_DLY_JPRDY_1_CD",
    "ITEM_DESIGN_LYT_DLY_JPRDY_2_CD",
    "ITEM_DESIGN_LYT_DLY_JPRDY_3_CD",
    "ITM_DESIGN_LYT_INIT_JPRDY_1_CD",
    "ITM_DESIGN_LYT_INIT_JPRDY_2_CD",
    "ITM_DESIGN_LYT_INIT_JPRDY_3_CD",
    "ITEM_DSGN_LYT_COMPLTN_INTLS_NM",
    "ITEM_DSGN_VRFD_MISSED_FUNC_CD",
    "ITM_DSGN_VRFD_DAILY_JPRDY_1_CD",
    "ITM_DSGN_VRFD_DAILY_JPRDY_2_CD",
    "ITM_DSGN_VRFD_DAILY_JPRDY_3_CD",
    "ITEM_DSGN_VRFD_INIT_JPRDY_1_CD",
    "ITEM_DSGN_VRFD_INIT_JPRDY_2_CD",
    "ITEM_DSGN_VRFD_INIT_JPRDY_3_CD",
    "ITEM_FRM_CNTNTY_MISSED_FUNC_CD",
    "ITM_FRM_CNTNTY_INIT_JPRDY_1_CD",
    "ITM_FRM_CNTNTY_INIT_JPRDY_2_CD",
    "ITM_FRM_CNTNTY_INIT_JPRDY_3_CD",
    "INVENTORY_AVAIL_DATE_RQRD_IND",
    "ITM_INVEN_AVAIL_DLY_JPRDY_1_CD",
    "ITM_INVEN_AVAIL_DLY_JPRDY_2_CD",
    "ITM_INVEN_AVAIL_DLY_JPRDY_3_CD",
    "ITEM_INV_AVAIL_INIT_JPRDY_1_CD",
    "ITEM_INV_AVAIL_INIT_JPRDY_2_CD",
    "ITEM_INV_AVAIL_INIT_JPRDY_3_CD",
    "ITM_INVEN_AVLBLTY_DT_INTLS_NM",
    "ITM_REC_ISS_MISSED_FUNCTION_CD",
    "ITEM_RECORD_ISS_DLY_JPRDY_1_CD",
    "ITEM_RECORD_ISS_DLY_JPRDY_2_CD",
    "ITEM_RECORD_ISS_DLY_JPRDY_3_CD",
    "ITM_RECORD_ISS_INIT_JPRDY_1_CD",
    "ITM_RECORD_ISS_INIT_JPRDY_2_CD",
    "ITM_RECORD_ISS_INIT_JPRDY_3_CD",
    "ITM_REC_ISSUE_COMPLTN_INTLS_NM",
    "ITM_TRFC_REC_MISSD_FUNCTION_CD",
    "ITEM_TRFC_REC_DAILY_JPRDY_1_CD",
    "ITEM_TRFC_REC_DAILY_JPRDY_2_CD",
    "ITEM_TRFC_REC_DAILY_JPRDY_3_CD",
    "ITEM_TRFC_REC_INIT_JPRDY_1_CD",
    "ITEM_TRFC_REC_INIT_JPRDY_2_CD",
    "ITEM_TRFC_REC_INIT_JPRDY_3_CD",
    "ITEM_TRFC_REC_COMPLTN_INTLS_NM",
    "WIRE_OFC_TSTD_JPRDY_DSTRBTN_CD",
    "ITEM_WIRED_OFC_DLY_JPRDY_1_CD",
    "ITEM_WIRED_OFC_DLY_JPRDY_2_CD",
    "ITEM_WIRED_OFC_DLY_JPRDY_3_CD",
    "ITEM_WIRED_OFC_INIT_JPRDY_1_CD",
    "ITEM_WIRED_OFC_INIT_JPRDY_2_CD",
    "ITEM_WIRED_OFC_INIT_JPRDY_3_CD",
]
