import pyspark.sql.types as T
from capacity_project import utils
from capacity_project.api.Scheduler import SchedulerAPI
from pyspark.sql import functions as F, Window as W
from transforms.api import transform_df, Input, Output, configure
import functools


@configure(profile=['EXECUTOR_MEMORY_MEDIUM'])
@transform_df(
    Output('/Innovation Lab/Metrics/Group Shared Data & Code/data/ontology/raw/SCHEDULES'),
    branches=Input('/Innovation Lab/Metrics/Group Shared Data & Code/data/ontology/raw/BRANCHES'),
    config=Input("/Innovation Lab/Palantir Admins/Quantum/inputs/config")
)
def my_compute_function(ctx, branches, config):
    token = utils.get_token(config)
    scheduler_api = SchedulerAPI(token)

    branches_agg = branches.groupBy("dataset_rid").agg(F.collect_set("branch").alias("branches"))
    branches_agg = branches_agg.withColumn("branches", F.coalesce(F.col("branches"),  F.array().cast("array<string>")))

    branches_agg = branches_agg.withColumn("salt", F.rand(seed=10)*10000)
    branches_agg = branches_agg.groupBy("salt").agg(
        F.collect_set(F.col("dataset_rid")).alias("dataset_rids"),
        F.collect_list(F.col("branches")).alias("branches_list"))
    flattenUdf = F.udf(fudf, T.ArrayType(T.StringType()))
    branches_agg = branches_agg.withColumn("branches", flattenUdf("branches_list")).select("branches", "dataset_rids")
    schedule_schema = T.StructType([
            T.StructField('schedule_rid', T.StringType(), True),
            T.StructField('name', T.StringType(), True),
            T.StructField('trigger', T.StringType(), True),
            T.StructField('enabled', T.BooleanType(), True),
            T.StructField('ignore_staleness', T.BooleanType(), True),
            T.StructField('created_date', T.StringType(), True),
            T.StructField('datasets', T.ArrayType(T.StringType()), True),
            T.StructField('branch', T.StringType(), True),
            T.StructField('last_updated_by', T.StringType(), True),
            T.StructField('last_updated_date', T.StringType(), True),
            T.StructField("schedule_type", T.StringType(), True),
            T.StructField('created_by_uid', T.StringType(), True),
            T.StructField('token_mode', T.StringType(), True),
            T.StructField('raw', T.StringType(), True),
        ])

    schedule_df = branches_agg.repartition(1000)\
        .rdd.mapPartitions(lambda datasets: get_schedules(datasets, scheduler_api)).toDF(schema=schedule_schema)

    schedule_df = (
        schedule_df.withColumn("created_date", F.to_date(F.col("created_date"), 'yyyy-MM-dd'))
        .withColumn("last_updated_date", F.to_date(F.col("last_updated_date"), 'yyyy-MM-dd'))
        .withColumn("year", F.year("created_date"))
        .withColumn("month", F.month("created_date"))
        .withColumn(
            "build_scope",
            F.when(F.col("token_mode") == "SCOPED_TOKEN", "PROJECT")
            .when(F.col("token_mode") == "USER_TOKEN", "USER")
            .otherwise(None)
        )
        .withColumn(
            "datasets",
            flattenUdf(F.collect_list(F.col("datasets")).over(W.partitionBy("schedule_rid")))
        )
    )

    schedule_df = schedule_df.dropDuplicates(["schedule_rid"]).repartition(5)

    return schedule_df


def f(specs):
    specs = set(list(map(lambda a: a["type"], specs)))
    spec_str = "/".join(specs)
    return spec_str


def get_schedules(branch_datasets, scheduler_api):
    rows = []
    branch_datasets = list(branch_datasets)
    for item in branch_datasets:
        branches = list(set(item.branches))
        datasets = item.dataset_rids
        branchIndex = 0
        datasetsIndex = 0
        while len(branches[branchIndex: branchIndex + 50]) > 0:
            branch_batch = branches[branchIndex: branchIndex + 50]
            branchIndex = branchIndex + 50
            while len(datasets[datasetsIndex: datasetsIndex + 500]):
                dataset_batch = datasets[datasetsIndex: datasetsIndex + 500]
                datasetsIndex = datasetsIndex + 500
                schedules = scheduler_api.get_schedules_by_dataset(dataset_batch, branch_batch)
                rows += [(
                    s['schedule']['rid'],
                    s['schedule'].get('name'),
                    str(s['schedule'].get('trigger')),
                    s['schedule']['enabled'],
                    s['schedule']['action']['runBuild'].get('ignoreStaleness'),
                    s['schedule']['creatorAttribution'].get('time'),
                    s['affectedDatasets'],
                    s['schedule']['action']['runBuild'].get('branch'),
                    s['schedule']['attribution']['userId'],
                    s['schedule']['attribution']['time'],
                    f(s["schedule"]["action"]["runBuild"]["jobSpecSelections"]),
                    s['schedule']['creatorAttribution']['userId'],
                    s['schedule']['tokenMode'],
                    str(s)
                ) for s in schedules]
    return rows


def fudf(val):
    return functools.reduce(lambda x, y: x+y, val)
