from transforms.api import transform_df, Input, Output, incremental
import pyspark.sql.functions as F


@transform_df(
    Output("ri.foundry.main.dataset.a510ae93-5bbc-4c9e-aa31-dd49a6c1d597"),
    asi=Input("ri.foundry.main.dataset.ed82d0a9-b567-49db-a72b-5b2c7a048541"),
    telco=Input("ri.foundry.main.dataset.dd70879c-2409-42ef-bb3e-28869a23250e"),
)
def my_compute_function(telco, asi):
    telco = telco.withColumn("source", F.lit('telco'))
    asi = asi.withColumn("source", F.lit('asi'))
    df = telco.unionByName(asi)
    return df
