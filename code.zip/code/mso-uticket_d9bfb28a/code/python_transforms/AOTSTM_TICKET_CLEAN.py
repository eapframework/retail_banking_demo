from transforms.api import transform_df, Input, Output
from pyspark.sql.functions import expr, col  # Required so we can do expressions within our field list to handle decoding.
## The purpose of this transform is to subset the more than 800 columns and introduce columns people NEED.
## we only decode columns we need and only have those in our view for normal business.  We can add additional
## columns easily from the RAW tables as time progresses.

@transform_df(
    Output("/Innovation Lab/[ETL] Ticketing/data/clean/AOTSTM_TICKET_CLEAN"),
    TICKET=Input("/Innovation Lab/[Source] Oracle ESAR/data/clean/ticket"),
    HIST=Input("/Innovation Lab/[Source] Oracle ESAR/data/clean/ticket_history"),
)
def select_columns_and_decode(TICKET, HIST):
    Desired_Column_Subset = ("ticket"
, "active_org"
, "managing_org"
, "client_id"
, expr("CASE WHEN ticket_role == 1 THEN 'Case'\
WHEN ticket_role == 3 THEN 'Internal Engagement'\
WHEN ticket_role == 4 THEN 'Main'\
WHEN ticket_role == 5 THEN 'Pending External'\
WHEN ticket_role == 6 THEN 'Pending Internal'\
ELSE 'Unexpected Value' END AS ticket_role_description")
, "first_activated_by"
, "first_cleared_by"
, "first_canceled_by"
, "first_closed_by"
, expr("CASE WHEN ticket_type == 0 THEN 'Client'\
WHEN ticket_type == 1 THEN 'User'\
WHEN ticket_type == 2 THEN 'Assist'\
WHEN ticket_type == 3 THEN 'Release'\
WHEN ticket_type == 4 THEN 'Administration'\
WHEN ticket_type == 5 THEN 'Auto Detect'\
WHEN ticket_type == 6 THEN 'GenChildren'\
WHEN ticket_type == 7 THEN 'Predictive'\
WHEN ticket_type == 8 THEN 'Proactive'\
WHEN ticket_type == 9 THEN 'e-Bonding'\
WHEN ticket_type == 10 THEN 'E-mail'\
WHEN ticket_type == 11 THEN 'Web'\
WHEN ticket_type == 12 THEN 'Routine Installation'\
WHEN ticket_type == 13 THEN 'Referred In'\
WHEN ticket_type == 14 THEN 'Referred to Self'\
WHEN ticket_type == 15 THEN 'Informational'\
WHEN ticket_type == 16 THEN 'Alarm or IWT Reported'\
WHEN ticket_type == 17 THEN 'LEC'\
WHEN ticket_type == 18 THEN 'Management'\
WHEN ticket_type == 19 THEN 'Provisioning'\
WHEN ticket_type == 20 THEN 'Reporting'\
WHEN ticket_type == 21 THEN 'Repair Tracking'\
WHEN ticket_type == 22 THEN 'Scheduled Maintenance'\
WHEN ticket_type == 23 THEN 'Other'\
ELSE 'Unexpected Value' END AS ticket_type_desc_tx")
, "end_user_name"
, "rept_svc_line_desc_tx"
, "event_class"
, "severity"
, "ticket_state"
, "asset_id"
, "agent_id"
, "last_modified_by"
, expr("from_utc_timestamp(\
           to_utc_timestamp(\
             from_unixtime(ticket_opened/1000),from_unixtime(unix_timestamp(), 'z')\
            ), 'UTC'\
    ) as ticket_opened_date_utc")
, expr("from_utc_timestamp(\
           to_utc_timestamp(\
             from_unixtime(trouble_reported/1000),from_unixtime(unix_timestamp(), 'z')\
            ), 'UTC'\
    ) as trouble_reported_date_utc")
, "service_restored_date"
, expr("round(adjtimetorestore/60, 0) AS time_to_restore_reported")
, "restore_duration"
, expr("round(adjtimetorepair/60/60, 0) AS mttr")
, expr("from_utc_timestamp(\
           to_utc_timestamp(\
             from_unixtime(ticket_closed/1000),from_unixtime(unix_timestamp(), 'z')\
            ), 'UTC'\
    ) as ticket_closed_date_utc")
, "problem_abstract"
, "resol_action_desc_tx"
, "resolution_text"
, "root_cause_desc_tx"
, "sub_root_cause_desc_tx"
, "first_activated"
, "resolution_set_name"
, "work_queue"
, "handover_text"
, "parent_ticket"
, "init_sev"
, "updated_by"
, "ticket_source"
, "reference_ticket_num"
, "repair_duration"
, "repair_d_m_time_min"
, "time_to_repair_unadj_reported"
, "adjtimetorepair"
, "adjtimetorestore"
, "tmp_defertimesum"
, "total_deferred_delayed_maint"
, "total_deferred_no_access"
, "deferred_reason_code"
,"account_contact"
,"account_phone"
,"account_contact_email"
, "affected_channels"
, "affected_locations"
, "asset_location_city"
, "asset_location_state"
, "asset_name"
, "asset_type"
, "billing_indicator"
, "changeactivitydate"
, "changeactivityid"
, "changeactivitysource"
, "changeactivitytype"
, "child_tkt_count"
, "chronic"
, "cleared_deferred_time"
, "client_first_notified"
, "client_name"
, "client_notified_cleared"
, "client_satisfied"
, "client_ticket"
, "closed_by"
, "completion_deadline"
, "count_closed_children"
, "count_open_children"
, "customer_care_description"
, "customer_experience"
, "discovery_method"
, "dispatch"
, expr("lower(end_user_id) end_user_id")
, "end_user_phone"
, "equipment_clli"
, "equipment_type"
, "escalation_deadline"
, "est_time_of_arrival"
, "event_message_count"
, "faults_caused_by_change"
, "fixit_bridge"
, "handover_fg"
, "has_child"
, "has_parent"
, "impact_severity"
, "key_item_affected"
, "last_modified_date"
, "location_id"
, "location_state_province"
, "monitor_for_cleared"
, "naa_mfab_req"
, "network_technology_list"
, "next_check_time"
, "org_group"
, "original_ticket_number"
, "owner_id"
, "prev_ticket_state"
, "provider_ticket"
, "related_equipment_id"
, "related_equipment_type"
, "remediation"
, "reported_customer_impact"
, "reported_product"
, "rept_request_type"
, "rept_svc_impact_flag"
, "rept_svc_line_cd"
, "requested_completion_date"
, "resol_action_cd"
, "resol_item_cd"
, "resol_item_desc_tx"
, "resol_request_type"
, "resol_svc_impact_flag"
, "resol_svc_line_desc_tx"
, "resolution_org"
, "resolution_product"
, "restore_d_m_time_min"
, "rma_number"
, "scrub_indicator"
, "serial_number"
, "service_provider"
, "severity_classification"
, "ss_activity_type"
, "status_bridge"
, "svc_comp_desc_tx"
, "ticket_cleared_date"
, "ticket_duration"
, "ticket_originator"
, "ticket_owner"
, "ticket_role"
, "ticket_type"
, "time_elapsed_for_monitoring"
, "total_d_m_time_min"
, "total_impacted_customer"
, "trouble_rept_desc_tx"
, "voip_options"
, "ith_queued_to_active"
, expr("case when (resol_request_type =0) then ('Fault')\
when (resol_request_type=1) then ('Informational')\
when (resol_request_type=2) then ('MAC')\
when (resol_request_type=3) then ('Routine Maintenance')\
when (resol_request_type=4) then ('Demand Maintenance')\
when (resol_request_type) NOT IN (0,1,2,3,4) then ('Action Required: Invalid Value')\
else (NULL) end resol_request_desc_tx")
, "engagement_indicator"
, "event_abstract"
, "reported_by"
, "client_helpdesk"
 )

    TICKET = TICKET.select(*Desired_Column_Subset)
    # HIST is the original set of data that has about 20M more tickets than the new ticket snapshot from Vertica
    # Filter HIST so that any Ticket # in TICKET gets removed from HIST so tickets won't get counted twice.
    # Then union the datasets so we keep the history.
    HIST = HIST.select(*Desired_Column_Subset)
    # Create a ticket lookup
    TTN = (
        TICKET
        .select("ticket")
        .withColumnRenamed("ticket", "lk_ticket")
    )
    # Join the historical data with the new ticket lookup so we can only keep tickets we are missing.
    HIST = (
        HIST
        .join(TTN, (HIST.ticket == TTN.lk_ticket), "left")
        .filter(col("lk_ticket").isNull())  # Only keep tickets that aren't already in the new TICKET dataset.
        .drop("lk_ticket")
    )
    # Bring in the filtered history with only tickets that were missing from the new snapshot.
    TICKET = TICKET.unionByName(HIST)

    return TICKET
