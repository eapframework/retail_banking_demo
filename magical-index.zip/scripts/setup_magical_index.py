#!/usr/bin/env python3
"""
Setup script for creating the "Magical Index" resource and establishing
relationships where it feeds all existing resources.

This script:
1. Creates the Magical Index resource
2. Fetches all existing resources
3. Creates FEEDS relationships from Magical Index to each resource

Usage:
    python scripts/setup_magical_index.py

Requirements:
- FastAPI server running on http://localhost:8000
- requests library (pip install requests)
"""

import os

import requests
import sys
from typing import List, Dict, Any

if os.path.exists(".env"):
    from dotenv import load_dotenv
    load_dotenv()

# Configure proxy settings to bypass corporate proxy for localhost
os.environ['NO_PROXY'] = 'localhost,127.0.0.1,*.local'
os.environ['HTTP_PROXY'] = ''
os.environ['HTTPS_PROXY'] = ''

# Configuration
API_BASE = "http://localhost:8000/api/v1"
MAGICAL_INDEX_ID = "auto:metadata:magical-index-root"
ACTOR_TYPE = "AGENT"
ACTOR_NAME = "Magical-Index"

def create_magical_index() -> Dict[str, Any]:
    """Create the Magical Index resource."""
    payload = {
        "resource_id": MAGICAL_INDEX_ID,
        "resource_name": "Magical Index",
        "resource_type": "ONTOLOGY",
        "resource_status": "DISCOVERED",
        "location": None,
        "platform": "auto",
        "actor_type": ACTOR_TYPE,
        "actor_name": ACTOR_NAME
    }

    print(f"Creating Magical Index resource: {MAGICAL_INDEX_ID}")
    response = requests.post(f"{API_BASE}/resources/", json=payload)

    if response.status_code == 201:
        print("✓ Magical Index created successfully")
        return response.json()
    elif response.status_code == 409:
        print("⚠ Magical Index already exists, proceeding...")
        # Fetch existing resource
        get_response = requests.get(f"{API_BASE}/resources/{MAGICAL_INDEX_ID}")
        if get_response.status_code == 200:
            return get_response.json()
        else:
            print(f"Error fetching existing Magical Index: {get_response.text}")
            sys.exit(1)
    else:
        print(f"Error creating Magical Index: {response.status_code} - {response.text}")
        sys.exit(1)

def get_all_resources() -> List[Dict[str, Any]]:
    """Fetch all existing resources."""
    print("Fetching all existing resources...")
    response = requests.get(f"{API_BASE}/resources/")

    if response.status_code != 200:
        print(f"Error fetching resources: {response.status_code} - {response.text}")
        sys.exit(1)

    resources = response.json()
    print(f"Found {len(resources)} existing resources")
    return resources

def create_relationship(upstream_id: str, downstream_id: str) -> bool:
    """Create a FEEDS relationship between two resources."""
    payload = {
        "upstream_resource_id": upstream_id,
        "downstream_resource_id": downstream_id,
        "relationship_type": "FEEDS",
        "notes": "Root metadata index feeds all resources",
        "actor_type": ACTOR_TYPE,
        "actor_name": ACTOR_NAME
    }

    response = requests.post(f"{API_BASE}/relationships/", json=payload)

    if response.status_code == 201:
        return True
    elif response.status_code == 422:
        # Check if it's because resources don't exist
        error_detail = response.json().get("detail", "")
        if "not found" in error_detail.lower():
            print(f"⚠ Skipping relationship {upstream_id} -> {downstream_id}: {error_detail}")
            return False
        else:
            print(f"Error creating relationship {upstream_id} -> {downstream_id}: {response.text}")
            return False
    else:
        print(f"Unexpected error creating relationship {upstream_id} -> {downstream_id}: {response.status_code} - {response.text}")
        return False

def main():
    """Main setup function."""
    print("=== Magical Index Setup Script ===\n")

    # # Create session with proxy bypass for localhost
    # session = requests.Session()
    # session.proxies = None  # Bypass proxy for localhost

    # Step 1: Create Magical Index
    magical_index = create_magical_index()
    print(f"Magical Index ID: {magical_index['resource_id']}\n")

    # Step 2: Get all resources
    resources = get_all_resources()
    print(resources)

    # Filter out the Magical Index itself
    other_resources = [r for r in resources['items'] if r['resource_id'] != MAGICAL_INDEX_ID]
    print(f"Will create relationships to {len(other_resources)} resources\n")

    # Step 3: Create relationships
    successful = 0
    failed = 0

    for resource in other_resources:
        resource_id = resource['resource_id']
        resource_name = resource['resource_name']

        print(f"Creating relationship: {MAGICAL_INDEX_ID} -> {resource_id} ({resource_name})")
        if create_relationship(MAGICAL_INDEX_ID, resource_id):
            successful += 1
        else:
            failed += 1

    print("=== Setup Complete ===")
    print(f"Relationships created: {successful}")
    print(f"Relationships failed/skipped: {failed}")

    if successful > 0:
        print("✓ Magical Index is now upstream to all resources")
    else:
        print("⚠ No relationships were created")

if __name__ == "__main__":
    main()