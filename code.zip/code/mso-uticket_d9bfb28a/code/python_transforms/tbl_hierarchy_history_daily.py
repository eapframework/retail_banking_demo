from transforms.api import incremental, Input, Output, transform, configure
from pyspark.sql import functions as F, types as T


@configure(profile='rubix-sixteen-executors')
@incremental(snapshot_inputs=["tbl_heir_daily", "initial_load"])
@transform(
    tbl_heir_daily=Input("ri.foundry.main.dataset.6680ece1-5820-40fb-8fbd-9025138edf80"),
    initial_load=Input("ri.foundry.main.dataset.eaaf5454-eee0-43cc-a68b-f54d30ff483f"),
    out=Output("ri.foundry.main.dataset.01a9b2a5-9f99-4577-bdd0-fd77bdb3a138")
)
def my_compute_function(ctx, tbl_heir_daily, initial_load, out):
    # set flag to false when doing initial load and set flag to true when doing incremental process
    # make sure the flag changes to false or true when completing a pull request to master
    flag = True

    if flag:
        curr_schema = T.StructType([
                            T.StructField('uid_0', T.StringType(), True),
                            T.StructField('rc', T.StringType(), True),
                            T.StructField('status',  T.StringType(), True),
                            T.StructField('position',  T.IntegerType(), True),
                            T.StructField('mgmt_level',  T.IntegerType(), True),
                            T.StructField('uid_1',  T.StringType(), True),
                            T.StructField('uid_2',  T.StringType(), True),
                            T.StructField('uid_3',  T.StringType(), True),
                            T.StructField('uid_4',  T.StringType(), True),
                            T.StructField('uid_5',  T.StringType(), True),
                            T.StructField('uid_6',  T.StringType(), True),
                            T.StructField('uid_7',  T.StringType(), True),
                            T.StructField('uid_8',  T.StringType(), True),
                            T.StructField('uid_9',  T.StringType(), True),
                            T.StructField('uid_10',  T.StringType(), True),
                            T.StructField('uid_11',  T.StringType(), True),
                            T.StructField('uid_12',  T.StringType(), True),
                            T.StructField('uid_13',  T.StringType(), True),
                            T.StructField('uid_14',  T.StringType(), True),
                            T.StructField('uid_15',  T.StringType(), True),
                            T.StructField('start_date',  T.DateType(), True),
                            T.StructField('supv_uid', T.StringType(), True),
                            T.StructField('end_date',  T.DateType(), True),
                            T.StructField('reason',  T.StringType(), True)
                            ])

        tbl_hier_hist = out.dataframe(mode='previous', schema=curr_schema)
        # create a dataframe from the previous run's data and only retrieve the data with a high end date.
        # We do this to determine if updates need to happen based on only the most recent row's data for each uid
        tbl_hier_hist_high_end_date = tbl_hier_hist.filter(tbl_hier_hist.end_date == '2050-01-01')

        tbl_heir_daily = tbl_heir_daily.dataframe(mode='current').alias('new')
        # since we are joining these two tables together, I am getting all the columns from current history tables data
        # and adding a hist_ to each column
        tbl_hier_hist_high_end_date = tbl_hier_hist_high_end_date.alias('curr')
        # The join condition for filtering out records that are updated in the new data
        join_condition = [(tbl_heir_daily.uid_0 == tbl_hier_hist.uid_0)]
        # get the records that have changes within the new data that are currently present in target
        tbl_hier_update = tbl_heir_daily.join(tbl_hier_hist_high_end_date, join_condition, 'inner') \
            .selectExpr(
                "new.uid_0",
                "CASE WHEN curr.uid_1 != new.uid_1 THEN 'uid_1' WHEN curr.uid_2 != new.uid_2 THEN 'uid_2' \
                    WHEN curr.uid_3 != new.uid_3 THEN 'uid_3' WHEN curr.uid_4 != new.uid_4 THEN 'uid_4' \
                    WHEN curr.uid_5 != new.uid_5 THEN 'uid_5' WHEN curr.uid_6 != new.uid_6 THEN 'uid_6' \
                    WHEN curr.uid_7 != new.uid_7 THEN 'uid_7' WHEN curr.uid_8 != new.uid_8 THEN 'uid_8' \
                    WHEN curr.uid_9 != new.uid_9 THEN 'uid_9' WHEN curr.uid_10 != new.uid_10 THEN 'uid_10' \
                    WHEN curr.uid_11 != new.uid_11 THEN 'uid_11' WHEN curr.uid_12 != new.uid_12 THEN 'uid_12' \
                    WHEN curr.uid_13 != new.uid_13 THEN 'uid_13' WHEN curr.uid_14 != new.uid_14 THEN 'uid_14' \
                    WHEN curr.uid_15 != new.uid_15 THEN 'uid_15' WHEN curr.position != new.position THEN 'position' \
                    WHEN curr.mgmt_level != new.mgmt_level THEN 'mgmt_level' WHEN curr.status != new.status THEN 'status' \
                    WHEN curr.rc != new.rc THEN 'rc' WHEN curr.supv_uid != new.supv_uid THEN 'supv_uid' ELSE '?' END AS reason"
            ).filter((tbl_hier_hist_high_end_date.end_date == '2050-01-01')
                     & (
                            (F.coalesce(tbl_heir_daily.rc, F.lit('')) != F.coalesce(tbl_hier_hist_high_end_date.rc, F.lit('')))
                            | (F.coalesce(tbl_heir_daily.status, F.lit('')) != F.coalesce(tbl_hier_hist_high_end_date.status, F.lit('')))
                            | (F.coalesce(tbl_heir_daily.position, F.lit(0)) != F.coalesce(tbl_hier_hist_high_end_date.position, F.lit(0)))
                            | (F.coalesce(tbl_heir_daily.mgmt_level, F.lit(0)) != F.coalesce(tbl_hier_hist_high_end_date.mgmt_level, F.lit(0)))
                            | (F.coalesce(tbl_heir_daily.uid_1, F.lit('')) != F.coalesce(tbl_hier_hist_high_end_date.uid_1, F.lit('')))
                            | (F.coalesce(tbl_heir_daily.uid_2, F.lit('')) != F.coalesce(tbl_hier_hist_high_end_date.uid_2, F.lit('')))
                            | (F.coalesce(tbl_heir_daily.uid_3, F.lit('')) != F.coalesce(tbl_hier_hist_high_end_date.uid_3, F.lit('')))
                            | (F.coalesce(tbl_heir_daily.uid_4, F.lit('')) != F.coalesce(tbl_hier_hist_high_end_date.uid_4, F.lit('')))
                            | (F.coalesce(tbl_heir_daily.uid_5, F.lit('')) != F.coalesce(tbl_hier_hist_high_end_date.uid_5, F.lit('')))
                            | (F.coalesce(tbl_heir_daily.uid_6, F.lit('')) != F.coalesce(tbl_hier_hist_high_end_date.uid_6, F.lit('')))
                            | (F.coalesce(tbl_heir_daily.uid_7, F.lit('')) != F.coalesce(tbl_hier_hist_high_end_date.uid_7, F.lit('')))
                            | (F.coalesce(tbl_heir_daily.uid_8, F.lit('')) != F.coalesce(tbl_hier_hist_high_end_date.uid_8, F.lit('')))
                            | (F.coalesce(tbl_heir_daily.uid_9, F.lit('')) != F.coalesce(tbl_hier_hist_high_end_date.uid_9, F.lit('')))
                            | (F.coalesce(tbl_heir_daily.uid_10, F.lit('')) != F.coalesce(tbl_hier_hist_high_end_date.uid_10, F.lit('')))
                            | (F.coalesce(tbl_heir_daily.uid_11, F.lit('')) != F.coalesce(tbl_hier_hist_high_end_date.uid_11, F.lit('')))
                            | (F.coalesce(tbl_heir_daily.uid_12, F.lit('')) != F.coalesce(tbl_hier_hist_high_end_date.uid_12, F.lit('')))
                            | (F.coalesce(tbl_heir_daily.uid_13, F.lit('')) != F.coalesce(tbl_hier_hist_high_end_date.uid_13, F.lit('')))
                            | (F.coalesce(tbl_heir_daily.uid_14, F.lit('')) != F.coalesce(tbl_hier_hist_high_end_date.uid_14, F.lit('')))
                            | (F.coalesce(tbl_heir_daily.uid_15, F.lit('')) != F.coalesce(tbl_hier_hist_high_end_date.uid_15, F.lit('')))
                            | (F.coalesce(tbl_heir_daily.supv_uid, F.lit('')) != F.coalesce(tbl_hier_hist_high_end_date.supv_uid, F.lit('')))
                        ))
        tbl_hier_update = tbl_hier_update.alias('update')
        tbl_hier_update = tbl_hier_update.filter(tbl_hier_update.reason != '?')
        # create a dataframe for just the new records
        new_records = tbl_heir_daily.join(tbl_hier_hist_high_end_date, on=tbl_heir_daily.uid_0 == tbl_hier_hist_high_end_date.uid_0, how='left_anti').selectExpr(
            "new.uid_0",
            "new.rc",
            "new.status",
            "new.position",
            "new.mgmt_level",
            "new.uid_1",
            "new.uid_2",
            "new.uid_3",
            "new.uid_4",
            "new.uid_5",
            "new.uid_6",
            "new.uid_7",
            "new.uid_8",
            "new.uid_9",
            "new.uid_10",
            "new.uid_11",
            "new.uid_12",
            "new.uid_13",
            "new.uid_14",
            "new.uid_15",
            "CAST(from_utc_timestamp(current_timestamp(), 'PST') as DATE) as start_date",
            "new.supv_uid",
            "DATE'2050-01-01' as end_date",
            "reason"
        )
        new_records = new_records.withColumn("start_date", F.date_sub(new_records.start_date, 1))

        # updating the records that are being inserted into the target table with a Start Date as the Current Date
        # and the end date as the High Date set (Max Date)
        tbl_hier_hist_daily = tbl_heir_daily.join(tbl_hier_hist_high_end_date, [tbl_heir_daily.uid_0 == tbl_hier_hist_high_end_date.uid_0, tbl_hier_hist_high_end_date.end_date == '2050-01-01'], how='inner').selectExpr(
            "new.uid_0",
            "new.rc",
            "new.status",
            "new.position",
            "new.mgmt_level",
            "new.uid_1",
            "new.uid_2",
            "new.uid_3",
            "new.uid_4",
            "new.uid_5",
            "new.uid_6",
            "new.uid_7",
            "new.uid_8",
            "new.uid_9",
            "new.uid_10",
            "new.uid_11",
            "new.uid_12",
            "new.uid_13",
            "new.uid_14",
            "new.uid_15",
            "CAST(from_utc_timestamp(current_timestamp(), 'PST') as DATE) as start_date",
            "new.supv_uid",
            "DATE'2050-01-01' as end_date",
            "CASE WHEN curr.uid_1 != new.uid_1 THEN 'uid_1' WHEN curr.uid_2 != new.uid_2 THEN 'uid_2' \
                WHEN curr.uid_3 != new.uid_3 THEN 'uid_3' WHEN curr.uid_4 != new.uid_4 THEN 'uid_4' \
                WHEN curr.uid_5 != new.uid_5 THEN 'uid_5' WHEN curr.uid_6 != new.uid_6 THEN 'uid_6' \
                WHEN curr.uid_7 != new.uid_7 THEN 'uid_7' WHEN curr.uid_8 != new.uid_8 THEN 'uid_8' \
                WHEN curr.uid_9 != new.uid_9 THEN 'uid_9' WHEN curr.uid_10 != new.uid_10 THEN 'uid_10' \
                WHEN curr.uid_11 != new.uid_11 THEN 'uid_11' WHEN curr.uid_12 != new.uid_12 THEN 'uid_12' \
                WHEN curr.uid_13 != new.uid_13 THEN 'uid_13' WHEN curr.uid_14 != new.uid_14 THEN 'uid_14' \
                WHEN curr.uid_15 != new.uid_15 THEN 'uid_15' WHEN curr.position != new.position THEN 'position' \
                WHEN curr.mgmt_level != new.mgmt_level THEN 'mgmt_level' WHEN curr.status != new.status THEN 'status' \
                WHEN curr.rc != new.rc THEN 'rc' WHEN curr.supv_uid != new.supv_uid THEN 'supv_uid' ELSE '?' END AS reason"
        ).filter((
                (F.coalesce(tbl_heir_daily.rc, F.lit('')) != F.coalesce(tbl_hier_hist_high_end_date.rc, F.lit('')))
                | (F.coalesce(tbl_heir_daily.status, F.lit('')) != F.coalesce(tbl_hier_hist_high_end_date.status, F.lit('')))
                | (F.coalesce(tbl_heir_daily.position, F.lit(0)) != F.coalesce(tbl_hier_hist_high_end_date.position, F.lit(0)))
                | (F.coalesce(tbl_heir_daily.mgmt_level, F.lit(0)) != F.coalesce(tbl_hier_hist_high_end_date.mgmt_level, F.lit(0)))
                | (F.coalesce(tbl_heir_daily.uid_1, F.lit('')) != F.coalesce(tbl_hier_hist_high_end_date.uid_1, F.lit('')))
                | (F.coalesce(tbl_heir_daily.uid_2, F.lit('')) != F.coalesce(tbl_hier_hist_high_end_date.uid_2, F.lit('')))
                | (F.coalesce(tbl_heir_daily.uid_3, F.lit('')) != F.coalesce(tbl_hier_hist_high_end_date.uid_3, F.lit('')))
                | (F.coalesce(tbl_heir_daily.uid_4, F.lit('')) != F.coalesce(tbl_hier_hist_high_end_date.uid_4, F.lit('')))
                | (F.coalesce(tbl_heir_daily.uid_5, F.lit('')) != F.coalesce(tbl_hier_hist_high_end_date.uid_5, F.lit('')))
                | (F.coalesce(tbl_heir_daily.uid_6, F.lit('')) != F.coalesce(tbl_hier_hist_high_end_date.uid_6, F.lit('')))
                | (F.coalesce(tbl_heir_daily.uid_7, F.lit('')) != F.coalesce(tbl_hier_hist_high_end_date.uid_7, F.lit('')))
                | (F.coalesce(tbl_heir_daily.uid_8, F.lit('')) != F.coalesce(tbl_hier_hist_high_end_date.uid_8, F.lit('')))
                | (F.coalesce(tbl_heir_daily.uid_9, F.lit('')) != F.coalesce(tbl_hier_hist_high_end_date.uid_9, F.lit('')))
                | (F.coalesce(tbl_heir_daily.uid_10, F.lit('')) != F.coalesce(tbl_hier_hist_high_end_date.uid_10, F.lit('')))
                | (F.coalesce(tbl_heir_daily.uid_11, F.lit('')) != F.coalesce(tbl_hier_hist_high_end_date.uid_11, F.lit('')))
                | (F.coalesce(tbl_heir_daily.uid_12, F.lit('')) != F.coalesce(tbl_hier_hist_high_end_date.uid_12, F.lit('')))
                | (F.coalesce(tbl_heir_daily.uid_13, F.lit('')) != F.coalesce(tbl_hier_hist_high_end_date.uid_13, F.lit('')))
                | (F.coalesce(tbl_heir_daily.uid_14, F.lit('')) != F.coalesce(tbl_hier_hist_high_end_date.uid_14, F.lit('')))
                | (F.coalesce(tbl_heir_daily.uid_15, F.lit('')) != F.coalesce(tbl_hier_hist_high_end_date.uid_15, F.lit('')))
                | (F.coalesce(tbl_heir_daily.supv_uid, F.lit('')) != F.coalesce(tbl_hier_hist_high_end_date.supv_uid, F.lit('')))
            ))
        tbl_hier_hist_daily = tbl_hier_hist_daily.withColumn("start_date", F.date_sub(tbl_hier_hist_daily.start_date, 1))

        # now we need to get a list of the live records that need to be updated and set the end date to the Current Date
        # update the archived records that have new live instances
        update_cond = [tbl_hier_hist.uid_0 == tbl_hier_update.uid_0, tbl_hier_hist_high_end_date.end_date == '2050-01-01']
        tbl_hier_hist_daily_stg_updates = tbl_hier_hist_high_end_date.join(tbl_hier_update, update_cond, 'left').selectExpr(
            "curr.uid_0",
            "curr.rc",
            "curr.status",
            "position",
            "mgmt_level",
            "curr.uid_1",
            "curr.uid_2",
            "curr.uid_3",
            "curr.uid_4",
            "curr.uid_5",
            "curr.uid_6",
            "curr.uid_7",
            "curr.uid_8",
            "curr.uid_9",
            "curr.uid_10",
            "curr.uid_11",
            "curr.uid_12",
            "curr.uid_13",
            "curr.uid_14",
            "curr.uid_15",
            "curr.start_date",
            "curr.supv_uid",
            "date_sub(CAST(from_utc_timestamp(current_timestamp(), 'PST') as DATE), 2) as end_date",
            "update.reason"
        ).filter(
            (F.isnull(tbl_hier_update.uid_0) == False)
            & (tbl_hier_hist_high_end_date.end_date == '2050-01-01')
        )

        duplicate_delete_condition = [tbl_hier_hist.uid_0 == tbl_hier_hist_daily.uid_0, tbl_hier_hist.end_date == '2050-01-01']
        tbl_hier_hist = tbl_hier_hist.join(tbl_hier_hist_daily, duplicate_delete_condition, 'left_anti')
        tbl_hier_hist_daily_stg = tbl_hier_hist.unionByName(tbl_hier_hist_daily)

        # insert the updated archived records
        ret_stg = tbl_hier_hist_daily_stg_updates.unionByName(tbl_hier_hist_daily_stg)

        # deleting the records with uids that are not present in the current daily table
        # essentially deleting employees that are no longer at the company
        del_uids = ret_stg.join(tbl_heir_daily, [tbl_heir_daily.uid_0 == ret_stg.uid_0], 'left_anti')
        ret = ret_stg.join(del_uids, del_uids.uid_0 == ret_stg.uid_0, 'left_anti')

        # adding the deleted records back into the table, but with a 'delete' reason and ending the record.
        del_uids = del_uids.withColumn('reason', F.when(del_uids.end_date == '2050-01-01', F.lit('delete')).otherwise(del_uids.reason))
        del_uids = del_uids.withColumn('end_date', F.when(del_uids.end_date == '2050-01-01', F.date_sub(F.current_date(), 2)).otherwise(del_uids.end_date))
        ret = ret.unionByName(new_records).unionByName(del_uids)

        ret = ret.withColumn('position', ret['position'].cast('int'))
        ret = ret.withColumn('mgmt_level', ret['mgmt_level'].cast('int'))
        ret = ret.filter(F.isnull(ret.uid_0) == False)

        # deleting records more than two years old
        ret = ret.filter(ret.end_date > F.date_sub(F.current_date(), 730))

        ret = ret.orderBy(ret.start_date.desc())
        ret = ret.dropDuplicates()

        out.set_mode("replace")
        out.write_dataframe(ret)
    else:
        initial_load = initial_load.dataframe(mode='current')
        tbl_hier_history = initial_load.selectExpr(
            "uid_0",
            "rc",
            "status",
            "position + 4 as position",
            "0 as mgmt_level",
            "'' as uid_1",
            "'' as uid_2",
            "'' as uid_3",
            "'' as uid_4",
            "uid_1 as uid_5",
            "uid_2 as uid_6",
            "uid_3 as uid_7",
            "uid_4 as uid_8",
            "uid_5 as uid_9",
            "uid_6 as uid_10",
            "uid_7 as uid_11",
            "uid_8 as uid_12",
            "uid_9 as uid_13",
            "uid_10 as uid_14",
            "uid_11 as uid_15",
            "start_date",
            "supv_uid",
            "end_date",
            "reason"
        )
        tbl_hier_history = tbl_hier_history.withColumn('start_date', F.to_date(tbl_hier_history['start_date']))
        tbl_hier_history = tbl_hier_history.withColumn('end_date', F.to_date(tbl_hier_history['end_date']))
        out.set_mode("replace")
        out.write_dataframe(tbl_hier_history)
