from pyspark.sql import functions as F
from pyspark.sql import types as T
from pyspark.sql import Window
from utility.incremental.constants import RANK_COL_NAME
from utility.incremental.timestamp_parsing import perform_backfill_timestamp_parsing
from pyspark.sql.dataframe import DataFrame
from transforms.api import TransformContext, IncrementalTransformOutput, IncrementalTransformInput
from typing import List, Callable, Optional
from utility.incremental.util import drop_unneeded_cols


def identity(x):
    return x


def process_update_insert(
        ctx: TransformContext,
        output: IncrementalTransformOutput,
        updates: IncrementalTransformInput,
        primary_keys: List[str],
        order_cols: List[str],
        num_partitions: int = None,
        backfill: IncrementalTransformInput = None,
        processing: Callable[[DataFrame], DataFrame] = identity):

    updates_df = updates.dataframe()
    updates_df = processing(updates_df)

    # output df will have the same schema after input is processed
    output_df = output.dataframe(mode="previous", schema=updates_df.schema)

    if backfill is not None:
        # Only expect to have any rows here in non-incremental runs.
        backfill = processing(backfill.dataframe(mode="added"))
        output_df = backfill.unionByName(output_df)

    result_df = output_df.unionByName(updates_df)

    window = (Window()
              .partitionBy([F.col(key) for key in primary_keys])
              .orderBy([F.col(col).desc() for col in order_cols]))
    result_df = (result_df.withColumn(RANK_COL_NAME, F.row_number().over(window))
                          .where(F.col(RANK_COL_NAME) == 1)
                          .drop(F.col(RANK_COL_NAME)))

    # rewrite the whole dataset since we changed arbitrary rows
    output.set_mode("replace")

    result_df = result_df.repartition(*primary_keys)
    output.write_dataframe(result_df)


def process_update_insert_multiple_updates(
        ctx: TransformContext,
        output: IncrementalTransformOutput,
        updates: List[IncrementalTransformInput],
        primary_keys: List[str],
        order_cols: List[str],
        num_partitions: int = None,
        backfill: IncrementalTransformInput = None,
        processing: Callable[[DataFrame], DataFrame] = identity):

    updates_df = updates[0].dataframe()
    updates_df = processing(updates_df)

    for update in updates[1:]:
        curr_df = update.dataframe()
        curr_df = processing(curr_df)
        updates_df = updates_df.unionByName(curr_df)

    # output df will have the same schema after input is processed
    output_df = output.dataframe(mode="previous", schema=updates_df.schema)

    if backfill is not None:
        # Only expect to have any rows here in non-incremental runs.
        backfill = processing(backfill.dataframe(mode="added"))
        output_df = backfill.unionByName(output_df)

    result_df = output_df.unionByName(updates_df)

    window = (Window()
              .partitionBy([F.col(key) for key in primary_keys])
              .orderBy([F.col(col).desc() for col in order_cols]))
    result_df = (result_df.withColumn(RANK_COL_NAME, F.row_number().over(window))
                          .where(F.col(RANK_COL_NAME) == 1)
                          .drop(F.col(RANK_COL_NAME)))

    # rewrite the whole dataset since we changed arbitrary rows
    output.set_mode("replace")

    result_df = result_df.repartition(*primary_keys)
    output.write_dataframe(result_df)

TIMESTAMP_COLUMN_NAME_SUFFIXES = ["_tm", "_dt", "_TMSTMP", "_TZ", "_ts", "_DATE", "_TIME", "_DATE001"]
JAN_2050_EPOCH_SECONDS = 2524608000


def is_timestamp_column(col):
    return (
         any(col.name.lower().endswith(suffix.lower()) for suffix in TIMESTAMP_COLUMN_NAME_SUFFIXES)
         and isinstance(col.dataType, T.LongType)
    )


# Parse timestamp values, which come in as long, into timestamps
def perform_timestamp_parsing(raw):
    for col in raw.schema:
        if is_timestamp_column(col):
            # All timestamps written out by Teradata are UTC milliseconds.
            raw = raw.withColumn(col.name, F.from_utc_timestamp(F.from_unixtime(raw[col.name] / 1000), "UTC"))
    return raw


# Upsert based on PK.
def update_insert(
        ctx: TransformContext,
        output: IncrementalTransformOutput,
        updates: IncrementalTransformInput,
        primary_keys: List[str],
        order_cols: List[str],
        num_partitions: int = None,
        backfill: IncrementalTransformInput = None,
        processing: Callable[[DataFrame], DataFrame] = None,
        return_df: Optional[bool] = False) -> None:
    updates_df = updates  # .dataframe()
    updates_df_old_schema = updates_df.schema
    updates_df = perform_timestamp_parsing(updates_df)

    # One time only the backfill may have the unparsed timestamps
    try:
        output_df = output.dataframe(mode="previous", schema=updates_df.schema)
    except Exception:
        output_df = output.dataframe(mode="previous", schema=updates_df_old_schema)
        output_df = perform_timestamp_parsing(output_df)

    if backfill is not None:
        # Only expect to have any rows here in non-incremental runs.
        # output_df = perform_backfill_timestamp_parsing(backfill.dataframe(mode="added")).unionByName(output_df)
        output_df = backfill.unionByName(output_df)

    result_df = output_df.unionByName(updates_df)

    if processing is not None:
        result_df = processing(result_df)

    window = (Window()
              .partitionBy([F.col(key) for key in primary_keys])
              .orderBy([F.col(col).desc() for col in order_cols]))
    result_df = (result_df.withColumn(RANK_COL_NAME, F.row_number().over(window))
                          .where(F.col(RANK_COL_NAME) == 1)
                          .drop(F.col(RANK_COL_NAME)))

    # rewrite the whole dataset since we changed arbitrary rows
    output.set_mode("replace")

    # return df instead of writing it out - will not apply repartitioning
    if return_df:
        return result_df

    if num_partitions is not None:
        result_df = result_df.repartition(num_partitions, *primary_keys)
        output.write_dataframe(
            result_df,
            bucket_cols=primary_keys,
            bucket_count=num_partitions,
            sort_by=primary_keys + order_cols
        )
    else:
        result_df = result_df.repartition(*primary_keys)
        output.write_dataframe(result_df)

def process_update_insert_core(
        ctx: TransformContext,
        output: IncrementalTransformOutput,
        updates_df: DataFrame,
        primary_keys: List[str],
        order_cols: List[str],
        num_partitions: Optional[int] = 200,
        backfill_df: Optional[DataFrame] = None,
        processing: Optional[Callable[[DataFrame], DataFrame]] = None,
        return_df: Optional[bool] = False,
        partition_cols: Optional[List[str]] = None) -> Optional[DataFrame]:
    updates_df = drop_unneeded_cols(updates_df)
    updates_df_old_schema = updates_df.schema

    # One time only the backfill may have the unparsed timestamps
    try:
        output_df = output.dataframe(mode="previous", schema=updates_df.schema)
    except Exception:
        output_df = output.dataframe(mode="previous", schema=updates_df_old_schema)
        output_df = perform_timestamp_parsing(output_df)

    if backfill_df is not None:
        # Only expect to have any rows here in non-incremental runs.
        updates_df = backfill_df.unionByName(updates_df)

    partition_cols = partition_cols or primary_keys
    full_df = updates_df.unionByName(output_df)
    # updates_df = updates_df.repartition(num_partitions, partition_cols)

    # We may process multiple updates, so keep only the latest row per key.
    window = Window().partitionBy(primary_keys).orderBy([F.col(col).desc() for col in order_cols])
    snapshot_df = (
        full_df.withColumn(RANK_COL_NAME, F.row_number().over(window))
        .where(F.col(RANK_COL_NAME) == 1)
        .drop(RANK_COL_NAME)
    )

    # rewrite the whole dataset since we changed arbitrary rows
    output.set_mode("replace")

    # return df instead of writing it out
    if return_df:
        return snapshot_df

    output.write_dataframe(
        snapshot_df,
        bucket_cols=partition_cols,
        bucket_count=num_partitions,
        sort_by=order_cols
    )