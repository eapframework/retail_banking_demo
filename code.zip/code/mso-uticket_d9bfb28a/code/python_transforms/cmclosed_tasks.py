# from pyspark.sql import functions as F
from transforms.api import transform, Input, Output


@transform(
  output=Output("ri.foundry.main.dataset.798ba39c-56f0-4099-9ed0-c178539a43fb"),
  my_input=Input("ri.foundry.main.dataset.46d229a0-80dd-484a-97b8-600e978dba7e")
)
def my_compute_function(output, my_input):
    output.write_dataframe(my_input.dataframe().coalesce(1), output_format="csv", options={"sep":"|_|;|_|", "lineSep":"\u0177", "header": "true"})
