import pyspark.sql.functions as F
from transforms.api import transform, Input, Markings, Output
from utility.column_clean import clean_columns, lowercase_columns

from ..libs.data_transform import replace_column_with_mapping


@transform(
    out=Output("ri.foundry.main.dataset.e6896e97-0e39-4583-9053-ffd43f20a52f"),
    in1=Input(
        'ri.foundry.main.dataset.17594510-edf0-4833-bd0f-6a46813dc14b',
        stop_propagating=Markings(
            ["ab6b32de-380a-490b-aadf-5357a3710600"], on_branches="master"),
    ),
    in2=Input(
        'ri.foundry.main.dataset.251b9b21-dc35-45a6-85dd-baf14292d0cd',
        stop_propagating=Markings(
            ["ab6b32de-380a-490b-aadf-5357a3710600"], on_branches="master"
        )
    ),
    in3=Input(
        'ri.foundry.main.dataset.0ac23d98-38b8-4c4b-b010-b3b221ad0c53',
        stop_propagating=Markings(
            ["ab6b32de-380a-490b-aadf-5357a3710600"], on_branches="master"
        )
    ),
    in4=Input(
        'ri.foundry.main.dataset.dd492089-4a73-4310-9130-33058d482d45',
        stop_propagating=Markings(
            ["ab6b32de-380a-490b-aadf-5357a3710600"], on_branches="master"
        )
    ),
    in5=Input(
        'ri.foundry.main.dataset.2294927d-c578-49ca-91f6-027d3b098bbb',
        stop_propagating=Markings(
            ["ab6b32de-380a-490b-aadf-5357a3710600"], on_branches="master"
        )
    ),
    in6=Input(
        'ri.foundry.main.dataset.8a046419-3741-40fb-b287-b1766c79a482',
        stop_propagating=Markings(
            ["ab6b32de-380a-490b-aadf-5357a3710600"], on_branches="master"
        )
    ),
    in7=Input(
        'ri.foundry.main.dataset.c3ea05a2-07ed-4020-a5dc-d44d46102e7b',
        stop_propagating=Markings(
            ["ab6b32de-380a-490b-aadf-5357a3710600"], on_branches="master"
        )
    )
)
def my_compute_function(ctx, in1, in2, in3, in4, in5, in6, in7, out):
    df1 = clean_columns(
        in1.dataframe(),
        strip_columns=strip_columns,
        integer_columns=cast_to_integer_columns,
        double_columns=cast_to_double_columns,
        decimal_columns=cast_to_decimal_columns,
        timestamp_columns=cast_to_timestamp_from_long_columns,
        datetime_columns=cast_to_timestamp_columns,
        datetime_format=datetime_format,
        date_columns=cast_to_date_columns,
        date_format=date_format,
        id_columns=cast_to_string_columns,
        integer_from_num_columns=cast_to_integer_from_decimal_columns
    )

    df1 = lowercase_columns(df1)
    df1 = df1.withColumn("total_duration", F.datediff(F.coalesce(F.col("case_closed_on"),
                        F.to_date(F.current_date(), 'yyyy-MM-dd')), F.col("created_on")))
    # - F.col("created_on"))
    df2 = clean_columns(
        in2.dataframe(),
        strip_columns=strip_columns,
        integer_columns=cast_to_integer_columns,
        double_columns=cast_to_double_columns,
        decimal_columns=cast_to_decimal_columns,
        timestamp_columns=cast_to_timestamp_from_long_columns,
        datetime_columns=cast_to_timestamp_columns,
        datetime_format=datetime_format,
        date_columns=cast_to_date_columns,
        date_format=date_format,
        id_columns=cast_to_string_columns,
        integer_from_num_columns=cast_to_integer_from_decimal_columns
    )

    df2 = lowercase_columns(df2)

    df2 = df2.groupby("case_number").agg(F.countDistinct('fa_number').alias('fa_count'),
            F.countDistinct('agreement_id').alias('agid_count'))

    df = df1.join(df2, ['case_number'], how='left')

    # Filter inactive records
    df = df.filter(df.active_flag == 'Y')

    # Cast timestamps from strings
    df = df.withColumn("created_on", F.to_timestamp("created_on", "yyyy-MM-dd HH:mm:ss"))
    df = df.withColumn("case_closed_on", F.to_timestamp("case_closed_on", "yyyy-MM-dd HH:mm:ss"))

    # Replace status values with English words
    list_all_df = in3.dataframe()
    cm_case_category_master_df = in4.dataframe()
    cm_case_category_type_df = in5.dataframe()
    cm_team_df = in6.dataframe()
    cm_workgroup_team_df = in7.dataframe()

    df = replace_column_with_mapping(df, list_all_df, 'urgent', 'SYSTEM_ID', 'LIST_VALUE')
    df = replace_column_with_mapping(df, list_all_df, 'status', 'SYSTEM_ID', 'LIST_VALUE')
    df = replace_column_with_mapping(df, cm_case_category_master_df, 'case_category', 'CASE_CATEGORY_ID', 'CASE_CATEGORY')  # noqa: E501
    df = replace_column_with_mapping(df, cm_case_category_type_df, 'case_type', 'CASE_TYPE_ID', 'CASE_TYPE')
    df = replace_column_with_mapping(df, cm_team_df, 'assigned_team', 'TEAM_ID', 'TEAM_LABEL')
    df = replace_column_with_mapping(df, cm_workgroup_team_df, 'assigned_workgroup', 'WORKGROUP_ID', 'WORKGROUP')
    df = replace_column_with_mapping(df, list_all_df, 'root_cause', 'SYSTEM_ID', 'LIST_VALUE')
    df = replace_column_with_mapping(df, list_all_df, 'refund_recovery_status', 'SYSTEM_ID', 'LIST_VALUE')
    # trims whitespace from 'Abatement' value in column
    df = df.withColumn('refund_recovery_status', F.trim('refund_recovery_status'))

    out.write_dataframe(df)


date_format = 'yyyy-MM-dd'
datetime_format = 'yyyy-MM-dd HH:mm:ss'

remove_cols = []
cast_to_date_columns = ["created_on", "case_closed_on"]
cast_to_timestamp_columns = ["SF_LOAD_TS_EST"]
cast_to_timestamp_from_long_columns = []
cast_to_integer_columns = []
cast_to_double_columns = []
cast_to_decimal_columns = []
cast_to_string_columns = []
cast_to_integer_from_decimal_columns = []
strip_columns = []
