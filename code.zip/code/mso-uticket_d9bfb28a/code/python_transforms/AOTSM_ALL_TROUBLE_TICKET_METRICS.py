



from transforms.api import transform_df, Input, Output
from pyspark.sql.functions import expr  # Required so we can do expressions within our field list to handle decoding.


@transform_df(
    Output("/Innovation Lab/[ETL] Ticketing/data/clean/AOTSM_ALL_TROUBLE_TICKET_METRICS_CLEAN"),
    METRICS=Input("/Innovation Lab/[Source] Oracle AOTS-M/data/clean/BOADMIN.TROUBLE_TICKET_METRICS"),
    METRICS_ARCHIVE=Input("/Innovation Lab/[Source] Oracle AOTS-M/data/clean/BOADMIN.TROUBLE_TICKET_METRICS_ARCHIVE"),
)
def Merge_And_Clean(METRICS, METRICS_ARCHIVE):
    Desired_Column_Subset = ("ticket_number"
, "ticket_status"
,"operation"
,"metric_id"
,"previous_metric_id"
,"assigned_region"
,"assigned_market"
,"assigned_district_sub_dept"
,"assigned_zone"
,"assigned"
,"assigned_to"
,"modifying_user"
,"department"
,"field_changed"
,"previous_value"
,"new_value"
, expr("from_utc_timestamp(\
           to_utc_timestamp(\
             from_unixtime(previous_date_time),from_unixtime(unix_timestamp(), 'z')\
            ), 'America/Los_Angeles'\
    ) as previous_date_time_pacific")
, expr("from_utc_timestamp(\
           to_utc_timestamp(\
             from_unixtime(previous_date_time),from_unixtime(unix_timestamp(), 'z')\
            ), 'UTC'\
    ) as previous_date_time")
, expr("from_utc_timestamp(\
           to_utc_timestamp(\
             from_unixtime(previous_date_time),from_unixtime(unix_timestamp(), 'z')\
            ), 'America/Chicago'\
    ) as previous_date_time_central")
, expr("from_utc_timestamp(\
           to_utc_timestamp(\
             from_unixtime(new_date_time),from_unixtime(unix_timestamp(), 'z')\
            ), 'America/Los_Angeles'\
    ) as new_date_time_pacific")
, expr("from_utc_timestamp(\
           to_utc_timestamp(\
             from_unixtime(new_date_time),from_unixtime(unix_timestamp(), 'z')\
            ), 'UTC'\
    ) as new_date_time")
, expr("from_utc_timestamp(\
           to_utc_timestamp(\
             from_unixtime(new_date_time),from_unixtime(unix_timestamp(), 'z')\
            ), 'America/Chicago'\
    ) as new_date_time_central")
, expr("from_utc_timestamp(\
           to_utc_timestamp(\
             from_unixtime(modified_date),from_unixtime(unix_timestamp(), 'z')\
            ), 'America/Los_Angeles'\
    ) as modified_date_pacific")
, expr("from_utc_timestamp(\
           to_utc_timestamp(\
             from_unixtime(modified_date),from_unixtime(unix_timestamp(), 'z')\
            ), 'UTC'\
    ) as modified_date")
, expr("from_utc_timestamp(\
           to_utc_timestamp(\
             from_unixtime(modified_date),from_unixtime(unix_timestamp(), 'z')\
            ), 'America/Chicago'\
    ) as modified_date_central")
,"seconds_in_previous_state"
,"days"
,"hours"
,"minutes"
,"seconds"
,"day"
,"month"
,"year"
,"week"
,"qtr"
,"fromapp"
)
    METRICS = METRICS.select(*Desired_Column_Subset)
    METRICS_ARCHIVE = METRICS_ARCHIVE.select(*Desired_Column_Subset)
    return METRICS.union(METRICS_ARCHIVE)