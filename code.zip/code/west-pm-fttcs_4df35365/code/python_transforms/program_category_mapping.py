from transforms.api import transform, Output, Input, configure

SPARK_PROFILES = [
        'DRIVER_MEMORY_EXTRA_EXTRA_LARGE',
        'DRIVER_CORES_LARGE',
        'EXECUTOR_MEMORY_LARGE',
        'EXECUTOR_CORES_LARGE',
        'NUM_EXECUTORS_32',
        'EXECUTOR_MEMORY_OVERHEAD_LARGE',
        'DYNAMIC_ALLOCATION_DISABLED'
]


@configure(profile=SPARK_PROFILES)
@transform(
    # replace this with your output dataset path
    # latest=Input("ri.foundry.main.dataset.a88082cf-51ca-48ad-9f90-912d951b06b1"),
    latest=Input("ri.foundry.main.dataset.9de51281-80f9-47c2-b6e3-0c8741dc1e4e"),
    prod=Output("ri.foundry.main.dataset.e2d8d814-aab3-4b34-ab6f-df4105884894"),
    )
def my_compute_function(ctx, latest, prod):

    cols = ['Program', 'Category', 'NationalProgram',
        'JobScope', 'Filter', 'Filter_Level', 'Rollup',
        'Notes', 'CreatedOn', 'ModifiedOn']

    # Read the Recent Release Changes.
    latest_df = latest.dataframe().select(*cols).distinct()

    # To fully replace the output
    prod.write_dataframe(latest_df)
