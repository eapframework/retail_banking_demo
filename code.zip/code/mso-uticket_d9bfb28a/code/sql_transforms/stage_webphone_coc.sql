CREATE TABLE `/Innovation Lab/[Source] Webphone/data/raw_data/stage_webphone_coc` AS
SELECT wp.*
, wp.cogs_splt[1] as cogs_1_attuid
, cogs_1.full_name as cogs_1_name
, cogs_1.jt_name as cogs_1_job_title
, cogs_1.direct_total_reports as cogs_1_direct_reports
, cogs_1.level as cogs_1_level
, wp.cogs_splt[2] as cogs_2_attuid
, cogs_2.full_name as cogs_2_name
, cogs_2.jt_name as cogs_2_job_title
, cogs_2.direct_total_reports as cogs_2_direct_reports
, cogs_2.level as cogs_2_level
, wp.cogs_splt[3] as cogs_3_attuid
, cogs_3.full_name as cogs_3_name
, cogs_3.jt_name as cogs_3_job_title
, cogs_3.direct_total_reports as cogs_3_direct_reports
, cogs_3.level as cogs_3_level
, wp.cogs_splt[4] as cogs_4_attuid
, cogs_4.full_name as cogs_4_name
, cogs_4.jt_name as cogs_4_job_title
, cogs_4.direct_total_reports as cogs_4_direct_reports
, cogs_4.level as cogs_4_level
, wp.cogs_splt[5] as cogs_5_attuid
, cogs_5.full_name as cogs_5_name
, cogs_5.jt_name as cogs_5_job_title
, cogs_5.direct_total_reports as cogs_5_direct_reports
, cogs_5.level as cogs_5_level
, wp.cogs_splt[6] as cogs_6_attuid
, cogs_6.full_name as cogs_6_name
, cogs_6.jt_name as cogs_6_job_title
, cogs_6.direct_total_reports as cogs_6_direct_reports
, cogs_6.level as cogs_6_level
, wp.cogs_splt[7] as cogs_7_attuid
, cogs_7.full_name as cogs_7_name
, cogs_7.jt_name as cogs_7_job_title
, cogs_7.direct_total_reports as cogs_7_direct_reports
, cogs_7.level as cogs_7_level
, wp.cogs_splt[8] as cogs_8_attuid
, cogs_8.full_name as cogs_8_name
, cogs_8.jt_name as cogs_8_job_title
, cogs_8.direct_total_reports as cogs_8_direct_reports
, cogs_8.level as cogs_8_level
, wp.cogs_splt[9] as cogs_9_attuid
, cogs_9.full_name as cogs_9_name
, cogs_9.jt_name as cogs_9_job_title
, cogs_9.direct_total_reports as cogs_9_direct_reports
, cogs_9.level as cogs_9_level
, wp.cogs_splt[10] as cogs_10_attuid
, cogs_10.full_name as cogs_10_name
, cogs_10.jt_name as cogs_10_job_title
, cogs_10.direct_total_reports as cogs_10_direct_reports
, cogs_10.level as cogs_10_level
, wp.cogs_splt[11] as cogs_11_attuid
, cogs_11.full_name as cogs_11_name
, cogs_11.jt_name as cogs_11_job_title
, cogs_11.direct_total_reports as cogs_11_direct_reports
, cogs_11.level as cogs_11_level
, wp.cogs_splt[12] as cogs_12_attuid
, cogs_12.full_name as cogs_12_name
, cogs_12.jt_name as cogs_12_job_title
, cogs_12.direct_total_reports as cogs_12_direct_reports
, cogs_12.level as cogs_12_level
, wp.cogs_splt[13] as cogs_13_attuid
, cogs_13.full_name as cogs_13_name
, cogs_13.jt_name as cogs_13_job_title
, cogs_13.direct_total_reports as cogs_13_direct_reports
, cogs_13.level as cogs_13_level
, wp.cogs_splt[14] as cogs_14_attuid
, cogs_14.full_name as cogs_14_name
, cogs_14.jt_name as cogs_14_job_title
, cogs_14.direct_total_reports as cogs_14_direct_reports
, cogs_14.level as cogs_14_level
, sup_name.full_name supervisor_name
FROM `/Innovation Lab/[Source] Webphone/data/clean/webphone_with_emails` wp
LEFT JOIN `/Innovation Lab/[Source] Webphone/data/clean/webphone_with_emails` cogs_1
ON wp.cogs_splt[1]=cogs_1.a1_sbcuid_attuid
LEFT JOIN `/Innovation Lab/[Source] Webphone/data/clean/webphone_with_emails` cogs_2
ON wp.cogs_splt[2]=cogs_2.a1_sbcuid_attuid
LEFT JOIN `/Innovation Lab/[Source] Webphone/data/clean/webphone_with_emails` cogs_3
ON wp.cogs_splt[3]=cogs_3.a1_sbcuid_attuid
LEFT JOIN `/Innovation Lab/[Source] Webphone/data/clean/webphone_with_emails` cogs_4
ON wp.cogs_splt[4]=cogs_4.a1_sbcuid_attuid
LEFT JOIN `/Innovation Lab/[Source] Webphone/data/clean/webphone_with_emails` cogs_5
ON wp.cogs_splt[5]=cogs_5.a1_sbcuid_attuid
LEFT JOIN `/Innovation Lab/[Source] Webphone/data/clean/webphone_with_emails` cogs_6
ON wp.cogs_splt[6]=cogs_6.a1_sbcuid_attuid
LEFT JOIN `/Innovation Lab/[Source] Webphone/data/clean/webphone_with_emails` cogs_7
ON wp.cogs_splt[7]=cogs_7.a1_sbcuid_attuid
LEFT JOIN `/Innovation Lab/[Source] Webphone/data/clean/webphone_with_emails` cogs_8
ON wp.cogs_splt[8]=cogs_8.a1_sbcuid_attuid
LEFT JOIN `/Innovation Lab/[Source] Webphone/data/clean/webphone_with_emails` cogs_9
ON wp.cogs_splt[9]=cogs_9.a1_sbcuid_attuid
LEFT JOIN `/Innovation Lab/[Source] Webphone/data/clean/webphone_with_emails` cogs_10
ON wp.cogs_splt[10]=cogs_10.a1_sbcuid_attuid
LEFT JOIN `/Innovation Lab/[Source] Webphone/data/clean/webphone_with_emails` cogs_11
ON wp.cogs_splt[11]=cogs_11.a1_sbcuid_attuid
LEFT JOIN `/Innovation Lab/[Source] Webphone/data/clean/webphone_with_emails` cogs_12
ON wp.cogs_splt[12]=cogs_12.a1_sbcuid_attuid
LEFT JOIN `/Innovation Lab/[Source] Webphone/data/clean/webphone_with_emails` cogs_13
ON wp.cogs_splt[13]=cogs_13.a1_sbcuid_attuid
LEFT JOIN `/Innovation Lab/[Source] Webphone/data/clean/webphone_with_emails` cogs_14
ON wp.cogs_splt[14]=cogs_14.a1_sbcuid_attuid
LEFT JOIN `/Innovation Lab/[Source] Webphone/data/clean/webphone_with_emails` sup_name
ON wp.supervisor_hrid=sup_name.a1_sbcuid_attuid