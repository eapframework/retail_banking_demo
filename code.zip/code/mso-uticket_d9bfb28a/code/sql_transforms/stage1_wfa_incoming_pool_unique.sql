CREATE TABLE `ri.foundry.main.dataset.ad924c05-ca5f-488e-aa82-c71525cbd8df` AS
    SELECT
    concat(
       CASE when site in ('K', 'I48') then 'WAL'
       when site in ('I', 'CAC') then 'WCA'
       when site in ('E') then 'WCT'
       when site in ('G', 'GAC') then 'WGA'
       when site in ('L') then 'WIL'
       when site in ('N') then 'WIN'
       when site in ('X', 'LMC') then 'WLM'
       when site in ('M') then 'WMI'
       when site in ('C') then 'WMW'
       when site in ('V', 'NFC') then 'WNF'
       when site in ('O') then 'WOH'
       when site in ('H') then 'WPN'
       when site in ('S') then 'WPS'
       when site in ('F', 'SFC') then 'WSF'
       when site in ('Y', 'TNC') then 'WTN'
       when site in ('T') then 'WTX'
       when site in ('W') then 'WWI'
       when site in ('R', 'A') then 'WYX'
       else 'TBD' end,
       tr,
        DATE_FORMAT(
            (from_unixtime(unix_timestamp(actl_rcv_dt ) + (actl_rcv_tm * 60) + (6 * 60 * 60))), 
            'MM/dd/YYYY HH:mm'
        )
    ) as ticket_number_unique
    , concat(
       CASE when site in ('K', 'I48') then 'WAL'
       when site in ('I', 'CAC') then 'WCA'
       when site in ('E') then 'WCT'
       when site in ('G', 'GAC') then 'WGA'
       when site in ('L') then 'WIL'
       when site in ('N') then 'WIN'
       when site in ('X', 'LMC') then 'WLM'
       when site in ('M') then 'WMI'
       when site in ('C') then 'WMW'
       when site in ('V', 'NFC') then 'WNF'
       when site in ('O') then 'WOH'
       when site in ('H') then 'WPN'
       when site in ('S') then 'WPS'
       when site in ('F', 'SFC') then 'WSF'
       when site in ('Y', 'TNC') then 'WTN'
       when site in ('T') then 'WTX'
       when site in ('W') then 'WWI'
       when site in ('R', 'A') then 'WYX'
       else 'TBD' end,
       tr,
        year(from_unixtime(unix_timestamp(actl_rcv_dt ) + (actl_rcv_tm * 60) + (6 * 60 * 60))) 
    ) as join_key
    , tr ext_key1
, site wfa_site
, CASE when site in ('K', 'I48') then 'WAL'
       when site in ('I', 'CAC') then 'WCA'
       when site in ('E') then 'WCT'
       when site in ('G', 'GAC') then 'WGA'
       when site in ('L') then 'WIL'
       when site in ('N') then 'WIN'
       when site in ('X', 'LMC') then 'WLM'
       when site in ('M') then 'WMI'
       when site in ('C') then 'WMW'
       when site in ('V', 'NFC') then 'WNF'
       when site in ('O') then 'WOH'
       when site in ('H') then 'WPN'
       when site in ('S') then 'WPS'
       when site in ('F', 'SFC') then 'WSF'
       when site in ('Y', 'TNC') then 'WTN'
       when site in ('T') then 'WTX'
       when site in ('W') then 'WWI'
       when site in ('R', 'A') then 'WYX'
       else 'TBD' end wfa_tkt_prefix
, trbl_cd wfa_trouble_code
, cast(from_unixtime(unix_timestamp(rcv_dt ) + (rcv_tm * 60) + (6 * 60 * 60)) as timestamp) wfa_start_dt
, cast(from_unixtime(unix_timestamp(closed_dt ) + (closed_tm * 60) + (6 * 60 * 60)) as timestamp) wfa_finish_dt
, closeout_summary wfa_closeout_summary 
, sf1
, sf2
, sf3
FROM `ri.foundry.main.dataset.4e8ff367-a3fa-4826-b057-c48ffe78812c`
WHERE lower(tr) REGEXP '^[a-z][a-z][0-9][0-9][0-9][0-9][0-9][0-9]$|[0-9a-z][0-9a-z][0-9a-z][0-9a-z][0-9a-z][0-9a-z][0-9a-z][0-9a-z][0-9a-z]'
