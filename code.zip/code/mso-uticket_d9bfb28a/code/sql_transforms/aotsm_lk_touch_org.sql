CREATE TABLE `ri.foundry.main.dataset.eaf6b4bf-b394-415a-b879-626b920ba4f7` AS
    SELECT distinct modifying_user
    , SVP_Name svp_name
    , VP_Name vp_name
    , AVP_Name avp_name
    , Director_Name director_name
    , dept_name
    , vp_org_name
    , supervisor_name 
    , cogs_1_name
    , cogs_2_name
    , cogs_3_name
    , cogs_4_name
    , cogs_5_name
    , cogs_6_name
    , cogs_7_name
    , cogs_8_name
    , cogs_9_name
    , cogs_10_name
    FROM `ri.foundry.main.dataset.1925a513-933d-4e17-9bbe-becb2fbb60b3` MOD_USER
    LEFT JOIN `ri.foundry.main.dataset.c7dce00a-301c-4599-9914-3345f86a475e` WEBPHONE
    ON MOD_USER.modifying_user=WEBPHONE.a1_sbcuid_attuid
    WHERE WEBPHONE.a1_sbcuid_attuid is not null