from pyspark.sql import functions as F
from transforms.api import transform, Input, Output, incremental
from utility.column_clean import clean_columns, lowercase_columns, remove_prefix


@transform(
    out=Output("/Innovation Lab/[Source] Teradata EDW - ASI_VIEWS/data/clean/vcan016_tirks_ckt_prep_header"),
    df=Input("/Innovation Lab/[Source] Teradata EDW - ASI_VIEWS/data/raw/snowflake/VCAN016_TIRKS_CKT_PREP_HEADER"),
)
def my_compute_function(df, out):
    df = df.dataframe().withColumn('CIRCUIT_IDENTIFICATION_CD_RAW', F.col('CIRCUIT_IDENTIFICATION_CD'))
    df = clean_columns(
        df,
        date_format=date_format, 
        date_columns=string_to_date,
        datetime_format=datetime_format, 
        datetime_columns=long_unixtime_to_timestamp,
        timestamp_from_string_format=string_unixtime_format,
        timestamp_from_string_columns=string_unixtime_to_timestamp,
        timestamp_format=long_unixtime_format, 
        timestamp_columns=long_unixtime_to_timestamp,
        integer_columns=string_to_integer_columns,
        double_columns=string_to_double_columns,
        decimal_columns=string_to_decimal_columns,
        id_columns=numeric_to_string_columns,
        integer_from_num_columns=decimal_to_integer,
        strip_columns=strip_string_columns,
    )
    # df = df.drop(*drop_columns)
    # df = remove_prefix(df, 'example_prefix')
    df = df.withColumn('pull_slice', F.lit(-1))
    for col in convert_to_short_columns:
        df = df.withColumn(col, df[col].cast("short"))
    df = lowercase_columns(df)
    out.write_dataframe(df)


drop_columns = []

date_format = 'yyyy-MM-dd'
string_to_date = []
datetime_format = 'yyyy-MM-dd HH:mm:ss'
string_to_timestamp = []

string_unixtime_format = None
string_unixtime_to_timestamp = []
long_unixtime_format = None
long_unixtime_to_timestamp = []

string_to_integer_columns = []
string_to_double_columns = []
string_to_decimal_columns = []

numeric_to_string_columns = []
decimal_to_integer = []

strip_string_columns = [
    "SBC_COMPANY_CD",
    "SBC_SYSTEM_CD",
    "CIRCUIT_ACCESS_CD",
    "CIRCUIT_LAYOUT_ORDER_NBR",
    "SBC_STATE_CD",
    "ADMINISTRATIVE_AREA_CD",
    "CURRENT_CIRCUIT_STATUS_CD",
    "CURRENT_CIRCUIT_ACTIVITY_CD",
    "CKT_LYT_ORD_ACTIVITY_STATUS_CD",
    "CKT_IDENTIFICATION_FORMAT_CD",
    "CIRCUIT_IDENTIFICATION_CD",
    "CIRCUIT_LOCATION_A_CLLI_CD",
    "CIRCUIT_LOCATION_Z_CLLI_CD",
    "SAFEGUARDING_MEASURE_PRTCTN_CD",
    "SERVICE_RESUMPTION_PRIORITY_CD",
    "ORDER_NBR",
    "ORDER_SUPPLEMENT_ID",
    "ORDER_CUSTOMER_CD",
    "ORDER_CUSTOMER_NM",
    "ORDER_CUSTOMER_TELEPHONE_NBR",
    "CUSTOMER_CONTACT_NM",
    "CUSTOMER_CONTACT_TELEPHONE_NBR",
    "MULTIWIRE_INDICATOR_CD",
    "LATA_STATE_CD",
    "LATA_CD",
    "CIRCUIT_GROUP_ACCESS_CD",
    "CUSTOMER_SWITCH_END_CD",
    "MAINT_CONTROL_OFC_LOC_CLLI_CD",
    "WRITING_CONTROL_OFFICE_CD",
    "BTN",
    "REBATE_REQUIRED_INTERVAL_DUR",
    "SERVICE_ADDR",
    "PURCHASE_ORDER_NBR",
    "ENGINEERING_CONTROL_OFFICE_CD",
    "INTER_EXCHANGE_CARRIER_CKT_NBR",
    "ACNA_CD",
    "CUST_CARRIER_NAME_ABRVTN_CD",
    "EML_A_TO_Z_DIRECTION_MSRMT",
    "OBJECTIVE_EML_Z_TO_A_MSRMT",
    "OBJECTIVE_EML_A_TO_Z_MSRMT",
    "MULTIWIRE_CIRCUIT_OVERRIDE_CD",
    "LOCATION_A_STATION_CLLI_CD",
    "LOCATION_Z_STATION_CLLI_CD",
    "LOCATION_A_STATION_ADDR",
    "LOCATION_Z_STATION_ADDR",
    "LOCATION_A_LOCAL_CONTACT_NM",
    "LOC_A_LOCAL_CONTACT_TEL_NBR",
    "LOCATION_Z_LOCAL_CONTACT_NM",
    "LOC_Z_LOCAL_CONTACT_TEL_NBR",
    "LOC_A_CIRCUIT_LOCATION_NBR",
    "LOC_Z_CIRCUIT_LOCATION_NBR",
    "NETWORK_CHANNEL_INTERFACE_CD",
    "SECDY_NTWK_CHNL_INTERFACE_CD",
    "ACTL_CLLI_CD",
    "ACTL_INFORMATION_TXT",
    "TIRKS_PROJECT_NBR",
    "PLUGIN_INVEN_CTRL_SYS_JOB_ID",
    "DETAILED_RGLTY_CKT_LYT_ORD_CD",
    "CARRIER_NETWORK_IDNTFCN_CD",
    "RELATED_ORDER_COMPLTN_INFO_CD",
    "RELATED_CKT_LYT_ORDER_INFO_TXT",
    "ORDER_ORIGINATOR_NM",
    "ORDER_ORIGINATOR_TELEPHONE_NBR",
    "MASTER_CUSTOMER_NBR",
    "MULTIPLE_RPTG_OFFICE_NBR_3_CD",
    "PLANNING_DESIGN_ACCESS_CD",
    "CIRCUIT_CONTROL_OFFICE_CLLI_CD",
    "CIRCUIT_CONTROL_OFFICE_CD",
    "OVERALL_CONTROL_OFFICE_CLLI_CD",
    "OVERALL_CONTROL_OFFICE_CD",
    "CIRCUIT_DIVERSITY_CD",
    "CIRCUIT_DROP_CONTINUE_PATH_IND",
    "AVOIDANCE_ROUTE_CLASS_CD",
    "CIRCUIT_MILEAGE_MSRMT",
    "HUNTING_GROUP_NBR",
    "RATE_CLASS_OF_SERVICE_CD",
    "USOC",
    "USOC_LOCATION_A_CD",
    "USOC_LOCATION_Z_CD",
    "BUREAU_GROUP_CD",
    "DESIGN_CONTACT_NM",
    "DESIGN_CONTACT_TELEPHONE_NBR",
    "CFA_A_END_FIELD_ID_FORMAT_CD",
    "CFA_A_END_FACILITY_DSGNTN_CD",
    "CFA_A_END_FACILITY_TYPE_CD",
    "CFA_A_END_CHANNEL_NBR",
    "CFA_A_END_TRMNL_A_LOC_CLLI_CD",
    "CFA_A_END_TRMNL_Z_LOC_CLLI_CD",
    "CFA_Z_END_FIELD_ID_FORMAT_CD",
    "CFA_Z_END_FACILITY_DSGNTN_CD",
    "CFA_Z_END_FACILITY_TYPE_CD",
    "CFA_Z_END_CHANNEL_NBR",
    "CFA_Z_END_TRMNL_A_LOC_CLLI_CD",
    "CFA_Z_END_TRMNL_Z_LOC_CLLI_CD",
    "NETWORK_CHANNEL_CD",
    "INTEREXCHANGE_USER_ACCESS_CD",
    "ACTL_PRIMARY_TRMNTN_PT_CLLI_CD",
    "ACTL_SECDY_TRMNTN_PT_CLLI_CD",
    "TRNSMSN_LEVEL_PRIMARY_PT_MSRMT",
    "TRNSMSN_LEVEL_SECDY_PT_MSRMT",
    "DESIGN_ROUTING_CD",
    "MSG_MECHANIZED_CTRL_PROCS_IND",
    "NO_CIRCUIT_DETAILS_IND",
    "MECHANIZED_DESIGN_IND",
    "FLOW_THRU_ON_IND",
    "MECHANIZED_DESIGN_MODEL_NBR",
    "MECHANIZED_DESIGN_NBR",
    "DIVERSE_CIRCUIT_ACCESS_CD",
    "HDSL_DOUBLER_IND",
]

convert_to_short_columns = ["CIRCUIT_DETAILS_ISSUE_NBR", "WORK_AUTHORIZATION_ISSUE_NBR"]