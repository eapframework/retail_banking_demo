from transforms.api import configure
from transforms.api import transform_df, Input, Output
from pyspark.sql import functions as F, types as T
from myproject.datasets.utils import uid_to_num, uid_dt_to_num


@configure(profile=['EXECUTOR_MEMORY_MEDIUM', 'NUM_EXECUTORS_16'])
@transform_df(
    Output("ri.foundry.main.dataset.ae5315b0-7f88-4fc2-88b0-35233744421f"),
    tbl_hier_hist_daily=Input("ri.foundry.main.dataset.01a9b2a5-9f99-4577-bdd0-fd77bdb3a138"),
    tbl_cenet_full=Input("ri.foundry.main.dataset.293d7d73-8e66-4221-89d6-a05b61aa34b6")
)
def my_compute_function(ctx, tbl_hier_hist_daily, tbl_cenet_full):
    spark = ctx.spark_session
    my_udf = F.udf(lambda z: uid_to_num(z), T.StringType())
    _ = spark.udf.register("my_udf", my_udf)

    uid_dt_based_udf = F.udf(lambda arr: uid_dt_to_num(arr), T.StringType())
    _ = spark.udf.register("uid_dt_based_udf", uid_dt_based_udf)

    tbl_cenet_full = tbl_cenet_full.filter(tbl_cenet_full.active == 'Y')
    current = tbl_hier_hist_daily.alias('a')
    current = current.join(tbl_cenet_full.alias("c0"),  [F.col("c0.uid") == current.uid_0], "left") \
        .join(tbl_cenet_full.alias("c1"), [F.col("c1.uid") == current.uid_1], "left") \
        .join(tbl_cenet_full.alias("c2"), [F.col("c2.uid") == current.uid_2], "left") \
        .join(tbl_cenet_full.alias("c3"), [F.col("c3.uid") == current.uid_3], "left") \
        .join(tbl_cenet_full.alias("c4"), [F.col("c4.uid") == current.uid_4], "left") \
        .join(tbl_cenet_full.alias("c5"), [F.col("c5.uid") == current.uid_5], "left") \
        .join(tbl_cenet_full.alias("c6"), [F.col("c6.uid") == current.uid_6], "left") \
        .join(tbl_cenet_full.alias("c7"), [F.col("c7.uid") == current.uid_7], "left") \
        .join(tbl_cenet_full.alias("c8"), [F.col("c8.uid") == current.uid_8], "left") \
        .join(tbl_cenet_full.alias("c9"), [F.col("c9.uid") == current.uid_9], "left") \
        .join(tbl_cenet_full.alias("c10"), [F.col("c10.uid") == current.uid_10], "left") \
        .join(tbl_cenet_full.alias("c11"), [F.col("c11.uid") == current.uid_11], "left") \
        .join(tbl_cenet_full.alias("c12"), [F.col("c12.uid") == current.uid_12], "left") \
        .join(tbl_cenet_full.alias("c13"), [F.col("c13.uid") == current.uid_13], "left") \
        .join(tbl_cenet_full.alias("c14"), [F.col("c14.uid") == current.uid_14], "left") \
        .join(tbl_cenet_full.alias("c15"), [F.col("c15.uid") == current.uid_15], "left") \
        .selectExpr(
            "a.uid_0 as sbc_uid",
            "a.rc",
            "a.status",
            "CAST(a.start_date AS varchar(20)) AS start_date",
            "a.end_date",
            "a.position",
            "a.mgmt_level",
            "c0.f_name as first_name",
            "c0.l_name as last_name",
            "c0.u_f_name as unofficial_first_name",
            "c0.m_name as middle_name",
            "CASE WHEN a.uid_0 = 0 THEN a.uid_0 else NULL END as l0_sbc_uid",
            "a.uid_1 as l1_sbc_uid",
            "a.uid_2 as l2_sbc_uid",
            "a.uid_3 as l3_sbc_uid",
            "a.uid_4 as l4_sbc_uid",
            "a.uid_5 as l5_sbc_uid",
            "a.uid_6 as l6_sbc_uid",
            "a.uid_7 as l7_sbc_uid",
            "a.uid_8 as l8_sbc_uid",
            "a.uid_9 as l9_sbc_uid",
            "a.uid_10 as l10_sbc_uid",
            "a.uid_11 as l11_sbc_uid",
            "a.uid_12 as l12_sbc_uid",
            "a.uid_13 as l13_sbc_uid",
            "a.uid_14 as l14_sbc_uid",
            "a.uid_15 as l15_sbc_uid",
            "CONCAT(c0.l_name, ',', ' ', c0.u_f_name) as l0_name",
            "c0.mgmt_level as l0_mgt_level_indicator",
            "c0.emp_status_code as l0_emp_status_code",
            "c0.active as l0_active",
            "c0.job_desc as l0_job_description",
            "CONCAT(c1.l_name, ',', ' ', c1.u_f_name) as l1_name",
            "c1.mgmt_level as l1_mgt_level_indicator",
            "c1.emp_status_code as l1_emp_status_code",
            "c1.active as l1_active",
            "c1.job_desc as l1_job_description",
            "CONCAT(c2.l_name, ',', ' ', c2.u_f_name) as l2_name",
            "c2.mgmt_level as l2_mgt_level_indicator",
            "c2.emp_status_code as l2_emp_status_code",
            "c2.active as l2_active",
            "c2.job_desc as l2_job_description",
            "CONCAT(c3.l_name, ',', ' ', c3.u_f_name) as l3_name",
            "c3.mgmt_level as l3_mgt_level_indicator",
            "c3.emp_status_code as l3_emp_status_code",
            "c3.active as l3_active",
            "c3.job_desc as l3_job_description",
            "CONCAT(c4.l_name, ',', ' ', c4.u_f_name) as l4_name",
            "c4.mgmt_level as l4_mgt_level_indicator",
            "c4.emp_status_code as l4_emp_status_code",
            "c4.active as l4_active",
            "c4.job_desc as l4_job_description",
            "CONCAT(c5.l_name, ',', ' ', c5.u_f_name) as l5_name",
            "c5.mgmt_level as l5_mgt_level_indicator",
            "c5.emp_status_code as l5_emp_status_code",
            "c5.active as l5_active",
            "c5.job_desc as l5_job_description",
            "CONCAT(c6.l_name, ',', ' ', c6.u_f_name) as l6_name",
            "c6.mgmt_level as l6_mgt_level_indicator",
            "c6.emp_status_code as l6_emp_status_code",
            "c6.active as l6_active",
            "c6.job_desc as l6_job_description",
            "CONCAT(c7.l_name, ',', ' ', c7.u_f_name) as l7_name",
            "c7.mgmt_level as l7_mgt_level_indicator",
            "c7.emp_status_code as l7_emp_status_code",
            "c7.active as l7_active",
            "c7.job_desc as l7_job_description",
            "CONCAT(c8.l_name, ',', ' ', c8.u_f_name) as l8_name",
            "c8.mgmt_level as l8_mgt_level_indicator",
            "c8.emp_status_code as l8_emp_status_code",
            "c8.active as l8_active",
            "c8.job_desc as l8_job_description",
            "CONCAT(c9.l_name, ',', ' ', c9.u_f_name) as l9_name",
            "c9.mgmt_level as l9_mgt_level_indicator",
            "c9.emp_status_code as l9_emp_status_code",
            "c9.active as l9_active",
            "c9.job_desc as l9_job_description",
            "CONCAT(c10.l_name, ',', ' ', c10.u_f_name) as l10_name",
            "c10.mgmt_level as l10_mgt_level_indicator",
            "c10.emp_status_code as l10_emp_status_code",
            "c10.active as l10_active",
            "c10.job_desc as l10_job_description",
            "CONCAT(c11.l_name, ',', ' ', c11.u_f_name) as l11_name",
            "c11.mgmt_level as l11_mgt_level_indicator",
            "c11.emp_status_code as l11_emp_status_code",
            "c11.active as l11_active",
            "c11.job_desc as l11_job_description",
            "CONCAT(c12.l_name, ',', ' ', c12.u_f_name) as l12_name",
            "c12.mgmt_level as l12_mgt_level_indicator",
            "c12.emp_status_code as l12_emp_status_code",
            "c12.active as l12_active",
            "c12.job_desc as l12_job_description",
            "CONCAT(c13.l_name, ',', ' ', c13.u_f_name) as l13_name",
            "c13.mgmt_level as l13_mgt_level_indicator",
            "c13.emp_status_code as l13_emp_status_code",
            "c13.active as l13_active",
            "c13.job_desc as l13_job_description",
            "CONCAT(c14.l_name, ',', ' ', c14.u_f_name) as l14_name",
            "c14.mgmt_level as l14_mgt_level_indicator",
            "c14.emp_status_code as l14_emp_status_code",
            "c14.active as l14_active",
            "c14.job_desc as l14_job_description",
            "CONCAT(c15.l_name, ',', ' ', c15.u_f_name) as l15_name",
            "c15.mgmt_level as l15_mgt_level_indicator",
            "c15.emp_status_code as l15_emp_status_code",
            "c15.active as l15_active",
            "c15.job_desc as l15_job_description",
            "c0.company_code",
            "c0.work_addr1",
            "c0.work_city",
            "c0.work_state",
            "c0.work_zip",
            "c0.supv_uid",
            "c0.emp_classification",
            "c0.hrid",
            "c0.job_desc",
            "c0.job_function_code",
            "a.supv_uid as supervisor_sbc_uid",
            "c0.ncs_date",
            "c0.contractor"
            ).filter((tbl_hier_hist_daily.status != 'D'))
    current = current.withColumn('start_date', current.start_date.cast(T.StringType()))
    current = current.withColumn('uid_based_key', my_udf('sbc_uid').cast(T.LongType()))

    current = current.withColumn('uid_dt_based_key', uid_dt_based_udf(F.array('uid_based_key', 'start_date')).cast(T.LongType()))
    current = current.withColumn('start_date', current.start_date.cast(T.TimestampType()))

    current = current.withColumn('end_date', current.end_date.cast('String'))
    current = current.withColumn('end_date', F.when(current.end_date == '2050-01-01', F.concat(current.end_date, F.lit(' 00:00:00')))
                                 .otherwise(F.concat(current.end_date, F.lit(' 23:59:00'))))
    current = current.withColumn('end_date', current.end_date.cast(T.TimestampType()))
    current = current.orderBy(current.start_date.desc())

    return current
