from transforms.api import transform, Output, Input, configure
from pyspark.sql import functions as F
from pyspark.sql.types import IntegerType
from pyspark.sql.window import Window


SPARK_PROFILES = [
        'DRIVER_MEMORY_EXTRA_EXTRA_LARGE',
        'DRIVER_CORES_LARGE',
        'EXECUTOR_MEMORY_LARGE',
        'EXECUTOR_CORES_LARGE',
        'NUM_EXECUTORS_32',
        'EXECUTOR_MEMORY_OVERHEAD_LARGE',
        'DYNAMIC_ALLOCATION_DISABLED'
]


@configure(profile=SPARK_PROFILES)
@transform(
    # replace this with your output dataset path
    smallcell_lvl_2_sites=Output("ri.foundry.main.dataset.7ed8adea-d4a4-4bb7-96fd-b9f207ae903c"),
    outinternal_lvl_1=Input("ri.foundry.main.dataset.45d4e145-6d09-4832-a86d-d1a7559f97d7"),
    tempout_smallcell_C=Output("ri.foundry.main.dataset.f3b9f144-c6bc-4f4f-b117-938bc18d359d"),
    tempout_smallcell_PA=Output("ri.foundry.main.dataset.4dd03d47-a26d-4839-9b1e-393b7af7a76a"),
    iwm=Input("ri.foundry.main.dataset.53bb3121-e1f0-4b82-b910-b540db3e1bdf"),
    )
def my_compute_function(ctx, iwm, outinternal_lvl_1, smallcell_lvl_2_sites,
                        tempout_smallcell_C, tempout_smallcell_PA):

    # get the necessary data from pace snapshot
    cols = [F.col("IWM_JOB_NUMBER").alias("iwm_number"),
            F.col("NATIONAL_PROGRAM").alias("national_program"),
            F.col("JOB_SCOPE").alias("job_scope"),
            F.col("JOB_STATUS").alias("status"),
            F.col("ORACLE_PTN").alias("oracle_ptn"),
            F.col("MOD_CODE").alias("mod_code"),
            F.col("SPECTRUM").alias("spectrum"),
            F.col("N_UDF4").alias("n_udf4"),
            F.col("N_UDF5").alias("n_udf5"),
            F.col("PRODUCT_GROUP").alias("product_group"),
            F.col("PRODUCT_SUB_GROUP").alias("product_subgroup"),
            F.col("PLANNING_NUMBER").alias("planning_number"),
            F.col("PLANNING_STATUS").alias("iplan_status"),
            F.col("FA_LOCATION_CODE").alias("fa_location_code"),
            F.col("ONAIR_ACTUAL_END_DATE").alias("onair_actual"),
            F.col("ONAIR_PLAN_END_DATE").alias("onair_forecast"),
            F.col("JOB_CATEGORY").alias("job_category"),
            F.col("ALLOCATION").alias("allocation"),
            F.col("SOLUTION").alias("solution"),
            F.col("NEW_SITE_BUILD").alias("new_site_build"),
            F.col("ASSOCIATED_FA").alias("associated_fa"),
            F.col("1220T_ACTUAL").alias("1220t_actual"),
            F.col("COMMITMENT_DATE").alias("commitment_date"),
            F.col("SCOPE_NAME").alias("scope_name"),
            ]

    iwm_df = iwm.dataframe().select(*cols).distinct()
    iwm_df = iwm_df.withColumn("allocation", F.when(F.col("allocation").isNull(), F.lit("NULL"))
                                              .otherwise(F.col("allocation")))

    # Catpture the Level 1 tagging required for MCA Sites tagging
    outinternal_lvl_1_df = outinternal_lvl_1.dataframe()
    outinternal_lvl_1_df = outinternal_lvl_1_df.withColumnRenamed('program', 'level1_program')

    # Filter out those Level 1 parent program used in Level 2 tagging. ** Consider add this into ALLInOne config table.
    # smallcell_sites_df = "level1_program in ('Small Cell - Nodes All In Jobs')"
    smallcell_sites_df = "level1_program in ('Small Cell - Nodes NSB Jobs', 'Small Cell - Nodes Nokia Swap Jobs 2',\
            'Small Cell - Nodes Ericsson Upgrades Jobs 2')"
    smallcell_lvl_1_df = outinternal_lvl_1_df.where(smallcell_sites_df)

    # Get the matching job's attributes
    smallcell_iwm_df = smallcell_lvl_1_df.join(
        iwm_df,
        "iwm_number",
        "inner"
    )

    # Get the SmallCell Sites Tagging columns added
    smallcell_df_out = prepare_SmallCell_Sites_tagging_data(smallcell_iwm_df, tempout_smallcell_C, tempout_smallcell_PA)
    out_df = (
        iwm_df
        .join(smallcell_df_out, 'iwm_number', 'left')
        .select("iwm_number", "smallcell_fa_rnk_NSB_C_order", "smallcell_fa_rnk_NSB_PA_order",
        "smallcell_fa_rnk_Nokia_C_order", "smallcell_fa_rnk_Nokia_PA_order",
        "smallcell_fa_rnk_Ericsson_C_order", "smallcell_fa_rnk_Ericsson_PA_order")
        .filter("smallcell_fa_rnk_NSB_C_order is not null OR smallcell_fa_rnk_NSB_PA_order is not null OR \
            smallcell_fa_rnk_Nokia_C_order is not null OR smallcell_fa_rnk_Nokia_PA_order is not null OR \
            smallcell_fa_rnk_Ericsson_C_order is not null OR smallcell_fa_rnk_Ericsson_PA_order is not null")
         .distinct()
    )
    # ----------------- Program Category SmallCell Sites tagging ENDs here -----------------

    cols_to_sum = ["smallcell_fa_rnk_NSB_C_order", "smallcell_fa_rnk_NSB_PA_order",
        "smallcell_fa_rnk_Nokia_C_order", "smallcell_fa_rnk_Nokia_PA_order",
        "smallcell_fa_rnk_Ericsson_C_order", "smallcell_fa_rnk_Ericsson_PA_order"]

    # Use coalesce to replace nulls with 0 before summing
    out_df = out_df.groupBy("iwm_number").agg(*[F.sum(F.coalesce(F.col(c), F.lit(0))).alias(c) for c in cols_to_sum])

    # Overall Level 1 Changes
    smallcell_lvl_2_sites.write_dataframe(out_df)


def prepare_SmallCell_Sites_tagging_data(iwm_df, tempout_mca_C, tempout_mca_PA):

    # Filter the valid project for Sites Tagging also filter out the valid MPT jobs based on 1220T_ACTUAL
    valid_jobs = "upper(status) in ('ON_GOING','COMPLETED') \
        and year(1220t_actual) not in (1920,1950)"

    # Select the columns required for tagging
    iwm_df = (
        iwm_df
        .select(
            F.col("iwm_number"),
            F.col("national_program"),
            F.col("job_scope"),
            F.col("fa_location_code"),
            F.col("mod_code"),
            F.year(F.coalesce(F.col("onair_actual"), F.col("onair_forecast"))).alias("plan_YR"),
            # F.left(F.col("scope_name")).alias("scope_YR"),
            F.col("scope_name"),
            F.year(F.col("commitment_date")).alias("commitment_YR"),
            F.year(F.col("onair_actual")).alias("actual_YR"),
            F.col("allocation")
        )
        .where(valid_jobs)
    )

    # Select the required data for Sites Tagging
    sites_filter = "national_program = 'Small Cell' and job_scope not like '%Relocation'"
    iwm_sites_df = iwm_df.where(sites_filter)

    # Select the required columns for Sites Tagging
    iwm_sites_df = (
        iwm_sites_df
        .select(
            F.col("iwm_number"),
            F.col("allocation")
        )
    )

    nsb_filter = "level1_program = 'Small Cell - Nodes NSB Jobs'"
    nokia_filter = "level1_program = 'Small Cell - Nodes Nokia Swap Jobs 2'"
    ericsson_filter = "level1_program = 'Small Cell - Nodes Ericsson Upgrades Jobs 2'"

    iwm_bau_sites_df = iwm_sites_df.where(nsb_filter)
    iwm_nokia_sites_df = iwm_sites_df.where(nokia_filter)
    iwm_ericcson_sites_df = iwm_sites_df.where(ericsson_filter)

    # filter the Valid jobs for commitment Tagging
    # Select the required columns
    valid_mca_C_df = (
        iwm_df
        .select(
            F.col("iwm_number"),
            F.col("mod_code"),
            F.col("commitment_YR").alias("YR"),
            F.col("fa_location_code")
        )
        .where("left(scope_name,4) = commitment_YR")
    )

    # Call the function for commitment Tagging for Sites per FA and ModCode
    tempout_C, C_df = Generate_SmallCell_tagging_C(iwm_bau_sites_df, valid_mca_C_df, "NSB")
    # merge the MCA Temp output, to add extra tagging columns
    tempout_C_df = tempout_C
    mca_df = C_df

    # Call the function for commitment Tagging for Sites per FA and ModCode
    tempout_C, C_df = Generate_SmallCell_tagging_C(iwm_nokia_sites_df, valid_mca_C_df, "Nokia")
    # merge the MCA Temp output, to add extra tagging columns
    tempout_C_df = tempout_C_df.unionByName(tempout_C, allowMissingColumns=True)
    mca_df = mca_df.unionByName(C_df, allowMissingColumns=True)

    # Call the function for commitment Tagging for Sites per FA and ModCode
    tempout_C, C_df = Generate_SmallCell_tagging_C(iwm_ericcson_sites_df, valid_mca_C_df, "Ericsson")
    # merge the MCA Temp output, to add extra tagging columns
    tempout_C_df = tempout_C_df.unionByName(tempout_C, allowMissingColumns=True)
    tempout_mca_C.write_dataframe(tempout_C_df)
    mca_df = mca_df.unionByName(C_df, allowMissingColumns=True)

    # filter out Valid jobs for MCA tag checking for Plan/Actual.
    # Select the required columns
    valid_mca_PA_df = (
        iwm_df
        .select(
            F.col("iwm_number"),
            F.col("mod_code"),
            F.col("plan_YR").alias("YR"),
            F.col("fa_location_code"),
            F.col("scope_name"),
            F.col("commitment_YR"),
            F.col("actual_YR")
        )
        .where("plan_YR is not null")
    )

    # Call the Function to do Plan and Actual tagging
    tempout_PA, PA_df = Generate_SmallCell_tagging_PA(iwm_bau_sites_df, valid_mca_PA_df, "NSB")
    # merge the MCA Temp output, to add extra tagging columns
    tempout_PA_df = tempout_PA
    mca_df = mca_df.unionByName(PA_df, allowMissingColumns=True)

    tempout_PA, PA_df = Generate_SmallCell_tagging_PA(iwm_nokia_sites_df, valid_mca_PA_df, "Nokia")
    # merge the MCA Temp output, to add extra tagging columns
    tempout_PA_df = tempout_PA_df.unionByName(tempout_PA, allowMissingColumns=True)
    mca_df = mca_df.unionByName(PA_df, allowMissingColumns=True)

    tempout_PA, PA_df = Generate_SmallCell_tagging_PA(iwm_ericcson_sites_df, valid_mca_PA_df, "Ericsson")
    # merge the MCA Temp output, to add extra tagging columns
    tempout_PA_df = tempout_PA_df.unionByName(tempout_PA, allowMissingColumns=True)
    tempout_mca_PA.write_dataframe(tempout_PA_df)
    mca_df = mca_df.unionByName(PA_df, allowMissingColumns=True)

    # retun the Dataset with sites Tagging columns
    return mca_df


def Generate_SmallCell_tagging_C(lvl1_df, iwm_df, RnkType):

    # Set the tagging variable based on InputType
    if RnkType == "NSB":
        MCA_Cat_Rank_udf = F.udf(SmallCell_Cat_Rank_NSB, IntegerType())
        ColName = "smallcell_fa_rnk_NSB_C_order"
    elif RnkType == "Nokia":
        MCA_Cat_Rank_udf = F.udf(SmallCell_Cat_Rank_Nokia, IntegerType())
        ColName = "smallcell_fa_rnk_Nokia_C_order"
    elif RnkType == "Ericsson":
        MCA_Cat_Rank_udf = F.udf(SmallCell_Cat_Rank_Ericsson, IntegerType())
        ColName = "smallcell_fa_rnk_Ericsson_C_order"

    # filter the required jobs
    # Limit the Tagging dataset to small and for valid Sites jobs
    iwm_df = iwm_df.join(
        lvl1_df,
        "iwm_number",
        "leftsemi"
    )

    iwm_df = iwm_df.withColumn('Cat_Order', MCA_Cat_Rank_udf(F.col('mod_code')))
    iwm_df = iwm_df.filter(iwm_df.Cat_Order.isNotNull())

    # Apply Rank() over partition logic
    partition = Window.partitionBy('YR', 'fa_location_code').orderBy('Cat_Order', 'iwm_number')
    iwm_df = iwm_df.withColumn('rnk_order', F.rank().over(partition))

    # Generate temp output for validation
    outdf = iwm_df.select(F.col("*"))

    # Filter the dataframe
    iwm_df = iwm_df.filter((F.col('rnk_order') == 1) & (F.col('Cat_Order').isNotNull()))

    iwm_df = (
        iwm_df
        .select(
            F.col("iwm_number").alias("iwm_number"),
            F.col("rnk_order").alias(ColName),
        )
    )

    return outdf, iwm_df


def Generate_SmallCell_tagging_PA(lvl1_df, iwm_df, RnkType):  # noqa: C901

    # Set the tagging variable based on InputType
    if RnkType == "NSB":
        MCA_Cat_Rank_udf = F.udf(SmallCell_Cat_Rank_NSB, IntegerType())
        ColName = "smallcell_fa_rnk_NSB_PA_order"
    elif RnkType == "Nokia":
        MCA_Cat_Rank_udf = F.udf(SmallCell_Cat_Rank_Nokia, IntegerType())
        ColName = "smallcell_fa_rnk_Nokia_PA_order"
    elif RnkType == "Ericsson":
        MCA_Cat_Rank_udf = F.udf(SmallCell_Cat_Rank_Ericsson, IntegerType())
        ColName = "smallcell_fa_rnk_Ericsson_PA_order"

    # filter the required jobs
    # Limit the Tagging dataset to small and for valid Sites jobs
    iwm_df = iwm_df.join(
        lvl1_df,
        "iwm_number",
        "leftsemi"
    )

    mca_df = iwm_df.where("left(scope_name,4) = commitment_YR and actual_YR = commitment_YR")
    mca_df = mca_df.withColumn('Cat_Order', MCA_Cat_Rank_udf(F.col('mod_code')))
    mca_df = mca_df.filter(mca_df.Cat_Order.isNotNull())

    # Apply Rank() over partition logic
    partition = Window.partitionBy('YR', 'fa_location_code').orderBy('Cat_Order', 'iwm_number')
    mca_df = mca_df.withColumn('rnk_order', F.rank().over(partition))

    # Select the required columns
    mca_df2 = iwm_df

    # exclude those FA found in Level1
    mca_df2 = mca_df2.join(mca_df, ['YR', "fa_location_code"], "left_anti")

    mca_df2 = mca_df2.withColumn('Cat_Order', MCA_Cat_Rank_udf(F.col('mod_code')))
    mca_df2 = mca_df2.filter(mca_df2.Cat_Order.isNotNull())

    # Apply Rank() over partition logic
    partition = Window.partitionBy('YR', 'fa_location_code').orderBy('Cat_Order', 'iwm_number')
    mca_df2 = mca_df2.withColumn('rnk_order', F.rank().over(partition))

    mca_df = mca_df2.unionByName(mca_df)

    # Generate temp output for validation
    outdf = mca_df.select(F.col("*"))

    # Filter the dataframe
    mca_df = mca_df.filter((F.col('rnk_order') == 1) & (F.col('Cat_Order').isNotNull()))

    mca_df = (
        mca_df
        .select(
            F.col("iwm_number").alias("iwm_number"),
            F.col("rnk_order").alias(ColName),
        )
    )

    return outdf, mca_df


def SmallCell_Cat_Rank_NSB(mod_code):
    # Here are the Ranking Order, Based on the ModCode(s)

    '''
    ======== Primary ========
    AAF29, AAF4P, AAJ2P, AALSC, AALSD, AAMTX, AAPBO, AAPBP
    ======== Standalone ========
    AAPBQ, AAPBR, AAMTY

    Added new ModCodes on 11/18

    '''

    mod_code_lookup = {
        1: ['AAF29', 'AAQ81', 'AAQ9B'],
        2: ['AAF4P', 'AAQ87', 'AAQ9C'],
        3: ['AAJ2P'], 4: ['AALSC', 'AAQ5Q'],
        5: ['AALSD', 'AAQ5W'], 6: ['AAMTX'], 7: ['AAPBO', 'AAQ9D'], 8: ['AAPBP', 'AAQ9E'],
        9: ['AAPBQ'], 10: ['AAPBR'], 11: ['AAMTY']
    }

    for key in mod_code_lookup.keys():
        if mod_code in mod_code_lookup[key]:
            return key


def SmallCell_Cat_Rank_Nokia(mod_code):
    # Here are the Ranking Order, Based on the ModCode(s)

    '''
    ======== Primary ========
    AAP6S, AAP6P
    ======== Standalone ========
    AAPB3, AAPB5, AAPB2, AAPB4

    Added new ModCodes on 11/18

    '''

    mod_code_lookup = {
        1: ['AAP6S', 'AAQ5E', 'AAQ5F'], 2: ['AAP6P', 'AAQ54', 'AAQ55'],
        3: ['AAPB3', 'AAQ5M', 'AAQ5N'], 4: ['AAPB5', 'AAQ5K', 'AAQ5L'],
        5: ['AAPB2', 'AAQ5C', 'AAQ5D'], 6: ['AAPB4', 'AAQ5A', 'AAQ5B']
    }

    for key in mod_code_lookup.keys():
        if mod_code in mod_code_lookup[key]:
            return key


def SmallCell_Cat_Rank_Ericsson(mod_code):
    # Here are the Ranking Order, Based on the ModCode(s)

    '''
    ======== Primary ========
    AAP6S, AAP6P
    ======== Standalone ========
    AAPB3, AAPB5, AAPB2, AAPB4

    Added new ModCodes on 11/18

    '''

    mod_code_lookup = {
        1: ['AAP6S', 'AAQ5E', 'AAQ5F'], 2: ['AAP6P', 'AAQ54', 'AAQ55'],
        3: ['AAPB3', 'AAQ5M', 'AAQ5N'], 4: ['AAPB5', 'AAQ5K', 'AAQ5L'],
        5: ['AAPB2', 'AAQ5C', 'AAQ5D'], 6: ['AAPB4', 'AAQ5A', 'AAQ5B']
    }

    for key in mod_code_lookup.keys():
        if mod_code in mod_code_lookup[key]:
            return key
