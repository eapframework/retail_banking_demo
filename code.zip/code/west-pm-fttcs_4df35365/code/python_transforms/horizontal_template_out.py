""" Description: WS Horizontal Template
    BRD Level: Internal, NOT included on landing page

LOG:
    Date          | Author   | Description
    12-04-2024    | an4927   | code cleanup for uniform syntax and commenting
    -             | -        | -
    -             | -        | -
"""


from pyspark.sql import Row
from transforms.api import transform, Output
from .horizontal_template import horizontal_template


@transform(
    out_template=Output("ri.foundry.main.dataset.70671ca9-7364-4c48-a859-8d5e5e8f112c"),
)
def my_compute_function(ctx, out_template):
    # Initial setup for json schema and variables
    schema = ['COLUMN_NO', 'COLUMN_NAME', 'SOURCE_COLUMN_NAME', 'EXPORT_DESTINATION_COLUMN', 'T_M_C', 'DEV_T_M_C',
        'IS_EXPORTED', 'DEV_EXPORT_FLAG', 'COLUMN_ORDER']
    rows = []
    row_count = 0

    # Read json file to pull values for table
    for d in horizontal_template:
        row_count = row_count + 1
        #rc_d = dict(d, "ROW_COUNT"=row_count)
        d['COLUMN_ORDER'] = row_count
        dict_for_row = {k: d.get(k, None) for k in schema}
        rows.append(Row(**dict_for_row))

    config_df = ctx.spark_session.createDataFrame(rows)
    out_template.write_dataframe(config_df)

    return
