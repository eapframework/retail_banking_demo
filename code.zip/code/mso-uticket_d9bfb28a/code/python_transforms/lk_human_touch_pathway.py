from pyspark.sql import functions as F
from pyspark.sql.window import Window
from transforms.api import transform_df, Input, Output


@transform_df(
    Output("ri.foundry.main.dataset.85bec1b0-457b-47c4-af42-8f0fdd680e2e"),
    touch=Input("ri.foundry.main.dataset.1925a513-933d-4e17-9bbe-becb2fbb60b3"),
)
def compute(touch):
    window = Window.partitionBy("ticket_number").orderBy(F.col("Modified_Time_1M"))
    touch = (
        touch
        .filter(F.col("is_human") == 1)
        .select(
            F.row_number().over(window).alias("row"),
            F.col("ticket_number"),
            F.concat_ws(',', F.collect_list(F.col("modifying_user")).over(window)).alias("human_pathway"),
        )
        .withColumn("maxrow", F.max(F.col("row")).over(Window.partitionBy("ticket_number")))
        .filter(F.col("row") == F.col("maxrow"))
        .drop("row")
        .drop("maxrow")
    )
    return touch
