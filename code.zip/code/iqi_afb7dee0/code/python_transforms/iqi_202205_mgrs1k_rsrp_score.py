from pyspark.sql import functions as F, types as T
from transforms.api import transform_df, Input, Output
from .utils import *


@transform_df(
    Output("ri.foundry.main.dataset.c8bcb90b-daab-4eac-b588-eaa50515968f"),
    metrics=Input("ri.foundry.main.dataset.75a4ccba-9d15-474c-b8a2-a4e836a655ae"),
    reference = Input("ri.foundry.main.dataset.0e340be8-66fa-43e8-aa3f-03fdde440481")
)
def compute(metrics, reference):
    df = metrics.filter(
            (F.col("yyyymm") == "202205") & (F.col("region").isNotNull())
        ).select(
            F.col("mgrs1k").alias("mgrs"),
            "zip",
            "state",
            "county",
            "region",
            "market",
            "submarket",
            "avg_rsrp"
        )

    # Map RSRPs to ranges
    from pyspark.ml.feature import Bucketizer
    bucketizer = Bucketizer(splits=[-float("inf"), -115, -110, -105, -95, -85, float('Inf')],inputCol="avg_rsrp", outputCol="metrics_color")
    df  = bucketizer.setHandleInvalid("keep").transform(df)
    labels = [RED, ORANGE, YELLOW, TEAL, BLUE, GREEN]
    label_array = F.array(*(F.lit(label) for label in labels))
    df = df.withColumn("metrics_color", label_array.getItem(F.col("metrics_color").cast("integer")))
    df = df.fillna({"metrics_color": PURPLE})

    # format the bins to shape
    bins = format_reference_bins(reference, size = 1000)

    # merge metrics with shapes
    df = df.join(bins, ["mgrs"], how='left')

    # select relevant fields
    df = df.select(
        "mgrs",
        "shape",
        "metrics_color"
    )

    return df
