from transforms.api import transform_df, Input, Output


@transform_df(
    Output(
        "/Innovation Lab/Data Governance/Code & Data/code/transforms-python/src/myproject/datasets/magritte_agents",
        sever_permissions=True,
    ),
    my_input=Input("ri.foundry.main.dataset.29dc30fc-6fce-45a6-90b3-740a182436fd"),
)
def my_compute_function(my_input):
    return my_input
