from transforms.api import transform, Input, Output, incremental
#from utility.incremental.update_insert import update_insert
from myproject.datasets.utils import update_insert
from utility.column_clean import clean_columns, lowercase_columns, remove_prefix, long_to_datetime
from pyspark.sql import functions as F
from myproject.datasets.column_clean import strip_all_string_col
from pyspark.sql.types import DecimalType, IntegerType


time_cols =['comp_can_tm','actl_comptln_tm','appt_tm','wrk_wndw_end_tm' ,'frst_asgn_tm','asgn_last_tm','cmtmt_tm','cust_advs_tm','frst_dsptch_tm','last_dsptch_tm','entry_tm' ,'escal_tm','latest_start_tm','load_end_tm','load_start_tm','cust_rptd_tm','rstrl_tm','ts_wr_tm' ,'askme_max_rstrl_tm']

@incremental(semantic_version=7)
@transform(
    output=Output("ri.foundry.main.dataset.a66ab7be-b938-4779-ba24-2dc644803bb1"),
    updates=Input("ri.foundry.main.dataset.f6f1d51b-c982-4401-a8b3-6c2f39c2dc74"),
)
def wifa_details(ctx, output, updates):
    updates = updates.dataframe()
    updates=lowercase_columns(updates)
    updates=strip_all_string_col(updates)
    updates=updates.drop("pull_slice") #This is required when we do the backfill using hashbucket only#
    updates = updates.withColumn("wr_id", F.col("wr_id").cast(DecimalType())) \
                .withColumn("comp_can_mam_tm", F.col("comp_can_mam_tm").cast(IntegerType())) \
                .withColumn("actl_comptln_mam_tm", F.col("actl_comptln_mam_tm").cast(IntegerType())) \
                .withColumn("appt_mam_tm", F.col("appt_mam_tm").cast(IntegerType())) \
                .withColumn("wrk_wndw_end_mam_tm", F.col("wrk_wndw_end_mam_tm").cast(IntegerType())) \
                .withColumn("frst_asgn_mam_tm", F.col("frst_asgn_mam_tm").cast(IntegerType())) \
                .withColumn("asgn_last_mam_tm", F.col("asgn_last_mam_tm").cast(IntegerType())) \
                .withColumn("cmtmt_mam_tm", F.col("cmtmt_mam_tm").cast(IntegerType())) \
                .withColumn("cust_advs_mam_tm", F.col("cust_advs_mam_tm").cast(IntegerType())) \
                .withColumn("frst_dsptch_mam_tm", F.col("frst_dsptch_mam_tm").cast(IntegerType())) \
                .withColumn("last_dsptch_mam_tm", F.col("last_dsptch_mam_tm").cast(IntegerType())) \
                .withColumn("entry_mam_tm", F.col("entry_mam_tm").cast(IntegerType())) \
                .withColumn("escal_mam_tm", F.col("escal_mam_tm").cast(IntegerType())) \
                .withColumn("estd_tech_dur", F.col("estd_tech_dur").cast(DecimalType(5,0))) \
                .withColumn("latest_start_mam_tm", F.col("latest_start_mam_tm").cast(IntegerType())) \
                .withColumn("load_end_mam_tm", F.col("load_end_mam_tm").cast(IntegerType())) \
                .withColumn("load_start_mam_tm", F.col("load_start_mam_tm").cast(IntegerType())) \
                .withColumn("nbr_cust_aff", F.col("nbr_cust_aff").cast(IntegerType())) \
                .withColumn("nbr_cust_rpt", F.col("nbr_cust_rpt").cast(IntegerType())) \
                .withColumn("nbr_hi_cxr", F.col("nbr_hi_cxr").cast(IntegerType())) \
                .withColumn("nbr_trbl_rpt", F.col("nbr_trbl_rpt").cast(IntegerType())) \
                .withColumn("cust_rptd_mam_tm", F.col("cust_rptd_mam_tm").cast(IntegerType())) \
                .withColumn("rstrl_mam_tm", F.col("rstrl_mam_tm").cast(IntegerType())) \
                .withColumn("ts_wr_mam_tm", F.col("ts_wr_mam_tm").cast(IntegerType())) \
                .withColumn("askme_tot_wrk_tm_dur", F.col("askme_tot_wrk_tm_dur").cast(IntegerType())) \
                .withColumn("askme_rcv_to_clr_dur", F.col("askme_rcv_to_clr_dur").cast(IntegerType())) \
                .withColumn("askme_rcv_to_clr2_dur", F.col("askme_rcv_to_clr2_dur").cast(IntegerType())) \
                .withColumn("askme_rcv_to_rstrl_dur", F.col("askme_rcv_to_rstrl_dur").cast(IntegerType())) \
                .withColumn("askme_rcv_to_dsptch_dur", F.col("askme_rcv_to_dsptch_dur").cast(IntegerType())) \
                .withColumn("askme_rcv_to_frst_asgn_dur", F.col("askme_rcv_to_frst_asgn_dur").cast(IntegerType())) \
                .withColumn("askme_frst_asgn_to_clr_dur", F.col("askme_frst_asgn_to_clr_dur").cast(IntegerType())) \
                .withColumn("askme_frst_asgn_to_clr2_dur", F.col("askme_frst_asgn_to_clr2_dur").cast(IntegerType())) \
                .withColumn("askme_frst_asgn_to_rstrl_dur", F.col("askme_frst_asgn_to_rstrl_dur").cast(IntegerType())) \
                .withColumn("askme_frst_asgn_to_dsptch_dur", F.col("askme_frst_asgn_to_dsptch_dur").cast(IntegerType())) \
                .withColumn("askme_dsptch_to_clr_dur", F.col("askme_dsptch_to_clr_dur").cast(IntegerType())) \
                .withColumn("askme_dsptch_to_clr2_dur", F.col("askme_dsptch_to_clr2_dur").cast(IntegerType())) \
                .withColumn("askme_dsptch_to_rstrl_dur", F.col("askme_dsptch_to_rstrl_dur").cast(IntegerType())) \
                .withColumn("askme_nbr_items", F.col("askme_nbr_items").cast(IntegerType())) \
                .withColumn("askme_pernr", F.col("askme_pernr").cast(IntegerType())) \
                .withColumn("askme_rcv_to_load_dur", F.col("askme_rcv_to_load_dur").cast(IntegerType())) \
                .withColumn("askme_load_to_clr_dur", F.col("askme_load_to_clr_dur").cast(IntegerType())) \
                .withColumn("askme_rcv_to_cmtmt_dur", F.col("askme_rcv_to_cmtmt_dur").cast(IntegerType())) \
                .withColumn("root_wr_id", F.col("root_wr_id").cast(DecimalType(10,0))) \
                .withColumn("from_wr_id", F.col("from_wr_id").cast(DecimalType(10,0))) \
                .withColumn("askme_cc_tot_wrk_tm", F.col("askme_cc_tot_wrk_tm").cast(IntegerType())) \
                .withColumn("askme_max_rstrl_mam_tm", F.col("askme_max_rstrl_mam_tm").cast(IntegerType())) \
                .withColumn("askme_alt_blg_loc_id", F.col("askme_alt_blg_loc_id").cast(DecimalType(18,0))) 
                #.withColumn("comp_can_dt", F.from_utc_timestamp(F.from_unixtime(F.col("comp_can_dt") / 1000), "UTC")) \
                #.withColumn("comp_can_dt", F.to_date(F.col("comp_can_dt"))) \
                #.withColumn("dw_load_dt", F.from_utc_timestamp(F.from_unixtime(F.col("dw_load_dt") / 1000), "UTC")) \
                #.withColumn("dw_load_dt", F.to_date(F.col("dw_load_dt"))) \
    update_insert(ctx, output, updates, primary_keys=["wr_id" , "ext_key1" , "comp_can_ts" , "src_cd"], order_cols=["dw_load_dt", "comp_can_dt"],time_cols=time_cols)