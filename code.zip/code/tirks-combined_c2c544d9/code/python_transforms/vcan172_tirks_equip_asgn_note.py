from transforms.api import transform, Input, Output, incremental
from utility.column_clean import clean_columns, lowercase_columns, remove_prefix


@transform(
    out=Output("/Innovation Lab/[Source] Teradata EDW - ASI_VIEWS/data/clean/vcan172_tirks_equip_asgn_note"),
    df=Input("/Innovation Lab/[Source] Teradata EDW - ASI_VIEWS/data/raw/snowflake/VCAN172_TIRKS_EQUIP_ASGN_NOTE"),
)
def my_compute_function(df, out):
    df = clean_columns(
        df.dataframe(),
        date_format=date_format, 
        date_columns=string_to_date,
        datetime_format=datetime_format, 
        datetime_columns=long_unixtime_to_timestamp,
        timestamp_from_string_format=string_unixtime_format,
        timestamp_from_string_columns=string_unixtime_to_timestamp,
        timestamp_format=long_unixtime_format, 
        timestamp_columns=long_unixtime_to_timestamp,
        integer_columns=string_to_integer_columns,
        double_columns=string_to_double_columns,
        decimal_columns=string_to_decimal_columns,
        id_columns=numeric_to_string_columns,
        integer_from_num_columns=decimal_to_integer,
        strip_columns=strip_string_columns,
    )
    # df = remove_prefix(df, 'example_prefix')
    df = df.withColumn("ASSIGNMENT_NOTE_SEQUENCE_NBR", df["ASSIGNMENT_NOTE_SEQUENCE_NBR"].cast("short"))
    df = lowercase_columns(df)
    df = df.drop(*drop_columns)
    out.write_dataframe(df)


drop_columns = ["dw_load_dt", "dw_load_tm", "dw_load_user", "dw_updt_ts", "dw_updt_user"]

date_format = 'yyyy-MM-dd'
string_to_date = []
datetime_format = 'yyyy-MM-dd HH:mm:ss'
string_to_timestamp = []

string_unixtime_format = None
string_unixtime_to_timestamp = []
long_unixtime_format = None
long_unixtime_to_timestamp = []

string_to_integer_columns = []
string_to_double_columns = []
string_to_decimal_columns = []

numeric_to_string_columns = []
decimal_to_integer = []

strip_string_columns = [
    "SBC_COMPANY_CD",
    "SBC_SYSTEM_CD",
    "SBC_STATE_CD",
    "EQUIPMENT_LOCATION_CLLI_CD",
    "HUMAN_EQUIP_CATALOG_ITEM_CD",
    "RELAY_RACK_CD",
    "UNIT_NBR",
    "SUBDIVISION_CD",
    "ASSIGNMENT_NOTE_TXT",
]

