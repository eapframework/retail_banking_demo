"""
MSO uTicket — Shared Utility Functions
Converted from Foundry utility.py → Databricks-native PySpark helpers.

These functions replicate the column-cleaning, timestamp-parsing, and
upsert (SCD1) logic that the Foundry transforms relied on.
"""

from pyspark.sql import DataFrame, functions as F, types as T, Window


# ---------------------------------------------------------------------------
# Timestamp helpers
# ---------------------------------------------------------------------------

TIMESTAMP_COLUMN_NAME_SUFFIXES = [
    "_tm", "_dt", "_TMSTMP", "_TZ", "_ts", "_DATE", "_TIME", "_DATE001"
]


def is_timestamp_column(col):
    """Check if a StructField looks like a millisecond-epoch timestamp."""
    return (
        any(col.name.lower().endswith(s.lower()) for s in TIMESTAMP_COLUMN_NAME_SUFFIXES)
        and isinstance(col.dataType, T.LongType)
    )


def perform_timestamp_parsing(df: DataFrame) -> DataFrame:
    """
    Auto-detect LongType columns whose names end with known timestamp suffixes
    and convert millis-since-epoch → TimestampType (UTC).
    """
    for col in df.schema:
        if is_timestamp_column(col):
            df = df.withColumn(
                col.name,
                F.from_utc_timestamp(F.from_unixtime(df[col.name] / 1000), "UTC"),
            )
    return df


def parse_epoch_millis_columns(df: DataFrame, columns: list) -> DataFrame:
    """Explicitly convert named columns from epoch-millis (Long) to Timestamp."""
    for c in columns:
        if c in df.columns:
            df = df.withColumn(
                c,
                F.from_utc_timestamp(F.from_unixtime(F.col(c) / 1000), "UTC"),
            )
    return df


# ---------------------------------------------------------------------------
# Column cleaning (replaces Foundry's clean_columns + lowercase_columns)
# ---------------------------------------------------------------------------

def clean_columns(
    df: DataFrame,
    *,
    timestamp_columns: list = None,
    integer_columns: list = None,
    float_columns: list = None,
    double_columns: list = None,
    decimal_columns: list = None,
    string_columns: list = None,
    strip_columns: list = None,
    date_columns: list = None,
    datetime_columns: list = None,
    datetime_format: str = "yyyy-MM-dd HH:mm:ss",
    date_format: str = "yyyy-MM-dd",
    integer_from_num_columns: list = None,
) -> DataFrame:
    """
    Apply casting / parsing to named column lists.
    Mirrors the Foundry utility.column_clean.clean_columns function.
    """
    for c in (timestamp_columns or []):
        if c in df.columns:
            df = df.withColumn(c, F.from_utc_timestamp(F.from_unixtime(F.col(c) / 1000), "UTC"))

    for c in (datetime_columns or []):
        if c in df.columns:
            df = df.withColumn(c, F.to_timestamp(F.col(c), datetime_format))

    for c in (date_columns or []):
        if c in df.columns:
            df = df.withColumn(c, F.to_date(F.col(c), date_format))

    for c in (integer_columns or []):
        if c in df.columns:
            df = df.withColumn(c, F.col(c).cast("integer"))

    for c in (float_columns or []):
        if c in df.columns:
            df = df.withColumn(c, F.col(c).cast("float"))

    for c in (double_columns or []):
        if c in df.columns:
            df = df.withColumn(c, F.col(c).cast("double"))

    for c in (decimal_columns or []):
        if c in df.columns:
            df = df.withColumn(c, F.col(c).cast("decimal(38,10)"))

    for c in (string_columns or []):
        if c in df.columns:
            df = df.withColumn(c, F.col(c).cast("string"))

    for c in (strip_columns or []):
        if c in df.columns:
            df = df.withColumn(c, F.trim(F.col(c)))

    for c in (integer_from_num_columns or []):
        if c in df.columns:
            df = df.withColumn(c, F.col(c).cast("decimal").cast("integer"))

    return df


def lowercase_columns(df: DataFrame) -> DataFrame:
    """Rename all columns to lower-case (Foundry convention)."""
    return df.select([F.col(c).alias(c.lower()) for c in df.columns])


# ---------------------------------------------------------------------------
# Status code mappings (from Contour CASE expressions)
# ---------------------------------------------------------------------------

STATUS_MAP = {
    0: "New", 1: "Assigned", 2: "Planning", 3: "Scheduled",
    4: "WorkInProgess", 5: "Pending", 6: "Resolved",
    7: "Closed", 8: "Cancelled",
}

TASK_STATUS_MAP = {
    0: "New", 1: "Scheduled", 2: "WorkInProgress",
    3: "Pending", 4: "Closed",
}

APPROVAL_STATUS_MAP = {
    0: "Approval Required", 1: "Pending Approval", 2: "Rejected",
    3: "Approved", 4: "Approval Process Cancelled", 5: "Not Required",
}


def map_status(col_name: str, mapping: dict, default: str = "Unknown"):
    """Build a CASE WHEN expression from a dict mapping."""
    expr = F.lit(default)
    for code, label in mapping.items():
        expr = F.when(F.col(col_name) == code, F.lit(label)).otherwise(expr)
    return expr


# ---------------------------------------------------------------------------
# MSO requester group filter list (from Contour Board 6)
# ---------------------------------------------------------------------------

MSO_REQUESTER_GROUPS = [
    "GNO-Mobility-Data-Apps", "GNO-Mobility-Femtocell", "GNO-Mobility-NSD-CALEA",
    "ATT-IT-GNO-MOBILITY-DCO", "GNO-Mobility-Policy-Profile", "GNO-Mobility-NSD-OTA-OPS",
    "GNO-Mobility-ActiveChargeData", "ATT-IT-GNO-MOBILITY-DAP", "ATT-IT-GNO-MOBILITY-PROBE",
    "GNO-MOBILITY-PROBE", "ATT-IT-STORAGE-OPS-T2", "GNO-Mobility-NSD-NTN-VoIP/PTT",
    "GNO-NRC-VOIP-SONUS", "GNO-NRC-VOIP-vSONUS", "GNO-NRC-VOIP-APPS", "GNO-NRC-VOIP-vAPPS",
    "GNO-NRC-VOIP-APPS-SFTSW", "GNO-Mobility-NSD-CCS-Op", "GNO-Mobility-NSD-DataSVC-Core",
    "GNO-Mobility-NSD-DCO", "GNO-Mobility-NSD-DevManageOPS", "GNO-Mobility-NSD-DNS",
    "GNO-Mobility-NSD-EA-Mobility", "GNO-Mobility-NSD-External-Part", "GNO-Mobility-NSD-IP-Bearer-OAM",
    "GNO-Mobility-NSD-LDAP", "GNO-Mobility-NSD-NI-Server-App", "GNO-Mobility-NSD-OTA",
    "GNO-Mobility-NSD-SMS", "GNO-Mobility-vTO", "MNRC-SGSN-MME-Operations",
    "ATT-IT-MOBILITY-VSCP-OPS", "GNO-Mobility-SGSN-Implement", "GNO-Mobility-SGSN-Operations",
    "ATT-IT-MOBILITY-VMMSC-OPS", "GNO-Mobility-Policy-Operations", "ATT-IT-GNO-MOBILITY-VMOG",
    "GNO-Mobility-National-DRA", "GNO-Mobility-IP-Bearer-OAM-BF", "ATT-IT-SYSHOSTING-MOBNT-T3-LNX",
    "ATT-IT-SYSHOSTING-MOBNT-T3-SOL", "GNO-Mobility-NSD-SA", "GNO-Mobility-Value-Added-Svcs",
    "ATT-IT-GNO-MOBILITY-VMOBT", "ATT-IT-GNO-MOBILITY-POLICY", "GNO-Mobility-Application-SVC",
    "GNO-Mobility-NSD-MCPTT", "GNO-Mobility-NSD-DBA", "GNO-Mobility-NSD-Net-Sec-FW",
    "IPNRC-SCPS", "GNO-Mobility-MMS", "GNO-MOBILITY-T2-TOOLS",
    "ATT-IT-ITONS-DT-FIREWALL", "GNO-NRC-VOIP-APPS-vSFTSW", "GNO-NRC-VOIP-CLOUDBAND-APPS",
    "GNO-NRC-VOIP-USP-NETWORKING", "GNO-NRC-VOIP-vUSP-NETWORKING", "GNO-NRC-VOIP-USP-SERVER",
    "GNO-NRC-VOIP-vUSP-SERVER", "GNO-NRC-VOIP-IRVING", "GNO-NRC-VOIP-CLOUDBAND-AGILE",
    "GNO-NRC-VOIP-AMS-APPS", "GNO-Mobility-EPC-Lifecycle",
]

MSO_CATEGORY_OVERRIDE = "Mobility-External Partner"
