from transforms.api import transform_df, Input, Output
from myproject.utils.global_code import session, get_header, PARENT_FOLDER
from pyspark.sql import functions as F

import pyspark.sql.types as T


@transform_df(
    Output(f"{PARENT_FOLDER}/all_projects"),
    projects_to_groups=Input(f"{PARENT_FOLDER}/projects_to_groups"),
    config=Input("/Innovation Lab/Palantir Admins/Quantum/inputs/config"),
)
def all_projects(ctx, projects_to_groups, config):
    headers = get_header(config)

    df = projects_to_groups.groupBy(
        "project_rid",
        "project_name",
        "project_path",
        "project_type",
        "project_description",
        "project_stage",
        "ingestion_managers",
        "pipeline_type",
        "most_recent_activity_time",
        "most_recent_activity_type",
    ).agg(F.collect_set(F.col("group_rid")).alias("multipass_group_rids"))

    projects = df.collect()
    project_dict = dict(
        df.rdd.map(lambda x: (x["project_name"], x["project_rid"])).collect()
    )
    # references = projects_to_references()

    reference_rows = []

    for project in projects:
        project_rid = project["project_rid"]
        project_name = project["project_name"]

        references = []
        reference_paths = []

        url = (
            "https://paloma.palantirfoundry.com/compass/api/projects/imports/"
            + project["project_rid"]
        )
        body = {"pageSize": 50}
        resp = session.post(url, headers=headers, json=body)

        while resp.status_code == 200 and resp.json()["values"] != None:
            for ref in resp.json()["values"]:
                if "importedFileSystemResource" in ref and (
                    len(ref["importedFileSystemResource"]["path"].split("/")) > 2
                ):
                    ref_project = ref["importedFileSystemResource"]["path"].split("/")[
                        2
                    ]
                    reference_paths.append(ref["importedFileSystemResource"]["path"])
                    ref_project_rid = (
                        project_dict[ref_project]
                        if ref_project in project_dict
                        else None
                    )
                    if ref_project_rid is not None:
                        references.append(ref_project_rid)
            if resp.json()["nextPageToken"] == None:
                break
            body = {"pageSize": 50, "pageToken": resp.json()["nextPageToken"]}
            resp = session.post(url, headers=headers, json=body)
        references = list(dict.fromkeys(references))
        reference_rows.append([project_name, references, reference_paths])

    reference_schema = T.StructType([T.StructField(*col) for col in OUTPUT_COLUMNS])
    references = ctx.spark_session.createDataFrame(
        reference_rows, schema=reference_schema
    ).dropDuplicates(["project_name"])

    default_roles = projects_to_groups.filter(
        projects_to_groups["default_role"] != "NONE"
    )
    default_roles = default_roles.select("default_role", "project_rid").dropDuplicates()
    default_roles = default_roles.withColumn(
        "project_allowed_by_everyone",
        F.col("default_role").isin("EDIT", "OWN", "PLATFORM ADMIN"),
    )

    df = df.join(default_roles, "project_rid", how="left")

    # df = df.join(jobs_by_project, df["project_name"] == jobs_by_project["project"], how="left").drop("project")
    # df = df.withColumn("total_job_count", F.when(F.col("total_job_count").isNull(), 0).otherwise(F.col("total_job_count")))
    # df = df.withColumn("total_repo_count", F.when(F.col("total_repo_count").isNull(), 0).otherwise(F.col("total_repo_count")))
    df = df.withColumn("organization", F.lit("DEEP"))
    df = df.join(references, "project_name", how="left")
    return df


OUTPUT_COLUMNS = [
    ("project_name", T.StringType()),
    ("reference_project", T.ArrayType(T.StringType())),
    ("reference_datasets", T.ArrayType(T.StringType())),
]
