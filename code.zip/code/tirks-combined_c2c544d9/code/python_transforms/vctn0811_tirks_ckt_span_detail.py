from transforms.api import transform, Input, Output, incremental
from utility.column_clean import clean_columns, lowercase_columns, remove_prefix
from ecdw.data.utils import get_string_cols
from pyspark.sql.functions import col


@transform(
    out=Output(
        "/Innovation Lab/[Source] Teradata EDW - ACCESS_VIEWS/data/clean/vctn0811$tirks_ckt_span_detail"
    ),
    df=Input(
        "/Innovation Lab/[Source] Teradata EDW - ACCESS_VIEWS/data/raw/snowflake/ACCESS_VIEWS.VCTN0811$TIRKS_CKT_SPAN_DETAIL"
    ),
)
def my_compute_function(df, out):
    df = clean_columns(
        df.dataframe(),
        date_format=date_format,
        date_columns=string_to_date,
        datetime_format=datetime_format,
        datetime_columns=long_unixtime_to_timestamp,
        timestamp_from_string_format=string_unixtime_format,
        timestamp_from_string_columns=string_unixtime_to_timestamp,
        timestamp_format=long_unixtime_format,
        timestamp_columns=long_unixtime_to_timestamp,
        integer_columns=string_to_integer_columns,
        double_columns=string_to_double_columns,
        decimal_columns=string_to_decimal_columns,
        id_columns=numeric_to_string_columns,
        integer_from_num_columns=decimal_to_integer,
        strip_columns=get_string_cols(df.dataframe()),
    )
    # df = df.drop(*drop_columns)
    # df = remove_prefix(df, 'example_prefix')
    df = lowercase_columns(df)
    df = df.withColumn(
        "facility_sequence_nbr", col("facility_sequence_nbr").cast("short")
    )
    out.write_dataframe(df)


drop_columns = []

date_format = "yyyy-MM-dd"
string_to_date = []
datetime_format = "yyyy-MM-dd HH:mm:ss"
string_to_timestamp = []

string_unixtime_format = None
string_unixtime_to_timestamp = []
long_unixtime_format = None
long_unixtime_to_timestamp = []

string_to_integer_columns = []
string_to_double_columns = []
string_to_decimal_columns = []

numeric_to_string_columns = []
decimal_to_integer = []

strip_string_columns = []
