from transforms.api import transform, Input, Output,incremental,configure
from utility.column_clean import clean_columns, lowercase_columns, remove_prefix
from utility.incremental.update_insert import update_insert_core
from pyspark.sql import functions as F
from utility.incremental.timestamp_parsing import perform_timestamp_parsing


@configure(profile=["EXECUTOR_MEMORY_MEDIUM", "NUM_EXECUTORS_16"])
@incremental(semantic_version=9)
@transform(
   out=Output("/Innovation Lab/[Source] Oracle ESAR/data/clean/ticket_transfer"),
   updates=Input("ri.foundry.main.dataset.6f5eafa9-a4f7-4b93-833c-2d520ed6ad8f"),
  # backfill=Input("/Innovation Lab/[Source] Oracle ESAR/data/raw/Prod/snowflake/esaar_tmviews.ticket_transfer_snowflake_reload")
)
def my_compute_function(ctx, out, updates):
    #updates_df = updates.dataframe().unionByName(backfill.dataframe())
    updates_df = updates.dataframe()
    updates = clean_columns(
        updates_df,
        timestamp_columns=cast_to_timestamp_from_long_columns,
        integer_columns=cast_to_integer_columns,
        datetime_format=datetime_format,
    )

    updates_df = perform_timestamp_parsing(updates)
    for column in float_columns:
        updates_df = updates_df.withColumn(column, updates_df[column].cast("decimal").alias(column))
    for column in cast_to_integer_columns:
        updates_df = updates_df.withColumn(column, updates_df[column].cast("decimal").alias(column))
    keys = ["request_id"]
    updates_df = lowercase_columns(updates_df)
    update_insert_core(ctx, out, updates_df, primary_keys=keys, order_cols=["load_ts"])


date_format = 'yyyy-MM-dd'
datetime_format = 'yyyy-MM-dd HH:mm:ss'
float_columns = [
    "ITH_QUEUED_TO_ACTIVE",
    "ITH_TIME_IN_PREVIOUS_STATE"
]
cast_to_integer_columns = [
    "STATUS",
    "ACTIVITY_TYPE",
    "QUEUED_TIME",
    "WORK_TIME",
    "PREV_REPT_SVC_IMPACT_FLAG",
    "PREV_REPT_REQUEST_TYPE",
    "PREV_REPT_SVC_LINE_CD",
    "PREV_TROUBLE_REPT_CD",
    "PREV_SEVERITY",
    "PREV_SLA",
    "PREV_AUTO_CLOSEABLE_FLAG",
    "PREV_RESOL_SVC_IMPACT_FLAG",
    "PREV_NETWORK_CHRONIC",
    "PREV_TICKET_TYPE",
    "FORM_TYPE",
    "PREV_MOD_DATE",
    "PREV_TRB_CLEARED",
    "PREV_INBOUNDCALLCOUNT",
    "PREV_OUTBOUNDCALLCOUNT",
    'TESTAUTOINDICATOR',
    "PREV_NETWORK_TICKET_PRIORITY",
    "PREV_REPAIR_DUR",
    "PREV_RESTORE_DUR",
    "AUTOINDICATORTEST",
    "UPDATE_COUNT",
    "LOCK_COUNT"
    # "LOAD_ID"
]
cast_to_timestamp_from_long_columns = [
    "CREATE_DATE",
    "MODIFIED_DATE",
    "ACTIVITY_TIME",
    "CLIENT_CONFIRMED_RESTORAL_DATE",
#    "CLIENT_NOTIFIED_RESTORED",
#    "CLIENT_CONFIRMED_CLEARED",
    "PREV_NEXT_CHECK_TIME",
    "PREV_SERVICE_RESTORED_DATE",
#    "PREV_CLIENT_FIRST_NOTIFIED",
    "PREV_DATE",
    "PREV_TICKET_DUE_DATE",
    'PREV_ALARM_SUPP_START_TIME',
    'PREV_ALARM_SUPP_END_TIME',
#    "PREVMODDATE",
#    "PREVTRBCLEARED"
]
