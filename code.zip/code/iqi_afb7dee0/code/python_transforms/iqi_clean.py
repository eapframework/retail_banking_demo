from transforms.api import transform_df, Input, Output
from .utils import F, StringType

@transform_df(
    Output("/Innovation Lab/[ETL] IQI/logic/transforms-python/src/myproject/datasets/formatted_iqi"),
    iqi=Input("/Innovation Lab/[Source] Vertica IQI/data/clean/iqi_ecgi_mgrs100m_monthly_summary"),
    reference=Input("/Innovation Lab/[Source] Vertica IQI/data/clean/iqi_public.cgi_reference")
)
def my_compute_function(iqi, reference):
    '''
    Join reference dataset with iqi summary
    Only include record that have USID
    '''
    reference = reference.select(
        F.col('cgi').alias('ecgi_short'),
        "technology",
        "softsectorname",
        "useid"
        )
    df = iqi.join(reference, ['ecgi_short'], how='left')
    # cast usid key to string
    df = df.withColumn('usid', df['usid'].cast(StringType()))
    df = df.filter(F.col('usid').isNotNull())
    df = df.filter(F.col('yyyymm').isNotNull())
    return df
