import json
from typing import Set

import pandas as pd
import requests
from pyspark.sql.functions import lit, to_timestamp
from pyspark.sql.types import StringType, StructField, StructType, TimestampType
from transforms.api import Input, Output, transform

from myproject.utils.global_code import get_header

BASE_URL = "https://paloma.palantirfoundry.com"
GROUP_ID = "75482d1f-e4f3-4346-b49a-7b5d2ddbf433"
GROUP_API = f"/api/v2/admin/groups/{GROUP_ID}/groupMembers"
EXPIRATIONS_API = "/multipass/api/groups/expirations/members"


@transform(
    output=Output("ri.foundry.main.dataset.685acccc-04d8-4a6e-904e-50d99123a350", sever_permissions=True),
    config=Input("ri.foundry.main.dataset.b5cb343e-1109-4401-b3fb-5137c32cb781"),
)
def compute(ctx, config, output):
    session = requests.Session()
    header = get_header(config.dataframe())
    session.headers.update(header)

    def get_group_members():
        all_members = []
        page_token = None

        while True:
            params = {
                "transitive": "true",
                "pageSize": 1000,  # Adjust as needed
            }
            if page_token:
                params["pageToken"] = page_token

            response = session.get(f"{BASE_URL}{GROUP_API}", params=params)
            response.raise_for_status()  # Raise an exception for HTTP errors

            data = response.json()
            members = data.get("data", [])
            all_members.extend(members)

            page_token = data.get("nextPageToken")
            if not page_token:
                break

        return all_members

    def get_expirations_info(group_ids: Set[str]):
        payload = {"groupIds": list(group_ids)}

        response = session.put(
            f"{BASE_URL}{EXPIRATIONS_API}", headers={"Content-Type": "application/json"}, data=json.dumps(payload)
        )
        response.raise_for_status()

        return response.json()

    # Get group members
    members = get_group_members()

    # Process members
    processed_members = [
        {"principalType": member["principalType"], "principalId": member["principalId"]} for member in members
    ]

    # Convert the processed members to a DataFrame
    members_pdf = pd.DataFrame(processed_members)
    group_df = ctx.spark_session.createDataFrame(members_pdf)

    # Get expirations info
    group_ids = {GROUP_ID}
    expirations_info = get_expirations_info(group_ids)

    # Process expirations
    processed_expirations = []
    expirations_by_group = expirations_info.get("expirationsByGroupId", {})
    for group_id, group_data in expirations_by_group.items():
        expirations_by_principal = group_data.get("expirationsByPrincipalId", {})
        for principal_id, principal_data in expirations_by_principal.items():
            expiration_time = principal_data.get("expiration")
            processed_expirations.append({
                "groupId": group_id,
                "principalId": principal_id,
                "expirationTime": expiration_time,
            })

    # Create DataFrame for expirations
    expirations_schema = StructType([
        StructField("groupId", StringType(), True),
        StructField("principalId", StringType(), True),
        StructField("expirationTime", TimestampType(), True),
    ])

    if processed_expirations:
        expirations_pdf = pd.DataFrame(processed_expirations)
        expirations_df = ctx.spark_session.createDataFrame(expirations_pdf, schema=expirations_schema)

        # Convert expirationTime to timestamp
        expirations_df = expirations_df.withColumn("expirationTime", to_timestamp("expirationTime"))
    else:
        # Create an empty DataFrame with the schema if there are no expirations
        expirations_df = ctx.spark_session.createDataFrame([], schema=expirations_schema)

    # Join the expirations information with the group members DataFrame
    result_df = group_df.join(expirations_df, ["principalId"], "left")

    # Add queryTime to the result DataFrame
    current_time = ctx.spark_session.sql("SELECT CURRENT_TIMESTAMP()").collect()[0][0]
    result_df = result_df.withColumn("queryTime", lit(current_time))

    # Write the result
    output.write_dataframe(result_df)
