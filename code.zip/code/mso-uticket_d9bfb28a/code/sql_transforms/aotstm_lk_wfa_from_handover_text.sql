CREATE TABLE `/Innovation Lab/[ETL] Ticketing/logic/aotstm/aotstm_lk_wfa_from_handover_text` AS
    SELECT ticket
    ,regexp_extract(handover_text, '([W][A-Z][A-Z][A-Z][A-Z][0-9][0-9][0-9][0-9][0-9][0-9])', 1) as wfa_ticket
    FROM `/Innovation Lab/[ETL] Ticketing/data/clean/AOTSTM_TICKET_CLEAN`
    WHERE upper(handover_text) REGEXP '[W][A-Z][A-Z][A-Z][A-Z][0-9][0-9][0-9][0-9][0-9][0-9]'