import json

inv = json.load(open(r'c:\deep-otis\wave-1\code\mso-uticket_d9bfb28a\inventory.json'))

missing = [
    'ri.magritte..agent.ef60021df9511431d161a78f82ff07c24831681aa7f62a4b42b48ab22f29d195',
    'ri.magritte..agent.ba489249e0847135a18b1970578b0b51cc0debd082a74dd330601763e8e16167',
    'ri.magritte..agent.5fd879bb4672f6462b63e829a95fa32633a349a14b392b95b0fbf927f35c8d58',
    'ri.magritte..source.ba31895a-153c-488b-9723-3aab067bc41e',
    'ri.foundry.main.dataset.7a1285bd-ad45-424a-86ec-9c333d4a7872',
    'ri.foundry.main.dataset.3d9b732c-060b-4075-b3c1-b7681b117fd3',
    'ri.foundry.main.dataset.4b7051a7-8404-4145-b552-3e583304aa76',
    'ri.foundry.main.dataset.573ddb29-8fe9-4198-9b62-f35d9b543559',
    'ri.foundry.main.dataset.d59e3472-db57-47c2-ab46-176f23a26476',
    'ri.foundry.main.dataset.a306bde0-7a8f-45a4-a431-c5d85903b856',
    'ri.foundry.main.dataset.60bb71df-34a1-4b8c-b452-6511a4a28d45',
    'ri.foundry.main.dataset.fbcca57c-9463-47d7-875e-7110296181f8',
    'ri.foundry.main.dataset.365744b9-deef-4449-8e82-2e1be8690df1',
    'ri.foundry.main.dataset.b06d7a0a-727e-4e9b-9fc2-781b942fbcc0',
    'ri.foundry.main.dataset.df8c4c2b-cdcf-40c5-92e2-dd0eaaf08856',
    'ri.foundry.main.dataset.56407dc5-dbab-44f1-9236-5de89b7702ab',
    'ri.foundry.main.dataset.d46d7eda-cf1a-4326-b0cf-99d6f7533802',
    'ri.foundry.main.dataset.071983e5-e8b6-47ea-833e-a39b32284633',
    'ri.foundry.main.dataset.e8409bca-d1ed-4a40-9aa9-f8c95ca22ef3',
]

for rid in missing:
    for entry in inv:
        if entry.get('input_rid') == rid:
            rtype = entry.get('resource_type', '?')
            path = entry.get('path', 'no-path')
            name = entry.get('name', 'no-name')
            fld = entry.get('file', None)
            nid = entry.get('node_id', None)
            print(f"RID:  {rid}")
            print(f"  type: {rtype}")
            print(f"  name: {name}")
            print(f"  path: {path}")
            print(f"  file: {fld}")
            print(f"  node: {nid}")
            print()
            break
    else:
        print(f"RID:  {rid}")
        print(f"  NOT FOUND in inventory")
        print()
