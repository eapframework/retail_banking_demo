# from pyspark.sql import functions as F
from transforms.api import transform, Input, Output


@transform(
  output=Output("ri.foundry.main.dataset.00f4b171-d182-43c5-bf93-414312dd9393"),
  my_input=Input("ri.foundry.main.dataset.42820dd4-81ca-4efa-9bab-0350946208fc")
)
def my_compute_function(output, my_input):
    output.write_dataframe(my_input.dataframe().coalesce(1), output_format="csv", options={"sep":"|_|;|_|", "lineSep":"\u0177", "header": "true"})
