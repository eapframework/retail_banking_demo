"""
MSO uTicket — Load Excel test data into Delta tables
=====================================================
Catalog: 31184_cerebro_poc4x
Schema:  otis

PREREQUISITES:
  1. Upload the 7 Excel files from extracted_code/data_sources/ to a
     Unity Catalog Volume. Example:
       Workspace UI → Catalog → 31184_cerebro_poc4x → otis → Volumes
       Create volume "data_sources" → upload the .xlsx files

     Or via CLI:
       databricks fs cp data_sources/ dbfs:/Volumes/31184_cerebro_poc4x/otis/data_sources/ --recursive

  2. Run create_tables.sql first to create the empty tables.

  3. Run this notebook in Databricks (Python notebook, cluster with
     pandas + openpyxl available).

FILE → TABLE MAPPING:
  chg_change_snowflake.xlsx                                    → chg_change_snowflake                                        (5 rows)
  esaars_dbor_cm_rviews.acmr14_affected_cllis.xlsx             → esaars_dbor_cm_rviews_acmr14_affected_cllis                 (1000 rows)
  esaars_dbor_cm_rviews.acmr14_affected_techs_snowflake.xlsx   → esaars_dbor_cm_rviews_acmr14_affected_techs_snowflake       (1000 rows)
  esaars_dbor_cm_rviews.acmr23_mobility_equipment_info...xlsx  → esaars_dbor_cm_rviews_acmr23_mobility_equipment_info...     (1000 rows)
  esaars_dbor_cm_rviews.ap_detail_snowflake.xlsx               → esaars_dbor_cm_rviews_ap_detail_snowflake                   (1000 rows)
  esaars_dbor_cm_rviews.ap_signature.xlsx                      → esaars_dbor_cm_rviews_ap_signature                          (1000 rows)
  esaars_dbor_cm_rviews.chg_task_snowflake.xlsx                → esaars_dbor_cm_rviews_chg_task_snowflake                    (6 rows)
"""

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------
CATALOG = "31184_cerebro_poc4x"
SCHEMA = "otis"

# Path to the uploaded Excel files in a Unity Catalog Volume
VOLUME_PATH = f"/Volumes/{CATALOG}/{SCHEMA}/data_sources"

# Map: Excel filename → target table name
FILE_TABLE_MAP = {
    "chg_change_snowflake.xlsx":
        "chg_change_snowflake",
    "esaars_dbor_cm_rviews.acmr14_affected_cllis.xlsx":
        "esaars_dbor_cm_rviews_acmr14_affected_cllis",
    "esaars_dbor_cm_rviews.acmr14_affected_techs_snowflake.xlsx":
        "esaars_dbor_cm_rviews_acmr14_affected_techs_snowflake",
    "esaars_dbor_cm_rviews.acmr23_mobility_equipment_info_snowflake.xlsx":
        "esaars_dbor_cm_rviews_acmr23_mobility_equipment_info_snowflake",
    "esaars_dbor_cm_rviews.ap_detail_snowflake.xlsx":
        "esaars_dbor_cm_rviews_ap_detail_snowflake",
    "esaars_dbor_cm_rviews.ap_signature.xlsx":
        "esaars_dbor_cm_rviews_ap_signature",
    "esaars_dbor_cm_rviews.chg_task_snowflake.xlsx":
        "esaars_dbor_cm_rviews_chg_task_snowflake",
}

# ---------------------------------------------------------------------------
# Load each Excel file into the corresponding Delta table
# ---------------------------------------------------------------------------
import pandas as pd

spark.sql(f"USE CATALOG `{CATALOG}`")
spark.sql(f"USE SCHEMA `{SCHEMA}`")

for xlsx_file, table_name in FILE_TABLE_MAP.items():
    file_path = f"{VOLUME_PATH}/{xlsx_file}"
    full_table = f"`{CATALOG}`.`{SCHEMA}`.`{table_name}`"

    print(f"\n{'='*60}")
    print(f"Loading: {xlsx_file}")
    print(f"  Into:  {full_table}")

    # Step 1: Read Excel with pandas
    pdf = pd.read_excel(file_path, engine="openpyxl")
    print(f"  Rows:  {len(pdf)}")

    # Step 2: Convert to Spark DataFrame
    sdf = spark.createDataFrame(pdf)

    # Step 3: Write to Delta table (append mode; use overwrite for full refresh)
    sdf.write.mode("overwrite").saveAsTable(full_table)

    # Step 4: Verify
    count = spark.table(full_table).count()
    print(f"  Loaded: {count} rows ✓")

print(f"\n{'='*60}")
print("All tables loaded successfully.")
