from transforms.api import transform, Input, Output
from myproject.utils.global_code import PARENT_FOLDER

# Spark utils
from pyspark.sql import functions as F


@transform(
    project_to_parent_project_mapping=Output(
        "/Innovation Lab/Data Governance/workbook-output/api_code/project_to_parent_project_mapping",
        sever_permissions=True,
    ),
    all_platform_data_with_lineage=Input(
        "/Innovation Lab/Data Governance/workbook-output/api_code/all_platform_data_with_lineage"
    ),
    all_platform_data=Input(f"{PARENT_FOLDER}/all_platform_data"),
)
def project_to_parent_project_mapping(
    all_platform_data_with_lineage, all_platform_data, project_to_parent_project_mapping
):
    all_platform_data = all_platform_data.dataframe()
    df = all_platform_data_with_lineage.dataframe()
    df = df.select(
        "project_name", "dataset_name", "parents", "has_parents", "project_rid"
    )
    df = df.filter(df["has_parents"] == "true")
    df = df.withColumn("exploded_parents", F.explode(df["parents"]))
    df = df.join(
        all_platform_data.select(
            "dataset_rid",
            all_platform_data["project_name"].alias("ref_project_name"),
            all_platform_data["project_rid"].alias("ref_project_rid"),
        ),
        df["exploded_parents"] == all_platform_data["dataset_rid"],
        how="left",
    ).drop("dataset_rid")

    df = df.select(
        "project_name", "project_rid", "ref_project_name", "ref_project_rid"
    ).distinct()
    df = df.filter(~((df["project_rid"].isNull()) | (df["ref_project_rid"].isNull())))
    project_to_parent_project_mapping.write_dataframe(df)
