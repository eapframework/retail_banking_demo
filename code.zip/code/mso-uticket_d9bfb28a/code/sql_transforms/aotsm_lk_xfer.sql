CREATE TABLE `ri.foundry.main.dataset.942bc24d-baf0-4ad6-9bab-080fff0f00cf` AS
    SELECT ticket_number
    , field_changed
    , concat_ws(',', collect_list(CONCAT(COALESCE(previous_value,'BLANK'), '->', new_value))) as xfer
    , collect_list(previous_value) as xfer_from_a
    , collect_list(new_value) as xfer_to_a
    , count(*) total_xfers
    FROM `ri.foundry.main.dataset.edfda3bc-b10d-4c84-8f1c-cf918094c33b`
    WHERE field_changed IN ('Department','Assigned to Zone','Assigned to District', 'Assigned-to') AND previous_value IS NOT NULL
    GROUP BY ticket_number, field_changed
