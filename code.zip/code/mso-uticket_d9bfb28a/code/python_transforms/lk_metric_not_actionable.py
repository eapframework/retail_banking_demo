from transforms.api import transform_df, Input, Output
from pyspark.sql.functions import expr, col

@transform_df(
    Output("/Innovation Lab/[ETL] Ticketing/logic/aotsm/lk_metric_not_actionable"),
    tickets=Input("/Innovation Lab/[ETL] Ticketing/data/clean/AOTSM_ALL_TROUBLE_TICKET_CLEAN"),
    lookupValues=Input("/Innovation Lab/[ETL] Ticketing/data/lookup/lk_text_match - values")
)
def findNotActionable(tickets, lookupValues):
    # Filter to only non actionable matches
    lookupValues = lookupValues.filter(lookupValues["metric_not_actionable"] == 1)
    # Grab and lowercase the fields to search
    tickets=tickets.select("ticket_number"
    ,expr("lower(resolution) as field1")
    ,expr("lower(resolution_type) as field2")
    ,expr("lower(resolution_category) as field3"))

    # Iterate through lookupValues and find matches
    firstrow = "true"
    for row in lookupValues.rdd.collect():   # noqa
        # Look for matches for this search string iteration
        matches=tickets.filter((col("field1").contains(row["search_string"])) 
        | (col("field2").contains(row["search_string"])) 
        | (col("field3").contains(row["search_string"]))) 

        # Save this match
        if firstrow == "true":
            allMatches = matches
            firstrow = "false"
        else:
            allMatches = allMatches.union(matches)

    return allMatches.select('ticket_number').distinct()
