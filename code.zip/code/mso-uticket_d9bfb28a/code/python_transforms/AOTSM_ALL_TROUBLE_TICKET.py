from transforms.api import transform_df, Input, Output
from utility.column_clean import long_to_datetime
from pyspark.sql import functions as F
from pyspark.sql.functions import expr  # Required so we can do expressions within our field list to handle decoding.
#  Merge Ticket & Ticket Archive into a single view and only contain the relevant columns for reporting.
#  Join Merged Ticket Data to Location to pull in latitude, longitude, and other Location based info.



@transform_df(
    Output("ri.foundry.main.dataset.42b9fbd8-2b68-49aa-b17e-9d40d0c87f0a"),
    TICKET=Input("ri.foundry.main.dataset.159c7a8d-bd40-4d74-81f0-fa21462285ec"),
    TICKET_ARCHIVE=Input("ri.foundry.main.dataset.f004cf3c-edc9-45b8-8040-352df512adc9"),
    LOCATION=Input("ri.foundry.main.dataset.fb6c8db8-fe01-4228-80d8-255888409cb3"),
)
def Merge_And_Clean(TICKET, TICKET_ARCHIVE, LOCATION):
    Desired_Column_Subset = ("ticket_number"
, "ticket_status"
, "submitter_department"
, "submitter_district_sub_dept"
, "submitter_zone"
, "assigned_district_sub_dept"
, "assigned_zone"
, "assigned_to"
, "assigned_department"
, "call_origin"
,expr("CASE WHEN entry_type == 0 THEN  'Trouble Report'\
 WHEN entry_type == 1 THEN  'Action Report'\
 WHEN entry_type == 2 then 'NET Report'\
 ELSE 'Unexpected Value' END AS entry_type")
,expr("CASE WHEN severity == 0 THEN  'Blank'\
 WHEN severity == 1 THEN  'Unknown'\
 WHEN severity == 2 then 'Warning'\
 WHEN severity == 3 then 'Minor'\
 WHEN severity == 4 then 'Major'\
 WHEN severity == 5 then 'Critical'\
 WHEN severity == 6 then 'SIR 2'\
 WHEN severity == 7 then 'SIR 1'\
 WHEN severity == 8 then 'SIR 1E'\
 WHEN severity == 9 then 'SIR 3'\
 WHEN severity == 10 then 'SIR 4'\
 ELSE 'Unexpected Value' END AS severity")
 ,expr("CASE WHEN cust_affect == 0 THEN  'No Outage'\
 WHEN cust_affect == 1 THEN  'Full Outage'\
 WHEN cust_affect == 2 then 'Greater than 50 pct'\
 WHEN cust_affect == 3 then 'Less than or equal 50 pct'\
 ELSE 'Unexpected Value' END AS cust_affect")
 , "alarm_time"
 , "date_time_up"
 , "create_date"
 , "return_to_service"
 , "resolved_time"
 , "closed_time"
 , "notamcreatetime"
 , "modified_date"
, "eq_region"
, "eq_market_cluster"
, "eq_market"
, "problem_category"
, "logic_id"
, "trout_ticket_number"
, "closed_by"
, "resolution_category"
, "resolution_type"
, "resolution"
, "common_id"
, "parent_id"
, "problem_detail"
, "short_description"
, "equipment_type"
, "parent_trouble_report_id"
, "equipment_priority"
, "technology"
, "manual_lec_ticket_number"
, "telco_provider_name"
, "telcoticketno"
, "circuit_type"
, "location_common_name"
, "submitted_by"
, "repeat_ticket"
, "problem_subcategory"
, "server_name"
, "server_serial"
, "vendor_name"
, "system_vendor_company"
, "reported_by"
, "alarmindicator"
, "closed_by_department"
, "equipsubtype"
, "oss_vendor2"
, "external_ticket_number"
, "cell_plat_outage"
, "resolved_by"
, "equipment_id"
, "notam_number"
, "notam_required"
, "ops_district"
, "ops_zone"
, expr("usid3 as tkt_usid3")
, "location_id"
, "resolved_by_district"
, "closed_by_district"
, "assigned_region"
, "assigned_market"
, "ctn"
, "device_model"
, "device_manufacturer"
, "clarify_parent_ticket"
, "clar_customer_problem"
, "clarify_case_type"
, "clarify_workgroup"
, "clarify_user_id"
, "clarify_date_time"
, "customer_promise_date_time"
, "ticket_type"
, "lecticketno"
, "notam_closed"
, "notam_expire_time"
, "equipment_name"
)


    Desired_Location_Column_Subset = (expr("location_id as loc_location_id")
, expr("city as loc_city")
, expr("latitude_decimal as loc_latitude_decimal")
, expr("longitude_decimal as loc_longitude_decimal")
, expr("state as loc_state")
, expr("usid as loc_usid")
, expr("zip_code as loc_zip_zode")
, expr("status as loc_status")
, expr("fa_location_code as loc_fa_location_code")
)
    TICKET = TICKET.select(*Desired_Column_Subset)
    TICKET = (
        TICKET
        .withColumn("notam_expire_time", long_to_datetime(F.col("notam_expire_time"), 'seconds'))
    )
    TICKET_ARCHIVE = TICKET_ARCHIVE.select(*Desired_Column_Subset)
    # Fix clarify_date_time and customer_promise_date_time epoch to timestamp conversion
    TICKET_ARCHIVE = (
        TICKET_ARCHIVE
        .withColumn("clarify_date_time", long_to_datetime(F.col("clarify_date_time"), 'seconds'))
        .withColumn("customer_promise_date_time", long_to_datetime(F.col("customer_promise_date_time"), 'seconds'))
        .withColumn("notam_expire_time", long_to_datetime(F.col("notam_expire_time"), 'seconds'))
    )
    TICKET_CLEAN = TICKET.join(TICKET_ARCHIVE, ["ticket_number"], "leftanti")
    TICKET_ALL = TICKET_CLEAN.union(TICKET_ARCHIVE)
    LOCATION = LOCATION.select(*Desired_Location_Column_Subset)
    return (TICKET_ALL.join(LOCATION, TICKET_ALL.location_id == LOCATION.loc_location_id,how='leftouter'))