"""
MSO uTicket — SDP Pipeline (Silver Layer)
==========================================
Clean/curated transforms converted from Foundry Python transforms.

Table type decisions:
  - Simple cleans (no dedup): @dp.table() streaming — map-only operations work
    on streaming DataFrames (cast, alias, withColumn).
  - SCD1 dedup tables: BOTH options side-by-side:
    Option A (DEFAULT): dp.create_auto_cdc_flow() — streaming SCD1 merge
    Option B (COMMENTED): @dp.materialized_view() — full-refresh with dedup
  - SQL JOIN: @dp.materialized_view() — JOINs need batch or watermark config

SDK migration:
  - @dlt.table              → @dp.table() (streaming) or @dp.materialized_view() (batch)
  - @dlt.view               → @dp.temporary_view()
  - dlt.read("x")           → spark.read.table("x")
  - dlt.read_stream("x")    → spark.readStream.table("x")
  - dlt.apply_changes()     → dp.create_auto_cdc_flow()
"""

from pyspark import pipelines as dp
from pyspark.sql import functions as F
from utilities import (
    clean_columns, lowercase_columns, parse_epoch_millis_columns,
    perform_timestamp_parsing,
)


# ═══════════════════════════════════════════════════════════════════════════
# 1. chg_change (clean) — SCD1 on (change_id, seqno), order by modified_date
#    Foundry: @incremental(semantic_version=3) with process_update_insert_core
# ═══════════════════════════════════════════════════════════════════════════

# --- Column lists (shared by both options) ---

_CHG_CHANGE_TS_COLS = [
    "create_date", "modified_date", "planned_start_date", "planned_end_date",
    "auto_close_time", "requested_completion_date", "actual_end_date",
    "actual_start_date", "igems_ccb_accept_date", "igems_deadline_date",
    "old_igems_rom_time", "lead_days_start_date", "lead_days_end_date",
    "lead_start_date", "lead_end_date", "max_end_date", "max_start_date",
    "min_end_date", "min_start_date", "release_scope_closed_date", "rfs_date",
    "red_tech_team_review_date", "release_fit_test_end_date",
    "release_fit_test_start_date", "client_ebond_date",
    "scheduled_downtime_start_date", "scheduled_downtime_end_date",
]

_CHG_CHANGE_DECIMAL_COLS = [
    "planned_duration__in_hours", "actual_duration__in_hours",
    "igems_total_time_worked", "igems_rom_time", "ztemptotaltimetask",
    "ztmpbackoutduration", "rescheduled_count", "seqno", "status",
    "request_urgency", "closure_code", "pending", "scope",
    "ztmpsubmitassociation", "escalated", "auto_close_days",
    "request_manager_to_reassign", "ztmpactiononsubmit", "confirm_resolution",
    "ztempnooftasks", "approval_status", "number_of_tasks", "priority",
    "source", "hotlist", "risk", "impact", "sequence",
    "zchangerelationshipkeyint", "zdependencynotification",
    "zotherchangessameorder", "zsubmittingdependent", "approval_required",
    "error_in_approval_process", "usersbylocf", "usersbyassetf",
    "target_level_mgtchain", "zlevelmgtchain", "business_risk",
    "technical_risk", "wap_type", "emergency", "cboenforcechgdependency",
    "cboenforcetskdependency", "palm_status", "ztmpuseescbushrs",
    "closure_impact", "reason", "total_components", "total_unsuccesful",
    "total_customer_impact", "ztempplanneddateduration", "zcc_excel_row",
    "zcc_excel_column", "zcc_excelrowcount", "ztempstatus",
    "ztempapprovalstatus", "previous_status", "previous_approval_status",
    "rejectcount", "approval_list_count", "approval_row_count",
    "zpreappcount", "zappcount", "ztemppreviousnumber",
    "ztemptotalapprovers", "asset_type", "igems_rom_costd", "in_window_",
    "visible_to_customer", "cbus_notif_fail_count", "reuse_integer_field1",
    "internalcircuittaskcount", "total_circuits",
    "total_qualifying_circuits", "total_ckt__tasks_created",
    "total_ckt_task_create_failures", "days", "hours", "minutes",
    "ztmprowcount", "total_total_ckt__tasks_created",
    "total_tasks_waiting_approval", "total_tasks_still_open",
    "verification_date_time", "ztmpdays", "ztmphours", "ztmpmin",
    "ztmpgmapprovaldate", "reuse_drop_down1", "allow_approval_comments",
    "details_2__tab_available", "max_critical_step_duration",
    "tmpmax_critical_step_duration", "re_approve_on_field_change",
    "sentinel_folder_created", "wms_ticket_created",
    "attachment_add_delete_forces_r", "ztmpbmpexists",
    "ztmpaffectedassetadddeleteflag", "affected_cllis_required",
    "affected_technologies_required", "auto_approve",
    "backout_summary_required", "checklistrequired", "cn_type_ticket",
    "components_tab", "cust_impact_description_requir",
    "customersfacriskrequired", "emergency_threshold",
    "enable_timed_notifications", "enable_timed_notificationsold",
    "force_conflict", "impact_required", "onsite_contact_info_required",
    "pci_ticket", "removal_required", "require_conflict_id_",
    "smop_details_tab_enabled", "step_specifics_required",
    "technical_risk_flex_option", "tmpmopdefaults", "tmpsteptblcnt",
    "work_type_required", "zstatelength", "ztmpreapprovalstatuscount",
    "in_scope_of_crp", "description_not_uct_test", "duration",
    "by_clli_metro_filter", "emergency_variable", "var_non_disruptive",
    "var_fcc_yes", "var_emergency_exceptions", "var_service_affected_911",
    "var_change_id_format_filter", "var_category_format_filter",
    "var_pa_right_format_filter", "var_sa_right_format_filter",
    "var_business_risk_format_filter", "end_date", "start_date",
]

_CHG_CHANGE_STRING_COLS = [
    "nrm_72_hours_advance", "maintenance_window_nrm", "maintenance_window_ip",
    "lab_tested_nrm", "lab_tested_ip", "ip_72_hours_advance",
]


def _apply_chg_change_cleaning(df):
    """Shared cleaning logic for chg_change — used by both Option A and B."""
    # Step 1: Lowercase all columns
    df = df.select([F.col(c).alias(c.lower()) for c in df.columns])

    # Step 2: Parse epoch-millis timestamps
    df = clean_columns(df, timestamp_columns=_CHG_CHANGE_TS_COLS, datetime_format="yyyy-MM-dd HH:mm:ss")
    df = perform_timestamp_parsing(df)

    # Step 3: Cast decimal columns
    for c in _CHG_CHANGE_DECIMAL_COLS:
        if c in df.columns:
            df = df.withColumn(c, F.col(c).cast("decimal(38,10)"))

    # Step 4: Cast string columns
    for c in _CHG_CHANGE_STRING_COLS:
        if c in df.columns:
            df = df.withColumn(c, F.col(c).cast("string"))

    # Step 5: Special backout timestamp handling
    if "backout_start" in df.columns:
        df = df.withColumn("backout_start", F.from_unixtime(F.col("backout_start") / 1000).cast("timestamp"))
    if "backout_end" in df.columns:
        df = df.withColumn("backout_end", F.from_unixtime(F.col("backout_end") / 1000).cast("timestamp"))

    return df


# ┌───────────────────────────────────────────────────────────────────────┐
# │ Option A (DEFAULT): Streaming SCD1 via dp.create_auto_cdc_flow()     │
# │ Processes only new/changed rows incrementally.                        │
# └───────────────────────────────────────────────────────────────────────┘

@dp.temporary_view()
def _chg_change_cleaned():
    """Staging view: apply all cleaning transforms to raw chg_change stream."""
    raw = spark.readStream.table("raw_chg_change_snowflake")
    return _apply_chg_change_cleaning(raw)


dp.create_streaming_table(
    name="clean_chg_change",
    comment="Cleaned CHG_CHANGE. Streaming SCD1 on (change_id, seqno) ordered by modified_date.",
    table_properties={"quality": "silver", "pipelines.autoOptimize.managed": "true"},
)

dp.create_auto_cdc_flow(
    target="clean_chg_change",
    source="_chg_change_cleaned",
    keys=["change_id", "seqno"],
    sequence_by="modified_date",
    stored_as_scd_type=1,
)


# ┌───────────────────────────────────────────────────────────────────────┐
# │ Option B (COMMENTED): Materialized view with full-refresh dedup       │
# │ Uncomment this and comment out Option A to use batch-mode instead.    │
# └───────────────────────────────────────────────────────────────────────┘

# @dp.materialized_view(
#     name="clean_chg_change",
#     comment="Cleaned CHG_CHANGE. Full-refresh SCD1 dedup on (change_id, seqno).",
#     table_properties={"quality": "silver", "pipelines.autoOptimize.managed": "true"},
# )
# def clean_chg_change():
#     raw = spark.read.table("raw_chg_change_snowflake")
#     df = _apply_chg_change_cleaning(raw)
#     # SCD1 dedup — keep latest row per (change_id, seqno)
#     from pyspark.sql import Window
#     w = Window.partitionBy("change_id", "seqno").orderBy(F.col("modified_date").desc())
#     df = df.withColumn("__rn__", F.row_number().over(w)).filter("__rn__ = 1").drop("__rn__")
#     return df


# ═══════════════════════════════════════════════════════════════════════════
# 2. chg_task (clean) — Simple streaming clean (no dedup in original)
#    Foundry: batch @transform, no @incremental
# ═══════════════════════════════════════════════════════════════════════════

_CHG_TASK_DECIMAL_COLS = [
    "seqno", "status", "request_urgency", "closure_code", "pending", "scope",
    "ztmpsubmitassociation", "request_supervisor_to_reassign", "ztempprevseqnum",
    "ztmpconflictsfound", "first_in_line", "ztmpbusinesshrsselection",
    "planned_duration", "actual_duration", "zclosedthistransaction",
    "zscheduledthistransaction", "zwipthistransaction", "zcanceledthistransaction",
    "ztmpreassignment", "priority", "hotlist", "sequence",
    "zdependencynotification", "ztmpothertaskssameorde", "cboenforcetskdependency",
    "work_order", "webserviceorder", "ztempnooftasks", "escalated",
    "chg_appr_status", "ztempstatus", "previous_status", "ztempplannedend",
    "ztemptotaltime", "ztempdifftime", "tasksequence", "previoustasksequence",
    "visible_to_customer",
]


@dp.table(
    name="clean_chg_task",
    comment="Cleaned CHG_TASK. Streaming append. 190 columns lowercased, many cast to decimal.",
    table_properties={"quality": "silver"},
)
def clean_chg_task():
    """Converted from: chg_task.py. Foundry RID: d59e3472."""
    raw = spark.readStream.table("raw_chg_task_snowflake")
    df = raw.select([F.col(c).alias(c.lower()) for c in raw.columns])
    df = perform_timestamp_parsing(df)
    for c in _CHG_TASK_DECIMAL_COLS:
        if c in df.columns:
            df = df.withColumn(c, F.col(c).cast("decimal(38,10)"))
    return df


# ═══════════════════════════════════════════════════════════════════════════
# 3. acmr14_affected_cllis (clean) — Simple streaming clean
# ═══════════════════════════════════════════════════════════════════════════

@dp.table(
    name="clean_acmr14_affected_cllis",
    comment="Cleaned ACMR14 Affected CLLIs. STATUS cast to integer, timestamps parsed.",
    table_properties={"quality": "silver"},
)
def clean_acmr14_affected_cllis():
    """Converted from: acmr14_affected_cllis.py. Foundry RID: 365744b9."""
    raw = spark.readStream.table("raw_acmr14_affected_cllis")
    df = clean_columns(
        raw,
        timestamp_columns=["CREATE_DATE", "MODIFIED_DATE"],
        integer_columns=["STATUS"],
        datetime_format="yyyy-MM-dd HH:mm:ss",
    )
    df = perform_timestamp_parsing(df)
    df = lowercase_columns(df)
    return df


# ═══════════════════════════════════════════════════════════════════════════
# 4. acmr14_affected_techs (clean) — Simple streaming clean
# ═══════════════════════════════════════════════════════════════════════════

@dp.table(
    name="clean_acmr14_affected_techs",
    comment="Cleaned ACMR14 Affected Technologies. STATUS, USED_FOR_CHG_TEMPLATE → integer.",
    table_properties={"quality": "silver"},
)
def clean_acmr14_affected_techs():
    """Converted from: acmr14_affected_techs.py. Foundry RID: 071983e5."""
    raw = spark.readStream.table("raw_acmr14_affected_techs_snowflake")
    df = clean_columns(
        raw,
        timestamp_columns=["CREATE_DATE", "MODIFIED_DATE"],
        integer_columns=["STATUS", "USED_FOR_CHG_TEMPLATE"],
        datetime_format="yyyy-MM-dd HH:mm:ss",
    )
    df = perform_timestamp_parsing(df)
    df = lowercase_columns(df)
    return df


# ═══════════════════════════════════════════════════════════════════════════
# 5. acmr23_mobility_equipment_info (clean) — SCD1 on (med_record_id)
#    Foundry: @incremental(semantic_version=5) with SCD1 upsert
# ═══════════════════════════════════════════════════════════════════════════

def _apply_acmr23_cleaning(df):
    """Shared cleaning logic for acmr23 — used by both Option A and B."""
    df = clean_columns(
        df,
        timestamp_columns=["CREATE_DATE", "MODIFIED_DATE", "PLANNED_START_DATE", "PLANNED_END_DATE"],
        datetime_format="yyyy-MM-dd HH:mm:ss",
    )
    df = perform_timestamp_parsing(df)
    df = lowercase_columns(df)
    return df


# ┌───────────────────────────────────────────────────────────────────────┐
# │ Option A (DEFAULT): Streaming SCD1 via dp.create_auto_cdc_flow()     │
# └───────────────────────────────────────────────────────────────────────┘

@dp.temporary_view()
def _acmr23_cleaned():
    """Staging view: apply cleaning transforms to raw acmr23 stream."""
    raw = spark.readStream.table("raw_acmr23_mobility_equipment_info_snowflake")
    return _apply_acmr23_cleaning(raw)


dp.create_streaming_table(
    name="clean_acmr23_mobility_equipment_info",
    comment="Cleaned ACMR23 Mobility Equipment. Streaming SCD1 on med_record_id.",
    table_properties={"quality": "silver"},
)

dp.create_auto_cdc_flow(
    target="clean_acmr23_mobility_equipment_info",
    source="_acmr23_cleaned",
    keys=["med_record_id"],
    sequence_by="modified_date",
    stored_as_scd_type=1,
)


# ┌───────────────────────────────────────────────────────────────────────┐
# │ Option B (COMMENTED): Materialized view with full-refresh dedup       │
# └───────────────────────────────────────────────────────────────────────┘

# @dp.materialized_view(
#     name="clean_acmr23_mobility_equipment_info",
#     comment="Cleaned ACMR23. Full-refresh SCD1 dedup on med_record_id.",
#     table_properties={"quality": "silver"},
# )
# def clean_acmr23_mobility_equipment_info():
#     raw = spark.read.table("raw_acmr23_mobility_equipment_info_snowflake")
#     df = _apply_acmr23_cleaning(raw)
#     from pyspark.sql import Window
#     w = Window.partitionBy("med_record_id").orderBy(F.col("modified_date").desc())
#     df = df.withColumn("__rn__", F.row_number().over(w)).filter("__rn__ = 1").drop("__rn__")
#     return df


# ═══════════════════════════════════════════════════════════════════════════
# 6. ap_signature (clean) — Simple streaming clean
# ═══════════════════════════════════════════════════════════════════════════

_AP_SIG_INT_COLS = [
    "SEQNO", "APPROVAL_STATUS", "SIGNATURE_METHOD", "INDEPENDENT",
    "IF_MULTIPLE_APPROVERS", "NUMBER_OF_GLOBAL_NOTIFICATIONS",
    "NUMBER_OF_STATE_NOTIFICATIONS", "LEVEL_SIG", "PREVIOUSSIGNATURENUMBER",
    "NEXTSIGNATURENUMBER", "XREFSIGNATUREID", "COMPLETED", "ORDER_X",
    "REACHED_DONE", "APPROVAL_LEVEL", "EXEMPT_FROM_REAPPROVAL",
]
_AP_SIG_FLOAT_COLS = [
    "CURRENT_APPROVAL_LEVEL", "CURRENT_APPROVAL_LEVEL_COUNT", "LAST_APP_CR_COUNT",
]
_AP_SIG_TS_COLS = [
    "CREATE_DATE_SIG", "MODIFIED_DATE_SIG", "NEXT_ACTION_ESCALATION_TIME",
    "NEXT_GLOBAL_ESCALATION_TIME", "NEXT_STATE_ESCALATION_TIME", "MODIFIED",
]


@dp.table(
    name="clean_ap_signature",
    comment="Cleaned AP_SIGNATURE. Integer + float casts, 6 timestamp columns.",
    table_properties={"quality": "silver"},
)
def clean_ap_signature():
    """Converted from: ars_dbor_cm_r1_ap_signature.py. Foundry RID: 60bb71df."""
    raw = spark.readStream.table("raw_ap_signature")
    df = clean_columns(
        raw,
        timestamp_columns=_AP_SIG_TS_COLS,
        integer_columns=_AP_SIG_INT_COLS,
        datetime_format="yyyy-MM-dd HH:mm:ss",
    )
    df = perform_timestamp_parsing(df)
    for c in _AP_SIG_INT_COLS:
        if c in df.columns:
            df = df.withColumn(c, F.col(c).cast("integer"))
    for c in _AP_SIG_FLOAT_COLS:
        if c in df.columns:
            df = df.withColumn(c, F.col(c).cast("float"))
    df = lowercase_columns(df)
    return df


# ═══════════════════════════════════════════════════════════════════════════
# 7. ap_detail (clean) — Simple streaming clean
# ═══════════════════════════════════════════════════════════════════════════

_AP_DTL_INT_COLS = [
    "SEQNO", "STATUS_DTL", "PRIORITY", "LEVEL_X", "APPROVAL_METHOD",
    "INTEGER_FIELD_1", "INTEGER_FIELD_2", "STATISTICAL_OVERRIDE", "ORDER_X",
]
_AP_DTL_FLOAT_COLS = [
    "REAL_FIELD_1", "REAL_FIELD_2", "DECIMAL_FIELD_1", "DECIMAL_FIELD_2",
]
_AP_DTL_TS_COLS = ["CREATE_DATE_DTL", "MODIFIED_DATE_DTL"]


@dp.table(
    name="clean_ap_detail",
    comment="Cleaned AP_DETAIL. Integer + decimal casts, 2 timestamp columns.",
    table_properties={"quality": "silver"},
)
def clean_ap_detail():
    """Converted from: ars_dbor_cm_r1_ap_detail.py. Foundry RID: fbcca57c."""
    raw = spark.readStream.table("raw_ap_detail_snowflake")
    df = clean_columns(
        raw,
        timestamp_columns=_AP_DTL_TS_COLS,
        integer_columns=_AP_DTL_INT_COLS,
        datetime_format="yyyy-MM-dd HH:mm:ss",
    )
    df = perform_timestamp_parsing(df)
    for c in _AP_DTL_INT_COLS:
        if c in df.columns:
            df = df.withColumn(c, F.col(c).cast("decimal(38,10)"))
    for c in _AP_DTL_FLOAT_COLS:
        if c in df.columns:
            df = df.withColumn(c, F.col(c).cast("decimal(38,10)"))
    df = lowercase_columns(df)
    return df


# ═══════════════════════════════════════════════════════════════════════════
# 8. ap_signature_enriched (SQL JOIN) — Materialized View
#    Joins clean_ap_signature + clean_ap_detail to resolve request (change_id).
#    Uses @dp.materialized_view() because JOINs across two streaming tables
#    require watermark configuration; batch MV is simpler and correct.
# ═══════════════════════════════════════════════════════════════════════════

@dp.materialized_view(
    name="silver_ap_signature_enriched",
    comment="AP_SIGNATURE joined with AP_DETAIL to resolve request (change_id). From ap_signature.sql.",
    table_properties={"quality": "silver"},
)
def silver_ap_signature_enriched():
    """
    Converted from: ap_signature.sql. Foundry RID: a306bde0.
    SELECT signature_id, alternate_signature, approval_id, approval_status,
           approver_signature, approvers, modified_date_sig, role, request
    FROM clean_ap_signature LEFT JOIN clean_ap_detail ON approval_id
    WHERE request IS NOT NULL
    """
    ap_sig = spark.read.table("clean_ap_signature")
    ap_dtl = spark.read.table("clean_ap_detail").select("request", "approval_id")

    return (
        ap_sig.alias("AP_SIGNATURE")
        .join(
            ap_dtl.alias("AP_DETAIL"),
            F.col("AP_SIGNATURE.approval_id") == F.col("AP_DETAIL.approval_id"),
            "left",
        )
        .where(F.col("AP_DETAIL.request").isNotNull())
        .select(
            F.col("AP_SIGNATURE.signature_id"),
            F.col("AP_SIGNATURE.alternate_signature"),
            F.col("AP_SIGNATURE.approval_id"),
            F.col("AP_SIGNATURE.approval_status"),
            F.col("AP_SIGNATURE.approver_signature"),
            F.col("AP_SIGNATURE.approvers"),
            F.col("AP_SIGNATURE.modified_date_sig"),
            F.col("AP_SIGNATURE.role"),
            F.col("AP_DETAIL.request"),
        )
    )
