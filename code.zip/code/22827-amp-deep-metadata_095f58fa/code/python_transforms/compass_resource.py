from transforms.api import transform, Input, Output, configure, incremental
from quantum_api_ingest.foundry.compass import CompassClient
from quantum_api_ingest.foundry.get_config import get_config
from pyspark.sql.types import ArrayType, BooleanType, MapType, StringType, StructField, StructType
from pyspark.sql import types as T
from typing import List, Dict
import logging

log = logging.getLogger(__name__)


def parse_marking(api_marking):
    return {
        "category_id": api_marking["categoryId"],
        "category_name": api_marking["categoryName"],
        "category_type": api_marking["categoryType"],
        "is_directly_applied": api_marking["isDirectlyApplied"],
        "is_organization": api_marking["isOrganization"],
        "marking_id": api_marking["markingId"],
        "marking_name": api_marking["markingName"],
    }


def parse_resource(resource):
    # What information about each resource we want to store in compass_resource
    return {
        "rid": resource["rid"],
        "name": resource["name"],
        "created_by_user": resource["created"]["userId"] if resource["created"] else None,
        "created_time": resource["created"]["time"] if resource["created"] else None,
        "last_modified_by_user": resource["modified"]["userId"] if resource["modified"] else None,
        "last_modified_time": resource["modified"]["time"] if resource["modified"] else None,
        "in_trash": resource["inTrash"] if resource["inTrash"] else False,
    }


def get_markings_of_resource(resource):
    # Creates a links for each marking this resource has
    marking_links = []
    if resource["defaultBranchWithMarkings"] and resource["defaultBranchWithMarkings"]["markings"]:
        for marking in resource["defaultBranchWithMarkings"]["markings"]:
            marking_links.append([resource["rid"], marking["markingId"]])
    return marking_links


def parse_project(project):
    # What information about each project we want to store in compass_project
    return {
        "rid": str(project["resource"]["rid"]),
        "name": str(project["resource"]["name"]),
        "path": str(project["resource"]["path"]),
        "description": project["resource"]["description"],
        "long_description": project["resource"]["longDescription"],
        "created_by_user_id": project["resource"]["created"]["userId"]
        if project["resource"]["created"] is not None
        else None,
        "created_time": project["resource"]["created"]["time"] if project["resource"]["created"] is not None else None,
        "modified_by_user_id": project["resource"]["modified"]["userId"]
        if project["resource"]["modified"] is not None
        else None,
        "modified_time": project["resource"]["modified"]["time"]
        if project["resource"]["modified"] is not None
        else None,
        "markings": [parse_marking(api_marking) for api_marking in project["resource"]["markings"]],
        "named_tags": project["resource"]["namedTags"],
        "is_private": project["isPrivate"],
        "propagate_permissions": project["propagatePermissions"],
        "role_grants": project["roleGrants"],
        # 'project_role_grants': project["roleGrants"],
    }


@incremental(snapshot_inputs=["config"], semantic_version=2)
@configure(
    profile=["NUM_EXECUTORS_32", "DRIVER_MEMORY_EXTRA_EXTRA_LARGE", "RPC_MESSAGE_MAX_SIZE_MAX", "EXECUTOR_MEMORY_LARGE"]
)
@transform(
    compass_resource=Output("ri.foundry.main.dataset.abafe87f-53af-4252-804c-9bbd24e010fa", sever_permissions=True),
    resource_markings=Output("ri.foundry.main.dataset.eea05946-fec5-4830-a631-ef72ca5365f5", sever_permissions=True),
    compass_project=Output("ri.foundry.main.dataset.5ace7ef7-b48d-446c-991b-dde1a60d423a", sever_permissions=True),
    compass_api_retries=Output("ri.foundry.main.dataset.1688fac2-e9d1-4766-9b4d-868e2e56c0ee", sever_permissions=True),
    config=Input("ri.foundry.main.dataset.b5cb343e-1109-4401-b3fb-5137c32cb781"),
)
def raw_compass_resource(ctx, compass_resource, resource_markings, compass_project, compass_api_retries, config):
    # NOTE: This is an incremental transform solely because we are writing to compass_api_retries incrementally.
    # Everything else in this transform works as a snapshot.
    compass = CompassClient(get_config(config))

    # Create the compass_resource dataset and the resource_markings dataset using
    # memory-efficient, throttling-aware iteration and batched lookups.

    # Define the schema for the resource_markings dataset
    resources_markings_schema = StructType(
        [
            StructField("resource_rid", StringType(), False),
            StructField("marking_id", StringType(), False),
        ]
    )

    # Define schema for resources to allow creating empty DataFrames safely
    resource_schema = StructType(
        [
            StructField("rid", StringType(), True),
            StructField("name", StringType(), True),
            StructField("created_by_user", StringType(), True),
            StructField("created_time", StringType(), True),
            StructField("last_modified_by_user", StringType(), True),
            StructField("last_modified_time", StringType(), True),
            StructField("in_trash", BooleanType(), True),
            StructField("path", StringType(), True),
        ]
    )

    # Buffers and DataFrame collectors to reduce driver memory footprint
    resource_rows_buffer: List[Dict] = []
    marking_rows_buffer: List[List[str]] = []
    resource_dfs: List = []
    marking_dfs: List = []

    # Limit the number of intermediate DataFrames kept to control driver memory/lineage
    MAX_INTERMEDIATE_FRAMES = 8

    def _compact_frames(dfs: List):
        if len(dfs) <= 1:
            return dfs
        head = dfs[0]
        for df in dfs[1:]:
            head = head.unionByName(df)
        return [head]

    # Working batch for path lookups
    current_batch_resources: List[Dict] = []
    current_batch_rids: List[str] = []

    # Tuning knobs
    page_size = 500
    path_lookup_batch = 2000
    # Keep buffers modest to avoid driver OOM when converting Python -> Spark
    flush_threshold = 10_000

    # Iterate pages without recursion, fetch paths for small batches, and flush to Spark periodically
    for api_resource in compass.iter_all_resources(
        page_size=page_size,
        decorations=["defaultBranchWithMarkings", "inTrash"],
        page_sleep=0.0,
    ):
        # Collect markings
        marking_rows_buffer.extend(get_markings_of_resource(api_resource))

        # Stage resource sans path for later augmentation
        res = parse_resource(api_resource)
        current_batch_resources.append(res)
        current_batch_rids.append(res["rid"])

        # If batch is ready, fetch paths and move into main buffer
        if len(current_batch_resources) >= path_lookup_batch:
            paths_map = compass.get_paths_batched(
                current_batch_rids,
                batch_size=1000,
                max_workers=4,
                sleep_between_batches=0.05,
            )
            for r in current_batch_resources:
                r["path"] = paths_map.get(r["rid"])
            resource_rows_buffer.extend(current_batch_resources)
            current_batch_resources, current_batch_rids = [], []

        # If buffers are large, flush into Spark DataFrames to free Python memory
        if len(resource_rows_buffer) >= flush_threshold:
            resource_dfs.append(ctx.spark_session.createDataFrame(resource_rows_buffer, schema=resource_schema))
            resource_rows_buffer = []
            if len(resource_dfs) >= MAX_INTERMEDIATE_FRAMES:
                resource_dfs = _compact_frames(resource_dfs)
        if len(marking_rows_buffer) >= flush_threshold:
            marking_dfs.append(ctx.spark_session.createDataFrame(marking_rows_buffer, resources_markings_schema))
            marking_rows_buffer = []
            if len(marking_dfs) >= MAX_INTERMEDIATE_FRAMES:
                marking_dfs = _compact_frames(marking_dfs)

    # Finalize any remaining path lookups after iteration
    if current_batch_resources:
        paths_map = compass.get_paths_batched(
            current_batch_rids,
            batch_size=1000,
            max_workers=4,
            sleep_between_batches=0.05,
        )
        for r in current_batch_resources:
            r["path"] = paths_map.get(r["rid"])
        resource_rows_buffer.extend(current_batch_resources)

    # Convert any remaining buffers to DataFrames
    if resource_rows_buffer:
        resource_dfs.append(ctx.spark_session.createDataFrame(resource_rows_buffer, schema=resource_schema))
        if len(resource_dfs) >= MAX_INTERMEDIATE_FRAMES:
            resource_dfs = _compact_frames(resource_dfs)
    if marking_rows_buffer:
        marking_dfs.append(ctx.spark_session.createDataFrame(marking_rows_buffer, resources_markings_schema))
        if len(marking_dfs) >= MAX_INTERMEDIATE_FRAMES:
            marking_dfs = _compact_frames(marking_dfs)

    # Union partitioned DataFrames and write outputs (replace mode as before)
    def _union_all_with_schema(dfs, schema):
        if not dfs:
            return ctx.spark_session.createDataFrame([], schema=schema)
        result = dfs[0]
        for df in dfs[1:]:
            result = result.unionByName(df)
        # Ensure final schema ordering/types
        return ctx.spark_session.createDataFrame(result.rdd, schema=schema)

    resource_markings.set_mode("replace")
    resource_markings.write_dataframe(_union_all_with_schema(marking_dfs, resources_markings_schema))

    compass_resource.set_mode("replace")
    compass_resource.write_dataframe(_union_all_with_schema(resource_dfs, resource_schema))

    # Create the project_output dataset

    all_project_rids: List[str] = []
    for namespace_rid in compass.get_all_namespaces():
        all_project_rids.extend(compass.get_project_rids_for_namespace(namespace_rid))
    markings_type = ArrayType(
        StructType(
            [
                StructField("category_id", StringType(), True),
                StructField("category_name", StringType(), True),
                StructField("category_type", StringType(), True),
                StructField("is_directly_applied", BooleanType(), True),
                StructField("is_organization", BooleanType(), True),
                StructField("marking_id", StringType(), True),
                StructField("marking_name", StringType(), True),
            ]
        ),
        True,
    )
    named_tags_type = ArrayType(
        StructType([StructField("rid", StringType(), True), StructField("name", StringType(), True)]), True
    )
    role_grants_type = MapType(
        StringType(),
        ArrayType(StructType([StructField("id", StringType(), True), StructField("type", StringType(), True)])),
    )
    project_schema = StructType(
        [
            StructField("rid", StringType(), True),
            StructField("name", StringType(), True),
            StructField("path", StringType(), True),
            StructField("description", StringType(), True),
            StructField("long_description", StringType(), True),
            StructField("created_by_user_id", StringType(), True),
            StructField("created_time", StringType(), True),
            StructField("modified_by_user_id", StringType(), True),
            StructField("modified_time", StringType(), True),
            StructField("markings", markings_type, True),
            StructField("named_tags", named_tags_type, True),
            StructField("is_private", BooleanType(), True),
            StructField("propagate_permissions", BooleanType(), True),
            StructField("role_grants", role_grants_type, True),
        ]
    )

    project_rows_buffer: List[Dict] = []
    project_dfs: List = []

    def _chunks(lst: List[str], n: int):
        for i in range(0, len(lst), n):
            yield lst[i : i + n]

    # Process projects in moderately sized groups; internal client batching handles retries & parallelism
    for rid_group in _chunks(all_project_rids, 2000):
        projects_map = compass.get_projects_by_rid_batched(
            rid_group, batch_size=250, max_workers=4, sleep_between_batches=0.05
        )
        for proj in projects_map.values():
            project_rows_buffer.append(parse_project(proj))
        if len(project_rows_buffer) >= flush_threshold:
            project_dfs.append(ctx.spark_session.createDataFrame(project_rows_buffer, schema=project_schema))
            project_rows_buffer = []
            if len(project_dfs) >= MAX_INTERMEDIATE_FRAMES:
                project_dfs = _compact_frames(project_dfs)

    if project_rows_buffer:
        project_dfs.append(ctx.spark_session.createDataFrame(project_rows_buffer, schema=project_schema))
        if len(project_dfs) >= MAX_INTERMEDIATE_FRAMES:
            project_dfs = _compact_frames(project_dfs)

    # compass_project is not an incremental dataset, so set write mode to replace
    compass_project.set_mode("replace")
    # Compact any outstanding frames to reduce lineage depth
    if len(project_dfs) > 1:
        project_dfs = _compact_frames(project_dfs)
    project_df = _union_all_with_schema(project_dfs, project_schema)
    compass_project.write_dataframe(project_df)

    # Write the failed API request retry attempts
    df = ctx.spark_session.createDataFrame(
        compass.retry_logs,
        schema=T.StructType(
            [
                T.StructField("occured_at", T.TimestampType(), False),
                T.StructField("retry_attempt", T.IntegerType(), False),
                T.StructField("retry_message", T.StringType(), False),
            ]
        ),
    )
    compass_api_retries.write_dataframe(df)
