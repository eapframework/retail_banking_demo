from transforms.api import configure, transform, Output
from pkg_resources import resource_stream
import shutil


LAYERS = [
    'iqi_202205_mgrs1k_rsrp_scores.json',
]


@configure(profile=['KUBERNETES_NO_EXECUTORS'])
@transform(
    # This should be the path to the dataset tagged with Vertex: Custom Mapbox Layers
    output=Output("ri.foundry.main.dataset.b7f97cec-b0b0-469b-a5f9-aced0115b49e"),
)
def my_compute_function(output):

    for layer in LAYERS:
        with output.filesystem().open(layer, 'wb') as output_file_stream:
            with resource_stream(__name__, layer) as input_file_stream:
                shutil.copyfileobj(input_file_stream, output_file_stream)
                input_file_stream.flush()