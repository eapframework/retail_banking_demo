CREATE TABLE `/Innovation Lab/[ETL] Ticketing/logic/force/stage1_force_events` TBLPROPERTIES (foundry_transform_profiles = 'EXECUTOR_MEMORY_MEDIUM, NUM_EXECUTORS_16') AS
    SELECT wrid
, eventid
,eventdatetime
,case when eventremarks is not null and action='NARRATIVE' then eventremarks else null end as narrative
, case when destinationuser REGEXP '[A-Z][A-Z][0-9][0-9][0-9][0-9a-z]'  then destinationuser
       when wrstatus in ('COMPLETE','DISPATCH','TAKEN') and sourceuser REGEXP '[A-Z][A-Z][0-9][0-9][0-9][0-9a-z]' then sourceuser
       else null end manual_user
, case when wrstatus in ('DISPATCH','TAKEN') then eventdatetime else null end dispatch_dt
, 'NDRT' force_system 
, region
FROM `/Innovation Lab/[Source] Oracle NDRT/data/clean/xbfwrevent_t`
UNION
SELECT wrid
, eventid
,eventdatetime
,case when eventremarks is not null and action='NARRATIVE' then eventremarks else null end as narrative
, case when destinationuser REGEXP '[A-Z][A-Z][0-9][0-9][0-9][0-9a-z]'  then destinationuser
       when wrstatus in ('COMPLETE','DISPATCH','TAKEN') and sourceuser REGEXP '[A-Z][A-Z][0-9][0-9][0-9][0-9a-z]' then sourceuser
       else null end manual_user
, case when wrstatus in ('DISPATCH','TAKEN') then eventdatetime else null end dispatch_first_dt
, 'Mobility' force_system
, 'Mobility' region 
FROM `/Innovation Lab/[Source] Oracle Force-M/data/clean/moblrpt.xbfwrevent_t`
