from transforms.api import transform, Input, Markings, Output
from utility.column_clean import clean_columns, lowercase_columns


@transform(
    out=Output("ri.foundry.main.dataset.c118b895-e3e7-4c08-944b-bee165e1ba94"),
    inp=Input(
        'ri.foundry.main.dataset.009ea619-0abd-4758-b5c4-90756469bf6a',
         stop_propagating=Markings(
            ["ab6b32de-380a-490b-aadf-5357a3710600"], on_branches="master"),
    )
)
def my_compute_function(ctx, inp, out):
    df = clean_columns(
        inp.dataframe(),
        strip_columns=strip_columns,
        integer_columns=cast_to_integer_columns,
        double_columns=cast_to_double_columns,
        decimal_columns=cast_to_decimal_columns,
        timestamp_columns=cast_to_timestamp_from_long_columns,
        datetime_columns=cast_to_timestamp_columns,
        datetime_format=datetime_format,
        date_columns=cast_to_date_columns,
        date_format=date_format,
        id_columns=cast_to_string_columns,
        integer_from_num_columns=cast_to_integer_from_decimal_columns
    )

    df = lowercase_columns(df)
    out.write_dataframe(df)


date_format = 'yyyy-MM-dd'
datetime_format = 'yyyy-MM-dd HH:mm:ss'

remove_cols = []
cast_to_date_columns = []
cast_to_timestamp_columns = ["SF_LOAD_TS_EST"]
cast_to_timestamp_from_long_columns = []
cast_to_integer_columns = []
cast_to_double_columns = []
cast_to_decimal_columns = []
cast_to_string_columns = []
cast_to_integer_from_decimal_columns = []
strip_columns = []
