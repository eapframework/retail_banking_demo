from pyspark.sql import functions as F, Window
from capacity_project import config
from transforms.api import transform_df, Input, Output
import logging

logger = logging.getLogger(__name__)


@transform_df(
    Output(f'{config.PARENT_FOLDER}/raw/LAST_30_DAYS_METRICS'),
    historical_metrics=Input(f'{config.PARENT_FOLDER}/raw/historical_metrics_weekly'),
)
def my_compute_function(historical_metrics):
    df = historical_metrics.withColumn(
        "date_diff", F.datediff(F.current_date(), F.col("start_date"))
    )
    df = df.filter(
        F.col("date_diff") <= 30
    )
    # for storage we want the most recent value and oldest value
    wind = Window.partitionBy("dataset_rid").orderBy(F.col("start_date").desc()).rowsBetween(Window.unboundedPreceding, Window.unboundedFollowing)
    df = df.select(
        "dataset_rid",
        "date_diff",
        F.first(F.col("disk_space")).over(wind).alias("current_disk_space"),
        F.last(F.col("disk_space")).over(wind).alias("last_disk_space"),
        "compute_time",
        "interactive_compute",
        F.first(F.col("disk_space")).over(wind).alias("current_indexed_storage"),
        F.last(F.col("disk_space")).over(wind).alias("last_indexed_storage"),
    )
    df = df.groupBy(
        "dataset_rid",
        "current_disk_space",
        "last_disk_space",
        "current_indexed_storage",
        "last_indexed_storage",
    ).agg(
        F.sum("compute_time").alias("last_30_days_compute_time"),
        F.sum("interactive_compute").alias("last_30_days_interactive_compute"),
        F.max("date_diff").alias("date_diff"),
    )

    # replicate disk change metrics
    # account that this isn't actually 30 days - perform these after aggregation as non deterministic
    df = df.select(
        "dataset_rid",
        "current_disk_space",
        "last_disk_space",
        "current_indexed_storage",
        "last_indexed_storage",
        ((F.col("current_disk_space") * F.lit(30))/(F.col("last_disk_space") * F.col("date_diff"))).alias("last_30_days_disk_change"),
        (((F.col("current_disk_space")-F.col("last_disk_space")) * F.lit(30))/(F.col("current_disk_space") * F.col("date_diff"))).alias("disk_change_last_30_days"),
        ((F.col("current_indexed_storage") * F.lit(30))/(F.col("last_indexed_storage") * F.col("date_diff"))).alias("last_30_days_indexed_storage_change"),
        (F.col("last_30_days_compute_time") * F.lit(60*30)/F.col("date_diff")).alias("last_30_days_compute_time"),
        (F.col("last_30_days_interactive_compute") * F.lit(30)/F.col("date_diff")).alias("last_30_days_interactive_compute"),
        F.current_date().alias("date"),
        F.year(F.current_date()).alias("year"),
        F.month(F.current_date()).alias("month"),
    )

    return df
