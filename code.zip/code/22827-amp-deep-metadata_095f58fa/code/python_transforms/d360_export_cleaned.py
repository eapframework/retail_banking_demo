from transforms.api import transform_df, Input, Output
from pyspark.sql import functions as F
from myproject.utils.global_code import *
import pyspark.sql.types as T


@transform_df(
    Output(
        "/Innovation Lab/Data Governance/Export/d360_export_cleaned",
        sever_permissions=True,
    ),
    datasets=Input("/Innovation Lab/Data Governance/Export/d360_export"),
    config=Input("/Innovation Lab/Palantir Admins/Quantum/inputs/config"),
    eng_feed_datasets=Input(
        "/Innovation Lab/Data Governance/Code & Data/data/engineered_feed_list"
    ),
)
def my_compute_function(ctx, config, datasets, eng_feed_datasets):
    headers = get_header(config)

    clean_datasets = (
        datasets.filter(
            (F.col("dataset_path").contains("clean"))
            | (F.col("is_in_data_catalog") == "Y")
        )
        .select("dataset_rid")
        .collect()
    )  # noqa
    clean_brd_rids = [row["dataset_rid"] for row in clean_datasets]

    in_data_catalog = datasets.filter(F.col("is_in_data_catalog") == "Y")
    brd_rows = in_data_catalog.select("dataset_rid").collect()  # noqa
    brd_rids = [row["dataset_rid"] for row in brd_rows]

    df = datasets.withColumn("upstream_lineage", F.lit(None))
    all_parents = {}
    for rid in brd_rids:
        body = {
            "datasetRids": [rid],
            "branchFallbacks": {"branches": []},
            "datasetRidsToIgnore": [],
        }
        get_parents = session.post(
            "{}/jobspecs/branches/master/upstream-jobspec-nodes".format(BUILD2_URI),
            headers=headers,
            json=body,
        ).json()

        parents = set()
        for obj in get_parents:
            parents.update({inp for inp in obj["inputs"] if "dataset" in inp})

        all_parents[rid] = parents

    for rid in brd_rids:
        if rid in all_parents:
            lineage = all_parents[rid]
            clean_lineage = [rid for rid in lineage if rid in clean_brd_rids]
            if len(clean_lineage) > 0:
                df = df.withColumn(
                    "upstream_lineage",
                    F.when(
                        (F.col("dataset_rid") == rid), F.lit(",".join(clean_lineage))
                    ).otherwise(df["upstream_lineage"]),
                )

    df = df.withColumn(
        "upstream_lineage_url",
        F.concat(
            F.lit("{}/data-integration/monocle/graph/datasets/".format(WORKSPACE_URI)),
            F.col("dataset_rid"),
            F.lit("?upstream=true&branchId=master"),
        ),
    )
    df = df.withColumn(
        "upstream_lineage",
        F.split(F.col("upstream_lineage"), ",").cast(T.ArrayType(T.StringType())),
    )
    df = df.drop("data_feed_type")
    df = df.join(
        eng_feed_datasets.select("engineered_vs_snapshot", "dataset_rid"),
        ["dataset_rid"],
        how="left",
    )
    df = df.withColumn(
        "data_feed_type",
        F.when(df["engineered_vs_snapshot"] == "engineered", F.lit("Engineered Feed"))
        .when(df["is_in_data_catalog"] == "Y", F.lit("N/A"))
        .otherwise(F.lit("Snapshot")),
    ).drop(df["engineered_vs_snapshot"])
    return df
