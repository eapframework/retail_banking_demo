CREATE TABLE `/Innovation Lab/[ETL] Ticketing/logic/aotsm/aotsm_lk_repeat_mnoc_mc8297` AS
       SELECT ticket_number as repeat_ticket_number_mnoc,
       problem_detail as repeat_problem_detail_mnoc,
       create_date as repeat_create_date_mnoc,
       closed_time as repeat_closed_time_mnoc,
       closed_by as repeat_closed_by_mnoc
        FROM `/Innovation Lab/[ETL] Ticketing/data/clean/AOTSM_ALL_TROUBLE_TICKET_CLEAN` A
    WHERE EXISTS (SELECT ticket_number
        FROM `/Innovation Lab/[ETL] Ticketing/data/clean/AOTSM_ALL_TROUBLE_TICKET_CLEAN` B
        WHERE 
            A.ticket_number!=B.ticket_number
        AND A.common_id=B.common_id
        AND A.problem_detail=B.problem_detail
        AND A.equipment_id=B.equipment_id
        AND A.create_date >= B.closed_time
        AND (unix_timestamp(A.create_date)-unix_timestamp(B.closed_time))/3600/24 <= 5)


/* A is the First Ticket.  B is the Look up for Previous ticket  */
/* Ticket is a Repeat if Created within 5 days of the previous ticket's closed time */