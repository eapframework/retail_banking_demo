from transforms.api import transform, Input, Output
from pyspark.sql import functions as F
from pyspark.sql.functions import dense_rank
from pyspark.sql.window import Window

@transform(
    out=Output("ri.foundry.main.dataset.9de51281-80f9-47c2-b6e3-0c8741dc1e4e"),
    hist=Input("ri.foundry.main.dataset.4b0f89a6-efc1-4ab1-b0ee-9d50f5d1f8a5"),
)
def compute(hist, out):
    hist_df = hist.dataframe()

    # Get the most recent MPT Release Changes
    # Ordering begins
    df = hist_df.withColumn('Flg_snp_datetime', F.date_format("ConfigSnapshot_TS", 'yyyyMMddHHmmss').cast('long'))
    window = Window().partitionBy().orderBy(F.col('Flg_snp_datetime').desc())
    df = df.withColumn("Flg_rank", dense_rank().over(window))
    df = df.filter(F.col("Flg_rank") == 1)

    cols = ['Program', 'Category', 'NationalProgram',
        'JobScope', 'Filter', 'Filter_Level', 'Rollup',
        'Notes', 'CreatedOn', 'ModifiedOn', 'ConfigSnapshot_TS']

    # select desired columns
    df_out = df.select(*cols).distinct()

    out.write_dataframe(df_out)
