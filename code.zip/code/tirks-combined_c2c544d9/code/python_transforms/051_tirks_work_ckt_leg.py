from transforms.api import transform_df, Input, Output, incremental
import pyspark.sql.functions as F


@transform_df(
    Output("ri.foundry.main.dataset.82b382a2-7d2d-4e50-b172-3241ae602ae7"),
    asi=Input("ri.foundry.main.dataset.168020e4-5a11-416d-8384-4d2953f3c2ac"),
    telco=Input("ri.foundry.main.dataset.01ac67ac-ad96-49fc-9627-c3ac68e02cf8"),
)
def my_compute_function(telco, asi):
    telco = telco.withColumn("source", F.lit('telco'))
    asi = asi.withColumn("source", F.lit('asi'))
    df = telco.unionByName(asi)
    return df
