CREATE TABLE `/Innovation Lab/[ETL] Ticketing/logic/aotstm/aotstm_lk_repeat` AS
    SELECT ticket FROM `/Innovation Lab/[ETL] Ticketing/data/clean/AOTSTM_TICKET_CLEAN` A
    WHERE EXISTS (SELECT ticket
        FROM `/Innovation Lab/[ETL] Ticketing/data/clean/AOTSTM_TICKET_CLEAN` B
        WHERE A.asset_id=B.asset_id
        AND A.problem_abstract=B.problem_abstract
        AND A.ticket_opened_date_utc > B.ticket_opened_date_utc
        AND (unix_timestamp(A.ticket_opened_date_utc)-unix_timestamp(B.ticket_opened_date_utc))/3600/24 < 28)