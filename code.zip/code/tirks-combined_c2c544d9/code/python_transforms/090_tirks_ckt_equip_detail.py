from transforms.api import transform_df, Input, Output
import pyspark.sql.functions as F


@transform_df(
    Output("ri.foundry.main.dataset.6c287c98-9d86-4469-ae06-427e02cdd73a"),
    asi=Input("ri.foundry.main.dataset.fa5c39d0-db7a-4e56-93e1-8242cd73d1a4"),
    telco=Input("ri.foundry.main.dataset.4242365c-4b99-484a-8270-a3545e473451"),
)
def my_compute_function(telco, asi):
    telco = telco.withColumn("source", F.lit('telco'))
    asi = asi.withColumn("source", F.lit('asi'))
    union = telco.unionByName(asi)
    return union
