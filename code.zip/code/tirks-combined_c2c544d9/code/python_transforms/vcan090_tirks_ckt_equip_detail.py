from transforms.api import transform, Input, Output, incremental
from utility.column_clean import clean_columns, lowercase_columns, remove_prefix


@transform(
    out=Output("/Innovation Lab/[Source] Teradata EDW - ASI_VIEWS/data/clean/vcan090_tirks_ckt_equip_detail"),
    df=Input("/Innovation Lab/[Source] Teradata EDW - ASI_VIEWS/data/raw/snowflake/VCAN090_TIRKS_CKT_EQUIP_DETAIL"),
)
def my_compute_function(df, out):
    df = clean_columns(
        df.dataframe(),
        date_format=date_format, 
        date_columns=string_to_date,
        datetime_format=datetime_format, 
        datetime_columns=long_unixtime_to_timestamp,
        timestamp_from_string_format=string_unixtime_format,
        timestamp_from_string_columns=string_unixtime_to_timestamp,
        timestamp_format=long_unixtime_format, 
        timestamp_columns=long_unixtime_to_timestamp,
        integer_columns=string_to_integer_columns,
        double_columns=string_to_double_columns,
        decimal_columns=string_to_decimal_columns,
        id_columns=numeric_to_string_columns,
        integer_from_num_columns=decimal_to_integer,
        strip_columns=strip_string_columns,
    )
    # df = df.drop(*drop_columns)
    # df = remove_prefix(df, 'example_prefix')
    df = lowercase_columns(df)
    out.write_dataframe(df)


drop_columns = []

date_format = 'yyyy-MM-dd'
string_to_date = []
datetime_format = 'yyyy-MM-dd HH:mm:ss'
string_to_timestamp = []

string_unixtime_format = None
string_unixtime_to_timestamp = []
long_unixtime_format = None
long_unixtime_to_timestamp = []

string_to_integer_columns = []
string_to_double_columns = []
string_to_decimal_columns = []

numeric_to_string_columns = []
decimal_to_integer = []

strip_string_columns = [
    "ADMINISTRATIVE_AREA_CD",
    "CIRCUIT_ACCESS_CD",
    "CIRCUIT_DROP_CONTINUE_PATH_CD",
    "CIRCUIT_LAYOUT_ORDER_NBR",
    "EQUIP_LOC_A_TRNSMSN_LVL_MSRMT",
    "EQUIP_LOC_Z_TRNSMSN_LVL_MSRMT",
    "EQUIPMENT_ASGNMT_ACTIVITY_CD",
    "EQUIPMENT_ASSIGNMENT_ACTION_CD",
    "EQUIPMENT_FUNCTION_CD",
    "EQUIPMENT_LINE_TYPE_CD",
    "EQUIPMENT_LOCATION_CLLI_CD",
    "EQUIPMENT_MISCELLANEOUS_TXT",
    "EQUIPMENT_SEQUENCE_NBR",
    "EQUIPMENT_SIGNAL_VOICE_PATH_CD",
    "HUMAN_EQUIP_CATALOG_ITEM_CD",
    "RELAY_RACK_CD",
    "SBC_COMPANY_CD",
    "SBC_STATE_CD",
    "SBC_SYSTEM_CD",
    "SUBDIVISION_CD",
    "UNIT_NBR"
]
