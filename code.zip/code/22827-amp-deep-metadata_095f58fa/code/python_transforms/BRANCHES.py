import pyspark.sql.types as T
from pyspark.sql import functions as F
from dateutil.parser import parse as parse_date
from capacity_project import config, utils
from capacity_project.api.Catalog import CatalogAPI
from transforms.api import transform_df, incremental, Input, Output
from datetime import datetime


@transform_df(
    Output(f'{config.PARENT_FOLDER}/raw/BRANCHES'),
    datasets=Input(f'{config.PARENT_FOLDER}/raw/SOURCE_DATASETS'),
    config=Input("/Innovation Lab/Palantir Admins/Quantum/inputs/config")

)
def my_compute_function(ctx, datasets, config):

    token = utils.get_token(config)
    catalog_api = CatalogAPI(token)

    branch_info = (datasets
                   .repartition(1000)
                   .rdd
                   .flatMap(lambda dataset: get_branches(catalog_api, dataset)))

    df = ctx.spark_session.createDataFrame(branch_info, schema=T.StructType([
        T.StructField('dataset_rid', T.StringType(), True),
        T.StructField('branch', T.StringType(), True),
        T.StructField('head_transaction_rid', T.StringType(), True),
        T.StructField('disk_usage_in_view', T.DoubleType(), True),
        T.StructField('creation_time', T.TimestampType(), True),
        T.StructField('last_modified_date', T.DateType(), True)
    ]))

    df = df.withColumn('creation_date',F.to_date(F.col("creation_time"), 'yyyy-MM'))
    return df


def get_branches(catalog_api, dataset):
    try:
        branches_req = [{'datasetRid': dataset.dataset_rid, 'branchId': branch} for branch in dataset.branches]
        branches_res = catalog_api.get_batch_branches(branches_req)
        branches_res = list(filter(lambda a: "transactionRid" in a["value"] and a["value"]["transactionRid"] is not None, branches_res))
        branches_res_with_size = catalog_api.get_disk_space_in_view_batch(branches_res)
        return [(
            b['key']['datasetRid'],
            b['key']['branchId'],
            b['value']['transactionRid'],
            b['value']["sizeInMbs"],
            parse_date(b['value']['creationTime']),
            dataset.last_modified_date, 
        ) for b in branches_res_with_size]
    except Exception as e:
        # catching errored out datasets
        return [(
            dataset.dataset_rid,
            b,
            f"ERROR: {str(e)}",
            0.0,
            None, # temp date value, invalid
            dataset.last_modified_date,
        ) for b in dataset.branches]
