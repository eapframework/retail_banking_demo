CREATE TABLE `/Innovation Lab/[ETL] Ticketing/data/clean/aotstm_lk_auto_touch` AS
SELECT HUMAN_TOUCH.ticket_number
, MIN(HUMAN_TOUCH.Modified_Time_1M) first_auto_touch
, MAX(HUMAN_TOUCH.Modified_Time_1M) last_auto_touch
, COUNT(HUMAN_TOUCH.ticket_number) total_auto_touches
FROM `/Innovation Lab/[ETL] Ticketing/logic/aotstm/aotstm_lk_ticket_touch_instances_unique` HUMAN_TOUCH
WHERE is_human=0
GROUP BY HUMAN_TOUCH.ticket_number

