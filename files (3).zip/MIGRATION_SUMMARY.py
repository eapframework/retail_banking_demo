"""
MSO uTicket — DLT → SDP Migration Summary
==========================================
All changes from the validated DLT pipeline to the new pyspark.pipelines SDK.

SDK: from pyspark import pipelines as dp  (alias: dp)
"""

# ═══════════════════════════════════════════════════════════════════════════
# GLOBAL CHANGES (applied to all 3 pipeline files)
# ═══════════════════════════════════════════════════════════════════════════
#
# 1. IMPORT:        import dlt          → from pyspark import pipelines as dp
# 2. READ BATCH:    dlt.read("x")       → spark.read.table("x")
# 3. READ STREAM:   dlt.read_stream("x")→ spark.readStream.table("x")
# 4. STREAMING TBL: @dlt.table          → @dp.table()       [returns streaming DF]
# 5. BATCH TABLE:   @dlt.table          → @dp.materialized_view()  [returns batch DF]
# 6. VIEW:          @dlt.view           → @dp.temporary_view()
# 7. APPLY CHANGES: dlt.apply_changes() → dp.create_auto_cdc_flow()
# 8. CREATE TARGET: dlt.create_streaming_live_table() → dp.create_streaming_table()
# 9. EXPECTATIONS:  @dlt.expect*        → @dp.expect*       [same names, dp prefix]


# ═══════════════════════════════════════════════════════════════════════════
# FILE-BY-FILE CHANGES
# ═══════════════════════════════════════════════════════════════════════════

# --- 01_bronze_ingestion.py ---
#
# BEFORE (DLT):                        AFTER (SDP):
# @dlt.table(name=...)                 @dp.table(name=...)        ← same decorator, new prefix
#   def raw_chg_change():                def raw_chg_change():
#     return spark.readStream...            return spark.readStream...  ← unchanged
#
# NEW: Added @dp.expect_or_drop() data quality expectations on PKs
# CONFIG: LANDING_ZONE now read from spark.conf.get() for DABs variable injection
#
# Table types: All 7 bronze tables are @dp.table() (streaming) — unchanged


# --- 02_silver_transforms.py ---
#
# ┌─────────────────────────────────────────────────────────────────────────┐
# │ SIMPLE CLEANS (5 tables): chg_task, acmr14_cllis, acmr14_techs,       │
# │                           ap_signature, ap_detail                       │
# ├─────────────────────────────────────────────────────────────────────────┤
# │ BEFORE: @dlt.table + dlt.read("x")                                     │
# │ AFTER:  @dp.table() + spark.readStream.table("x")                      │
# │ These are now STREAMING TABLES reading from bronze streams.             │
# │ All transform ops (cast, alias, withColumn) work on streaming DFs.     │
# └─────────────────────────────────────────────────────────────────────────┘
#
# ┌─────────────────────────────────────────────────────────────────────────┐
# │ SCD1 TABLES (2 tables): chg_change, acmr23_equipment                   │
# ├─────────────────────────────────────────────────────────────────────────┤
# │ BEFORE: @dlt.table + row_number().over(Window) dedup                    │
# │                                                                         │
# │ AFTER Option A (DEFAULT — streaming CDC):                               │
# │   @dp.temporary_view()  ← staging view with cleaning transforms        │
# │   dp.create_streaming_table(name=...)  ← empty target                  │
# │   dp.create_auto_cdc_flow(                                              │
# │       target=..., source=...,                                           │
# │       keys=["change_id", "seqno"],                                      │
# │       sequence_by="modified_date",                                      │
# │       stored_as_scd_type=1,                                             │
# │   )                                                                     │
# │                                                                         │
# │ AFTER Option B (COMMENTED — batch MV with dedup):                       │
# │   @dp.materialized_view() + spark.read.table() + Window dedup          │
# │                                                                         │
# │ KEY INSIGHT: create_auto_cdc_flow doesn't need an explicit "operation"  │
# │ column. When no apply_as_deletes is specified, all incoming rows are    │
# │ treated as upserts — matching the Foundry incremental behavior.         │
# └─────────────────────────────────────────────────────────────────────────┘
#
# ┌─────────────────────────────────────────────────────────────────────────┐
# │ SQL JOIN (1 table): silver_ap_signature_enriched                        │
# ├─────────────────────────────────────────────────────────────────────────┤
# │ BEFORE: @dlt.table + dlt.read("x")  (batch)                            │
# │ AFTER:  @dp.materialized_view() + spark.read.table("x")  (batch)       │
# │ Stays as materialized view — JOIN of two tables needs batch or          │
# │ watermark config. Batch MV is simpler and correct.                      │
# └─────────────────────────────────────────────────────────────────────────┘


# --- 03_gold_contour_analytics.py ---
#
# ┌─────────────────────────────────────────────────────────────────────────┐
# │ GOLD ANALYTICS (4 tables): open, closed, cmclosed_tasks, notasks       │
# ├─────────────────────────────────────────────────────────────────────────┤
# │ BEFORE: @dlt.table + dlt.read("x")  (batch)                            │
# │ AFTER:  @dp.materialized_view() + spark.read.table("x")  (batch)       │
# │ Multi-way LEFT JOINs stay as materialized views. No streaming here.    │
# └─────────────────────────────────────────────────────────────────────────┘
#
# ┌─────────────────────────────────────────────────────────────────────────┐
# │ EXPORT TABLES (4 tables): open_export, closed_export, etc.             │
# ├─────────────────────────────────────────────────────────────────────────┤
# │ BEFORE: @dlt.view (not persisted)                                       │
# │ AFTER:  @dp.table() + spark.readStream.table("gold_mv")                │
# │ PROMOTED from non-persisted views to streaming tables.                  │
# │ These capture every gold MV refresh as new data in a Delta table.       │
# │ Downstream consumers (AOTS, Power BI, etc.) can subscribe to changes.  │
# └─────────────────────────────────────────────────────────────────────────┘


# ═══════════════════════════════════════════════════════════════════════════
# TABLE TYPE SUMMARY
# ═══════════════════════════════════════════════════════════════════════════
#
# Layer   | Table                               | SDP Type              | Streaming?
# --------|-------------------------------------|-----------------------|----------
# Bronze  | raw_chg_change_snowflake            | @dp.table()           | ✅ Yes
# Bronze  | raw_chg_task_snowflake              | @dp.table()           | ✅ Yes
# Bronze  | raw_acmr14_affected_cllis           | @dp.table()           | ✅ Yes
# Bronze  | raw_acmr14_affected_techs_snowflake | @dp.table()           | ✅ Yes
# Bronze  | raw_acmr23_mobility_equipment_info  | @dp.table()           | ✅ Yes
# Bronze  | raw_ap_signature                    | @dp.table()           | ✅ Yes
# Bronze  | raw_ap_detail_snowflake             | @dp.table()           | ✅ Yes
# --------|-------------------------------------|-----------------------|----------
# Silver  | clean_chg_change                    | create_streaming_table| ✅ Yes (SCD1 CDC)
# Silver  | clean_chg_task                      | @dp.table()           | ✅ Yes
# Silver  | clean_acmr14_affected_cllis         | @dp.table()           | ✅ Yes
# Silver  | clean_acmr14_affected_techs         | @dp.table()           | ✅ Yes
# Silver  | clean_acmr23_mobility_equipment_info| create_streaming_table| ✅ Yes (SCD1 CDC)
# Silver  | clean_ap_signature                  | @dp.table()           | ✅ Yes
# Silver  | clean_ap_detail                     | @dp.table()           | ✅ Yes
# Silver  | silver_ap_signature_enriched        | @dp.materialized_view | ❌ Batch (JOIN)
# --------|-------------------------------------|-----------------------|----------
# Gold    | mso_aotscm_open_tickets             | @dp.materialized_view | ❌ Batch (5 JOINs)
# Gold    | mso_aotscm_closed_tickets           | @dp.materialized_view | ❌ Batch (5 JOINs)
# Gold    | cmclosed_tasks                      | @dp.materialized_view | ❌ Batch (1 JOIN)
# Gold    | cmclosed_notasks                    | @dp.materialized_view | ❌ Batch (4 JOINs)
# --------|-------------------------------------|-----------------------|----------
# Export  | mso_aotscm_open_tickets_export      | @dp.table()           | ✅ Yes
# Export  | mso_aotscm_closed_tickets_export    | @dp.table()           | ✅ Yes
# Export  | cmclosed_tasks_export               | @dp.table()           | ✅ Yes
# Export  | cmclosed_notasks_export             | @dp.table()           | ✅ Yes
# --------|-------------------------------------|-----------------------|----------
# Staging | _chg_change_cleaned                 | @dp.temporary_view    | (internal)
# Staging | _acmr23_cleaned                     | @dp.temporary_view    | (internal)
#
# TOTAL: 7 bronze + 8 silver + 4 gold + 4 export + 2 staging = 25 datasets
#        15 streaming + 5 materialized views + 2 staging views + 2 CDC targets + 1 MV
#
# Streaming coverage: 15 of 19 persisted tables are streaming (79%)
# The 5 non-streaming tables all involve JOINs that require batch processing.


# ═══════════════════════════════════════════════════════════════════════════
# DABs CHANGES
# ═══════════════════════════════════════════════════════════════════════════
#
# - Added `continuous: true` for prod target (enables always-on streaming)
# - Added `continuous: false` for dev/staging (triggered mode)
# - LANDING_ZONE injected via pipeline `configuration` → spark.conf.get()
# - Updated spark_version to 15.4.x for Spark 4.1+ / pyspark.pipelines support
# - Added per-table CSV export job tasks with parameterized source/output paths
