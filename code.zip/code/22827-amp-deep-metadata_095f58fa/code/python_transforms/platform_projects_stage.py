from pyspark.sql import functions as F
from transforms.api import transform_df, Input, Output

@transform_df(
    Output("/Innovation Lab/Data Governance/DEEP Project Object/platform_projects_cleaned"),
    source_df=Input("/Innovation Lab/Data Governance/AT&T Internal Shareable Resources/platform_projects_pre_cleaned"),
    aip_approved=Input("/Innovation Lab/Data Governance/AIP Access/aip_approved_group"),
    aip_streamline_materialization=Input("ri.foundry.main.dataset.c345f22e-cf20-422b-85a9-40d48567d6f3"),
)
def compute(source_df, aip_approved, aip_streamline_materialization):
    # Filter aip_approved for principalType = 'GROUP'
    aip_approved_groups = aip_approved.filter(F.col("principalType") == "GROUP")
    # Explode the multipass_group_rids array
    exploded_df = source_df.withColumn("group_rid", F.explode("multipass_group_rids"))

    #list of PA00X rids to whitelist
    pa_ids = [
    "f755547f-22a2-4f3c-99a2-e498c2dc4e6f",
    "2abc651f-51b5-4a1b-af07-261193d7b7ab",
    "2c2eaa5b-b2d6-42c8-9824-cdaf97efbab1",
    "d446b994-a60a-4a8d-992e-7861954e34d5",
    "547becfa-5a34-44da-82ce-80f27ca879ca",
    "e24d9e65-5777-4407-8dbc-301065363acf",
    "1455979c-f161-4223-bcfe-645cdf5feffd",
    "4b11fad1-ad50-48f3-9f16-862e9d949851",
    "ca9b76f5-908b-4b99-acf5-7681e06e4006",
    "59f8a55c-e544-4dcd-aeb2-c4643c26175a",
    "cef413b2-a830-4406-b975-75623b12c10c",
    "824f3c37-8f3c-45f1-b5f3-9b130abae135",
    "683b7ebf-517d-48a4-bd3a-816780b5642c",
    "f1c87e13-3972-44a3-8d32-771f2bf73beb",
    "d43bf788-7da2-4bef-8a49-ad7129443784",
    "363a05f6-2a3e-467b-a91c-1ffd60945482",
    "c03c8f04-f2c9-4b82-afcb-8a2378c56798",
    "59ad0e4f-d628-4ff5-b6b7-26bfc310049e",
    "ac45464f-8d4b-490d-98d1-e7fdebbedafa",
    "412e94a5-f545-4bd9-bda1-3539d0c82d5c",
    "46f57e89-fca3-4a77-a027-fb06961e4ebd",
    "57818412-dc1b-4fd5-9b06-db77ecb30c92",
    "efdeac64-15ad-43eb-8866-ab0c1809180b",
    "23d2c8e9-81e4-471b-ab8e-eb9610e9ccbb",
    "4fb01a1f-3e15-4a54-8b0d-66f581e182b2",
    "35069dcf-8f38-43df-b723-f89936332666",
    "35ca50d3-2e3e-450c-ac0c-d78c194a9fe0",
    "9ad7e5ef-e968-43fe-a940-c56ae0e555a4",
    "9ad7e5ef-e968-43fe-a940-c56ae0e555a4",
    "746951db-5b5a-4aa5-b5fd-3136ac8592de",
    "584087b9-d21c-468d-b3fd-7db751ea4149",
    "44c16ff5-e7a5-4410-8255-46b57bba07c3",
    "08b820f4-a57b-42df-9ca4-1dfa53e54fc1",
    "2a158640-8a0d-4e8f-94af-eaa11b5b8f5d",
    "2a3c3203-0be7-4a62-925c-2ed474ed2247"
]

    #list of Palantir employee groups
    pal_ids = ["f83e52a9-33f6-4f9c-b4fd-f0a452a20b20", "80def80c-4ff6-4439-bc5f-e688553068bd","1b3ee7ec-c317-4ac3-ac2e-27d17e465219"]

     # Filter out group_rid IDs that are in pa_ids or pal_ids
    filtered_df = exploded_df.filter(~F.col("group_rid").isin(pa_ids + pal_ids))


    # Perform a left join between filtered_df and aip_approved where project_type is "Use Case"
    joined_df = filtered_df.join(
        aip_approved_groups,
        (filtered_df.group_rid == aip_approved_groups.principalId) & (filtered_df.project_type == "Use Case"),
        "left"
    )

    # Perform a left join between filtered_df and aip_streamline_materialization where project_type is "Use Case"
    joined_df = joined_df.join(
        aip_streamline_materialization,
        (filtered_df.project_rid == aip_streamline_materialization.rid_) & (filtered_df.project_type == "Use Case"),
        "left"
    )

    # Add the new columns
    result_df = joined_df.groupBy(source_df.columns).agg(
        F.max(F.when(F.col("principalId").isNotNull(), F.lit(True)).otherwise(F.lit(False))).alias("aip_access_status"),
        F.max(F.when(F.col("expirationTime").isNotNull(), F.lit(True)).otherwise(F.lit(False))).alias("aip_expiration_time"),
        F.max("expirationTime").alias("aip_expiration_time_set"), F.first("opp_id").alias("opp_id")
    )

    # Select all columns from source_df and add the new columns
    columns_to_select = source_df.columns + ["aip_access_status", "aip_expiration_time", "aip_expiration_time_set", "opp_id"]
    
    return result_df.select(*columns_to_select)