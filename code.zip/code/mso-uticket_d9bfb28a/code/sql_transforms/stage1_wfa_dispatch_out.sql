CREATE TABLE `ri.foundry.main.dataset.1150117d-75c0-4b0b-b9ed-9d092a86931c` AS
    SELECT ext_key1
    , concat_ws(';', collect_set(cast(caus_cd as integer)))  cause_code_list_out
    , concat_ws(';', collect_set(cast(trbl_fnd_cd as integer)))  trbl_fnd_cd_list_out
    , concat_ws(';', collect_list(trbl_fnd_desc)) trbl_fnd_desc_out
    FROM `ri.foundry.main.dataset.a3ee0d5c-7903-483c-82c8-370b37eeb678`
    WHERE lower(ext_key1) REGEXP '^[a-z][a-z][0-9][0-9][0-9][0-9][0-9][0-9]$|[0-9a-z][0-9a-z][0-9a-z][0-9a-z][0-9a-z][0-9a-z][0-9a-z][0-9a-z][0-9a-z]'
    group by ext_key1