# Project Inventory Summary

**Project name:** [ETL] IQI

**Merge timestamp:** 2026-03-16T14:41:29.427705

**Project output dir:** `iqi_afb7dee0`

**Total resources in project folder:** 31

**Total merged records:** 57

**Unresolved (project_only) resources:** 0

## Resource Counts by Type

- **codeworkbookdataset:** 1
- **contouranalysis:** 1
- **datasource:** 2
- **foundrydataset:** 1
- **magritteagent:** 8
- **marbleserverlayer:** 1
- **monoclegraph:** 3
- **notepad:** 2
- **opusmaplayer:** 1
- **pipelinebuilder:** 1
- **pythontransformation:** 22
- **rawdataset:** 12
- **slatedocument:** 1
- **vectorworkbook:** 1

## Mode

Flat output — workshop subdirectories removed after merge.
