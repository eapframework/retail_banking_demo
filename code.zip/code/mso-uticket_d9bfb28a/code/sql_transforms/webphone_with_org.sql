CREATE TABLE `/Innovation Lab/[Source] Webphone/data/clean_data/webphone_with_org` AS
    SELECT country_code,
dept_id,
dept_name,
business_group_id,
business_group_name,
business_subgroup,
business_subgroup_name,
business_unit,
business_unit_name,
vp_org,
vp_org_name,
cel,
city,
countrydesc,
e_mail,
first_name,
handle,
hrid,
job_title_code,
jt_name,
last_name,
location_clli_code,
middle_name,
costcenter,
pager,
pager_pin,
preferred_name,
prefix_name,
state,
status,
name_suffix,
level,
title_name,
address,
zip,
supervisor_hrid,
a1_sbcuid_attuid,
cogs_common_org_grouping_sys,
silo,
direct_total_reports,
bellsouth_uid,
cingular_cuid,
financial_loc_code,
e_mail_alias,
payroll_id,
consulting_company,
management_level_indicator,
occupancy_indicator,
primary_gtr,
secondary_gtr,
cpid_record_indicator,
geographic_location_code,
architectural_object_id,
company_code,
company_description,
consultant_flag,
room_number,
telephone_number,
load_ts,
data_dt,
email,
full_name,
cogs_splt,
cogs_1_attuid,
cogs_1_name,
cogs_1_job_title,
cogs_1_direct_reports,
cogs_1_level,
cogs_2_attuid,
cogs_2_name,
cogs_2_job_title,
cogs_2_direct_reports,
cogs_2_level,
cogs_3_attuid,
cogs_3_name,
cogs_3_job_title,
cogs_3_direct_reports,
cogs_3_level,
cogs_4_attuid,
cogs_4_name,
cogs_4_job_title,
cogs_4_direct_reports,
cogs_4_level,
cogs_5_attuid,
cogs_5_name,
cogs_5_job_title,
cogs_5_direct_reports,
cogs_5_level,
cogs_6_attuid,
cogs_6_name,
cogs_6_job_title,
cogs_6_direct_reports,
cogs_6_level,
cogs_7_attuid,
cogs_7_name,
cogs_7_job_title,
cogs_7_direct_reports,
cogs_7_level,
cogs_8_attuid,
cogs_8_name,
cogs_8_job_title,
cogs_8_direct_reports,
cogs_8_level,
cogs_9_attuid,
cogs_9_name,
cogs_9_job_title,
cogs_9_direct_reports,
cogs_9_level,
cogs_10_attuid,
cogs_10_name,
cogs_10_job_title,
cogs_10_direct_reports,
cogs_10_level,
cogs_11_attuid,
cogs_11_name,
cogs_11_job_title,
cogs_11_direct_reports,
cogs_11_level,
cogs_12_attuid,
cogs_12_name,
cogs_12_job_title,
cogs_12_direct_reports,
cogs_12_level,
cogs_13_attuid,
cogs_13_name,
cogs_13_job_title,
cogs_13_direct_reports,
cogs_13_level,
cogs_14_attuid,
cogs_14_name,
cogs_14_job_title,
cogs_14_direct_reports,
cogs_14_level,
supervisor_name
, CASE WHEN w.cogs_10_level == 6 THEN w.cogs_10_name
       WHEN w.cogs_9_level == 6 THEN w.cogs_9_name
       WHEN w.cogs_8_level == 6 THEN w.cogs_8_name
       WHEN w.cogs_7_level == 6 THEN w.cogs_7_name
       WHEN w.cogs_6_level == 6 THEN w.cogs_6_name
       WHEN w.cogs_5_level == 6 THEN w.cogs_5_name
       WHEN w.cogs_4_level == 6 THEN w.cogs_4_name
       WHEN w.cogs_3_level == 6 THEN w.cogs_3_name
       WHEN w.cogs_2_level == 6 THEN w.cogs_2_name
       ELSE 'NO SVP' END SVP_Name
, CASE WHEN w.cogs_2_level == 5 THEN w.cogs_2_name
       WHEN w.cogs_3_level == 5 THEN w.cogs_3_name
       WHEN w.cogs_4_level == 5 THEN w.cogs_4_name
       WHEN w.cogs_5_level == 5 THEN w.cogs_5_name
       WHEN w.cogs_6_level == 5 THEN w.cogs_6_name
       WHEN w.cogs_7_level == 5 THEN w.cogs_7_name
       WHEN w.cogs_8_level == 5 THEN w.cogs_8_name
       WHEN w.cogs_9_level == 5 THEN w.cogs_9_name
       WHEN w.cogs_10_level == 5 THEN w.cogs_10_name
       ELSE 'NO VP' END VP_Name
, CASE WHEN w.cogs_2_level == 4 THEN w.cogs_2_name
       WHEN w.cogs_3_level == 4 THEN w.cogs_3_name
       WHEN w.cogs_4_level == 4 THEN w.cogs_4_name
       WHEN w.cogs_5_level == 4 THEN w.cogs_5_name
       WHEN w.cogs_6_level == 4 THEN w.cogs_6_name
       WHEN w.cogs_7_level == 4 THEN w.cogs_7_name
       WHEN w.cogs_8_level == 4 THEN w.cogs_8_name
       WHEN w.cogs_9_level == 4 THEN w.cogs_9_name
       WHEN w.cogs_10_level == 4 THEN w.cogs_10_name
       ELSE 'NO AVP' END AVP_Name
, CASE WHEN w.cogs_2_level == 3 THEN w.cogs_2_name
       WHEN w.cogs_3_level == 3 THEN w.cogs_3_name
       WHEN w.cogs_4_level == 3 THEN w.cogs_4_name
       WHEN w.cogs_5_level == 3 THEN w.cogs_5_name
       WHEN w.cogs_6_level == 3 THEN w.cogs_6_name
       WHEN w.cogs_7_level == 3 THEN w.cogs_7_name
       WHEN w.cogs_8_level == 3 THEN w.cogs_8_name
       WHEN w.cogs_9_level == 3 THEN w.cogs_9_name
       WHEN w.cogs_10_level == 3 THEN w.cogs_10_name
       ELSE 'NO Director' END Director_Name
, CASE WHEN w.cogs_10_level == 6 THEN w.cogs_10_attuid
       WHEN w.cogs_9_level == 6 THEN w.cogs_9_attuid
       WHEN w.cogs_8_level == 6 THEN w.cogs_8_attuid
       WHEN w.cogs_7_level == 6 THEN w.cogs_7_attuid
       WHEN w.cogs_6_level == 6 THEN w.cogs_6_attuid
       WHEN w.cogs_5_level == 6 THEN w.cogs_5_attuid
       WHEN w.cogs_4_level == 6 THEN w.cogs_4_attuid
       WHEN w.cogs_3_level == 6 THEN w.cogs_3_attuid
       WHEN w.cogs_2_level == 6 THEN w.cogs_2_attuid
       ELSE 'NO SVP' END svp_attuid
, CASE WHEN w.cogs_2_level == 5 THEN w.cogs_2_attuid
       WHEN w.cogs_3_level == 5 THEN w.cogs_3_attuid
       WHEN w.cogs_4_level == 5 THEN w.cogs_4_attuid
       WHEN w.cogs_5_level == 5 THEN w.cogs_5_attuid
       WHEN w.cogs_6_level == 5 THEN w.cogs_6_attuid
       WHEN w.cogs_7_level == 5 THEN w.cogs_7_attuid
       WHEN w.cogs_8_level == 5 THEN w.cogs_8_attuid
       WHEN w.cogs_9_level == 5 THEN w.cogs_9_attuid
       WHEN w.cogs_10_level == 5 THEN w.cogs_10_attuid
       ELSE 'NO VP' END vp_attuid
, CASE WHEN w.cogs_2_level == 4 THEN w.cogs_2_attuid
       WHEN w.cogs_3_level == 4 THEN w.cogs_3_attuid
       WHEN w.cogs_4_level == 4 THEN w.cogs_4_attuid
       WHEN w.cogs_5_level == 4 THEN w.cogs_5_attuid
       WHEN w.cogs_6_level == 4 THEN w.cogs_6_attuid
       WHEN w.cogs_7_level == 4 THEN w.cogs_7_attuid
       WHEN w.cogs_8_level == 4 THEN w.cogs_8_attuid
       WHEN w.cogs_9_level == 4 THEN w.cogs_9_attuid
       WHEN w.cogs_10_level == 4 THEN w.cogs_10_attuid
       ELSE 'NO AVP' END avp_attuid
, CASE WHEN w.cogs_2_level == 3 THEN w.cogs_2_attuid
       WHEN w.cogs_3_level == 3 THEN w.cogs_3_attuid
       WHEN w.cogs_4_level == 3 THEN w.cogs_4_attuid
       WHEN w.cogs_5_level == 3 THEN w.cogs_5_attuid
       WHEN w.cogs_6_level == 3 THEN w.cogs_6_attuid
       WHEN w.cogs_7_level == 3 THEN w.cogs_7_attuid
       WHEN w.cogs_8_level == 3 THEN w.cogs_8_attuid
       WHEN w.cogs_9_level == 3 THEN w.cogs_9_attuid
       WHEN w.cogs_10_level == 3 THEN w.cogs_10_attuid
       ELSE 'NO Director' END director_attuid
FROM `/Innovation Lab/[Source] Webphone/data/raw_data/stage_webphone_coc` w