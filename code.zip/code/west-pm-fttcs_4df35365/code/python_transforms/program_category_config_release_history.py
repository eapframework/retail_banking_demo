from transforms.api import transform, Output, Input, incremental
from pyspark.sql import functions as F


@incremental(semantic_version=6, snapshot_inputs=['dev', 'rel'])
@transform(
    dev=Input("ri.foundry.main.dataset.a88082cf-51ca-48ad-9f90-912d951b06b1"),
    rel=Input("ri.foundry.main.dataset.7bc2063a-6892-4bf2-8f5b-75c1494e0f72"),
    hist=Output("ri.foundry.main.dataset.4b0f89a6-efc1-4ab1-b0ee-9d50f5d1f8a5"),
)
def my_compute_function(dev, rel, hist, ctx):

    # def my_compute_function(dev, rel, hist):
    # prod_df = dev.dataframe().distinct()
    # prod_df = prod_df.withColumn('ConfigSnapshot_TS', F.lit(F.current_timestamp()))
    # hist.write_dataframe(prod_df)

    # Read the Release changes for Program Category.
    rel_df = rel.dataframe().distinct()

    # check for today release changes (if any)
    rel_df = rel_df.withColumn('TodayDt', F.date_format(F.current_date(), 'MM/dd/yyyy'))
    rel_df = rel_df.filter((F.col('ReleaseDate') == F.col("TodayDt")) & (F.col('IsApproved') == 'Y'))
    # Set the default action as Add for new and update
    rel_df = rel_df.withColumn("RelaseAction", F.when(F.col("RelaseAction").isNull(), F.lit("Add"))
        .otherwise(F.col("RelaseAction")))

    # check for valid Rows
    if rel_df.count() == 0:
        hist.abort()
        return
    else:
        from pyspark.sql.types import StructType, StructField, StringType, IntegerType, TimestampType

        # Define your schema
        schema = StructType([
            StructField('Program', StringType(), nullable=True),
            StructField('Category', StringType(), nullable=True),
            StructField('NationalProgram', StringType(), nullable=True),
            StructField('JobScope', StringType(), nullable=True),
            StructField('Filter', StringType(), nullable=True),
            StructField('Filter_Level', IntegerType(), nullable=True),
            StructField('Rollup', StringType(), nullable=True),
            StructField('Notes', StringType(), nullable=True),
            StructField('CreatedOn', TimestampType(), nullable=True),
            StructField('ModifiedOn', TimestampType(), nullable=True),
            StructField('ConfigSnapshot_TS', TimestampType(), nullable=True),
        ])

        # Read the (current) config changes
        hist_df = hist.dataframe('previous', schema)
        # Get the most recent Snapshot date
        old_df_latest = hist_df.sort("ConfigSnapshot_TS", ascending=False).limit(1).select(F.col("ConfigSnapshot_TS"))

        cols = ['Program', 'Category', 'NationalProgram',
            'JobScope', 'Filter', 'Filter_Level', 'Rollup',
        'Notes', 'CreatedOn', 'ModifiedOn']

        # Get the recent config version
        latest_df = (
            hist_df
            .join(old_df_latest, on=['ConfigSnapshot_TS'], how='inner')
            .select(*cols)
        )

        # Filterout those Release programs
        latest_df = latest_df.join(rel_df, ['Program'], "left_anti")

        # Read the DEV Release changes.
        dev_df = dev.dataframe().distinct()

        # Get the updated program changes from DEV
        dev_df = (
            dev_df.join(rel_df, 'Program', 'inner')
            .select(*cols)
            .where("RelaseAction != 'Delete'")
            .distinct()
        )

        # Merge those Release Changes together
        prod_df = latest_df.unionByName(dev_df, allowMissingColumns=True)

        # final dataframe
        prod_df = prod_df.withColumn('ConfigSnapshot_TS', F.lit(F.current_timestamp()))

        # create the History for the changes
        hist.write_dataframe(prod_df)
