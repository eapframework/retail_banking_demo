from pyspark.sql import functions as F
from transforms.api import Input, Output, transform_df


@transform_df(
    Output("ri.foundry.main.dataset.92eb8aaf-91e8-48d2-ae68-1647ee3d0a1f"),
    multipass_group=Input("ri.foundry.main.dataset.5e6789b0-7de3-40fd-8a07-e923cc2730b0"),
    multipass_user=Input("ri.foundry.main.dataset.dc71055c-0725-45ca-935a-655cf3cf5b41"),
)
def all_multipass_groups(multipass_group, multipass_user):
    df = multipass_group.join(multipass_user, ["user_id"], how="left")
    df = df.withColumn("attuid", F.split(F.col("user_name"), "@").getItem(0))
    df = df.groupBy("group_id", "group_name", "group_realm").agg(
        F.collect_list("user_name").alias("user_list"),
        F.collect_list("attuid").alias("user_list_attuids"),
        F.first(F.col("max_expiration")).alias("max_expiration"),
        F.first(F.col("max_duration_in_seconds")).alias("max_duration_in_seconds"),
    )

    df = df.withColumnRenamed("group_id", "group_rid")
    return df.select(
        "group_rid",
        "group_name",
        "group_realm",
        "user_list",
        "user_list_attuids",
        "max_expiration",
        "max_duration_in_seconds",
    )
