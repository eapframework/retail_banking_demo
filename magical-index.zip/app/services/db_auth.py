"""Shared Databricks SQL connection factory with dual-mode authentication.

Supports two auth modes, selected automatically based on environment variables:

1. **Service Principal (OAuth M2M)** — used for Databricks Apps deployment.
   Requires: DATABRICKS_HOST, DATABRICKS_CLIENT_ID, DATABRICKS_CLIENT_SECRET

2. **Personal Access Token (PAT)** — used for local development.
   Requires: DATABRICKS_HOST, DATABRICKS_TOKEN

Both DeltaStore (app/services/store.py) and the UC provisioning script
(scripts/create_uc_tables.py) import from this module so auth logic is
defined once.
"""
from __future__ import annotations

import os


def get_connection(
    host: str | None = None,
    http_path: str | None = None,
):
    """Return a ``databricks.sql`` connection using the best available auth.

    Parameters are optional; if not supplied they are read from env vars.

    Auth resolution order:
      1. If DATABRICKS_CLIENT_ID and DATABRICKS_CLIENT_SECRET are set →
         service-principal OAuth via ``databricks-sdk Config``.
      2. Else if DATABRICKS_TOKEN is set → PAT-based auth.
      3. Otherwise → raise RuntimeError.
    """
    from databricks import sql as dbsql

    host = host or os.getenv("DATABRICKS_HOST", "")
    http_path = http_path or os.getenv("DATABRICKS_HTTP_PATH", "")

    if not host or not http_path:
        raise RuntimeError(
            "DATABRICKS_HOST and DATABRICKS_HTTP_PATH are required for a "
            "Databricks SQL connection."
        )

    client_id = os.getenv("DATABRICKS_CLIENT_ID")
    client_secret = os.getenv("DATABRICKS_CLIENT_SECRET")

    if client_id and client_secret:
        # Service principal (OAuth M2M) — Databricks Apps deployment
        try:
            from databricks.sdk.core import Config
        except ImportError as exc:
            raise RuntimeError(
                "The databricks-sdk package is required for service-principal "
                "auth. Install it with: pip install databricks-sdk"
            ) from exc

        # Explicitly suppress PAT (token=None) to avoid "more than one
        # authorization method" error when DATABRICKS_TOKEN is also in env.
        cfg = Config(
            host=f"https://{host}" if not host.startswith("https://") else host,
            client_id=client_id,
            client_secret=client_secret,
            token=None,
        )
        return dbsql.connect(
            server_hostname=cfg.host,
            http_path=http_path,
            credentials_provider=lambda: cfg.authenticate,
        )

    # PAT-based auth — local development
    token = os.getenv("DATABRICKS_TOKEN")
    if not token:
        raise RuntimeError(
            "No Databricks credentials found. Set either "
            "DATABRICKS_CLIENT_ID + DATABRICKS_CLIENT_SECRET (service principal) "
            "or DATABRICKS_TOKEN (PAT) in your environment."
        )

    return dbsql.connect(
        server_hostname=host,
        http_path=http_path,
        access_token=token,
    )
