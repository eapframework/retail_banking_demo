# Bruno collection for Magical Index API

Two easy ways to use this with the Bruno VS Code plugin:

- Import from OpenAPI (recommended)
  - In Bruno: Import → OpenAPI
  - URL: http://127.0.0.1:8000/openapi.json
  - This generates all requests directly from the FastAPI spec.

- Import the included Postman collection (Bruno supports Postman v2.1)
  - In Bruno: Import → Postman
  - Select `Magical Index.postman_collection.json`
  - Optionally import environment `Local.postman_environment.json` for `{{baseUrl}}`

## Local environment
- `{{baseUrl}}` defaults to `http://127.0.0.1:8000/api/v1`
- Start the API before running requests:
  - `python -m uvicorn app.main:app --reload`
