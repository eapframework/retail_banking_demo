CREATE TABLE `/Innovation Lab/[ETL] Ticketing/logic/aotsm/aotsm_lk_ticket_touch_instances_unique` AS
    SELECT A.ticket_number
    , A.Modified_Time_1M
    , A.modifying_user
    , A.is_human
    FROM `/Innovation Lab/[ETL] Ticketing/logic/aotsm/aotsm_lk_ticket_touch_instances` A
    LEFT JOIN `/Innovation Lab/[ETL] Ticketing/logic/aotsm/aotsm_lk_ticket_touch_instances` B
    ON A.ticket_number=B.ticket_number
      AND A.modifying_user=B.modifying_user
      AND (A.Modified_Time_1M - interval 1 minute) = B.Modified_Time_1M
      WHERE B.Modified_Time_1M is null
