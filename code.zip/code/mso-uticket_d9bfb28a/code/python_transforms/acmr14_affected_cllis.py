from transforms.api import transform, Input, Output,incremental,configure
from utility.column_clean import clean_columns, lowercase_columns, remove_prefix
from utility.incremental.update_insert import update_insert_core
from pyspark.sql import functions as F
from utility.incremental.timestamp_parsing import perform_timestamp_parsing


# @incremental(semantic_version=2)
@transform(
   out=Output("/Innovation Lab/[Source] Oracle ESAR/data/clean/acmr14_affected_cllis"),
   updates=Input("/Innovation Lab/[Source] Oracle ESAR/data/raw/Prod/snowflake/esaars_dbor_cm_rviews.acmr14_affected_cllis"),
)
def my_compute_function(ctx, out, updates):
    updates = clean_columns(
        updates.dataframe(),
        timestamp_columns=cast_to_timestamp_from_long_columns,
        integer_columns=cast_to_integer_columns,
        datetime_format=datetime_format,
    )

    updates_df = perform_timestamp_parsing(updates)
    for column in float_columns:
        updates_df = updates_df.withColumn(column, updates_df[column].cast("float").alias(column))
    for column in cast_to_integer_columns:
        updates_df = updates_df.withColumn(column, updates_df[column].cast("integer").alias(column))
    # keys = ["request_id"]
    updates_df = lowercase_columns(updates_df)
    # update_insert_core(ctx, out, updates_df, primary_keys=keys, order_cols=["modified_date"])
    out.write_dataframe(updates_df)


date_format = 'yyyy-MM-dd'
datetime_format = 'yyyy-MM-dd HH:mm:ss'
float_columns = [
]
cast_to_integer_columns = ["STATUS"
]
cast_to_timestamp_from_long_columns = [
    "CREATE_DATE",
    "MODIFIED_DATE"
]
