from transforms.api import transform, Input, Output, incremental,configure
from utility.incremental.update_insert import update_insert_core
import logging
from transforms.api import transform, Input, Output, incremental
from utility.column_clean import clean_columns, lowercase_columns, remove_prefix
logger = logging.getLogger(__name__)


@configure(profile=['rubix-eight-executors', 'med-executor-mem'])
@incremental(semantic_version=6)
@transform(
   out=Output("/Innovation Lab/[Source] Oracle ESAR/data/clean/referral_ticket"),
   updates=Input("/Innovation Lab/[Source] Oracle ESAR/data/raw/Prod/snowflake/esaar_tmviews.referral_ticket_snowflake"),
   backfill=Input("ri.foundry.main.dataset.5de1afbd-d7b2-4a45-8a7c-b27e31a516c1"),
)
def my_compute_function(ctx, out, updates, backfill):
    backfill = backfill.dataframe()
    updates = updates.dataframe()
    updates = backfill.unionByName(updates)
    updates_df = clean_columns(
        updates,#.dataframe()
        strip_columns=strip_columns,
        integer_columns=cast_to_integer_columns,
        double_columns=cast_to_double_columns,
        decimal_columns=cast_to_decimal_columns,
        timestamp_columns=cast_to_timestamp_from_long_columns,
        datetime_columns=cast_to_timestamp_columns,
        datetime_format=datetime_format,
        date_columns=cast_to_date_columns,
        date_format=date_format,
        id_columns=cast_to_string_columns,
        integer_from_num_columns=cast_to_integer_from_decimal_columns
    )
    
    updates_df = lowercase_columns(updates_df)
    for c in cast_to_short_columns:
        updates_df = updates_df.withColumn(c, updates_df[c].cast('short'))
    
    keys = ["referral_ticket"]
    df = update_insert_core(ctx, out, updates_df, primary_keys=keys, order_cols=["modified_date"], return_df = True)
    out.write_dataframe(df)

cast_to_short_columns=[]
date_format = 'yyyy-MM-dd'
datetime_format = 'yyyy-MM-dd HH:mm:ss'

cast_to_date_columns = []
cast_to_timestamp_columns = []
cast_to_timestamp_from_long_columns = [] #["MODIFIED_DATE","EXPECTED_CALLBACK_TIME","CLIENT_REFER_DATE","EST_TIME_TO_REPAIR","VENDOR_CONTACTED_TIME","PARENT_NEXT_CHECK_TIME","TICKET_DUE_DATE"
#,"TECH_COMPLETION_DATE","TECH_DISPATCH_DATE","TECH_CLOSED_DATE","VENDOR_DISPATCH_ACK_DATE","LOAD_TS","TT_TROUBLE_REPORTED","TT_TICKET_CLOSED","TT_TICKET_OPENED","TT_LAST_MODIFIED_DATE"]
cast_to_integer_columns = []
cast_to_double_columns = []
cast_to_decimal_columns = ["ADJTIMETOREPAIR","ASSET_TYPE","AUTO_CLOSEABLE_FLAG","AVAYA_PARENT_EBONDED_","BMD_CKT_SVC_CLS","BMD_WORKCENTER_TYPE","BUSIP_INDICATOR","CHRONIC","CIRCUIT_STATUS","CKTBYASSETINDICATOR","CLEARPARENTTA","CLIENT_HD_TYPE"
,"CLIENT_VENDOR_EBOND_UPDATES","COPY_NOTES_TO_LOG","CRITIQUE","CRITIQUE_DISSAT_CODE","CSI","CUSTOMER_CHRONIC",
"D_M_TIME_END","D_M_TIME_START","DEFERRAL_STATUS","DIRECTNBIPVPN","DISPATCH","DISPATCH_AUTHORIZED_CALNET","DSP_SIGNALING",
"EM_EBOND","ESCALATION","HELPDESK_STATUS","INITBY","N_A_TIME_END","N_A_TIME_START","NB_IPVPNINDICATOR","OPTIONAL_REFERRAL_FIELDS",
"PHYSICAL_DISPATCH","POWER_TO_CPE","PREV_MOD_DATE","PREV_TROUBLE_CLEARED","PROVIDER_CONTROL_INDICATOR","RECENT_INSTALLATION",
"REF_SEARCH_FLAG","REFERRAL_MODE","REPAIR_D_M_TIME_MIN","REPAIR_N_A_TIME_MIN","REPEAT_TROUBLE","REPORTED_REQUEST_TYPE",
"REPT_SVC_LINE_CD","RESOL_ACTION_CD","RESOL_ITEM_CD","RESOL_SVC_LINE_CD","RESOLUTIONBYPASSLEVEL","RESTORE_D_M_TIME__MIN",
"RESTORE_N_A_TIME__MIN","ROOT_CAUSE_CD","SA_REQUEST_INDICATOR","SCHEDULE_LATER_DATE","SERVICE_RESTORED_DATE","SEVERITY",
"SPECIAL_ATTENTION","SS_ACTIVITY_TYPE","STATE","SVC_COMP_CD","TAPROCESS","TERMINAL_STATE","TICKET_ROLE","TIME_TO_ARRIVE",
"TIME_TO_ARRIVE_UNADJ","TMP_ASSETID_NUM","TMP_CRITIQUED","TMP_LEVEL","TOTAL_D_M_TIME_MIN","TOTAL_N_A_TIME_MIN","TOTAL_RETRY_COUNT",
"TROUBLE_REPORTED_LEVEL_3_CODE","TROUBLE_REPT_CD","TROUBLEREPORTSTATUS","TSP","TTRINDEX","UNRESOLVED_INDICATOR","VENDOR_MEET_FLAG",
"VENDOR_TICKET_OPENED_DATE","WF_COMBLOGLGTH","WF_CUSTLOGLGTH","WF_INTLOGLGTH","WF_MFABLOGLGTH","ZBMPREFFLAG","ZBMPTICKETCHECK"]
cast_to_string_columns = []
cast_to_integer_from_decimal_columns = []
strip_columns = []