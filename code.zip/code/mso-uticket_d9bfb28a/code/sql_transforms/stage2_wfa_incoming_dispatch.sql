CREATE TABLE `ri.foundry.main.dataset.394e0874-dbcd-4e44-bedc-6c8e8fc2744f` AS
    SELECT POOL.*
    , cause_code_list_in
    , trbl_fnd_cd_list_in
    , trbl_fnd_desc_in
    , cause_code_list_out
    , trbl_fnd_cd_list_out
    , trbl_fnd_desc_out
    FROM `ri.foundry.main.dataset.e4ccb37f-3d08-4b23-85d9-06027b30a7fa` POOL
    FULL OUTER JOIN `ri.foundry.main.dataset.1150117d-75c0-4b0b-b9ed-9d092a86931c` DPO
    ON POOL.ext_key1=DPO.ext_key1
    FULL OUTER JOIN `ri.foundry.main.dataset.c1d5c184-621d-4729-9ab9-2c5458af5816` DPI
    ON DPO.ext_key1=DPI.ext_key1
    WHERE POOL.ext_key1 is not null
    