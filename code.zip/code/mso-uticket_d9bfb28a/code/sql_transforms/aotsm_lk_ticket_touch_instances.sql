CREATE TABLE `/Innovation Lab/[ETL] Ticketing/logic/aotsm/aotsm_lk_ticket_touch_instances` AS
SELECT ticket_number
, date_trunc('minute',new_date_time) Modified_Time_1M
, modifying_user
, CASE WHEN first(LK_MECH.id) is not null then 0
       WHEN modifying_user REGEXP '^[a-zA-Z][a-zA-Z][0-9][0-9][0-9][0-9a-zA-Z]$' THEN 1 ELSE 0 END is_human
FROM `/Innovation Lab/[ETL] Ticketing/data/clean/AOTSM_ALL_TROUBLE_TICKET_METRICS_CLEAN` M
LEFT JOIN `/Innovation Lab/[ETL] Ticketing/data/lookup/lk_nonhuman_users - values` LK_MECH
on M.modifying_user=LK_MECH.id
GROUP BY ticket_number, modifying_user, date_trunc('minute',new_date_time)
ORDER BY ticket_number, date_trunc('minute',new_date_time)