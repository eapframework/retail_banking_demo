# Extracted Code Files — MSO uTicket Lineage

Extracted from `mso-uticket_d9bfb28a/code` based on the 31 user_rids in `validate_lineage.py` and the lineage image.

## RID → Code File Mapping

### Python Transforms (12 files)

| RID | Type | File | Role |
|---|---|---|---|
| `...0000097e...` | PythonTransformation | `MSO_AOTS_CM_OpenTickets.py` | OUTPUT (mso_aotscm_open_tickets) |
| `...00f4b171...` | PythonTransformation | `MSO_AOTS_CM_ClosedTickets.py` | OUTPUT (mso_aotscm_closed_tickets) |
| `...798ba39c...` | PythonTransformation | `cmclosed_tasks.py` | OUTPUT (cmclosed_tasks) |
| `...87be04bd...` | PythonTransformation | `cmclosed_notasks.py` | OUTPUT (cmclosed_notasks) |
| `...515f79aa...` | PythonTransformation | `chg_change.py` | OUTPUT (chg_change clean) |
| `...d59e3472...` | PythonTransformation | `chg_task.py` | OUTPUT (chg_task clean) |
| `...ae0545f5...` | PythonTransformation | `ars_dbor_cm_r1_acmr23_mobility_equipment_info.py` | OUTPUT |
| `...365744b9...` | PythonTransformation | `acmr14_affected_cllis.py` | OUTPUT |
| `...071983e5...` | PythonTransformation | `acmr14_affected_techs.py` | OUTPUT |
| `...60bb71df...` | PythonTransformation | `ars_dbor_cm_r1_ap_signature.py` | OUTPUT |
| `...fbcca57c...` | PythonTransformation | `ars_dbor_cm_r1_ap_detail.py` | OUTPUT |
| N/A | Shared Utility | `utility.py` | Shared helper (column_clean, incremental) |

### SQL Transforms (1 file)

| RID | Type | File | Role |
|---|---|---|---|
| `...a306bde0...` | SqlTransformation | `ap_signature.sql` | OUTPUT (ap_signature) |

## RIDs Without Code (19 of 31)

### Contour Dashboards (no code — interactive UI)
- `...b22912bc...` — Contour (input to MSO_AOTS_CM_OpenTickets.py)
- `...42820dd4...` — Contour (input to MSO_AOTS_CM_ClosedTickets.py)
- `...46d229a0...` — Contour (input to cmclosed_tasks.py)
- `...064b7d50...` — Contour (input to cmclosed_notasks.py)

### Raw Datasets (no code — Magritte ingestion)
- `...573ddb29...` — RawDataset (esaars_dbor_cm_rviews.chg_task_snowflake)
- `...b06d7a0a...` — RawDataset (esaars source)
- `...df8c4c2b...` — RawDataset (esaars source)
- `...56407dc5...` — RawDataset (esaars_dbor_cm_rviews.ap_detail_snowflake)
- `...d46d7eda...` — RawDataset (esaars source)
- `...e8409bca...` — RawDataset
- `...b541996c...` — RawDataset (chg_change_snowflake, input to chg_change.py)
- `...19b1503a...` — RawDataset (acmr23 equipment raw, input to acmr23.py)

### Magritte Infrastructure (no code — UI configured)
- `ri.magritte..agent.ef60021d...` — MagritteAgent
- `ri.magritte..agent.ba489249...` — MagritteAgent
- `ri.magritte..agent.5fd879bb...` — MagritteAgent
- `ri.magritte..source.ba31895a...` — DataSource (Oracle ESAR)
