from transforms.api import transform_df, Input, Output
# import pyspark.sql.functions as F


@transform_df(
    Output("ri.foundry.main.dataset.47ddd356-8e2b-44b5-876f-6e5ccdb43d84"),
    tg=Input("ri.foundry.main.dataset.84af4d6b-876f-42c4-9f05-95a78ace9fd3"),
)
def my_compute_function(tg):
    return tg
