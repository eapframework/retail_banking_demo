""" Description: WS Task Details Clean
    BRD Level: Internal, NOT included on landing page

LOG:
    Date          | Author   | Description
    12-02-2024    | an4927   | code cleanup for uniform syntax and commenting
    -             | -        | -
    -             | -        | -
"""


from pyspark.sql import functions as F
from pyspark.sql.functions import col, when, row_number
from transforms.api import transform, Output, Input
from pyspark.sql.window import Window


@transform(
    out=Output("ri.foundry.main.dataset.052f1932-3d72-4c3f-9aef-5a34880d7925"),
    Tsk=Input("ri.foundry.main.dataset.02ef14fa-b8fe-43b9-9c99-5deede1454e5"),
    prog_cat=Input("ri.foundry.main.dataset.30950e66-179c-4b47-8d2c-332399b45faf"),
)
def my_compute_function(out, Tsk, prog_cat):
    t1 = Tsk.dataframe()

    windowSpec = Window.partitionBy("IWM_JOB_NUMBER", "TASK_MILESTONE_CODE",
            "PREDECESSOR_TASK_AND_STATUS").orderBy(col("LAST_MODIFIED_TS").desc())
    t1 = t1.withColumn("ROW_NUM", row_number().over(windowSpec))
    t1 = t1.filter(col("ROW_NUM") == 1).drop("ROW_NUM")

    # Concatenate predecessor tasks and statuses column
    df_pred = t1.groupBy("IWM_JOB_NUMBER", "TASK_MILESTONE_CODE", "HD_MET").agg(F.concat_ws("; ",
            F.collect_set(t1.PREDECESSOR_TASK_AND_STATUS)).alias("PREDECESSOR_TASK_AND_STATUS"))
    t1 = t1.drop("PREDECESSOR_TASK_AND_STATUS")
    t1 = t1.join(df_pred, ["IWM_JOB_NUMBER", "TASK_MILESTONE_CODE", "HD_MET"], 'left')
    t1 = t1.withColumn("PREDECESSOR_TASK_AND_STATUS",
            when(col("PREDECESSOR_TASK_AND_STATUS") == "", None).otherwise(col("PREDECESSOR_TASK_AND_STATUS")))
    df_tsk = t1.select(F.col("*")).distinct()

    # PROGRAM CATEGORY code
    prog_cat = prog_cat.dataframe()
    prog_cat = prog_cat.select(F.col('iwm_number').alias('IWM_JOB_NUMBER'),
                               F.col('program').alias('PROGRAM'),
                               F.col('category').alias('CATEGORY'))
    df_tsk = df_tsk.join(prog_cat,['IWM_JOB_NUMBER'], 'left')
    df_tsk = df_tsk.filter(F.col('WORKORDER_STATUS') != F.lit('FORCE_CLOSED'))

    # df_tsk = df_tsk.fillna({"HD_MET": "NA"})
    df_tsk = df_tsk.withColumn("TASK_MILESTONE_ENQUEUE_STATUS",
            when(col("TASK_MILESTONE_ENQUEUE_STATUS") == 'FAILURE', None)
            .otherwise(col("TASK_MILESTONE_ENQUEUE_STATUS")))

    # # Cast a list of columns to timestamp type
    columns_to_ts = ["LAST_MODIFIED_TS", "SF_DEEP_SYNC_TS", "LATEST_UPDATE_TS"]
    df_tskf = (
        df_tsk
        .select(
            *(c for c in df_tsk.columns if c not in columns_to_ts),
            *(F.from_unixtime(col(c) / 1000).cast("timestamp").alias(c) for c in columns_to_ts))
        )

    out.write_dataframe(df_tskf)
