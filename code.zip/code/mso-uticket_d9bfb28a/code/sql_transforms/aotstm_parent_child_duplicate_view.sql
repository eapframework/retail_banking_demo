CREATE TABLE `/Innovation Lab/[ETL] Ticketing/data/clean/aotstm_parent_ie_duplicate_view` TBLPROPERTIES (foundry_transform_profiles = 'EXECUTOR_MEMORY_MEDIUM')AS
    SELECT MAIN.*
    , IE.ticket ie_ticket
    , IE.distinct_humans ie_distinct_humans
    , IE.distinct_active_org ie_distinct_active_org
    , IE.distinct_supervisor_name ie_distinct_supervisor_name
    , IE.distinct_director_name ie_distinct_director_name
    , IE.distinct_avp_name ie_distinct_avp_name
    , IE.distinct_vp_name ie_distinct_vp_name
    , IE.distinct_svp_name ie_distinct_svp_name
    , IE.distinct_vp_org_name ie_vp_org_name
    , IE.first_activated ie_first_activated
    , IE.updated_by ie_updated_by
    , IE.asset_id ie_asset_id
    , IE.parent_ticket ie_parent_ticket
    , IE.ticket_state ie_ticket_state
    , IE.restore_duration ie_restore_duration
    , IE.last_modified_by ie_last_modified_by
    , IE.first_activated_by ie_first_activated_by
    , IE.problem_abstract ie_problem_abstract
    , IE.first_canceled_by ie_first_canceled_by
    , IE.first_closed_by ie_first_closed_by
    , IE.ticket_source ie_ticket_source
    , IE.init_sev ie_init_sev
    , IE.client_id ie_client_id
    , IE.ticket_closed_date_utc ie_ticket_closed_date_utc
    , IE.ticket_opened_date_utc ie_ticket_opened_date_utc
    , IE.resol_action_desc_tx ie_resol_action_desc_tx
    , IE.service_restored_date ie_service_restored_date
    , IE.resolution_set_name ie_resolution_set_name
    , IE.last_human_touch ie_last_human_touch
    , IE.last_auto_touch ie_last_auto_touch
    , IE.ticket_role_description ie_ticket_role_description
    , IE.sub_root_cause_desc_tx ie_sub_root_cause_desc_tx
    , IE.handover_text ie_handover_text
    , IE.time_to_restore_reported ie_time_to_restore_reported
    , IE.total_human_touches ie_total_human_touches
    , IE.trouble_reported_date_utc ie_trouble_reported_date_utc
    , IE.resolution_text ie_resolution_text
    , IE.total_auto_touches ie_total_auto_touches
    , IE.work_queue ie_work_queue
    , IE.human_pathway ie_human_pathway
    , IE.rept_svc_line_desc_tx ie_rept_svc_line_desc_tx
    , IE.end_user_name ie_end_user_name
    , IE.first_cleared_by ie_first_cleared_by
    , IE.event_class ie_event_class
    , IE.severity ie_severity
    , IE.first_auto_touch ie_first_auto_touch
    , IE.root_cause_desc_tx ie_root_cause_desc_tx
    , IE.managing_org ie_managing_org
    , IE.ticket_type_desc_tx ie_ticket_type_desc_tx
    , IE.active_org ie_active_org
    , IE.first_human_attuid ie_first_human_attuid
    , IE.work_driver_type ie_work_driver_type
    , IE.agent_id ie_agent_id
    , IE.first_human_touch ie_first_human_touch
    , IE.mttr ie_mttr
    , IE.Manual_Touch_Category ie_manual_touch_category
    , IE.Automation_Touch_Category ie_automation_touch_category
    , IE.current_center_l1_area ie_center
    FROM `/Innovation Lab/[ETL] Ticketing/data/clean/AOTSTM_TICKET_CLEAN_STAGE` IE
    LEFT JOIN `/Innovation Lab/[ETL] Ticketing/data/clean/AOTSTM_TICKET_CLEAN_STAGE` MAIN
    on IE.parent_ticket=MAIN.ticket
    WHERE IE.parent_ticket is not null 
    AND IE.ticket_role_description='Internal Engagement'
    AND MAIN.ticket_role_description='Main'