CREATE TABLE `ri.foundry.main.dataset.2d138c2f-c871-45b5-b139-696eb5ab44e2` AS
    SELECT concat(
       CASE when site in ('K', 'I48') then 'WAL'
       when site in ('I', 'CAC') then 'WCA'
       when site in ('E') then 'WCT'
       when site in ('G', 'GAC') then 'WGA'
       when site in ('L') then 'WIL'
       when site in ('N') then 'WIN'
       when site in ('X', 'LMC') then 'WLM'
       when site in ('M') then 'WMI'
       when site in ('C') then 'WMW'
       when site in ('V', 'NFC') then 'WNF'
       when site in ('O') then 'WOH'
       when site in ('H') then 'WPN'
       when site in ('S') then 'WPS'
       when site in ('F', 'SFC') then 'WSF'
       when site in ('Y', 'TNC') then 'WTN'
       when site in ('T') then 'WTX'
       when site in ('W') then 'WWI'
       when site in ('R', 'A') then 'WYX'
       else 'TBD' end,
       ext_key1,
        DATE_FORMAT(
            (first_entry_ts), 
            'MM/dd/YYYY HH:mm'
        )
    ) as ticket_number_unique
    , concat(
       CASE when site in ('K', 'I48') then 'WAL'
       when site in ('I', 'CAC') then 'WCA'
       when site in ('E') then 'WCT'
       when site in ('G', 'GAC') then 'WGA'
       when site in ('L') then 'WIL'
       when site in ('N') then 'WIN'
       when site in ('X', 'LMC') then 'WLM'
       when site in ('M') then 'WMI'
       when site in ('C') then 'WMW'
       when site in ('V', 'NFC') then 'WNF'
       when site in ('O') then 'WOH'
       when site in ('H') then 'WPN'
       when site in ('S') then 'WPS'
       when site in ('F', 'SFC') then 'WSF'
       when site in ('Y', 'TNC') then 'WTN'
       when site in ('T') then 'WTX'
       when site in ('W') then 'WWI'
       when site in ('R', 'A') then 'WYX'
       else 'TBD' end,
       ext_key1,
        entry_year
    ) as join_key
    , ext_key1
    , cause_code_list_out
    , trbl_fnd_cd_list_out
    , trbl_fnd_desc_out
    FROM
    (
    SELECT ext_key1
    , site
    , year(askme_creat_ts) entry_year
    , min(askme_creat_ts) first_entry_ts
    , count(distinct askme_creat_ts) distinct_entries
    , concat_ws(",", collect_set(cast(cast(caus_cd as integer) as string))) cause_code_list_out
    , concat_ws(",", collect_set(cast(cast(trbl_fnd_cd as integer) as string))) trbl_fnd_cd_list_out
    , concat_ws(",", collect_set(trbl_fnd_desc)) trbl_fnd_desc_out
    FROM `ri.foundry.main.dataset.a3ee0d5c-7903-483c-82c8-370b37eeb678`
    WHERE lower(ext_key1) REGEXP '^[a-z][a-z][0-9][0-9][0-9][0-9][0-9][0-9]$|[0-9a-z][0-9a-z][0-9a-z][0-9a-z][0-9a-z][0-9a-z][0-9a-z][0-9a-z][0-9a-z]'
    GROUP BY
    ext_key1
    , site
    , year(askme_creat_ts)
    )