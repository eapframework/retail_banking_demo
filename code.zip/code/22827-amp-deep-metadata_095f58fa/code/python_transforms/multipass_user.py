from transforms.api import transform, Input, Output
from pyspark.sql.functions import col, explode
from pyspark.sql import functions as F, Window


@transform(
    multipass_user=Output("ri.foundry.main.dataset.dc71055c-0725-45ca-935a-655cf3cf5b41"),
    user_attributes=Output("ri.foundry.main.dataset.2d5fceb3-f92a-4cb1-bc22-e8232e96f93a"),
    multipass_user_raw=Input("ri.foundry.main.dataset.3f14d1f4-59f0-471d-be56-9b003f89ad88")
)
def clean_multipass_user(multipass_user, user_attributes, multipass_user_raw):

    user = multipass_user_raw.dataframe()
    multipass_user_df = (
        user
        .select(
            user["id"].alias("user_id"),
            user["username"].alias("user_name"),
            user["attributes"].getItem("multipass:realm").getItem(0).alias("user_realm"),
            user["attributes"].getItem("multipass:email:primary").getItem(0).alias("email_address"),
            user["attributes"].getItem("multipass:given-name").getItem(0).alias("given_name"),
            user["attributes"].getItem("multipass:family-name").getItem(0).alias("family_name")
        )
        .withColumn("realm_rank", F.when(F.col("user_realm") == "sso", 0).otherwise(1))
    )

    window = (
        Window()
        .partitionBy(["user_name"])
        .orderBy(F.col("realm_rank").asc(), F.col("family_name").desc())
    )
    multipass_user_df = (
        multipass_user_df
        .withColumn("temp_rank", F.row_number().over(window))
        .filter(F.col("temp_rank") == 1)
        .drop("temp_rank", "realm_rank")
        .distinct()
    )
    multipass_user.write_dataframe(multipass_user_df)

    user_attributes.write_dataframe(
        user.select(
            col("id").alias("user_id"),
            col("username").alias("user_name"),
            explode("attributes").alias("attribute_name", "attribute_values")
        ).select(
            col("user_id"),
            col("user_name"),
            col("attribute_name"),
            explode("attribute_values").alias("attribute_value")
        )
    )
