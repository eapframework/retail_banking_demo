# Project Inventory Summary

**Project name:** [ETL] Tirks Combined

**Merge timestamp:** 2026-03-17T10:50:01.750178

**Project output dir:** `tirks-combined_c2c544d9`

**Total resources in project folder:** 31

**Total merged records:** 136

**Unresolved (project_only) resources:** 0

## Resource Counts by Type

- **blobsterpdf:** 1
- **codeworkbookdataset:** 1
- **contouranalysis:** 3
- **datasource:** 3
- **foundrydataset:** 1
- **magritteagent:** 3
- **networkegresspolicy:** 4
- **pythontransformation:** 69
- **rawdataset:** 49
- **vectorworkbook:** 1
- **virtualtable:** 1

## Mode

Flat output — workshop subdirectories removed after merge.
