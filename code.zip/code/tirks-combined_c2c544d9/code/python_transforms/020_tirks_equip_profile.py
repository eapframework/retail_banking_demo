from transforms.api import transform_df, Input, Output


@transform_df(
    Output("ri.foundry.main.dataset.c9bf8b0d-4c1b-4594-8f54-1ef86a7d67ef"),
    profile_a=Input("ri.foundry.main.dataset.a2f17218-8684-418f-8d41-10b09285b72b"),
    profile_b=Input("ri.foundry.main.dataset.52353bc5-a7e7-4a95-8cfb-ebae6c9494f0"),
)
def my_compute_function(profile_a, profile_b):
    def prep(df):
        return (df
                .withColumnRenamed('human_equip_catalog_item_cd', 'heci')
                .withColumnRenamed('equipment_location_clli_cd', 'clli')
                )
    profile_a = prep(profile_a)
    profile_b = prep(profile_b)
    profile_a = (profile_a
                 .drop('data_dt')
                 .drop('rec_type')
                 .drop('load_ts')
                 )
    return profile_a.unionByName(profile_b)
