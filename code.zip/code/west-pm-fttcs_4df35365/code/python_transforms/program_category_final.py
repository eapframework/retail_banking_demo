from transforms.api import transform, Output, Input, configure
from pyspark.sql import functions as F

SPARK_PROFILES = [
        'DRIVER_MEMORY_EXTRA_EXTRA_LARGE',
        'DRIVER_CORES_LARGE',
        'EXECUTOR_MEMORY_LARGE',
        'EXECUTOR_CORES_LARGE',
        'NUM_EXECUTORS_32',
        'EXECUTOR_MEMORY_OVERHEAD_LARGE',
        'DYNAMIC_ALLOCATION_DISABLED'
]


@configure(profile=SPARK_PROFILES)
@transform(
    # replace this with your output dataset path
    out=Output("ri.foundry.main.dataset.30950e66-179c-4b47-8d2c-332399b45faf"),
    outunpivot=Output("ri.foundry.main.dataset.82c096b8-c307-4eac-bf2f-5cbb24cf6f15"),
    progcat_sites_lvl_2=Input("ri.foundry.main.dataset.abbd3a7d-c765-44d8-b65f-60a8f49abe99"),
    outinternal_lvl_1=Input("ri.foundry.main.dataset.45d4e145-6d09-4832-a86d-d1a7559f97d7"),
    progcat_mapping_allinone=Input("ri.foundry.main.dataset.e2d8d814-aab3-4b34-ab6f-df4105884894"),
    )
def my_compute_function(ctx, progcat_sites_lvl_2, outinternal_lvl_1, progcat_mapping_allinone,
                        out, outunpivot):

    # Get IWM Details with Sites Tagging columns from Step_2
    # Overall Level 1 Changes
    outinternal_lvl_1_df = outinternal_lvl_1.dataframe()

    # Overall Level 2 Changes
    progcat_sites_lvl_2_df = progcat_sites_lvl_2.dataframe()

    # Grap MPT AllInOne config changes
    progcat_mapping_allinone_df = progcat_mapping_allinone.dataframe()

    # Get the program details
    program_df = progcat_mapping_allinone_df.select(F.col("Program").alias("program"),
            F.col("Category").alias("category")).distinct()

    # merge the results (level1 and level2)
    progcat_df2 = outinternal_lvl_1_df.unionByName(progcat_sites_lvl_2_df, allowMissingColumns=True)

    # Get the Internal details
    out_df = progcat_df2.join(program_df, "program", "left")\
                   .select('program', 'iwm_number', 'category').distinct()\
                   .where("(program is not null or category is not null)")

    out_df_1 = out_df.select(F.col("program").alias("PROGRAM"),
                             F.col("iwm_number").alias("IWM_NUMBER"),
                             F.col("category").alias("CATEGORY"))
    outunpivot.write_dataframe(out_df_1)

    # prepare categories and LISTAGG Programs and Categories
    out_df = out_df.groupBy("iwm_number") \
                   .agg(
                        F.concat_ws(" | ", F.collect_set("program")).alias("program"),
                        F.concat_ws(" | ", F.collect_set("category")).alias("category")
                    )

    if (out_df.count() == 0):
        out.abort()
    else:
        out.write_dataframe(out_df)
