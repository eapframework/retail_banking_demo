import os, re

user_rids = [
'ri.magritte..agent.ef60021df9511431d161a78f82ff07c24831681aa7f62a4b42b48ab22f29d195',
'ri.magritte..agent.ba489249e0847135a18b1970578b0b51cc0debd082a74dd330601763e8e16167',
'ri.magritte..agent.5fd879bb4672f6462b63e829a95fa32633a349a14b392b95b0fbf927f35c8d58',
'ri.magritte..source.ba31895a-153c-488b-9723-3aab067bc41e',
'ri.foundry.main.dataset.46d229a0-80dd-484a-97b8-600e978dba7e',
'ri.foundry.main.dataset.0000097e-561e-451b-b7da-3466116b304a',
'ri.foundry.main.dataset.42820dd4-81ca-4efa-9bab-0350946208fc',
'ri.foundry.main.dataset.b22912bc-1f34-4a4f-85cb-1a7e87a0fbe2',
'ri.foundry.main.dataset.00f4b171-d182-43c5-bf93-414312dd9393',
'ri.foundry.main.dataset.064b7d50-842a-487a-accf-ae54cfb8abe2',
'ri.foundry.main.dataset.7a1285bd-ad45-424a-86ec-9c333d4a7872',
'ri.foundry.main.dataset.798ba39c-56f0-4099-9ed0-c178539a43fb',
'ri.foundry.main.dataset.87be04bd-5cbe-416e-8a26-3630492a8c97',
'ri.foundry.main.dataset.3d9b732c-060b-4075-b3c1-b7681b117fd3',
'ri.foundry.main.dataset.4b7051a7-8404-4145-b552-3e583304aa76',
'ri.foundry.main.dataset.573ddb29-8fe9-4198-9b62-f35d9b543559',
'ri.foundry.main.dataset.d59e3472-db57-47c2-ab46-176f23a26476',
'ri.foundry.main.dataset.a306bde0-7a8f-45a4-a431-c5d85903b856',
'ri.foundry.main.dataset.60bb71df-34a1-4b8c-b452-6511a4a28d45',
'ri.foundry.main.dataset.fbcca57c-9463-47d7-875e-7110296181f8',
'ri.foundry.main.dataset.365744b9-deef-4449-8e82-2e1be8690df1',
'ri.foundry.main.dataset.b06d7a0a-727e-4e9b-9fc2-781b942fbcc0',
'ri.foundry.main.dataset.b541996c-95a1-4b52-9753-055b78c5d2b2',
'ri.foundry.main.dataset.515f79aa-80bc-4973-9d9e-ce42ed412d05',
'ri.foundry.main.dataset.df8c4c2b-cdcf-40c5-92e2-dd0eaaf08856',
'ri.foundry.main.dataset.19b1503a-ffbf-4c9d-8381-b65db7da23dd',
'ri.foundry.main.dataset.56407dc5-dbab-44f1-9236-5de89b7702ab',
'ri.foundry.main.dataset.d46d7eda-cf1a-4326-b0cf-99d6f7533802',
'ri.foundry.main.dataset.071983e5-e8b6-47ea-833e-a39b32284633',
'ri.foundry.main.dataset.e8409bca-d1ed-4a40-9aa9-f8c95ca22ef3',
'ri.foundry.main.dataset.ae0545f5-c03b-4292-961d-2e7459397e95',
]
user_rids_set = set(r.strip() for r in user_rids)

# Load lineage for type info
import json
with open(r'c:\deep-otis\wave-1\code\mso-uticket_d9bfb28a\lineage\lineage.json') as f:
    lg = json.load(f)
rid_type = {n['rid']: (n['resource_type'], n.get('depth','?')) for n in lg['nodes']}

# Scan code
code_dir = r'c:\deep-otis\wave-1\code\mso-uticket_d9bfb28a\code'
rid_to_files = {}
for root, _, files in os.walk(code_dir):
    for fname in files:
        if not fname.endswith(('.py','.sql')): continue
        fpath = os.path.join(root, fname)
        content = open(fpath, encoding='utf-8', errors='ignore').read()
        found_rids = set(re.findall(r'ri\.foundry\.main\.dataset\.[0-9a-f-]+', content))
        # check Input/Output role
        for rid in found_rids:
            if rid not in rid_to_files:
                rid_to_files[rid] = []
            # determine role
            if ('Output(\"' + rid + '\"') in content:
                role = 'OUTPUT'
            elif ('Input(\"' + rid + '\"') in content:
                role = 'INPUT'
            elif 'CREATE TABLE' in content and ('`' + rid + '`') in content:
                role = 'OUTPUT(SQL)'
            else:
                role = 'REF'
            rid_to_files[rid].append((fname, role))

# Also check path-based refs
path_rids = {}
for root, _, files in os.walk(code_dir):
    for fname in files:
        if not fname.endswith(('.py','.sql')): continue
        fpath = os.path.join(root, fname)
        content = open(fpath, encoding='utf-8', errors='ignore').read()
        for path in re.findall(r'\"(/Innovation Lab/[^\"]+)\"', content):
            path_rids.setdefault(path, []).append(fname)

print('='*80)
print('RID CROSS-REFERENCE: Your 31 RIDs vs Code Files')
print('='*80)

matched_count = 0
unmatched = []
for rid in user_rids:
    rtype, depth = rid_type.get(rid, ('?','?'))
    short = rid.split('.')[-1][:8] if 'dataset' in rid else rid.split('.')[-1][:16]
    files = rid_to_files.get(rid, [])
    if files:
        matched_count += 1
        file_str = ', '.join(f'{f}[{r}]' for f,r in files)
        print(f'MATCH  d={depth} {rtype:25s} {short}  =>  {file_str}')
    else:
        unmatched.append((rid, rtype, depth, short))

print()
print(f'MATCHED: {matched_count} / {len(user_rids)}')
print()
if unmatched:
    print('--- NO CODE MATCH ---')
    for rid, rtype, depth, short in unmatched:
        print(f'  d={depth} {rtype:25s} {rid}')
 