CREATE TABLE `/Innovation Lab/[ETL] Ticketing/logic/aotstm/aotstm_lk_ticket_touch_instances_unique` AS
    SELECT distinct A.ticket_number
    , A.Modified_Time_1M
    , A.active_org
    , A.work_queue
    , A.adj_mod_user
    , A.is_human
      FROM `/Innovation Lab/[ETL] Ticketing/data/clean/aotstm_lk_ticket_touch_instances` A
      LEFT JOIN `/Innovation Lab/[ETL] Ticketing/data/clean/aotstm_lk_ticket_touch_instances` B
      ON A.ticket_number=B.ticket_number
      AND A.active_org=B.active_org
      AND A.work_queue=B.work_queue
      AND A.adj_mod_user=B.adj_mod_user
      AND (A.Modified_Time_1M - interval 1 minute) = B.Modified_Time_1M
      WHERE B.Modified_Time_1M is null
