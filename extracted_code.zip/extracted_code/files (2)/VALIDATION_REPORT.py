# ════════════════════════════════════════════════════════════════════════════
# MSO uTicket DLT Conversion — VALIDATION REPORT
# Validated: 2026-03-22
# ════════════════════════════════════════════════════════════════════════════

# ┌─────────────────────────────────────────────────────────────────────────┐
# │                        VALIDATION SUMMARY                               │
# ├─────────────────────────────────────────────────────────────────────────┤
# │  Total checks:           15                                             │
# │  ✅ PASS:                12                                             │
# │  ⚠️ MINOR ISSUE:         2                                             │
# │  ❌ BUG FOUND:           1                                             │
# └─────────────────────────────────────────────────────────────────────────┘


# ════════════════════════════════════════════════════════════════════════════
# ❌ BUG #1: apsig_request column missing alias
# Severity: MEDIUM — will cause missing column in gold output
# ════════════════════════════════════════════════════════════════════════════
#
# Location: 03_gold_contour_analytics.py → _build_base_joined()
#
# The apsig join selects F.col("request") WITHOUT aliasing it as "apsig_request".
# The Contour's join prefix is "apsig", and the gold kept_columns list references
# "apsig_request". Since the column isn't aliased, it stays as "request" in the
# DataFrame, and the defensive select(available) will silently skip "apsig_request".
#
# FIX REQUIRED:
#   Change in _build_base_joined(), apsig section:
#
#   BEFORE:
#     apsig = dlt.read("silver_ap_signature_enriched").select(
#         F.col("request"),
#         F.col("approver_signature").alias("apsig_approver_signature"),
#         ...
#     )
#     chg = chg.join(apsig, chg.change_id == apsig.request, "left")
#
#   AFTER:
#     apsig_raw = dlt.read("silver_ap_signature_enriched")
#     apsig = apsig_raw.select(
#         F.col("request"),  # keep unaliased for join condition
#         F.col("approver_signature").alias("apsig_approver_signature"),
#         F.col("role").alias("apsig_role"),
#         F.col("approval_status").alias("apsig_approval_status"),
#     )
#     chg = chg.join(apsig, chg.change_id == apsig.request, "left")
#     chg = chg.withColumnRenamed("request", "apsig_request")
#
#   OR simpler approach — alias after join:
#     chg = chg.join(apsig, chg.change_id == apsig.request, "left") \
#              .drop("request") \
#              .withColumn("apsig_request", F.col("change_id"))
#     (Since request = change_id by join condition)


# ════════════════════════════════════════════════════════════════════════════
# ⚠️ MINOR ISSUE #1: status CASE WHEN default value difference
# Severity: LOW — no practical impact
# ════════════════════════════════════════════════════════════════════════════
#
# Contour status CASE WHEN has NO ELSE clause → unmatched returns NULL
# DLT map_status() uses default='Unknown' → unmatched returns 'Unknown'
#
# Impact: None in practice, because status is always filtered to known values
# (0-6 for open, 7-8 for closed) BEFORE the mapping is applied.
# Any unmatched status code would indicate a data quality issue.
#
# Optional fix: Change map_status call to use default=None:
#   map_status("status", STATUS_MAP, None)


# ════════════════════════════════════════════════════════════════════════════
# ⚠️ MINOR ISSUE #2: .distinct() added to ap_detail subquery
# Severity: LOW — likely no row count difference
# ════════════════════════════════════════════════════════════════════════════
#
# Location: 02_silver_transforms.py → silver_ap_signature_enriched()
#
# DLT adds .distinct() to the ap_detail subquery:
#   ap_dtl = dlt.read("clean_ap_detail").select("request", "approval_id").distinct()
#
# Original SQL has no DISTINCT:
#   SELECT request, approval_id FROM clean_ap_detail
#
# Since ap_detail has PK (approval_id, seqno), multiple seqno values per
# approval_id are possible. Without DISTINCT, the JOIN produces row fanout.
# With DISTINCT, it collapses duplicate (request, approval_id) pairs.
#
# In practice, all seqno variants for the same approval_id have the same
# "request" value, so DISTINCT on (request, approval_id) produces identical
# rows to without DISTINCT. The result set is therefore the same.
#
# Optional fix: Remove .distinct() for exact fidelity:
#   ap_dtl = dlt.read("clean_ap_detail").select("request", "approval_id")


# ════════════════════════════════════════════════════════════════════════════
# ✅ VALIDATED ITEMS (all passed)
# ════════════════════════════════════════════════════════════════════════════
#
# 1. LINEAGE EDGES (7 bronze→silver, 1 silver→silver, 4 silver→gold)
#    - All 7 Python transform Input() RIDs/paths correctly mapped to bronze tables ✅
#    - ap_signature.sql inputs (clean_ap_signature + clean_ap_detail) correct ✅
#    - 4 Contour starting datasets + join RIDs all match silver table references ✅
#
# 2. ap_signature.sql JOIN LOGIC
#    - SELECT columns: 9/9 match (signature_id, alternate_signature, approval_id,
#      approval_status, approver_signature, approvers, modified_date_sig, role, request) ✅
#    - JOIN condition: ON approval_id = approval_id ✅
#    - WHERE clause: request IS NOT NULL ✅
#
# 3. CONTOUR JOIN DATASETS (all 4 contours)
#    - Starting dataset RID e8409bca → clean_chg_change ✅
#    - Join 1: a306bde0 → silver_ap_signature_enriched, on change_id=request, prefix=apsig ✅
#    - Join 2: ae0545f5 → clean_acmr23_equipment, on change_id=change_id ✅
#    - Join 3: d59e3472 → clean_chg_task, on change_id=change_id, prefix=task ✅
#    - Join 4: 071983e5 → clean_acmr14_affected_techs, on change_id=change_id, prefix=new ✅
#    - Join 5: 365744b9 → clean_acmr14_affected_cllis, on change_id=change_id ✅
#
# 4. CONTOUR JOIN COLUMN SELECTION
#    - apsig: 3 content columns + request join key ✅
#    - equipment: 3 columns (equipment_id, equipment_name, equipment_type) ✅
#    - task: 13 columns (all match contour joinedColumns) ✅
#    - techs: 1 column (technology → new_technology) ✅
#    - cllis: 1 column (location) ✅
#
# 5. REQUESTER GROUP FILTER
#    - Contour: 63 unique groups + 4 duplicates = 68 total mentions
#    - DLT: 63 unique groups
#    - Category override "Mobility-External Partner": present in both ✅
#    - Exact set match verified ✅
#
# 6. STATUS / TASK_STATUS / APPROVAL_STATUS FILTERS
#    - Open: status NOT IN (7, 8) ✅
#    - Closed: status IN (7, 8) ✅
#    - Closed date: Year(change_closed_by_eastern_dt) >= YEAR(current) - 1 ✅
#    - cmclosed: DATE_SUB(current_date, 365) ✅
#
# 7. STATUS CASE WHEN MAPPINGS
#    - STATUS_MAP: 9 entries (0-8), all values match contour exactly ✅
#    - TASK_STATUS_MAP: 5 entries (0-4), default='Status Unknown' matches ✅
#    - APPROVAL_STATUS_MAP: 6 entries (0-5), default='Unknown' matches ✅
#
# 8. GOLD TABLE KEPT COLUMNS
#    - mso_aotscm_open_tickets: 62/62 columns exact match ✅
#    - mso_aotscm_closed_tickets: 62/62 columns exact match ✅
#    - cmclosed_tasks: 50/50 columns exact match ✅
#    - cmclosed_notasks: 53/53 columns exact match ✅
#    - supervisor_group → assignee_group rename: present where expected ✅
#
# 9. EASTERN TZ DATE FORMATTING
#    - Open: 4 UTC columns (create_date, modified_date, planned_start_date, planned_end_date) ✅
#           1 raw column (change_closed_by_eastern_dt) ✅
#    - Closed: 3 UTC columns (no modified_date — matches contour) ✅
#              1 raw column ✅
#    - Format string: 'yyyy-MM-dd HH:mm:ss a' matches contour ✅
#
# 10. FILTER ORDER
#     - Status NUMERIC filters applied BEFORE CASE WHEN text mapping ✅
#     - Matches contour board sequence (filter boards precede expression boards) ✅
#
# 11. CONTOUR JOIN INCLUSION/EXCLUSION
#     - cmclosed_tasks: 1 join (task only), no apsig/equipment/techs/cllis ✅
#     - cmclosed_notasks: 4 joins (apsig/equipment/techs/cllis), no task ✅
#     - open/closed: 5 joins (all) ✅
#
# 12. SILVER TRANSFORM COLUMN LISTS
#     - chg_change.py: 142 decimal columns exact match ✅
#       (6 additional strings correctly excluded — commented out in source)
#     - chg_change.py: 27 timestamp columns exact match ✅
#     - chg_change.py: 6 string columns exact match ✅
