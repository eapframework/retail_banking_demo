from pyspark.sql import functions as F
from transforms.api import transform_df, Input, Output, configure


@configure(profile=['EXECUTOR_MEMORY_LARGE', 'NUM_EXECUTORS_16'])
@transform_df(
    Output("ri.foundry.main.dataset.60dd2e03-44d5-4cb4-bda3-33bd45764578"),
    summary=Input("ri.foundry.main.dataset.7a482456-442b-4652-a78d-4461b14debcd"),
    generator=Input('ri.foundry.main.dataset.9c457ebd-3eb9-4fb6-9acf-7bec66164458'), #contact: rf2635
)
def compute(summary, generator):
    return bin_oc(summary, generator)


def bin_oc(summary, generator, pk="usid", rsrp="rsrp"):
    """
    This logic is designed for generator capital allocation projects with 12 months analysis
    more sample points -> more accurate information to guide planning
    Get overlapping coverage rate at geographic bin level - What is the percentage of bins served
    by pk cell tower that is served by another cell tower.
    """

    # Reformat generator information
    generator = generator.select(
        F.col("1toN_USID").alias("usid"),
        (F.substring(F.col("1toN_Activity_3"), 1, 1) == 'y').alias("generator_present")
    )

    # add generator information to summary table
    summary = summary.join(generator, [pk], how='left')
    df = summary.select("yyyymm", "mgrs100m", pk, "generator_present").dropDuplicates()
    backup = summary.where((F.col(rsrp) > -105))

    '''
    Overlapping coverage bin analysis: geographical overlapping coverage bins
    '''
    backup = backup.groupBy('mgrs100m', 'yyyymm').agg(
        F.collect_set(pk).alias('oc_set'), # number of servers serving this bin
        F.collect_set(F.when(F.col("generator_present"), F.col(pk)).otherwise(None)).alias("hardened_set")
    )

    # join overlapping bins to usid data
    df = df.join(backup, ['yyyymm', 'mgrs100m'], how='left')
    df = (
        df.withColumn("oc_usids", F.array_except(F.col("oc_set"), F.array(F.col("usid"))))
        .withColumn("oc_hardened_usids", F.array_except(F.col("hardened_set"), F.array(F.col("usid"))))
    )

    # BIN LEVEL Analysis
    df = df.withColumn("oc", F.size('oc_usids') >= 1)

    # HARDENING Analysis
    df = df.withColumn("harden", F.size("oc_hardened_usids") >= 1)

    # summarize
    oc_bins_analysis = (
        df.groupBy('yyyymm', pk, 'generator_present').agg(
            F.count(F.lit(1)).alias('tot_bins'),
            F.sum(F.when(F.col("oc"), F.lit(1))).alias("oc_bins"),
            F.sum(F.when(~F.col("oc"), F.lit(1))).alias("no_oc_bins"),
            F.sum(F.when(F.col("harden"), F.lit(1))).alias("hardened_bins"),
            F.sum(F.when(~F.col("harden"), F.lit(1))).alias("no_hardened_bins"),
        )
    )
    oc_bins_analysis = (
        oc_bins_analysis.withColumn('geo_oc_rate', F.col('oc_bins') / F.col('tot_bins'))
        .withColumn('hardened_oc_rate', F.col('hardened_bins') / F.col('tot_bins'))
    )

    return oc_bins_analysis.fillna(0)
