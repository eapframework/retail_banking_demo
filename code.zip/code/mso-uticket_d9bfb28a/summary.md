# Project Inventory Summary

**Project name:** MSO uTicket

**Merge timestamp:** 2026-03-17T11:15:35.123066

**Project output dir:** `mso-uticket_d9bfb28a`

**Total resources in project folder:** 22

**Total merged records:** 228

**Unresolved (project_only) resources:** 0

## Resource Counts by Type

- **codeworkbookdataset:** 5
- **contour:** 6
- **contouranalysis:** 10
- **datasource:** 14
- **fusionsheet:** 4
- **magritteagent:** 15
- **networkegresspolicy:** 4
- **pythontransformation:** 62
- **rawdataset:** 58
- **sqltransformation:** 48
- **uploadeddataset:** 1
- **virtualtable:** 1

## Mode

Flat output — workshop subdirectories removed after merge.
