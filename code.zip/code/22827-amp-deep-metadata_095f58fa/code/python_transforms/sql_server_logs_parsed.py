from pyspark.sql import functions as F
from pyspark.sql import types as T
from transforms.api import transform_df, Input, Output


@transform_df(
    Output("/Innovation Lab/Palantir Admins/Quantum/extensions/data/clean/sql_server_logs_parsed"),
    logs=Input("/Innovation Lab/Platform Monitoring/log_parsing/raw/foundry_sql_server/sql_server_event_logs"),
)
def my_compute_function(logs):
    schema = T.StructType([
        T.StructField("type", T.StringType(), True),
        T.StructField("time", T.StringType(), True),
        T.StructField("eventName", T.StringType(), True),
        T.StructField("values", T.StructType([
            T.StructField("sessionId", T.StringType(), True),
            T.StructField("statementId", T.StringType(), True),
            T.StructField("inputRids", T.ArrayType(T.StringType(), True), True),
            T.StructField("executionEngine", T.StringType(), True),
            T.StructField("prepareTime", T.StringType(), True),
            T.StructField("completionTime", T.StringType(), True),
            T.StructField("resultSizeInBytes", T.StringType(), True),
            T.StructField("timeToStreamResultMillis", T.StringType(), True),
            T.StructField("userAgent", T.StringType(), True),
            T.StructField("_requestId", T.StringType(), True),
        ]), True),
        T.StructField("uid", T.StringType(), True),
        T.StructField("tokenId", T.StringType(), True),
        T.StructField("traceId", T.StringType(), True),
        T.StructField("unsafeParams", T.StringType(), True),
        T.StructField("tags", T.StringType(), True),
    ])

    parsed_logs = logs.select(
        F.col('row'),
        F.from_json(F.col('row'), schema).getItem('type').alias('type'),
        F.from_json(F.col('row'), schema).getItem('time').alias('time'),
        F.from_json(F.col('row'), schema).getItem('eventName').alias('eventName'),
        F.from_json(F.col('row'), schema).getItem('values').getItem('sessionId').alias('sessionId'),
        F.from_json(F.col('row'), schema).getItem('values').getItem('statementId').alias('statementId'),
        F.from_json(F.col('row'), schema).getItem('values').getItem('inputRids').alias('inputRids'),
        F.from_json(F.col('row'), schema).getItem('values').getItem('userAgent').alias('userAgent'),
        F.from_json(F.col('row'), schema).getItem('uid').alias('uid'),
        F.from_json(F.col('row'), schema).getItem('tokenId').alias('tokenId'),
        F.from_json(F.col('row'), schema).getItem('traceId').alias('traceId'),
    )

    return parsed_logs
