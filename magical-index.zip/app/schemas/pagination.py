from __future__ import annotations

from typing import Generic, List, TypeVar

from pydantic import BaseModel, Field


# Default pagination settings
DEFAULT_LIMIT = 100
MAX_LIMIT = 1000


class PaginationParams(BaseModel):
    """Query parameters for pagination.
    
    Attributes:
        offset: Number of records to skip (default: 0)
        limit: Maximum number of records to return (default: 100, max: 1000)
    """
    offset: int = Field(default=0, ge=0, description="Number of records to skip")
    limit: int = Field(default=DEFAULT_LIMIT, ge=1, le=MAX_LIMIT, description="Maximum number of records to return")


T = TypeVar("T")


class PaginatedResponse(BaseModel, Generic[T]):
    """Generic paginated response wrapper.
    
    Attributes:
        items: List of items for the current page
        total: Total number of items across all pages
        offset: Current offset (number of items skipped)
        limit: Maximum number of items per page
        has_more: Whether there are more items beyond the current page
    """
    items: List[T]
    total: int = Field(description="Total number of items across all pages")
    offset: int = Field(description="Number of items skipped")
    limit: int = Field(description="Maximum items per page")
    has_more: bool = Field(description="Whether there are more items beyond this page")

    @classmethod
    def create(cls, items: List[T], total: int, offset: int, limit: int) -> PaginatedResponse[T]:
        """Factory method to create a paginated response.
        
        Args:
            items: List of items for the current page
            total: Total number of items across all pages
            offset: Current offset
            limit: Current limit
            
        Returns:
            PaginatedResponse with has_more calculated automatically
        """
        has_more = (offset + len(items)) < total
        return cls(
            items=items,
            total=total,
            offset=offset,
            limit=limit,
            has_more=has_more,
        )
