CREATE TABLE `/Innovation Lab/Data Governance/AT&T Internal Shareable Resources/access_roles_pre_object` TBLPROPERTIES (foundry_sever_inherited_permissions = 'true') AS WITH

upstart_role_details as (
    SELECT
        *
    FROM `/Innovation Lab/Data Governance/HaloE Upstart Role Mapping/all_haloe_upstart_groups`
),

all_mp_groups as (
    SELECT
        *
    FROM `/Innovation Lab/Palantir Admins/Quantum/extensions/data/inputs/all_multipass_groups`

    UNION

    SELECT
        *
    FROM `/Innovation Lab/Palantir Admins/Quantum/extensions/data/inputs/all_multipass_groups_with_empty`
    WHERE user_list[0] is null
)

SELECT
    group_rid,
    group_name,
    group_realm,
    user_list,
    user_list_attuids,
    upstart_role_details.Upstart_Role,
    upstart_role_details.Owner,
    upstart_role_details.Approver1,
    upstart_role_details.Approver2,
    upstart_role_details.Approver3,
    upstart_role_details.Role_Description,
    max_expiration,
    max_duration_in_seconds
FROM all_mp_groups


LEFT JOIN upstart_role_details
ON upstart_role_details.HaloE_Group = all_mp_groups.group_name