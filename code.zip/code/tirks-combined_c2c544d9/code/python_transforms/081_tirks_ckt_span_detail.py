from transforms.api import transform_df, Input, Output, incremental
import pyspark.sql.functions as F


@transform_df(
    Output("ri.foundry.main.dataset.63080816-00af-4bf8-b91c-f1ee57c40368"),
    asi=Input("ri.foundry.main.dataset.cb07019c-2b58-4569-84f7-f0f25be14e88"),
    telco=Input("ri.foundry.main.dataset.8b5cda03-3f83-4d2b-83d8-1ce2a88cb57a"),
)
def my_compute_function(telco, asi):
    telco = telco.withColumn("source", F.lit('telco'))
    asi = asi.withColumn("source", F.lit('asi'))
    df = telco.unionByName(asi)
    return df