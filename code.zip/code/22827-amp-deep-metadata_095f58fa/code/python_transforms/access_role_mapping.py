from transforms.api import transform_df, Input, Output
from myproject.utils.global_code import PARENT_FOLDER
from pyspark.sql import functions as F


@transform_df(
    Output(f"{PARENT_FOLDER}/access_role_mapping", sever_permissions=True),
    project_to_groups=Input(f"{PARENT_FOLDER}/projects_to_groups"),
    refs=Input(
        "/Innovation Lab/Data Governance/workbook-output/api_code/project_to_parent_project_mapping"
    ),
    roles=Input(
        "/Innovation Lab/Data Governance/AT&T Internal Shareable Resources/access_roles_object"
    ),
    ref_groups=Input(f"{PARENT_FOLDER}/referenced_groups"),
    ops_role=Input(
        "/Innovation Lab/Data Governance/Slate Access Dashboard - Backing Data/projects_with_operational_roles_dataset"
    ),
)
def my_compute_function(project_to_groups, refs, roles, ref_groups, ops_role):
    # Start off with a mapping of all projects and the multipass groups configured on those projects
    df = project_to_groups
    refs = refs.withColumnRenamed("project_rid", "project_id")
    # Map all upstream and downstream projects to this list - TODO Swap for project_to_parent_project_mapping (Data Lineage APIs)
    df = df.join(
        refs.select("ref_project_rid", "ref_project_name", "project_id"),
        df["project_rid"] == refs["project_id"],
        how="left",
    ).drop("project_id", "default_role")

    # Filtering out rows that don't contain a group rid
    df = df.filter(df["group_rid"] != "")

    # Bringing in multipass groups of the parent projects
    df = df.join(
        ref_groups,
        df["ref_project_rid"] == ref_groups["referenced_project_rid"],
        how="left",
    ).drop("referenced_project_rid")

    # Bringing in the Upstart role names for Use Cases (Current Project)
    df = df.join(roles, df["group_rid"] == roles["group_rid"], how="left").select(
        "project_rid",
        "project_name",
        "project_type",
        df["group_rid"],
        "access_level",
        "ref_project_rid",
        "ref_project_name",
        "ref_group_rid",
        "ref_access_level",
        roles["group_name"].alias("use_case_group_name"),
        roles["Upstart_Role"].alias("use_case_roles"),
    )

    # Bringing in Upstart role names for Data Sources (Parent Projects)
    df = df.join(roles, df["ref_group_rid"] == roles["group_rid"], how="left").select(
        "project_rid",
        "project_name",
        "project_type",
        "access_level",
        "use_case_group_name",
        "use_case_roles",
        roles["group_name"].alias("reference_group_name"),
        roles["Upstart_Role"].alias("data_roles"),
    )

    # For Data Source Projects, filter out all PA/PU use case roles and all PA/PU data roles
    # For Use Case Projects, filter out all PA use case roles and all PA/PU data roles
    groups_to_roles = [
        ("use_case_group_name", "use_case_roles"),
        ("reference_group_name", "data_roles"),
    ]
    for group, role in groups_to_roles:
        df = df.withColumn(
            role,
            F.when(
                (
                    (df[group].like("%PA%"))
                    | ((df["project_type"] == "Data Source") & df[group].like("%PU%"))
                ),
                "",
            ).otherwise(df[role]),
        )
        if group == "reference_group_name":
            df = df.withColumn(
                role,
                F.when(
                    ((df["project_type"] == "Use Case") & (df[group].like("%PU%"))), ""
                ).otherwise(df[role]),
            )

    df = df.withColumn(
        "viewer_roles",
        F.when(df["access_level"] == "READ", df["use_case_roles"]).otherwise(""),
    )
    df = df.withColumn(
        "editor_roles",
        F.when(df["access_level"] == "EDIT", df["use_case_roles"]).otherwise(""),
    )

    df = df.drop("reference_group_name", "use_case_group_name").drop(
        "access_level", "use_case_roles"
    )

    df = df.groupBy("project_name", "project_rid", "project_type").agg(
        F.array_remove(F.collect_set("viewer_roles"), "").alias("viewer_roles_agg"),
        F.array_remove(F.collect_set("editor_roles"), "").alias("editor_roles_agg"),
        F.array_remove(F.collect_set("data_roles"), "").alias("data_roles_agg"),
    )

    df = df.join(
        ops_role.select(
            ops_role["upstart_role_name"].alias("operations_roles_agg"),
            ops_role["use_case_project_rid"],
        ),
        df["project_rid"] == ops_role["use_case_project_rid"],
        how="left",
    ).drop("use_case_project_rid")

    return df
