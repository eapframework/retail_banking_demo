from transforms.api import transform, Input, Output
from .utils import latest_months, F
from pyspark.sql.types import StringType
from transforms.api import configure


@configure(profile=['EXECUTOR_MEMORY_MEDIUM', 'NUM_EXECUTORS_16'])
@transform(
    coverage=Output("ri.foundry.main.dataset.f45c90f1-086a-4bfb-9b59-473eedb669ed"),
    neighbors=Output("ri.foundry.main.dataset.32c17c78-6a71-44c4-ad29-3f240c28bcab"),
    iqi=Input("ri.foundry.main.dataset.5dbda0fe-8deb-482f-b454-6d3b38100be6"),
)
def my_compute_function(iqi, neighbors, coverage):
    '''
    Compute coverage object backing dataset and neighbor relationship dataset
    neighbor dataset: which other usid is providing rsrp >-105 overlapping coverage
    coverage dataset: hosts all metrics in coverage object
    '''
    # define relevent columns
    time = ['yyyymm']
    ids = ['usid']
    latlon = ['mgrs100m', 'sw_lat', 'sw_long']
    sum_cols = [
        'rsrp_grt_n90',
        'rsrp_n90_to_n100',
        'rsrp_n100_to_n110',
        'rsrp_n110_to_n115',
        'rsrp_less_n115',
        'rsrq_grt_n10',
        'rsrq_n10_to_n14',
        'rsrq_n14_to_n18',
        'rsrq_less_n18',
        'volte_calls_attempted',
        'volte_setup_success',
        'volte_calls_ended',
        'volte_calls_dropped',
        # 'volte_one_way_audio_detected', # Not in iqi v2
        'volte_call_reinit',
        'total_bytes_down',
        'total_bytes_up'
    ]
    # In v2 we have rsrp, rsrq, puschtxpower and snr. We do not have jitter.
    average_cols = ['avg_rsrp', 'avg_rsrq', 'avg_puschtxpower', 'avg_snr']  # , 'avg_mean_jitter']
    count_cols = ['rsrp_recs', 'rsrq_recs', 'puschtxpower_recs', 'snr_recs']  # 'jitter_recs',

    # Renaming the average columns to match our naming scheme and casts usid to string
    iqi_df = iqi.dataframe()
    # Adding repartition to attempt to solve oom issue commenting out partition as i may be unneeded
    # iqi_df = iqi_df.repartition(8)
    iqi_df = iqi_df.withColumnRenamed('rsrp', 'avg_rsrp')\
                   .withColumnRenamed('rsrq', 'avg_rsrq')\
                   .withColumnRenamed('puschtxpower', 'avg_puschtxpower')\
                   .withColumnRenamed('snr', 'avg_snr')
    # Select relevant columns and only keep latest month data
    iqi_df = iqi_df.select(*time, *ids, *latlon, *sum_cols, *average_cols, *count_cols)
    ##################################################
    # Aggregate coverage to usid and mgrs100m level. #
    ##################################################
    # define aggregation expressions
    average_over_count = zip(average_cols, count_cols)
    exprs = [F.sum(x).alias(x) for x in sum_cols]
    for pair in average_over_count:
        field, count = pair
        exprs.append((F.sum(F.col(field)*F.col(count))/F.sum(count)).alias(field))
    # Do the aggregation
    keys = time+ids+latlon
    df = iqi_df.groupBy(*keys).agg(*exprs)
    ##############################################################
    # Calculate the number of neighbors for overlapping coverage #
    ##############################################################
    # reserve overlapping coverage dataframe
    oc = iqi_df.where((F.col('avg_rsrp') > -105))
    # Find out neighbors
    oc_df = oc.select('yyyymm', F.col('usid').alias('neighbor'), 'mgrs100m')
    # Dropping duplicate rows
    oc_df = oc_df.dropDuplicates()
    neighbors_df = iqi_df.select('yyyymm', 'usid', 'mgrs100m').join(oc_df, ['yyyymm', 'mgrs100m'])
    neighbors_df = neighbors_df.filter(F.col('usid') != F.col('neighbor')).dropDuplicates()
    neighbors.write_dataframe(neighbors_df)
    # Find overlapping coverage count
    oc = neighbors_df.groupby('usid', 'yyyymm', 'mgrs100m').agg(F.countDistinct("usid").alias('coverage_count'))
    df = df.join(oc, ['usid', 'yyyymm', 'mgrs100m'], how='left')
    df = df.fillna({'coverage_count': '0'})
    ##############################################################
    #                       Add misc columns                     #
    ##############################################################
    df = df.select(
                    "*",
                    # Calculate geohash
                    F.concat(F.col('sw_lat'), F.lit(','), F.col('sw_long')).alias('geohash'),
                    # Add id
                    F.concat(F.col('yyyymm'), F.lit('_'), F.col('usid'), F.lit('_'), F.col('mgrs100m')).alias('coverage_id'),
                    # Add national_id column
                    F.lit("us").alias("national_id"),
                    # Add use case column
                    F.lit('ri.compass.main.folder.afb7dee0-77e6-4b3b-be33-af16d547ff3b').alias('usecase')
                )
    coverage.write_dataframe(df)
