# Project Inventory Summary

**Project name:** Towers & Poles Operations

**Merge timestamp:** 2026-03-16T16:00:49.028752

**Project output dir:** `towers-poles-operations_bbcee845`

**Total resources in project folder:** 27

**Total merged records:** 55

**Unresolved (project_only) resources:** 0

## Resource Counts by Type

- **codeworkbookdataset:** 3
- **datasource:** 2
- **eddiepipeline:** 4
- **foundrydataset:** 9
- **magritteagent:** 4
- **monoclegraph:** 4
- **networkegresspolicy:** 4
- **pipelinebuilder:** 11
- **pythontransformation:** 4
- **rawdataset:** 5
- **vectorworkbook:** 4
- **virtualtable:** 1

## Mode

Flat output — workshop subdirectories removed after merge.
