from transforms.api import configure
from transforms.api import transform, Input, Output,incremental
from utility.column_clean import lowercase_columns
from ..utils import process_update_insert


@incremental(semantic_version=3)
@configure(profile=['EXECUTOR_MEMORY_MEDIUM', 'PARQUET_DISABLE_VECTORIZED_READER'])
@transform(
   out=Output("ri.foundry.main.dataset.24a588e0-e370-4736-b45d-8cd65f482916"),
   df=Input("ri.foundry.main.dataset.314e9c26-0155-411f-ae58-fa11194714f8"),
)
def my_compute_function(ctx,df, out):
    def processing(df):
        df = lowercase_columns(df)
        return df
    process_update_insert(ctx, out, df, ["wrid"], ["timestamp"], None, None, processing)
