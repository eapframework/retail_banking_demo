from transforms.api import transform_df, Input, Output, incremental
import pyspark.sql.functions as F
from functools import reduce


@transform_df(
    Output("/Innovation Lab/[ETL] Tirks Combined/data/032_tirks_cable_circuit"),
    asi=Input("/Innovation Lab/[Source] Teradata EDW - ASI_VIEWS/data/clean/vcan032_tirks_cable_circuit"),
    telco=Input("/Innovation Lab/[Source] Teradata EDW - ACCESS_VIEWS/data/prod_clean/vctn032_tirks_cable_circuit"),
    vbtn=Input("/Innovation Lab/[Source] Teradata EDW - ACCESS_VIEWS/data/prod_clean/vbtn032_tirks_cable_circuit"),
)
def my_compute_function(telco, asi, vbtn):
    telco = telco.withColumn("source", F.lit('telco'))
    asi = asi.withColumn("source", F.lit('asi'))
    vbtn = vbtn.withColumn("source", F.lit('vbtn'))

    # select hardcoded output cols to guarantee schema
    telco = telco.select(output_cols)
    asi = asi.select(output_cols)
    vbtn = vbtn.select(output_cols)

    # Union all together by name
    df = reduce(
        lambda x, y: x.unionByName(y),
        [telco, asi, vbtn]
    )

    return df


output_cols = [
    "sbc_company_cd",
    "sbc_system_cd",
    "cable_location_a_clli_cd",
    "cable_location_z_clli_cd",
    "cable_id",
    "cable_last_unit_range_nbr",
    "cable_header_sequence_nbr",
    "cable_unit_nbr",
    "cable_subdivision_sequence_nbr",
    "circuit_assignment_seq_nbr",
    "sbc_state_cd",
    "cbl_subdivision_from_wire_nbr",
    "cbl_subdivision_thru_wire_nbr",
    "primary_alternate_asgnmt_cd",
    "ckt_layout_ord_activity_due_dt",
    "circuit_assignment_activity_cd",
    "circuit_layout_order_nbr",
    "ckt_lyt_ord_activity_status_cd",
    "circuit_access_cd",
    "ckt_identification_format_cd",
    "circuit_identification_cd",
    "circuit_location_a_clli_cd",
    "circuit_location_z_clli_cd",
    "detailed_rglty_ckt_lyt_ord_cd",
    "assignment_misuse_cd",
    "multiwire_circuit_cd",
    "circuit_group_access_cd",
    "assignment_responsibility_cd",
    "facility_detail_cd",
    "source",
]
