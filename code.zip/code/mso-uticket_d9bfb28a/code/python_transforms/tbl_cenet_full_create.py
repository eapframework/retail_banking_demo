from transforms.api import transform_df, Output, Input
import pyspark.sql.functions as func
from pyspark.sql.types import StructType, StructField, StringType, DateType, IntegerType, LongType, DoubleType


@transform_df(
    Output("/Innovation Lab/AFO Hierarchy/data/process/cenet/tbl_cenet_stg"),
    initial_load=Input("/Innovation Lab/[Source] MAPP/data/clean/tbl_cenet_full")
)
def my_compute_function(initial_load):
    initial_load = initial_load.drop('work_delivery_code')
    initial_load = initial_load.drop('work_bldg_tax_code')
    initial_load = initial_load.drop('market_zone')
    initial_load = initial_load.drop('home_addr1')
    initial_load = initial_load.drop('home_addr2')
    initial_load = initial_load.drop('blsuid')
    initial_load = initial_load.withColumn('uid', func.trim(func.col('uid')))
    initial_load = initial_load.withColumn('hire_date', func.col('hire_date').cast(DateType()))
    initial_load = initial_load.withColumn('ncs_date', func.col('ncs_date').cast(DateType()))
    initial_load = initial_load.withColumn('datestamp', func.col('datestamp').cast(DateType()))
    return initial_load
