from transforms.api import transform, Input, Markings, Output
from utility.column_clean import clean_columns, lowercase_columns
from pyspark.sql.functions import to_date, to_timestamp, date_format as F, col


@transform(
    out=Output("ri.foundry.main.dataset.77c6d751-ebac-41cd-9a9b-76d8533fbec6"),
    inp=Input(
        'ri.foundry.main.dataset.f57a9072-48d7-44ad-a541-dcf88f011502',
        stop_propagating=Markings(
            ["ab6b32de-380a-490b-aadf-5357a3710600"], on_branches="master"
        )
    ),
)
def my_compute_function(ctx, inp, out):
    df = clean_columns(
        inp.dataframe(),
        strip_columns=strip_columns,
        integer_columns=cast_to_integer_columns,
        double_columns=cast_to_double_columns,
        decimal_columns=cast_to_decimal_columns,
        timestamp_columns=cast_to_timestamp_from_long_columns,
        datetime_columns=cast_to_timestamp_columns,
        datetime_format=datetime_format,
        date_columns=cast_to_date_columns,
        date_format=date_format,
        id_columns=cast_to_string_columns,
        integer_from_num_columns=cast_to_integer_from_decimal_columns
    )
    df = lowercase_columns(df)
    # List of columns for date transformation
    columns = [
        "intake_date",
        "submitted_date",
        "package_completed_date",
        "current_date",
        "modified_date",
        "term_commencement_date",
        "rent_commencement_date",
        "user_response_received_on",
        "column_2460m_date_sent_to_iwm",
        "actualization_date_iwm",
        "forecast_date_iwm"
        ]

    # Apply the to_date transformation to each column
    for column in columns:
        df = df.withColumn(column, to_date(col(column), "MM/dd/yyyy"))
    df=df.withColumn("fa_number",col("fa_number").cast('long'))
    df = df.withColumn("start_date_month", to_date(df["start_date_month"], "MM/yyyy"))# giving yyyy-mm-dd date as first date of month
    df = df.withColumn("start_date_time", to_timestamp(df["start_date_time"], "MM/dd/yyyy HH:mm:ss"))
    df = df.withColumn("end_date_time", to_timestamp(df["end_date_time"], "MM/dd/yyyy HH:mm:ss"))

    out.write_dataframe(df)

date_format = 'yyyy-MM-dd'
datetime_format = 'yyyy-MM-dd HH:mm:ss'

cast_to_date_columns = []
cast_to_timestamp_columns = ["SF_LOAD_TS_EST"]
cast_to_timestamp_from_long_columns = []
cast_to_integer_columns = []
cast_to_double_columns = []
cast_to_decimal_columns = []
cast_to_string_columns = []
cast_to_integer_from_decimal_columns = []
strip_columns = []
