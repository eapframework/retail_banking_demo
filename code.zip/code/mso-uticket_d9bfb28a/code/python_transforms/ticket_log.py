from transforms.api import transform, Input, Output, incremental
from utility.incremental.update_insert import update_insert_core
import logging
from transforms.api import transform, Input, Output, incremental, configure
from utility.column_clean import clean_columns, lowercase_columns, remove_prefix
logger = logging.getLogger(__name__)


@configure(profile=['NUM_EXECUTORS_64', 'EXECUTOR_MEMORY_MEDIUM', 'DRIVER_MEMORY_MEDIUM'])
@incremental(semantic_version=5)
@transform(
   out=Output("ri.foundry.main.dataset.8bf3023b-92c5-4550-ac3e-bdd786509c9b"),
   updates=Input("ri.foundry.main.dataset.16f8790a-890a-4b5f-bf55-d4d0cbeb8878")
   )
def my_compute_function(ctx, out, updates):
    #updates = updates.dataframe()
    updates_df = clean_columns(
        updates.dataframe(),
        strip_columns=strip_columns,
        integer_columns=cast_to_integer_columns,
        double_columns=cast_to_double_columns,
        decimal_columns=cast_to_decimal_columns,
        timestamp_columns=cast_to_timestamp_from_long_columns,
        datetime_columns=cast_to_timestamp_columns,
        datetime_format=datetime_format,
        date_columns=cast_to_date_columns,
        date_format=date_format,
        id_columns=cast_to_string_columns,
        integer_from_num_columns=cast_to_integer_from_decimal_columns
    )
    
    updates_df = lowercase_columns(updates_df)
    for c in cast_to_short_columns:
        updates_df = updates_df.withColumn(c, updates_df[c].cast('short'))
    
    keys = ["request_id","ticket_nb","ticket_log_seq","log_seqno"]
    # logger.info(f"{dir(out)}")
    # update_insert_core(ctx, output, updates_df, keys, ["node_record_added"], num_partitions=200)
    update_insert_core(ctx, out, updates_df, primary_keys=keys, order_cols=["ticket_last_modified_date"])

cast_to_short_columns=[]
date_format = 'yyyy-MM-dd'
datetime_format = 'yyyy-MM-dd HH:mm:ss'

cast_to_date_columns = []
cast_to_timestamp_columns = []
cast_to_timestamp_from_long_columns = ["TICKET_LAST_MODIFIED_DATE","TICKET_DATE_TIME","SECONDARY_ACTIVITY_DATE","DATE_X"]
cast_to_integer_columns = []
cast_to_double_columns = []
cast_to_decimal_columns = []
cast_to_string_columns = []
cast_to_integer_from_decimal_columns = []
strip_columns = []