from transforms.api import transform, Input, Output, incremental
from utility.column_clean import clean_columns, lowercase_columns, remove_prefix


@transform(
    out=Output("/Innovation Lab/[Source] Teradata EDW - ASI_VIEWS/data/clean/vcan035_tirks_span_circuit"),
    df=Input("/Innovation Lab/[Source] Teradata EDW - ASI_VIEWS/data/raw/snowflake/SDW_AEDW_ASI_VIEWS.vcan035_tirks_span_circuit"),
)
def my_compute_function(df, out):
    df = clean_columns(
        df.dataframe(),
        date_format=date_format, 
        date_columns=string_to_date,
        datetime_format=datetime_format, 
        datetime_columns=long_unixtime_to_timestamp,
        timestamp_from_string_format=string_unixtime_format,
        timestamp_from_string_columns=string_unixtime_to_timestamp,
        timestamp_format=long_unixtime_format, 
        timestamp_columns=long_unixtime_to_timestamp,
        integer_columns=string_to_integer_columns,
        double_columns=string_to_double_columns,
        decimal_columns=string_to_decimal_columns,
        id_columns=numeric_to_string_columns,
        integer_from_num_columns=decimal_to_integer,
        strip_columns=strip_string_columns,
    )
    # df = df.drop(*drop_columns)
    # df = remove_prefix(df, 'example_prefix')
    df = lowercase_columns(df)
    df = df.withColumn("span_line_nbr", df["span_line_nbr"].cast("short"))
    df = df.withColumn("span_line_nbr", df["span_line_nbr"].cast("short"))
    df = df.distinct()
    out.write_dataframe(df)


drop_columns = []

date_format = 'yyyy-MM-dd'
string_to_date = []
datetime_format = 'yyyy-MM-dd HH:mm:ss'
string_to_timestamp = []

string_unixtime_format = None
string_unixtime_to_timestamp = []
long_unixtime_format = None
long_unixtime_to_timestamp = []

string_to_integer_columns = []
string_to_double_columns = []
string_to_decimal_columns = []

numeric_to_string_columns = []
decimal_to_integer = []

strip_string_columns = [
    "SBC_COMPANY_CD",
    "SBC_SYSTEM_CD",
    "SPAN_GROUP_ACCESS_CD",
    "PRIMARY_ALTERNATE_ASGNMT_CD",
    "CIRCUIT_ASSIGNMENT_SEQ_NBR",
    "SBC_STATE_CD",
    "SPAN_FACILITY_DESIGNATION_CD",
    "SPAN_FACILITY_TYPE_CD",
    "SPAN_LOCATION_A_CLLI_CD",
    "SPAN_LOCATION_Z_CLLI_CD",
    "CIRCUIT_ASSIGNMENT_VIEW_CD",
    "CIRCUIT_ASSIGNMENT_ACTIVITY_CD",
    "CIRCUIT_LAYOUT_ORDER_NBR",
    "CIRCUIT_ACCESS_CD",
    "CKT_IDENTIFICATION_FORMAT_CD",
    "CIRCUIT_IDENTIFICATION_CD",
    "CIRCUIT_LOCATION_A_CLLI_CD",
    "CIRCUIT_LOCATION_Z_CLLI_CD",
    "CKT_LYT_ORD_ACTIVITY_STATUS_CD",
]
