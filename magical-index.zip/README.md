# Magical Index

## Overview
Magical Index is platform agnostic relational catalog microservice to create and traverse a "mental image" of data/code/processes for humans and agents (e.g., Cascade). It is implemented in FastAPI, and designed to run locally for development and later in a Databricks app with Unity Catalog/Delta as storage.

**Architecture: 3-Table Design**
- **Resources** (7 columns): `resource_id` (PK, auto-generated), `resource_name`, `location`, `resource_type`, `resource_status`, `last_by`, `last_update_time`
- **Relationships** (4 columns): `upstream_resource_id`, `downstream_resource_id`, `relationship_type`, `notes`
- **Activity Logs** (7 columns): `log_id` (PK, auto-generated), `resource_id`, `action`, `actor_type`, `actor_name`, `details`, `timestamp`

**Key Features**
- Resource status: PLANNED, DISCOVERED, EXTRACTED, TRANSFORMED, DEPLOYED, STAGED_FOR_DECOMMISSION
- Auto-generated IDs: If you don't provide `resource_id`, the system generates `{platform}:{type}:{id}` (e.g., `foundry:dataset:abc123`)
- Platform-aware: IDs include platform (foundry, databricks, github, adls) for easy filtering if agent provides platform information
- Immutable audit trail: Every create/update/delete is logged with actor and timestamp
- Graph lineage: A FEEDS B relationships with cascade delete
- Auto-documented API via Swagger at /docs

**Magical Index Workflow** 
![Magical Index Workflow](images\magical_index_workflow.jpg)

## Quickstart (local)
1. Open a terminal in this folder:
   ```powershell
   cd {local_path}
   ```
2. Create/activate a venv (recommended):
   ```powershell
   python -m venv .venv
   & .\.venv\Scripts\Activate.ps1
   ```
3. Install dependencies:
   ```powershell
   python -m pip install -r requirements.txt
   ```
4. Run the API (python -m avoids PATH issues):
   ```powershell
   python -m uvicorn app.main:app --reload
   ```
5. Open Swagger UI: http://127.0.0.1:8000/docs

## Running tests
```powershell
python -m pytest -q          # Quick summary
python -m pytest -vv         # Verbose with test names
```
Tests use the in-memory backend automatically — no Databricks connection required.

## API cheatsheet
http://127.0.0.1:8000/docs

## Unity Catalog tables (Databricks)
- Resources table: `magical-index-rid` (7 columns)
- Relationships table: `magical-index-rel` (4 columns)
- Activity logs table: `magical-index-log` (7 columns)

Use the provided script to create the catalog, schema, and tables if missing.

### Create UC tables via Databricks SQL
1. Ensure you have a Databricks SQL Warehouse and a PAT (Personal Access Token).
2. Set environment variables (or copy `.env.example` → `.env` and fill values):
   - `DATABRICKS_HOST` (e.g., https://adb-<workspace-id>.<region>.azuredatabricks.net)
   - `DATABRICKS_HTTP_PATH` (e.g., /sql/1.0/warehouses/<warehouse-id>)
   - `DATABRICKS_TOKEN` (your PAT; do NOT commit)
   - `UC_CATALOG` (e.g., cdo_catalog)
   - `UC_SCHEMA` (e.g., magical_index)
   - Optional overrides: `MAGICAL_INDEX_RID_TABLE`, `MAGICAL_INDEX_REL_TABLE`
3. Install deps and run:
   ```powershell
   python -m pip install -r requirements.txt
   python -c "exec(open('scripts/create_uc_tables.py').read())"
   ```
4. The script is idempotent and will ensure:
   - Catalog, schema exist
   - Tables `magical-index-rid`, `magical-index-rel`, and `magical-index-log` exist

## Project layout
```
magical_index/                    # FastAPI server (Databricks App)
├─ app/
│  ├─ main.py                     # FastAPI app + routers
│  ├─ core/
│  │  └─ config.py                # Settings (env-driven)
│  ├─ api/
│  │  └─ v1/
│  │     ├─ __init__.py           # API router
│  │     └─ endpoints/
│  │        ├─ resources.py       # Resource endpoints
│  │        ├─ operations.py      # Graph traversal & extraction prep
│  │        ├─ relationships.py   # Relationship endpoints
│  │        ├─ activity_logs.py   # Activity log endpoints
│  │        └─ diagnostics.py     # Config and readiness endpoints
│  ├─ schemas/                    # Pydantic models
│  │  ├─ resource.py              # 7-column resource schema
│  │  ├─ relationship.py          # 4-column relationship schema
│  │  └─ activity_log.py          # 7-column activity log schema
│  └─ services/
│     ├─ store.py                 # InMemoryStore + DeltaStore
│     └─ db_auth.py               # Dual-mode auth (SP + PAT)
├─ scripts/
│  └─ create_uc_tables.py         # Idempotent UC provisioning
├─ tests/                         # pytest suite (inmemory backend)
│  ├─ conftest.py
│  ├─ test_diagnostics_api.py
│  ├─ test_resources_api.py       # 8 tests
│  ├─ test_relationships_api.py   # 5 tests
│  ├─ test_activity_logs_api.py   # 7 tests
│  └─ test_deployment_scenario.py # 1 test (magical_index + UC tables)
├─ bruno/                         # Bruno collection for manual API testing
├─ app.yaml                       # Databricks Apps deployment descriptor
├─ requirements.txt               # Server dependencies
├─ pytest.ini                     # Test configuration
└─ .env.example                   # Example environment configuration
```

## Configuration

### Local Development (.env)
For local development, create a `.env` file with your configuration:
- `PROJECT_NAME` — title shown in docs
- `API_V1_STR` — API base path (default /api/v1)
- `ALLOWED_ORIGINS` — CORS origins (JSON list)
- `STORAGE_BACKEND` — `delta` (default) or `inmemory` (for tests/local)
- Databricks/UC:
  - `DATABRICKS_HOST`, `DATABRICKS_HTTP_PATH`
  - `DATABRICKS_TOKEN` (PAT for local dev) OR `DATABRICKS_CLIENT_ID` + `DATABRICKS_CLIENT_SECRET` (service principal)
  - `UC_CATALOG`, `UC_SCHEMA`

### Databricks Apps Deployment (app.yaml)
For Databricks Apps deployment, all configuration is in `app.yaml`:
- Environment variables are set in the `env:` section
- Service principal credentials should be configured as Databricks App secrets (not in app.yaml)
- The app will automatically use service principal auth when `DATABRICKS_CLIENT_ID` and `DATABRICKS_CLIENT_SECRET` are present
- See `app.yaml` for the full configuration template
  - `MAGICAL_INDEX_RID_TABLE`, `MAGICAL_INDEX_REL_TABLE`, `MAGICAL_INDEX_LOG_TABLE`

### Calling the Deployed App

Authentication is handled by the Databricks CLI. One-time setup:
```bash
databricks auth login --host https://adb-3138568880081167.7.azuredatabricks.net
```

Example API call (curl):
```bash
TOKEN=$(databricks auth token --host https://adb-3138568880081167.7.azuredatabricks.net --json | jq -r .access_token)
curl -H "Authorization: Bearer $TOKEN" \
  https://gandalf-magical-index-3138568880081167.7.azure.databricksapps.com/api/v1/diagnostics/config
```

## Storage backends
- **inmemory** — data resets on restart; used for tests and rapid local dev.
- **delta** (default) — persists to UC Delta tables via Databricks SQL connector.

Keep the FastAPI surface the same; only the store wiring changes based on `STORAGE_BACKEND`.

## Credentials handling
- Do not commit secrets. `.env` is ignored via `.gitignore`.
- Authenticate via Databricks CLI: `databricks auth login --host <workspace-url>`
- Credentials are stored in `~/.databrickscfg` and picked up automatically by the Databricks SDK.

## Guidelines for contributors (beginner friendly)
- Keep endpoint functions small and documented (docstrings become Swagger docs)
- Add/adjust Pydantic schemas in `app/schemas/`
- Keep business logic in `app/services/` (not in endpoint functions)
- If you add a new route, add a docstring (summary + purpose)
- Prefer explicit types (helps Swagger and readability)

---

# Deployment

This section covers how to deploy code changes to the live Databricks App at:

> **https://gandalf-magical-index-3138568880081167.7.azure.databricksapps.com/docs**

## Current deployment details

| Setting | Value |
|---------|-------|
| **App name** | `gandalf-magical-index` |
| **Workspace** | `adb-3138568880081167.7.azuredatabricks.net` |
| **Workspace source path** | `/Workspace/Users/jz1019@att.com/gandalf-magical-index` |
| **UC Catalog** | `31184_cerebro_poc4x` |
| **UC Schema** | `gandalf_magical_index` |
| **SQL Warehouse** | `/sql/1.0/warehouses/272ea6561d0f4778` |

## Prerequisites (one-time setup)

### 1. Install the Databricks CLI

```bash
# Windows (winget)
winget install Databricks.DatabricksCLI

# macOS (brew)
brew install databricks/tap/databricks
```

### 2. Authenticate and create a CLI profile

Each team member creates their own profile. The profile name can be anything you choose.

```bash
databricks auth login --host https://adb-3138568880081167.7.azuredatabricks.net
```

This opens a browser for OAuth login and saves your credentials to `~/.databrickscfg`.
To verify your profiles:

```bash
databricks auth profiles
```

> **Note:** Databricks Apps require **OAuth JWT tokens** for API calls. PATs (`dapi...`) are rejected with HTTP 401. The `databricks auth login` flow handles this automatically.

## Deploy changes (step-by-step)

Replace `<PROFILE>` below with your own Databricks CLI profile name (from `databricks auth profiles`).

### Step 1 — Upload changed files to the workspace

For a **single file** change (most common):

```bash
databricks workspace import /Workspace/Users/jz1019@att.com/gandalf-magical-index/<relative/path/to/file> \
  --file <relative/path/to/file> \
  --overwrite --format AUTO \
  -p <PROFILE>
```

Example — after editing `app/services/store.py`:

```bash
databricks workspace import /Workspace/Users/jz1019@att.com/gandalf-magical-index/app/services/store.py \
  --file app/services/store.py \
  --overwrite --format AUTO \
  -p <PROFILE>
```

For **multiple files** or continuous development, use sync:

```bash
databricks sync --watch . /Workspace/Users/jz1019@att.com/gandalf-magical-index \
  --exclude-from .gitignore \
  -p <PROFILE>
```

### Step 2 — Deploy the app

```bash
databricks apps deploy gandalf-magical-index \
  --source-code-path /Workspace/Users/jz1019@att.com/gandalf-magical-index \
  -p <PROFILE>
```

A successful deploy prints `"state": "SUCCEEDED"`. The app typically restarts in ~10–15 seconds.

### Step 3 — Verify the deployment

Open the Swagger UI to confirm the app is running with your changes:

> https://gandalf-magical-index-3138568880081167.7.azure.databricksapps.com/docs

Or run the integration test suite:

```bash
python tests/test_deployed_api.py
```

This runs 37 tests across all API endpoints (resources, relationships, activity logs, diagnostics, edge cases) and writes a Markdown report to `tests/deployed_api_report.md`.

## Quick-reference commands

```bash
# Check your profiles
databricks auth profiles

# Re-authenticate if token expired
databricks auth login --host https://adb-3138568880081167.7.azuredatabricks.net

# Upload a single file
databricks workspace import /Workspace/Users/jz1019@att.com/gandalf-magical-index/<path> \
  --file <path> --overwrite --format AUTO -p <PROFILE>

# Deploy
databricks apps deploy gandalf-magical-index \
  --source-code-path /Workspace/Users/jz1019@att.com/gandalf-magical-index -p <PROFILE>

# Check app status
databricks apps list -p <PROFILE>

# Get a bearer token for curl/httpx calls
databricks auth token --host https://adb-3138568880081167.7.azuredatabricks.net -p <PROFILE>
```

## UC table permissions (admin only)

If a new service principal needs access to the backing UC tables:

```sql
GRANT USAGE ON CATALOG `31184_cerebro_poc4x` TO `<service-principal>`;
GRANT USAGE ON SCHEMA `31184_cerebro_poc4x`.`gandalf_magical_index` TO `<service-principal>`;
GRANT SELECT, MODIFY ON SCHEMA `31184_cerebro_poc4x`.`gandalf_magical_index` TO `<service-principal>`;
