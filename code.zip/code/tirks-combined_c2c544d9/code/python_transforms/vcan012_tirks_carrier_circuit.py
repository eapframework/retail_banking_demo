from pyspark.sql import functions as F
from transforms.api import transform, Input, Output, incremental
from utility.column_clean import clean_columns, lowercase_columns, remove_prefix


@transform(
    out=Output("/Innovation Lab/[Source] Teradata EDW - ASI_VIEWS/data/clean/vcan012_tirks_carrier_circuit"),
    df=Input("/Innovation Lab/[Source] Teradata EDW - ASI_VIEWS/data/raw/snowflake/SDW_AEDW_ASI_VIEWS.vcan012_tirks_carrier_circuit"),
)
def my_compute_function(df, out):
    df = df.dataframe().withColumn('CARRIER_IDENTIFICATION_CD_RAW', F.col('CARRIER_IDENTIFICATION_CD'))
    df = clean_columns(
        df,
        date_format=date_format,
        date_columns=string_to_date,
        datetime_format=datetime_format,
        datetime_columns=long_unixtime_to_timestamp,
        timestamp_from_string_format=string_unixtime_format,
        timestamp_from_string_columns=string_unixtime_to_timestamp,
        timestamp_format=long_unixtime_format, 
        timestamp_columns=long_unixtime_to_timestamp,
        integer_columns=string_to_integer_columns,
        double_columns=string_to_double_columns,
        decimal_columns=string_to_decimal_columns,
        id_columns=numeric_to_string_columns,
        integer_from_num_columns=decimal_to_integer,
        strip_columns=strip_string_columns,
    )
    # df = df.drop(*drop_columns)
    # df = remove_prefix(df, 'example_prefix')
    df = lowercase_columns(df)
    df = df.withColumn("channel_nbr", df["channel_nbr"].cast("short"))
    df = df.withColumn("circuit_assignment_seq_nbr", df["circuit_assignment_seq_nbr"].cast("short"))
    out.write_dataframe(df)


drop_columns = []

date_format = 'yyyy-MM-dd'
string_to_date = []
datetime_format = 'yyyy-MM-dd HH:mm:ss'
string_to_timestamp = []

string_unixtime_format = None
string_unixtime_to_timestamp = []
long_unixtime_format = None
long_unixtime_to_timestamp = []

string_to_integer_columns = []
string_to_double_columns = []
string_to_decimal_columns = []

numeric_to_string_columns = []
decimal_to_integer = []

strip_string_columns = [
    "SBC_COMPANY_CD",
    "SBC_SYSTEM_CD",
    "CARRIER_RECORD_TYPE_CD",
    "CARRIER_FACILITY_VIEW_CD",
    "CARRIER_CIRCUIT_ACCESS_CD",
    "CARRIER_INVENTORY_STATUS_CD",
    "SBC_STATE_CD",
    "CARRIER_IDENTIFICATION_CD",
    "ASSIGNMENT_RESPONSIBILITY_CD",
    "CARRIER_CKT_LAYOUT_ORDER_NBR",
    "PRIMARY_ALTERNATE_ASGNMT_CD",
    "CIRCUIT_ASSIGNMENT_VIEW_CD",
    "CIRCUIT_ASSIGNMENT_ACTIVITY_CD",
    "CKT_IDENTIFICATION_FORMAT_CD",
    "CIRCUIT_IDENTIFICATION_CD",
    "CIRCUIT_ACCESS_CD",
    "ASSIGNMENT_MISUSE_CD",
    "MULTIWIRE_CIRCUIT_CD",
    "DETAILED_RGLTY_GENERATION_CD",
    "DETL_RGLTY_FACILITY_CLASS_CD",
    "LOC_A_CHANNEL_PLUGIN_FUNC_CD",
    "LOC_Z_CHANNEL_PLUGIN_FUNC_CD",
    "CIRCUIT_LOCATION_A_CLLI_CD",
    "CIRCUIT_LOCATION_Z_CLLI_CD",
    "CIRCUIT_GROUP_ACCESS_CD",
    "LOC_A_DETL_RGLTY_STUDY_AREA_CD",
    "LOC_Z_DETL_RGLTY_STUDY_AREA_CD",
    "SERVICE_RESUMPTION_PRIORITY_CD",
    "CIRCUIT_LAYOUT_ORDER_NBR",
    "CKT_LYT_ORD_ACTIVITY_STATUS_CD",
]
