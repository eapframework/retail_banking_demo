""" Description: WS Job Details Clean
    BRD Level: Internal, NOT included on landing page

LOG:
    Date          | Author   | Description
    12-02-2024    | an4927   | code cleanup for uniform syntax and commenting
    -             | -        | -
    -             | -        | -
"""


from pyspark.sql import functions as F
from pyspark.sql.functions import col, when
from transforms.api import transform, Output, Input
from pyspark.sql.window import Window


@transform(
    out=Output("ri.foundry.main.dataset.053b8c98-05b2-45b7-be6e-1db1d597726e"),
    Job=Input("ri.foundry.main.dataset.e22328fc-bee6-4816-b6c2-a169b53710b8"),
    Tsk=Input("ri.foundry.main.dataset.02ef14fa-b8fe-43b9-9c99-5deede1454e5"),
    horizontal_template=Input("ri.foundry.main.dataset.70671ca9-7364-4c48-a859-8d5e5e8f112c"),
    prog_cat=Input("ri.foundry.main.dataset.30950e66-179c-4b47-8d2c-332399b45faf"),
    )
def my_compute_function(ctx, Job, out, Tsk, horizontal_template, prog_cat):
    j1 = Job.dataframe()
    df_job = j1.select(F.col("*")).distinct()

    # Cast a list of columns to timestamp type
    columns_to_ts = ["SITE_MODIFIED_DATE", "LAST_MODIFIED_TS", "SF_DEEP_SYNC_TS", "UPDATEDSTATUSON"]
    df_jobf = (
        df_job
        .select(
            *(c for c in df_job.columns if c not in columns_to_ts),
            *(F.from_unixtime(col(c) / 1000).cast("timestamp").alias(c) for c in columns_to_ts))
        )

    # Create default as null to remove empty strings
    columns_default = ["STRUCTURE_TYPE"]
    df_jobf = df_jobf.select(*[when(col(c) == "", None).otherwise(col(c)).alias(c)
            if c in columns_default else col(c) for c in df_jobf.columns])

    # PROGRAM CATEGORY code
    prog_cat = prog_cat.dataframe()
    prog_cat = prog_cat.select(F.col('iwm_number').alias('IWM_JOB_NUMBER'),
                               F.col('program').alias('PROGRAM'),
                               F.col('category').alias('CATEGORY'))
    df_jobf = df_jobf.join(prog_cat, ['IWM_JOB_NUMBER'], 'left')
    t1_EQ = Tsk.dataframe()
    df_EQ0 = t1_EQ.select(
        F.col("IWM_JOB_NUMBER"),
        F.col("TASK_MILESTONE_CODE")
    ).distinct().filter(F.col("TASK_MILESTONE_ENQUEUE_STATUS") == 'ENQUEUED')

    # Reorder columns based off horizontal template
    horizontal_template_df = horizontal_template.dataframe()
    df_h1_EQ = horizontal_template_df.select(
       F.substring(F.col("COLUMN_NAME"), 1, 5).alias('TASK_MILESTONE_CODE'),
       F.col("COLUMN_NO"),
       F.col("COLUMN_NAME")
    )
    # .filter((F.col("T_M_C") == 'T'))

    df_f_EQ1 = df_EQ0.join(df_h1_EQ, ['TASK_MILESTONE_CODE'], 'inner')
    df_f_EQ2 = df_f_EQ1.select(
        F.col("IWM_JOB_NUMBER"),
        F.col("TASK_MILESTONE_CODE")
    ).distinct()
    window = Window().partitionBy('IWM_JOB_NUMBER').orderBy('TASK_MILESTONE_CODE')

    df_f_EQ3 = df_f_EQ2.select(
        F.col("IWM_JOB_NUMBER"),
        F.col("TASK_MILESTONE_CODE")
    ).distinct()

    # Sort values by job and task for final join
    df_f_EQ3 = df_f_EQ3.withColumn("values_sorted", F.concat_ws(",",
            F.collect_list("TASK_MILESTONE_CODE").over(window)))
    df_f_EQ4 = df_f_EQ3.select(
        F.col("IWM_JOB_NUMBER"),
        F.col("values_sorted")
    ).groupby(F.col("IWM_JOB_NUMBER")).agg(F.max("values_sorted").alias('ENQUEUED_TASKS'))

    df_job1 = df_jobf.join(df_f_EQ4, ['IWM_JOB_NUMBER'], 'left')

    # Cast a list of columns to date type
    columns_to_dt = ["LAST_ACTUALIZED_TASK_ACTUAL_END_DATE", "ONAIR_PLAN_END_DATE", "ONAIR_ACTUAL_END_DATE"]
    df_jobf1 = (
        df_job1
        .select(
            *(c for c in df_job1.columns if c not in columns_to_dt),
            *(F.from_unixtime(col(c) / 1000).cast("date").alias(c) for c in columns_to_dt))
        )

    # Select all distinct rows for final dataframe
    df_final = df_jobf1.select(F.col("*")).distinct()
    out.write_dataframe(df_final)
