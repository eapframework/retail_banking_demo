# Project Inventory Summary

**Project name:** CMT Bandwidth

**Merge timestamp:** 2026-03-16T16:20:25.358931

**Project output dir:** `cmt-bandwidth_f455dc3f`

**Total resources in project folder:** 28

**Total merged records:** 60

**Unresolved (project_only) resources:** 0

## Resource Counts by Type

- **blacksmithdocument:** 1
- **blobsterspreadsheet:** 1
- **contouranalysis:** 8
- **datasource:** 5
- **eddiepipeline:** 3
- **magritteagent:** 7
- **networkegresspolicy:** 4
- **pythontransformation:** 13
- **rawdataset:** 14
- **unknown:** 1
- **vectorworkbook:** 2
- **virtualtable:** 1

## Mode

Flat output — workshop subdirectories removed after merge.
