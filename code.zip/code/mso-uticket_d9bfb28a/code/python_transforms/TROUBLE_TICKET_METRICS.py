from transforms.api import transform, Input, Output
from utility.column_clean import clean_columns, lowercase_columns, remove_prefix


@transform(
   out=Output("/Innovation Lab/[Source] Oracle AOTS-M/data/clean/BOADMIN.TROUBLE_TICKET_METRICS"),
   df=Input("/Innovation Lab/[Source] Oracle AOTS-M/data/raw/BOADMIN.TROUBLE_TICKET_METRICS"),
)
def my_compute_function(df, out):
    df = clean_columns(
        df.dataframe(),
        strip_columns=strip_columns,
        integer_columns=cast_to_integer_columns,
        double_columns=cast_to_double_columns,
        decimal_columns=cast_to_decimal_columns,
        timestamp_columns=cast_to_timestamp_from_long_columns,
        datetime_columns=cast_to_timestamp_columns,
        datetime_format=datetime_format,
        date_columns=cast_to_date_columns,
        date_format=date_format,
        id_columns=cast_to_string_columns,
        integer_from_num_columns=cast_to_integer_from_decimal_columns
    )
    df = lowercase_columns(df)
    out.write_dataframe(df)

date_format = 'yyyy-MM-dd'
datetime_format = 'yyyy-MM-dd HH:mm:ss'

cast_to_date_columns = []
cast_to_timestamp_columns = []
cast_to_timestamp_from_long_columns = []
cast_to_integer_columns = []
cast_to_double_columns = []
cast_to_decimal_columns = []
cast_to_string_columns = []
cast_to_integer_from_decimal_columns = [
    "DAYS",
    "ENTRY_TYPE",
    "HOURS",
    "MINUTES",
    "MODIFIED_DATE",
    "NEW_DATE_TIME",
    "PREVIOUS_DATE_TIME",
    "RECORD_STATUS",
    "SECONDS_IN_PREVIOUS_STATE",
    "SECONDS",
    "SEVERITY",
    "DAY",
    "MONTH",
    "YEAR",
    "WEEK",
    "QTR",
]
strip_columns = [
    "ASSIGNED_DISTRICT_SUB_DEPT",
    "ASSIGNED_MARKET",
    "ASSIGNED_REGION",
    "ASSIGNED",
    "ASSIGNED_ZONE",
    "ASSIGNED_TO",
    "COMMON_ID",
    "DDD_HH_MM",
    "DEPARTMENT",
    "EQUIPMENT_NAME",
    "FIELD_CHANGED",
    "FORM_CHANGED",
    "LAST_MODIFIED_BY",
    "METRIC_ID",
    "MODIFYING_USER",
    "NEW_VALUE",
    "OPERATION",
    "PARENT_ID",
    "PARENT_NAME",
    "PREVIOUS_METRIC_ID",
    "PREVIOUS_MODIFIED_BY",
    "PREVIOUS_VALUE",
    "RECORD_ID_CHANGED",
    "SUBMITTER",
    "TICKET_NUMBER",
    "TICKET_STATUS",
    "ZSHORT_DESCRIPTION",
    "PREVIOUS_DEPARTMENT",
    "PREVIOUS_ASSIGNED_REGION",
    "PREVIOUS_ASSIGNED_MARKET",
    "PREVIOUS_ASSIGNED_DISTRICT",
    "PREVIOUS_ASSIGNED_ZONE",
    "APPLICATION_USERID",
    "FROMAPP",
]