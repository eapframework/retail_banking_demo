from transforms.api import transform_df, Input, Output, configure
from capacity_project import config, utils
from capacity_project.api.Catalog import CatalogAPI
import pyspark.sql.types as T
from pyspark.sql import functions as F


@configure(profile=['EXECUTOR_MEMORY_MEDIUM', 'NUM_EXECUTORS_32'])
@transform_df(
    Output(f'{config.PARENT_FOLDER}/raw/SOURCE_DATASETS'),
    datasets=Input("/Innovation Lab/Data Governance/Code & Data/data/all_platform_data"),
    config=Input("/Innovation Lab/Palantir Admins/Quantum/inputs/config")
)
def my_compute_function(ctx, datasets, config):

    datasets = datasets.where(F.col("project_rid").isNotNull())

    token = utils.get_token(config)
    ca_api = CatalogAPI(token)
    datasets = datasets.withColumn("created_date", F.to_date(F.col("created_date"), 'yyyy-MM-dd')) \
                       .withColumn("last_modified_date", F.to_date(F.col("last_modified_date"), 'yyyy-MM-dd'))

    branches = (datasets
                .repartition(128)
                .rdd
                .flatMap(lambda dataset: get_branches(ca_api, dataset)))

    branch_df = ctx.spark_session.createDataFrame(branches, schema=T.StructType([
        T.StructField('dataset_rid', T.StringType(), True),
        T.StructField('branches', T.ArrayType(T.StringType()), True)
    ])).where(F.size(F.col("branches")) > 0)

    source_datasets = branch_df.join(datasets, "dataset_rid", "left") \
                               .withColumn("branchCount", F.size(F.col("branches")))
    return source_datasets


def get_branches(ca_api, dataset):
    branch_list = []
    branch_set = ca_api.get_branches(dataset.dataset_rid)
    if branch_set is None:
        return [(dataset.dataset_rid, None)]
    for branch in branch_set:
        branch_list.append(branch)
    return [(dataset.dataset_rid, branch_list)]
