import requests
from transforms.api import Input, Output, configure, transform
from pyspark.sql import types as T, functions as F
from quantum_api_ingest.foundry.get_config import get_config
from quantum_api_ingest.foundry.multipass import MultipassClient
import datetime


@configure(profile=["DRIVER_MEMORY_MEDIUM"])
@transform(
    output_df=Output("ri.foundry.main.dataset.50389607-896a-4651-b6d2-590d729a06fd", sever_permissions=True),
    input_df=Input("ri.foundry.main.dataset.3f14d1f4-59f0-471d-be56-9b003f89ad88"),
    config=Input("ri.foundry.main.dataset.b5cb343e-1109-4401-b3fb-5137c32cb781"),
)
def raw_multipass_group(ctx, config, input_df, output_df):
    multipass = MultipassClient(get_config(config))
    users = input_df.dataframe().rdd.map(lambda x: (x["id"])).collect()
    group_response = []
    added_settings = {}
    for user in users:
        try:
            groups = multipass.get_groups_for_user(user)["groups"]
            groups_unscanned = [group["id"] for group in groups if group["id"] not in list(added_settings.keys())]
            try:
                expiration_settings = multipass.get_expiration_settings(groups_unscanned).get(
                    "groupMemberExpirationSettings"
                )
            except Exception as e:
                expiration_settings = {}
            added_settings = {**added_settings, **expiration_settings}
        except requests.exceptions.HTTPError as e:
            if e.response.status_code == 403:
                continue
            else:
                raise
        for g in groups:
            g["user_id"] = user
        group_response += groups
    groups_metadata = []
    for key, value in added_settings.items():
        if value["maxExpiration"]:
            value["maxExpiration"] = datetime.datetime.fromisoformat(value["maxExpiration"][:-1])
        if value["maxDurationInSeconds"]:
            value["maxDurationInSeconds"] = int(value["maxDurationInSeconds"])
        groups_metadata += [{"id": key, **value}]
    groups_metadata_df = (
        ctx.spark_session.createDataFrame(groups_metadata, schema)
        .withColumnRenamed("maxExpiration", "max_expiration")
        .withColumnRenamed("maxDurationInSeconds", "max_duration_in_seconds")
    )
    group_df = ctx.spark_session.createDataFrame(group_response).join(groups_metadata_df, "id", "left")
    output_df.write_dataframe(group_df)


schema = T.StructType(
    [
        T.StructField(
            "id",
            T.StringType()
        ),
        T.StructField(
            "maxExpiration",
            T.TimestampType()
        ),
        T.StructField(
            "maxDurationInSeconds",
            T.IntegerType()
        )
    ]
)
