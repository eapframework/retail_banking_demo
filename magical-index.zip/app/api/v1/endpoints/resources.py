from __future__ import annotations

from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query, status

from app.schemas.pagination import PaginatedResponse, PaginationParams
from app.schemas.resource import (
    ActorType,
    ResourceCreate,
    ResourceRead,
    ResourceStatus,
    ResourceUpdate,
)
from app.services.store import store


router = APIRouter()


@router.post("/", response_model=ResourceRead, status_code=status.HTTP_201_CREATED)
def create_resource(payload: ResourceCreate) -> ResourceRead:
    """Create a resource. Auto-generates ``resource_id`` if not provided.

    Returns 409 if the given ``resource_id`` already exists.
    """
    try:
        return store.create_resource(payload)
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(exc))



@router.get("/{resource_id}", response_model=ResourceRead)
def get_resource(resource_id: str) -> ResourceRead:
    """Fetch a single resource by ``resource_id``. 404 if not found."""
    resource = store.get_resource(resource_id)
    if resource is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Resource not found")
    return resource


@router.get("/", response_model=PaginatedResponse[ResourceRead])
def list_resources(
    resource_status: Optional[ResourceStatus] = Query(None),
    resource_type: Optional[str] = Query(None),
    platform: Optional[str] = Query(None),
    pagination: PaginationParams = Depends(),
) -> PaginatedResponse[ResourceRead]:
    """List resources with pagination, optionally filtered by ``resource_status``, ``resource_type``, and/or ``platform``.
    
    Supports pagination via offset and limit query parameters.
    Returns paginated response with total count and has_more flag.
    """
    items, total = store.list_resources(
        resource_status=resource_status,
        resource_type=resource_type,
        platform=platform,
        offset=pagination.offset,
        limit=pagination.limit,
    )
    return PaginatedResponse.create(
        items=items,
        total=total,
        offset=pagination.offset,
        limit=pagination.limit,
    )


@router.patch("/{resource_id}", response_model=ResourceRead)
def update_resource(
    resource_id: str,
    payload: ResourceUpdate,
) -> ResourceRead:
    """Update any mutable field on a resource.

    Provide only the fields you want to change.  Every mutation is recorded
    in the activity log.
    """
    updated = store.update_resource(resource_id, payload)
    if updated is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Resource not found")
    return updated


@router.delete("/{resource_id}")
def delete_resource(
    resource_id: str,
    actor_type: ActorType = Query(...),
    actor_name: str = Query(..., min_length=1),
) -> dict[str, bool]:
    """Delete a resource and its relationships. Returns ``{deleted: true}`` on success."""
    deleted = store.delete_resource(resource_id, actor_type=actor_type, actor_name=actor_name)
    if not deleted:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Resource not found")
    return {"deleted": True}
