# from pyspark.sql import functions as F
from transforms.api import transform_df, Input, Output


@transform_df(
    Output("ri.foundry.main.dataset.9c457ebd-3eb9-4fb6-9acf-7bec66164458"),
    source_df_manual=Input("ri.foundry.main.dataset.4bf71c6d-a089-479a-b7ee-86330b134595"),
    source_df_automated=Input("ri.foundry.main.dataset.713ccb4d-a9e7-430b-8a1f-28e9bf88558b"),
)
def compute(source_df_manual, source_df_automated):

    df = source_df_automated
    df = df.select(
        "1toN_Region", 
        "1toN_Market_Cluster",
        "1toN_Market",
        "1toN_State",
        "1toN_FA",
        "1toN_USID",
        "1toN_Activity_1",
        "1toN_Activity_2",
        "1toN_Activity_3",
        "conwell_site_type",
        "1toN_update_date",
        # new fields from updated source process
        "1toN_pseudo_FA",
        # "Gen_Program_Site_Group",
        # "filename",
        # "file_date",
        # "load_date"
    )
    return df
