from transforms.api import transform, Output, Input, configure
from pyspark.sql import functions as F
from .program_category_utils import prepare_cband_1c_data, applyFilters, rollup_crp


SPARK_PROFILES = [
        'DRIVER_MEMORY_EXTRA_EXTRA_LARGE',
        'DRIVER_CORES_LARGE',
        'EXECUTOR_MEMORY_LARGE',
        'EXECUTOR_CORES_LARGE',
        'NUM_EXECUTORS_32',
        'EXECUTOR_MEMORY_OVERHEAD_LARGE',
        'DYNAMIC_ALLOCATION_DISABLED'
]


@configure(profile=SPARK_PROFILES)
@transform(
    # replace this with your output dataset path
    outinternal_lvl_1=Output("ri.foundry.main.dataset.45d4e145-6d09-4832-a86d-d1a7559f97d7"),
    tempout=Output("ri.foundry.main.dataset.5e26ce2e-9e49-4724-8572-806f04aad044"),
    iwm=Input("ri.foundry.main.dataset.53bb3121-e1f0-4b82-b910-b540db3e1bdf"),
    progcat_mapping_allinone=Input("ri.foundry.main.dataset.e2d8d814-aab3-4b34-ab6f-df4105884894"),
    )
def my_compute_function(ctx, iwm, progcat_mapping_allinone, outinternal_lvl_1, tempout):

    # get the necessary data from pace snapshot
    cols = [F.col("IWM_JOB_NUMBER").alias("iwm_number"),
            F.col("NATIONAL_PROGRAM").alias("national_program"),
            F.col("JOB_SCOPE").alias("job_scope"),
            F.col("JOB_STATUS").alias("status"),
            F.col("ORACLE_PTN").alias("oracle_ptn"),
            F.col("MOD_CODE").alias("mod_code"),
            F.col("SPECTRUM").alias("spectrum"),
            F.col("N_UDF4").alias("n_udf4"),
            F.col("N_UDF5").alias("n_udf5"),
            F.col("PRODUCT_GROUP").alias("product_group"),
            F.col("PRODUCT_SUB_GROUP").alias("product_subgroup"),
            F.col("PLANNING_NUMBER").alias("planning_number"),
            F.col("PLANNING_STATUS").alias("iplan_status"),
            F.col("FA_LOCATION_CODE").alias("fa_location_code"),
            F.col("ONAIR_ACTUAL_END_DATE").alias("onair_actual"),
            F.col("ONAIR_PLAN_END_DATE").alias("onair_forecast"),
            F.col("JOB_CATEGORY").alias("job_category"),
            F.col("ALLOCATION").alias("allocation"),
            F.col("SOLUTION").alias("solution"),
            F.col("NEW_SITE_BUILD").alias("new_site_build"),
            F.col("ASSOCIATED_FA").alias("associated_fa"),
            F.col("1220T_ACTUAL").alias("1220t_actual"),
            F.col("COMMITMENT_DATE").alias("commitment_date"),
            F.col("SCOPE_NAME").alias("scope_name"),
            ]

    iwm_df = iwm.dataframe().select(*cols).distinct()
    iwm_df = iwm_df.withColumn("allocation", F.when(F.col("allocation").isNull(), F.lit("NULL"))
                                              .otherwise(F.col("allocation")))

    # iwm_df = iwm_df.filter(F.col("iwm_number").isin('WSCTB0023366','WSGSC0050444','WSCHI0050735','WSNYJ0065796'))

    # Grap MPT AllInOne config changes
    progcat_mapping_allinone_df = progcat_mapping_allinone.dataframe()

    # Filter the programs for Level 1 tagging
    progcat_mapping_allinone_df = progcat_mapping_allinone_df.where("coalesce(Filter_Level,'1') = '1'")

    # Get the program details
    program_df = progcat_mapping_allinone_df.select(F.col("Program").alias("program")).distinct()

    # Get the program's rollup details
    prgroll_df = progcat_mapping_allinone_df.select(F.col("Program").alias("program"),
                F.col("Rollup").alias("rollup")) \
                .distinct() \
                .where('Rollup != ""')

    # Get the program's National jobScope Task Mappings
    prgjsmapping_df = progcat_mapping_allinone_df.select(F.col("Program").alias("program"),
                F.col("NationalProgram").alias("national_program"),
                F.col("JobScope").alias("job_scope")) \
                .distinct() \
                .where('NationalProgram != "" or JobScope != ""')

    # Capture the filter details and split into levels
    prgfilters_df = progcat_mapping_allinone_df.select(F.col("Program").alias("program"),
                F.col("Filter").alias("filter")) \
                .distinct() \
                .where("Filter != ''")

    # Get the 1C tagging column added to tag CBand 1C tagging
    df_out = prepare_cband_1c_data(iwm_df, tempout)
    df = (
        iwm_df
        .join(df_out, 'iwm_number', 'left')
    )

    # apply Filters to populate the Level-1 Programs
    out_df = applyFilters(ctx, df, program_df, prgjsmapping_df, prgfilters_df)

    # apply rollup changes
    rollup_df = rollup_crp(prgroll_df)

    out_df2 = (
        out_df
        .join(rollup_df, "program", "inner")
        .withColumn("program", F.col("rollup_program"))
        .drop("rollup_program")
    )

    # apply rollup changes
    out_df = out_df.unionByName(out_df2).distinct()

    # Overall Level 1 Changes
    outinternal_lvl_1.write_dataframe(out_df)
