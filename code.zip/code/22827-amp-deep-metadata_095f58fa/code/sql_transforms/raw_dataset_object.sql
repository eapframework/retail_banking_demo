CREATE TABLE `/Innovation Lab/Data Governance/AT&T Internal Shareable Resources/raw_dataset_object` TBLPROPERTIES (foundry_sever_inherited_permissions = 'true') AS WITH

dataset_type_column AS (
    SELECT
        project_name,
        dataset_rid,
        dataset_path,
        dataset_name,
        last_modified_date,
        created_date,
        magritte_extract_name,
        magritte_extract_rid,
        magritte_source_name,
        magritte_source_rid,
        magritte_source_type,
        magritte_subfolder,
        trashed,
        CAST(null as string) as schema,
        APD.description,
        MP.id,
        MP.username as created_by_email,
        SPLIT(MP.username, '@')[0] as attuid,
        WEBP.full_name as created_by_name,
        project_rid,
        CASE
            WHEN DATEDIFF(current_timestamp(), CAST(last_modified_date as Timestamp)) < 3 THEN 'Recurring Feed'
            ELSE 'Snapshot'
        END AS feed_type,
        'Unreviewed' as dataset_status,
        'DEEP' as program,
        CASE
            WHEN magritte_extract_rid is not null  THEN 'raw_dataset'
            ELSE 'derived_dataset'
        END AS dataset_type
    FROM `/Innovation Lab/Data Governance/Code & Data/data/all_platform_data` APD

    LEFT JOIN `/Innovation Lab/Palantir Admins/Quantum/Quantum - API Ingest v2/raw/multipass_user` MP
    ON created_by_user_id = MP.id AND dataset_path NOT LIKE ('%Users%') AND trashed == False

    LEFT JOIN `/Innovation Lab/[Source] Webphone/data/clean/webphone_with_emails` WEBP
    ON MP.username = WEBP.email
)

SELECT
    *
FROM dataset_type_column
WHERE dataset_type != 'derived_dataset' and magritte_source_name is not null and trashed = false