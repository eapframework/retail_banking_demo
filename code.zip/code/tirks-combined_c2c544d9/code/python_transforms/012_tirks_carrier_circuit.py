from transforms.api import transform_df, Input, Output, incremental
import pyspark.sql.functions as F


@transform_df(
    Output("/Innovation Lab/[ETL] Tirks Combined/data/012_tirks_carrier_circuit"),
    asi=Input("/Innovation Lab/[Source] Teradata EDW - ASI_VIEWS/data/clean/vcan012_tirks_carrier_circuit"),
    telco=Input("/Innovation Lab/[Source] Teradata EDW - ACCESS_VIEWS/data/prod_clean/vctn012_tirks_carrier_circuit"),
)
def my_compute_function(telco, asi):
    telco = telco.withColumn("source", F.lit('telco'))
    asi = asi.withColumn("source", F.lit('asi'))
    df = telco.unionByName(asi)
    return df
