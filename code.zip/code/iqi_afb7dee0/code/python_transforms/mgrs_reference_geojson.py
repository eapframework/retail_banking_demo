from pyspark.sql import functions as F, types as T
from transforms.api import transform_df, Input, Output
from shapely.geometry import shape
import json


@F.udf(returnType=T.BooleanType())
def validate_polygon(geo):
    '''
    geo: geojson string of polygon shape
    '''
    polygon = shape(json.loads(geo))
    return polygon.is_valid


@transform_df(
    Output("ri.foundry.main.dataset.f25057b5-53d3-499f-a7ce-0276c4f8d830"),
    source_df=Input("ri.foundry.main.dataset.0e340be8-66fa-43e8-aa3f-03fdde440481"),
)
def compute(source_df):
    '''
    Read this wiki THOROUGHLY before preceeding
    {
        "type": "Polygon",
        "coordinates": [
            [[30.0, 10.0], [40.0, 40.0], [20.0, 40.0], [10.0, 20.0], [30.0, 10.0]]
        ]
    }
    Latitude = south and north
    Longitude = west and east
    '''
    # Reduce dataset size by limiting bins to North America
    Northernmost = 72
    Southernmost = 20
    Easternmost = -55
    Westernmost = -175
    df = source_df.filter(
        (F.col("ne_lat") < Northernmost) &
        (F.col("sw_lat") > Southernmost) &
        (F.col("ne_long") < Easternmost) &
        (F.col("sw_long") > Westernmost)
    )

    # Keep 1k bins only for now
    df = df.filter(F.col("bin_size") == 100)

    # Remove records without lengths to the sides
    df = df.withColumn("bad_bin", 
        (F.col("sw_lat") == F.col("nw_lat")) |
        (F.col("se_lat") == F.col("ne_lat")) |
        (F.col("ne_long") == F.col("nw_long")) |
        (F.col("se_long") == F.col("sw_long"))
    )
    df = df.filter(~F.col("bad_bin"))
    df = df.drop("bad_bin")

    # Form polygon
    df = df.withColumn("type", F.lit("Polygon"))\
                    .withColumn("coordinates", 
                        F.array(
                            F.array(
                                F.array(F.col("sw_long"), F.col("sw_lat")),
                                F.array(F.col("se_long"), F.col("se_lat")),
                                F.array(F.col("ne_long"), F.col("ne_lat")),
                                F.array(F.col("nw_long"), F.col("nw_lat")),
                                F.array(F.col("sw_long"), F.col("sw_lat")),
                            )
                        )
                    )
    df = df.withColumn("shape", F.to_json(F.struct("type", "coordinates")))

    # Validate shape with shapely
    df = df.withColumn("valid_shape", validate_polygon(F.col("shape")))
    df = df.filter(F.col("valid_shape"))
    df = df.drop("valid_shape")

    # Drop binary column
    df = df.drop("geospatial_idx")

    return df
