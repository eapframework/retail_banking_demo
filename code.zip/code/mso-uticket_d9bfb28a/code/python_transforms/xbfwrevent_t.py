from transforms.api import configure
from transforms.api import transform, Input, Output,incremental
from utility.column_clean import clean_columns, lowercase_columns, remove_prefix
from ..utils import perform_timestamp_parsing,process_update_insert
from utility.incremental.update_insert import update_insert_core


@incremental(semantic_version=7)
@configure(profile=['EXECUTOR_MEMORY_MEDIUM', 'PARQUET_DISABLE_VECTORIZED_READER'])
@transform(
   out=Output("ri.foundry.main.dataset.2e4582c3-91f4-45a4-8fab-4cdc09ef70b5"),
   df=Input("ri.foundry.main.dataset.7144ba2f-0d66-4605-896c-82407cf92295"),
)
def my_compute_function(ctx,df, out):
    def processing(df):
        df = lowercase_columns(df)
        return df
    process_update_insert(ctx, out, df, ["eventid"], ["eventdatetime"], None, None, processing)
    # update_insert(ctx, out, df, ["eventid"], ["eventdatetime"], None, None, processing)
    # updates_df = perform_timestamp_parsing(lowercase_columns(df.dataframe(mode="added")))
    # # backfill_df = perform_timestamp_parsing(backfill.dataframe(mode="added")).drop("pull_slice")
    # update_insert_core(ctx, out, updates_df, backfill_df=None, primary_keys=[
    #   'eventid'], order_cols=["eventdatetime"])      df,
        strip_columns=strip_columns,
        integer_columns=cast_to_integer_columns,
        double_columns=cast_to_double_columns,
        decimal_columns=cast_to_decimal_columns,
        timestamp_columns=cast_to_timestamp_from_long_columns,
        datetime_columns=cast_to_timestamp_columns,
        datetime_format=datetime_format,
        date_columns=cast_to_date_columns,
        date_format=date_format,
        id_columns=cast_to_string_columns,
        integer_from_num_columns=cast_to_integer_from_decimal_columns,
    )
    df = lowercase_columns(df)

    # Fetches a list of the files that are in the dataset
    files = list(out.filesystem(mode='previous').ls())
    logger.info("previous files count: {}".format(len(files)))
    if (len(files) > FILE_COUNT_LIMIT):
        logger.info("Files more than threshold, will be repartitioning the data")
        # incremental merge and replace
        previous_df = out.dataframe('previous', schema=nullableSchema(out.dataframe("current").schema))
        df = df.unionByName(previous_df)
        df = df.repartition(600, "eventid")
        mode = 'replace'
    else:
        logger.info("Files less than threshold, no repartitioning required")
        # Standard incremental mode
        mode = 'modify'

    df = df.dropDuplicates()
    out.set_mode(mode)
    out.write_dataframe(df)


def nullableSchema(schema):
    return T.StructType([T.StructField(s.name, s.dataType, True) for s in schema])


date_format = "yyyy-MM-dd"
datetime_format = "yyyy-MM-dd HH:mm:ss"

cast_to_date_columns = []
cast_to_timestamp_columns = []
cast_to_timestamp_from_long_columns = ["EVENTDATETIME"]
cast_to_integer_columns = []
cast_to_double_columns = []
cast_to_decimal_columns = []
cast_to_string_columns = []
cast_to_integer_from_decimal_columns = []
strip_columns = []
