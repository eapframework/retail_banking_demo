from pyspark.sql import functions as F
from pyspark.sql.window import Window
from pyspark.sql.functions import dense_rank
from transforms.api import transform_df, Input, Output


@transform_df(
    Output("ri.foundry.main.dataset.d064abd5-145a-433f-a174-615ecf38e768"),
    source_df=Input("ri.foundry.main.dataset.a2b652a8-0ab4-4860-aa5b-ff6c1fe22c01"),
)
def compute(source_df):
    # Use window function to prioritize selecting when att_eng_zone_gid has entry
    source_df = source_df.filter(source_df.usid_active_ind == "Y")
    source_df = source_df.filter(source_df.on_air_ind == "Y")
    # Create window per usid, grabbing highest zone gid and ranking
    # This rank will let us set up selecting and avoid selecting null for zone gid where possible
    user_window = Window().partitionBy('usid').orderBy(F.col("att_eng_zone_gid"))
    df = source_df.withColumn('profile_row_num', dense_rank().over(user_window))
    # New window needed actually to select for the rank
    w = Window.partitionBy('usid')
    df = df.withColumn('max_row_num', F.max('profile_row_num').over(w))\
        .where(F.col('profile_row_num') == F.col('max_row_num'))\
        .drop('max_row_num')
    # Selecting the columns needed
    df = df.select("usid", "att_eng_zone_gid").dropDuplicates(["usid"])
    return df
