# Project Inventory Summary

**Project name:** West PM FTTCS

**Merge timestamp:** 2026-03-16T14:39:40.689133

**Project output dir:** `west-pm-fttcs_4df35365`

**Total resources in project folder:** 21

**Total merged records:** 53

**Unresolved (project_only) resources:** 0

## Resource Counts by Type

- **codeworkbookdataset:** 10
- **contour:** 2
- **contouranalysis:** 3
- **datasource:** 2
- **foundrydataset:** 1
- **fusionsheet:** 1
- **magritteagent:** 7
- **pipelinebuilder:** 1
- **pythontransformation:** 15
- **rawdataset:** 8
- **vectorworkbook:** 3

## Mode

Flat output — workshop subdirectories removed after merge.
