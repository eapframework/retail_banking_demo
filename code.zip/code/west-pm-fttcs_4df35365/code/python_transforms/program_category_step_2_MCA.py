from transforms.api import transform, Output, Input, configure
from pyspark.sql import functions as F
from pyspark.sql.types import IntegerType
from pyspark.sql.window import Window


SPARK_PROFILES = [
        'DRIVER_MEMORY_EXTRA_EXTRA_LARGE',
        'DRIVER_CORES_LARGE',
        'EXECUTOR_MEMORY_LARGE',
        'EXECUTOR_CORES_LARGE',
        'NUM_EXECUTORS_32',
        'EXECUTOR_MEMORY_OVERHEAD_LARGE',
        'DYNAMIC_ALLOCATION_DISABLED'
]


@configure(profile=SPARK_PROFILES)
@transform(
    # replace this with your output dataset path
    mca_lvl_2_sites=Output("ri.foundry.main.dataset.a717def0-53c1-408c-a138-23c55fc6a37c"),
    outinternal_lvl_1=Input("ri.foundry.main.dataset.45d4e145-6d09-4832-a86d-d1a7559f97d7"),
    tempout_mca_C=Output("ri.foundry.main.dataset.33b36d9d-56f3-4389-87a0-5988fe261e70"),
    tempout_mca_PA=Output("ri.foundry.main.dataset.63ec88c3-f182-4d73-8515-086ab63fd525"),
    iwm=Input("ri.foundry.main.dataset.53bb3121-e1f0-4b82-b910-b540db3e1bdf"),
    )
def my_compute_function(ctx, iwm, outinternal_lvl_1, mca_lvl_2_sites,
                        tempout_mca_C, tempout_mca_PA):

    # get the necessary data from pace snapshot
    cols = [F.col("IWM_JOB_NUMBER").alias("iwm_number"),
            F.col("NATIONAL_PROGRAM").alias("national_program"),
            F.col("JOB_SCOPE").alias("job_scope"),
            F.col("JOB_STATUS").alias("status"),
            F.col("ORACLE_PTN").alias("oracle_ptn"),
            F.col("MOD_CODE").alias("mod_code"),
            F.col("SPECTRUM").alias("spectrum"),
            F.col("N_UDF4").alias("n_udf4"),
            F.col("N_UDF5").alias("n_udf5"),
            F.col("PRODUCT_GROUP").alias("product_group"),
            F.col("PRODUCT_SUB_GROUP").alias("product_subgroup"),
            F.col("PLANNING_NUMBER").alias("planning_number"),
            F.col("PLANNING_STATUS").alias("iplan_status"),
            F.col("FA_LOCATION_CODE").alias("fa_location_code"),
            F.col("ONAIR_ACTUAL_END_DATE").alias("onair_actual"),
            F.col("ONAIR_PLAN_END_DATE").alias("onair_forecast"),
            F.col("JOB_CATEGORY").alias("job_category"),
            F.col("ALLOCATION").alias("allocation"),
            F.col("SOLUTION").alias("solution"),
            F.col("NEW_SITE_BUILD").alias("new_site_build"),
            F.col("ASSOCIATED_FA").alias("associated_fa"),
            F.col("1220T_ACTUAL").alias("1220t_actual"),
            F.col("COMMITMENT_DATE").alias("commitment_date"),
            F.col("SCOPE_NAME").alias("scope_name"),
            ]

    iwm_df = iwm.dataframe().select(*cols).distinct()
    iwm_df = iwm_df.withColumn("allocation", F.when(F.col("allocation").isNull(), F.lit("NULL"))
                                              .otherwise(F.col("allocation")))

    # Catpture the Level 1 tagging required for MCA Sites tagging
    outinternal_lvl_1_df = outinternal_lvl_1.dataframe()
    outinternal_lvl_1_df = outinternal_lvl_1_df.withColumnRenamed('program', 'level1_program')
    # Filter out those Level 1 parent program used in Level 2 tagging. ** Consider add this into ALLInOne config table.

    mca_lvl_1_df = outinternal_lvl_1_df.filter(F.col("level1_program").isin('MCA HW BAU',
            'Nokia Swaps HW', 'MCA HW Ericsson Upgrades'))

    # 'MCA HW All In'
    # mca_sites_df = "level1_program in ('MCA HW All In','MCA HW BAU','Nokia Swaps HW','MCA HW Ericsson Upgrades')"
    # mca_lvl_1_df = outinternal_lvl_1_df.filter(mca_sites_df)

    # Get the matching job's attributes
    mca_iwm_df = mca_lvl_1_df.join(
        iwm_df,
        "iwm_number",
        "inner"
    )

    # ----------------- Program Category MCA Sites tagging STARTs here -----------------
    '''
    # Prepare for MCA Sites Tagging
    df_out = prepare_AllInSites_tagging_data(mca_iwm_df, mca_lvl_1_df, tempout_mca_C, tempout_mca_PA)

    df_out = (
        df_out
        .select("iwm_number", "mca_fa_rnk_C_order", "mca_fa_rnk_PA_order")
        .filter("mca_fa_rnk_C_order is not null OR mca_fa_rnk_PA_order is not null")
        .distinct()
    )

    cols_to_sum = ["mca_fa_rnk_C_order", "mca_fa_rnk_PA_order"]

    # Use coalesce to replace nulls with 0 before summing
    df_out = df_out.groupBy("iwm_number").agg(*[F.sum(F.coalesce(F.col(c), F.lit(0))).alias(c) for c in cols_to_sum])

    out_df = (
        iwm_df
        .join(df_out, 'iwm_number', 'left')
        .select("iwm_number", "mca_fa_rnk_C_order", "mca_fa_rnk_PA_order")
        .filter("mca_fa_rnk_C_order is not null OR mca_fa_rnk_PA_order is not null")
        .distinct()
    )

    '''
    # Get the Sites Tagging columns added
    df_out = prepare_Sites_tagging_data(mca_iwm_df, mca_lvl_1_df, tempout_mca_C, tempout_mca_PA)

    df_out = (
        df_out
        .select("iwm_number",
                "mca_fa_rnk_BAU_C_order", "mca_fa_rnk_BAU_PA_order",
                "mca_fa_rnk_Nokia_C_order", "mca_fa_rnk_Nokia_PA_order",
                "mca_fa_rnk_Ericsson_C_order", "mca_fa_rnk_Ericsson_PA_order")
        .filter("mca_fa_rnk_BAU_C_order is not null OR mca_fa_rnk_BAU_PA_order is not null OR \
            mca_fa_rnk_Nokia_C_order is not null OR mca_fa_rnk_Nokia_PA_order is not null OR \
            mca_fa_rnk_Ericsson_C_order is not null OR mca_fa_rnk_Ericsson_PA_order is not null")
        .distinct()
    )

    cols_to_sum = ["mca_fa_rnk_BAU_C_order", "mca_fa_rnk_BAU_PA_order",
                "mca_fa_rnk_Nokia_C_order", "mca_fa_rnk_Nokia_PA_order",
                "mca_fa_rnk_Ericsson_C_order", "mca_fa_rnk_Ericsson_PA_order"]

    # Use coalesce to replace nulls with 0 before summing
    df_out = df_out.groupBy("iwm_number").agg(*[F.sum(F.coalesce(F.col(c), F.lit(0))).alias(c) for c in cols_to_sum])

    # "mca_fa_rnk_C_order", "mca_fa_rnk_PA_order"

    out_df = (
        df_out
        .select("iwm_number", "mca_fa_rnk_BAU_C_order", "mca_fa_rnk_BAU_PA_order",
                "mca_fa_rnk_Nokia_C_order", "mca_fa_rnk_Nokia_PA_order",
                "mca_fa_rnk_Ericsson_C_order", "mca_fa_rnk_Ericsson_PA_order")
    )
    # ----------------- Program Category MCA Sites tagging ENDs here -----------------

    # Overall Level 1 Changes
    mca_lvl_2_sites.write_dataframe(out_df)


def prepare_AllInSites_tagging_data(iwm_df, lvl1_df, tempout_mca_C, tempout_mca_PA):

    # Filter the valid project for Sites Tagging also filter out the valid MPT jobs based on 1220T_ACTUAL
    valid_jobs = "upper(status) in ('ON_GOING','COMPLETED') \
        and year(1220t_actual) not in (1920,1950)"
    # iwm_df = iwm_df.where(valid_jobs)

    # Select the columns required for tagging
    iwm_df = (
        iwm_df
        .select(
            F.col("iwm_number"),
            F.col("fa_location_code"),
            F.col("mod_code"),
            F.year(F.coalesce(F.col("onair_actual"), F.col("onair_forecast"))).alias("plan_YR"),
            # F.left(F.col("scope_name")).alias("scope_YR"),
            F.col("scope_name"),
            F.year(F.col("commitment_date")).alias("commitment_YR"),
            F.year(F.col("onair_actual")).alias("actual_YR"),
            F.col("allocation")
        )
        .where(valid_jobs)
    )

    # Select the required data for Sites Tagging
    sites_filter = "level1_program = 'MCA HW All In'"
    iwm_sites_df = lvl1_df.where(sites_filter)

    # Limit the Tagging dataset to small and for valid Sites jobs
    iwm_df = iwm_df.join(
        iwm_sites_df,
        "iwm_number",
        "leftsemi"
    )

    # Select the required columns for Sites Tagging
    iwm_sites_df = (
        iwm_sites_df
        .join(iwm_df, "iwm_number", "inner")
        .select(
            F.col("iwm_number"),
            F.col("level1_program"),
            F.col("allocation")
        )
    )

    # filter the Valid jobs for commitment Tagging
    # Select the required columns
    valid_mca_C_df = (
        iwm_df
        .select(
            F.col("iwm_number"),
            F.col("mod_code"),
            F.col("commitment_YR").alias("YR"),
            F.col("fa_location_code")
        )
        .where("left(scope_name,4) = commitment_YR")
    )

    # Call the function for commitment Tagging for Sites per FA and ModCode
    tempout_C, C_df = Generate_MCA_tagging_C(iwm_sites_df, valid_mca_C_df, "Sites")
    # merge the MCA Temp output, to add extra tagging columns
    mca_df = C_df

    # filter out Valid jobs for MCA tag checking for Plan/Actual.
    # Select the required columns
    valid_mca_PA_df = (
        iwm_df
        .select(
            F.col("iwm_number"),
            F.col("mod_code"),
            F.col("plan_YR").alias("YR"),
            F.col("fa_location_code"),
            F.col("scope_name"),
            F.col("commitment_YR"),
            F.col("actual_YR")
        )
        .where("plan_YR is not null")
    )

    # Call the Function to do Plan and Actual tagging
    tempout_PA, PA_df = Generate_MCA_tagging_PA(iwm_sites_df, valid_mca_PA_df, "Sites")
    # merge the MCA Temp output, to add extra tagging columns
    mca_df = mca_df.unionByName(PA_df, allowMissingColumns=True)

    # retun the Dataset with sites Tagging columns
    return mca_df


def prepare_Sites_tagging_data(iwm_df, lvl1_df, tempout_mca_C, tempout_mca_PA):

    # Filter the valid project for Sites Tagging also filter out the valid MPT jobs based on 1220T_ACTUAL
    valid_jobs = "upper(status) in ('ON_GOING','COMPLETED') \
        and year(1220t_actual) not in (1920,1950)"
    # iwm_df = iwm_df.where(valid_jobs)

    # Select the columns required for tagging
    iwm_df = (
        iwm_df
        .select(
            F.col("iwm_number"),
            F.col("fa_location_code"),
            F.col("mod_code"),
            F.year(F.coalesce(F.col("onair_actual"), F.col("onair_forecast"))).alias("plan_YR"),
            # F.left(F.col("scope_name")).alias("scope_YR"),
            F.col("scope_name"),
            F.year(F.col("commitment_date")).alias("commitment_YR"),
            F.year(F.col("onair_actual")).alias("actual_YR"),
            F.col("allocation")
        )
        .where(valid_jobs)
    )

    # Select the required data for Sites Tagging
    iwm_sites_df = lvl1_df

    # Limit the Tagging dataset to small and for valid Sites jobs
    iwm_df = iwm_df.join(
        iwm_sites_df,
        "iwm_number",
        "leftsemi"
    )

    # Select the required columns for Sites Tagging
    iwm_sites_df = (
        iwm_sites_df
        .join(iwm_df, "iwm_number", "inner")
        .select(
            F.col("iwm_number"),
            F.col("level1_program"),
            F.col("allocation"),
            F.col("plan_YR"),
            F.col("commitment_YR")
        )
    )

    bau_filter = "level1_program = 'MCA HW BAU' and (plan_YR > 2024 OR commitment_YR > 2024)"

    bau_filter_2024 = "level1_program = 'MCA HW BAU' and (plan_YR <= 2024 OR commitment_YR <= 2024)"

    nokia_filter = "level1_program = 'Nokia Swaps HW'"

    ericsson_filter = "level1_program = 'MCA HW Ericsson Upgrades'"

    iwm_bau_sites_df = iwm_sites_df.where(bau_filter)
    iwm_bau_sites_df_2024 = iwm_sites_df.where(bau_filter_2024)
    iwm_nokia_sites_df = iwm_sites_df.where(nokia_filter)
    iwm_ericcson_sites_df = iwm_sites_df.where(ericsson_filter)

    # filter the Valid jobs for commitment Tagging
    # Select the required columns
    valid_mca_C_df = (
        iwm_df
        .select(
            F.col("iwm_number"),
            F.col("mod_code"),
            F.col("commitment_YR").alias("YR"),
            F.col("fa_location_code")
        )
        .where("left(scope_name,4) = commitment_YR")
    )

    valid_mca_C_2024_df = (
        iwm_df
        .select(
            F.col("iwm_number"),
            F.col("mod_code"),
            F.col("commitment_YR").alias("YR"),
            F.col("fa_location_code")
        )
        .where("left(scope_name,4) = commitment_YR and commitment_YR <= 2024")
    )

    valid_mca_C_2025_df = (
        iwm_df
        .select(
            F.col("iwm_number"),
            F.col("mod_code"),
            F.col("commitment_YR").alias("YR"),
            F.col("fa_location_code")
        )
        .where("left(scope_name,4) = commitment_YR and commitment_YR > 2024")
    )

    # Call the function for commitment Tagging for Sites per FA and ModCode
    tempout_C, C_df = Generate_MCA_tagging_C(iwm_bau_sites_df_2024, valid_mca_C_2024_df, "BAU_2024")
    # merge the MCA Temp output, to add extra tagging columns
    tempout_C_df = tempout_C
    mca_df = C_df

    # Call the function for commitment Tagging for Sites per FA and ModCode
    tempout_C, C_df = Generate_MCA_tagging_C(iwm_bau_sites_df, valid_mca_C_2025_df, "BAU")
    # merge the MCA Temp output, to add extra tagging columns
    tempout_C_df = tempout_C_df.unionByName(tempout_C, allowMissingColumns=True)
    mca_df = mca_df.unionByName(C_df, allowMissingColumns=True)

    # Call the function for commitment Tagging for Sites per FA and ModCode
    tempout_C, C_df = Generate_MCA_tagging_C(iwm_nokia_sites_df, valid_mca_C_df, "Nokia")
    # merge the MCA Temp output, to add extra tagging columns
    tempout_C_df = tempout_C_df.unionByName(tempout_C, allowMissingColumns=True)
    mca_df = mca_df.unionByName(C_df, allowMissingColumns=True)

    # Call the function for commitment Tagging for Sites per FA and ModCode
    tempout_C, C_df = Generate_MCA_tagging_C(iwm_ericcson_sites_df, valid_mca_C_df, "Ericsson")
    # merge the MCA Temp output, to add extra tagging columns
    tempout_C_df = tempout_C_df.unionByName(tempout_C, allowMissingColumns=True)
    tempout_mca_C.write_dataframe(tempout_C_df)
    mca_df = mca_df.unionByName(C_df, allowMissingColumns=True)

    # filter out Valid jobs for MCA tag checking for Plan/Actual.
    # Select the required columns
    valid_mca_PA_df = (
        iwm_df
        .select(
            F.col("iwm_number"),
            F.col("mod_code"),
            F.col("plan_YR").alias("YR"),
            F.col("fa_location_code"),
            F.col("scope_name"),
            F.col("commitment_YR"),
            F.col("actual_YR")
        )
        .where("plan_YR is not null")
    )

    valid_mca_PA_2024_df = (
        iwm_df
        .select(
            F.col("iwm_number"),
            F.col("mod_code"),
            F.col("plan_YR").alias("YR"),
            F.col("fa_location_code"),
            F.col("scope_name"),
            F.col("commitment_YR"),
            F.col("actual_YR")
        )
        .where("plan_YR is not null and plan_YR <= 2024")
    )

    valid_mca_PA_2025_df = (
        iwm_df
        .select(
            F.col("iwm_number"),
            F.col("mod_code"),
            F.col("plan_YR").alias("YR"),
            F.col("fa_location_code"),
            F.col("scope_name"),
            F.col("commitment_YR"),
            F.col("actual_YR")
        )
        .where("plan_YR is not null and plan_YR > 2024")
    )

    # Call the Function to do Plan and Actual tagging
    tempout_PA, PA_df = Generate_MCA_tagging_PA(iwm_bau_sites_df_2024, valid_mca_PA_2024_df, "BAU_2024")
    # merge the MCA Temp output, to add extra tagging columns
    tempout_PA_df = tempout_PA
    mca_df = mca_df.unionByName(PA_df, allowMissingColumns=True)

    tempout_PA, PA_df = Generate_MCA_tagging_PA(iwm_bau_sites_df, valid_mca_PA_2025_df, "BAU")
    # merge the MCA Temp output, to add extra tagging columns
    tempout_PA_df = tempout_PA_df.unionByName(tempout_PA, allowMissingColumns=True)
    mca_df = mca_df.unionByName(PA_df, allowMissingColumns=True)

    tempout_PA, PA_df = Generate_MCA_tagging_PA(iwm_nokia_sites_df, valid_mca_PA_df, "Nokia")
    # merge the MCA Temp output, to add extra tagging columns
    tempout_PA_df = tempout_PA_df.unionByName(tempout_PA, allowMissingColumns=True)
    mca_df = mca_df.unionByName(PA_df, allowMissingColumns=True)

    tempout_PA, PA_df = Generate_MCA_tagging_PA(iwm_ericcson_sites_df, valid_mca_PA_df, "Ericsson")
    # merge the MCA Temp output, to add extra tagging columns
    tempout_PA_df = tempout_PA_df.unionByName(tempout_PA, allowMissingColumns=True)
    tempout_mca_PA.write_dataframe(tempout_PA_df)
    mca_df = mca_df.unionByName(PA_df, allowMissingColumns=True)

    # retun the Dataset with sites Tagging columns
    return mca_df


def Generate_MCA_tagging_C(lvl1_df, iwm_df, RnkType):

    # Set the tagging variable based on InputType
    if RnkType == "Sites":
        MCA_Cat_Rank_udf = F.udf(MCA_Cat_Rank, IntegerType())
        ColName = "mca_fa_rnk_C_order"
    elif RnkType == "BAU_2024":
        MCA_Cat_Rank_udf = F.udf(MCA_Cat_Rank_BAU_2024, IntegerType())
        ColName = "mca_fa_rnk_BAU_C_order"
    elif RnkType == "BAU":
        MCA_Cat_Rank_udf = F.udf(MCA_Cat_Rank_BAU, IntegerType())
        ColName = "mca_fa_rnk_BAU_C_order"
    elif RnkType == "Nokia":
        MCA_Cat_Rank_udf = F.udf(MCA_Cat_Rank_Nokia, IntegerType())
        ColName = "mca_fa_rnk_Nokia_C_order"
    elif RnkType == "Ericsson":
        MCA_Cat_Rank_udf = F.udf(MCA_Cat_Rank_Ericsson, IntegerType())
        ColName = "mca_fa_rnk_Ericsson_C_order"

    # filter the required jobs
    # Limit the Tagging dataset to small and for valid Sites jobs
    iwm_df = iwm_df.join(
        lvl1_df,
        "iwm_number",
        "leftsemi"
    )

    iwm_df = iwm_df.withColumn('Cat_Order', MCA_Cat_Rank_udf(F.col('mod_code')))
    iwm_df = iwm_df.filter(iwm_df.Cat_Order.isNotNull())

    # Apply Rank() over partition logic
    partition = Window.partitionBy('YR', 'fa_location_code').orderBy('Cat_Order', 'iwm_number')
    iwm_df = iwm_df.withColumn('rnk_order', F.rank().over(partition))

    # Generate temp output for validation
    outdf = iwm_df.select(F.col("*"))

    # Filter the dataframe
    iwm_df = iwm_df.filter((F.col('rnk_order') == 1) & (F.col('Cat_Order').isNotNull()))

    iwm_df = (
        iwm_df
        .select(
            F.col("iwm_number").alias("iwm_number"),
            F.col("rnk_order").alias(ColName),
        )
    )

    return outdf, iwm_df


def Generate_MCA_tagging_PA(lvl1_df, iwm_df, RnkType):  # noqa: C901

    # Set the tagging variable based on InputType
    if RnkType == "Sites":
        MCA_Cat_Rank_udf = F.udf(MCA_Cat_Rank, IntegerType())
        ColName = "mca_fa_rnk_PA_order"
    elif RnkType == "BAU_2024":
        MCA_Cat_Rank_udf = F.udf(MCA_Cat_Rank_BAU_2024, IntegerType())
        ColName = "mca_fa_rnk_BAU_PA_order"
    elif RnkType == "BAU":
        MCA_Cat_Rank_udf = F.udf(MCA_Cat_Rank_BAU, IntegerType())
        ColName = "mca_fa_rnk_BAU_PA_order"
    elif RnkType == "Nokia":
        MCA_Cat_Rank_udf = F.udf(MCA_Cat_Rank_Nokia, IntegerType())
        ColName = "mca_fa_rnk_Nokia_PA_order"
    elif RnkType == "Ericsson":
        MCA_Cat_Rank_udf = F.udf(MCA_Cat_Rank_Ericsson, IntegerType())
        ColName = "mca_fa_rnk_Ericsson_PA_order"

    # filter the required jobs
    # Limit the Tagging dataset to small and for valid Sites jobs
    iwm_df = iwm_df.join(
        lvl1_df,
        "iwm_number",
        "leftsemi"
    )

    mca_df = iwm_df.where("left(scope_name,4) = commitment_YR and actual_YR = commitment_YR")
    mca_df = mca_df.withColumn('Cat_Order', MCA_Cat_Rank_udf(F.col('mod_code')))
    mca_df = mca_df.filter(mca_df.Cat_Order.isNotNull())

    # Apply Rank() over partition logic
    partition = Window.partitionBy('YR', 'fa_location_code').orderBy('Cat_Order', 'iwm_number')
    mca_df = mca_df.withColumn('rnk_order', F.rank().over(partition))

    # Select the required columns
    mca_df2 = iwm_df

    # exclude those FA found in Level1
    mca_df2 = mca_df2.join(mca_df, ['YR', "fa_location_code"], "left_anti")

    mca_df2 = mca_df2.withColumn('Cat_Order', MCA_Cat_Rank_udf(F.col('mod_code')))
    mca_df2 = mca_df2.filter(mca_df2.Cat_Order.isNotNull())

    # Apply Rank() over partition logic
    partition = Window.partitionBy('YR', 'fa_location_code').orderBy('Cat_Order', 'iwm_number')
    mca_df2 = mca_df2.withColumn('rnk_order', F.rank().over(partition))

    mca_df = mca_df2.unionByName(mca_df)

    # Generate temp output for validation
    outdf = mca_df.select(F.col("*"))

    # Filter the dataframe
    mca_df = mca_df.filter((F.col('rnk_order') == 1) & (F.col('Cat_Order').isNotNull()))

    mca_df = (
        mca_df
        .select(
            F.col("iwm_number").alias("iwm_number"),
            F.col("rnk_order").alias(ColName),
        )
    )

    return outdf, mca_df


def MCA_Cat_Rank(mod_code):
    # Here are the Ranking Order, Based on the ModCode(s)

    '''
    ======== Primary ========
    1.Nokia Swap Primary (AAP64)
    2.Cband Primary (AAM0N)
    3.5G NR/5G Upgrade Primary (AALUA)
    4.LTE AC Primary (AAGLZ,AAGM0,AAGM1,AAGM3,AAGM4,AAGM6,AADBN,AADBO,AADBP,AADBQ,AAGJT,AAGUU,AAGUW)
    6.BWE Primary (AAGNQ,AAGNT)
    7.4T4R Primary (AAGNV)
    ======== Standalone ========
    2.Cband Standalone(AAM16)
    3.5G NR/5G Upgrade Standalone (AAK0R)
    4.LTE AC Standalone (AAGM9,AAGMA,AAGMB,AAGMC,AAGMD,AAGME,AAGJU,AAGUT,LTE2C,LTE3C,LTE4C,LTE5C,LTE6C)
    6.BWE Standalone (AADR3,AAGNS,AAGNU)
    7.4T4R Standalone (AAGNW)
    ======== Secondary ========
    1.Nokia Swap Secondary (AAP65)
    2.Cband Secondary (AAM17)
    3.5G NR/5G Upgrade Secondary (AAHRS)
    4.LTE AC Secondary (AADBR,AADBS,AADBT,AADBU,AADBV,AAGJV,AAGUV)
    6.BWE Secondary (AAGF3,AAGF4)
    7.4T4R Secondary (AACB5)

    '''

    mod_code_lookup = {
        1: ['AAP64'], 2: ['AAM0N'], 3: ['AALUA'], 4: ['AAGLZ'], 5: ['AAGM0'], 6: ['AAGM1'], 7: ['AAGM3'], 8: ['AAGM4'],
        9: ['AAGM6'], 10: ['AADBN'], 11: ['AADBO'], 12: ['AADBP'], 13: ['AADBQ'], 14: ['AAGJT'], 15: ['AAGUU'],
        16: ['AAGUW'], 17: ['AAGNQ'], 18: ['AAGNT'], 19: ['AAGNV'], 20: ['AAM16'], 21: ['AAK0R'],
        22: ['AAGM9'], 23: ['AAGMA'], 24: ['AAGMB'], 25: ['AAGMC'], 26: ['AAGMD'], 27: ['AAGME'], 28: ['AAGJU'],
        29: ['AAGUT'], 30: ['LTE2C'], 31: ['LTE3C'], 32: ['LTE4C'], 33: ['LTE5C'], 34: ['LTE6C'], 35: ['AADR3'],
        36: ['AAGNS'], 37: ['AAGNU'], 38: ['AAGNW'], 39: ['AAP65'], 40: ['AAM17'], 41: ['AAHRS'], 42: ['AADBR'],
        43: ['AADBS'], 44: ['AADBT'], 45: ['AADBU'], 46: ['AADBV'], 47: ['AAGJV'], 48: ['AAGUV'], 49: ['AAGF3'],
        50: ['AAGF4'], 51: ['AACB5']
    }

    for key in mod_code_lookup.keys():
        if mod_code in mod_code_lookup[key]:
            return key


def MCA_Cat_Rank_BAU(mod_code):
    # Here are the Ranking Order, Based on the ModCode(s)

    '''
    ======== Primary ========
    # 1.Nokia Swap Primary (AAP64)
    2.Cband Primary (AAM0N)
    3.5G NR/5G Upgrade Primary (AALUA)
    4.LTE AC Primary (AAGLZ,AAGM0,AAGM1,AAGM3,AAGM4,AAGM6,AADBN,AADBO,AADBP,AADBQ,AAGJT,AAGUU,AAGUW)
    6.BWE Primary (AAGNQ,AAGNT)
    7.4T4R Primary (AAGNV)
    ======== Standalone ========
    2.Cband Standalone(AAM16)
    3.5G NR/5G Upgrade Standalone (AAK0R)
    4.LTE AC Standalone (AAGM9,AAGMA,AAGMB,AAGMC,AAGMD,AAGME,AAGJU,AAGUT,LTE2C,LTE3C,LTE4C,LTE5C,LTE6C)
    6.BWE Standalone (AADR3,AAGNS,AAGNU)
    7.4T4R Standalone (AAGNW)

    mod_code_lookup = {
        1: ['AAM0N'], 2: ['AALUA'], 3: ['AAGLZ'], 4: ['AAGM0'], 5: ['AAGM1'], 6: ['AAGM3'], 7: ['AAGM4'], 8: ['AAGM6'],
        9: ['AADBN'], 10: ['AADBO'], 11: ['AADBP'], 12: ['AADBQ'], 13: ['AAGJT'], 14: ['AAGUU'], 15: ['AAGUW'],
        16: ['AAGNQ'], 17: ['AAGNT'], 18: ['AAGNV'], 19: ['AAM16'], 20: ['AAK0R'],
        21: ['AAGM9'], 22: ['AAGMA'], 23: ['AAGMB'], 24: ['AAGMC'], 25: ['AAGMD'], 26: ['AAGME'], 27: ['AAGJU'],
        28: ['AAGUT'], 29: ['LTE2C'], 30: ['LTE3C'], 31: ['LTE4C'], 32: ['LTE5C'], 33: ['LTE6C'], 34: ['AADR3'],
        35: ['AAGNS'], 36: ['AAGNU'], 37: ['AAGNW']
    }

    Added new ModCodes on 11/18
    '''

    mod_code_lookup = {
        1: ['AAM0N', 'AAQ01', 'AAQ02', 'AAQ03', 'AAQ04', 'AAQ05', 'AAQ06'],
        2: ['AALUA', 'AAQ6A', 'AAQ6B'], 
        3: ['AAGLZ'], 4: ['AAGM0'], 5: ['AAGM1'], 6: ['AAGM3'], 7: ['AAGM4'], 8: ['AAGM6', 'AAPZ6'],
        9: ['AADBN'], 10: ['AADBO'], 11: ['AADBP'], 12: ['AADBQ'], 13: ['AAGJT', 'AAPZ4', 'AAPZ5', 'AAPZ6'],
        14: ['AAGUU'], 15: ['AAGUW'],
        16: ['AAGNQ', 'AAQ0R'], 17: ['AAGNT', 'AAQ0T'], 18: ['AAGNV', 'AAQ5O'],
        19: ['AAM16', 'AAQ07', 'AAQ08', 'AAQ09', 'AAQ0A', 'AAQ0B', 'AAQ0C'], 20: ['AAK0R', 'AAQ69'],
        21: ['AAGM9'], 22: ['AAGMA'], 23: ['AAGMB'], 24: ['AAGMC'], 25: ['AAGMD'], 26: ['AAGME', 'AAPZC'],
        27: ['AAGJU'], 28: ['AAGUT'], 29: ['LTE2C'], 30: ['LTE3C'], 31: ['LTE4C'], 32: ['LTE5C'],
        33: ['LTE6C', 'AAPZA', 'AAPZB', 'AAPZC'], 34: ['AADR3', 'AAQ0N'],
        35: ['AAGNS', 'AAQ0S'], 36: ['AAGNU', 'AAQ0U'], 37: ['AAGNW', 'AAQ5P'],
    }

    for key in mod_code_lookup.keys():
        if mod_code in mod_code_lookup[key]:
            return key


def MCA_Cat_Rank_BAU_2024(mod_code):
    # Here are the Ranking Order, Based on the ModCode(s)

    '''
    ======== Primary ========
    # 1.Nokia Swap Primary (AAP64)
    2.Cband Primary (AAM0N)
    3.5G NR/5G Upgrade Primary (AALUA)
    4.LTE AC Primary (AAGLZ,AAGM0,AAGM1,AAGM3,AAGM4,AAGM6,AADBN,AADBO,AADBP,AADBQ,AAGJT,AAGUU,AAGUW)
    6.BWE Primary (AAGNQ,AAGNT)
    7.4T4R Primary (AAGNV)
    ======== Standalone ========
    2.Cband Standalone(AAM16)
    3.5G NR/5G Upgrade Standalone (AAK0R)
    4.LTE AC Standalone (AAGM9,AAGMA,AAGMB,AAGMC,AAGMD,AAGME,AAGJU,AAGUT,LTE2C,LTE3C,LTE4C,LTE5C,LTE6C)
    6.BWE Standalone (AADR3,AAGNS,AAGNU)
    7.4T4R Standalone (AAGNW)
    ======== Secondary ========
    # 1.Nokia Swap Secondary (AAP65)
    2.Cband Secondary (AAM17)
    3.5G NR/5G Upgrade Secondary (AAHRS)
    4.LTE AC Secondary (AADBR,AADBS,AADBT,AADBU,AADBV,AAGJV,AAGUV)
    6.BWE Secondary (AAGF3,AAGF4)
    7.4T4R Secondary (AACB5)

    mod_code_lookup = {
        1: ['AAM0N'], 2: ['AALUA'], 3: ['AAGLZ'], 4: ['AAGM0'], 5: ['AAGM1'], 6: ['AAGM3'], 7: ['AAGM4'], 8: ['AAGM6'],
        9: ['AADBN'], 10: ['AADBO'], 11: ['AADBP'], 12: ['AADBQ'], 13: ['AAGJT'], 14: ['AAGUU'], 15: ['AAGUW'],
        16: ['AAGNQ'], 17: ['AAGNT'], 18: ['AAGNV'], 19: ['AAM16'], 20: ['AAK0R'],
        21: ['AAGM9'], 22: ['AAGMA'], 23: ['AAGMB'], 24: ['AAGMC'], 25: ['AAGMD'], 26: ['AAGME'], 27: ['AAGJU'],
        28: ['AAGUT'], 29: ['LTE2C'], 30: ['LTE3C'], 31: ['LTE4C'], 32: ['LTE5C'], 33: ['LTE6C'], 34: ['AADR3'],
        35: ['AAGNS'], 36: ['AAGNU'], 37: ['AAGNW'], 38: ['AAM17'], 39: ['AAHRS'], 40: ['AADBR'], 41: ['AADBS'],
        42: ['AADBT'], 43: ['AADBU'], 44: ['AADBV'], 45: ['AAGJV'], 46: ['AAGUV'], 47: ['AAGF3'], 48: ['AAGF4'],
        49: ['AACB5']
    }

    Added new ModCodes on 11/18

    '''

    mod_code_lookup = {
        1: ['AAM0N', 'AAQ01', 'AAQ02', 'AAQ03', 'AAQ04', 'AAQ05', 'AAQ06'],
        2: ['AALUA', 'AAQ6A', 'AAQ6B'],
        3: ['AAGLZ'], 4: ['AAGM0'], 5: ['AAGM1'], 6: ['AAGM3'], 7: ['AAGM4'], 8: ['AAGM6', 'AAPZ6'],
        9: ['AADBN'], 10: ['AADBO'], 11: ['AADBP'], 12: ['AADBQ'], 13: ['AAGJT', 'AAPZ4', 'AAPZ5', 'AAPZ6'],
        14: ['AAGUU'], 15: ['AAGUW'],
        16: ['AAGNQ', 'AAQ0R'], 17: ['AAGNT', 'AAQ0T'], 18: ['AAGNV', 'AAQ5O'],
        19: ['AAM16', 'AAQ07', 'AAQ08', 'AAQ09', 'AAQ0A', 'AAQ0B', 'AAQ0C'], 20: ['AAK0R', 'AAQ69'],
        21: ['AAGM9'], 22: ['AAGMA'], 23: ['AAGMB'], 24: ['AAGMC'], 25: ['AAGMD'], 26: ['AAGME', 'AAPZC'],
        27: ['AAGJU'], 28: ['AAGUT'], 29: ['LTE2C'], 30: ['LTE3C'], 31: ['LTE4C'], 32: ['LTE5C'],
        33: ['LTE6C', 'AAPZA', 'AAPZB', 'AAPZC'], 34: ['AADR3', 'AAQ0N'],
        35: ['AAGNS', 'AAQ0S'], 36: ['AAGNU', 'AAQ0U'], 37: ['AAGNW', 'AAQ5P'],
        38: ['AAM17', 'AAQ0D', 'AAQ0E', 'AAQ0F', 'AAQ0G', 'AAQ0H', 'AAQ0J'], 
        39: ['AAHRS', 'AAQ66', 'AAQ67', 'AAQ68'], 40: ['AADBR'], 41: ['AADBS'],
        42: ['AADBT'], 43: ['AADBU'], 44: ['AADBV'], 45: ['AAGJV'], 46: ['AAGUV', 'AAPZ7', 'AAPZ8', 'AAPZ9'],
        47: ['AAGF3', 'AAQ0P'], 48: ['AAGF4', 'AAQ0Q'],
        49: ['AACB5', 'AAQ4N'],
    }

    for key in mod_code_lookup.keys():
        if mod_code in mod_code_lookup[key]:
            return key


def MCA_Cat_Rank_Nokia(mod_code):
    # Here are the Ranking Order, Based on the ModCode(s)

    '''
    ======== Primary ========
    1.Nokia Swap Primary (AAP64)

    Added new ModCodes on 11/18

    '''

    mod_code_lookup = {
        1: ['AAP64', 'AAQ4T', 'AAQ4U', 'AAQ4V']
    }

    for key in mod_code_lookup.keys():
        if mod_code in mod_code_lookup[key]:
            return key


def MCA_Cat_Rank_Ericsson(mod_code):
    # Here are the Ranking Order, Based on the ModCode(s)

    '''
    ======== Secondary ========
    3.5G NR/5G Upgrade Secondary (AAHRS)

    Added new ModCodes on 11/18

    '''

    mod_code_lookup = {
        1: ['AAHRS', 'AAQ66', 'AAQ67', 'AAQ68']
    }

    for key in mod_code_lookup.keys():
        if mod_code in mod_code_lookup[key]:
            return key
