CREATE TABLE `ri.foundry.main.dataset.525c0558-03a2-4e65-b371-4fefaa92d7c6` AS
    SELECT concat(
       CASE when site in ('K', 'I48') then 'WAL'
       when site in ('I', 'CAC') then 'WCA'
       when site in ('E') then 'WCT'
       when site in ('G', 'GAC') then 'WGA'
       when site in ('L') then 'WIL'
       when site in ('N') then 'WIN'
       when site in ('X', 'LMC') then 'WLM'
       when site in ('M') then 'WMI'
       when site in ('C') then 'WMW'
       when site in ('V', 'NFC') then 'WNF'
       when site in ('O') then 'WOH'
       when site in ('H') then 'WPN'
       when site in ('S') then 'WPS'
       when site in ('F', 'SFC') then 'WSF'
       when site in ('Y', 'TNC') then 'WTN'
       when site in ('T') then 'WTX'
       when site in ('W') then 'WWI'
       when site in ('R', 'A') then 'WYX'
       else 'TBD' end,
       ext_key1,
        DATE_FORMAT(
            (first_entry_ts), 
            'MM/dd/YYYY HH:mm'
        )
    ) as ticket_number_unique
    , concat(
       CASE when site in ('K', 'I48') then 'WAL'
       when site in ('I', 'CAC') then 'WCA'
       when site in ('E') then 'WCT'
       when site in ('G', 'GAC') then 'WGA'
       when site in ('L') then 'WIL'
       when site in ('N') then 'WIN'
       when site in ('X', 'LMC') then 'WLM'
       when site in ('M') then 'WMI'
       when site in ('C') then 'WMW'
       when site in ('V', 'NFC') then 'WNF'
       when site in ('O') then 'WOH'
       when site in ('H') then 'WPN'
       when site in ('S') then 'WPS'
       when site in ('F', 'SFC') then 'WSF'
       when site in ('Y', 'TNC') then 'WTN'
       when site in ('T') then 'WTX'
       when site in ('W') then 'WWI'
       when site in ('R', 'A') then 'WYX'
       else 'TBD' end,
       ext_key1,
        entry_year
    ) as join_key
    , ext_key1
    , CASE when site in ('K', 'I48') then 'WAL'
       when site in ('I', 'CAC') then 'WCA'
       when site in ('E') then 'WCT'
       when site in ('G', 'GAC') then 'WGA'
       when site in ('L') then 'WIL'
       when site in ('N') then 'WIN'
       when site in ('X', 'LMC') then 'WLM'
       when site in ('M') then 'WMI'
       when site in ('C') then 'WMW'
       when site in ('V', 'NFC') then 'WNF'
       when site in ('O') then 'WOH'
       when site in ('H') then 'WPN'
       when site in ('S') then 'WPS'
       when site in ('F', 'SFC') then 'WSF'
       when site in ('Y', 'TNC') then 'WTN'
       when site in ('T') then 'WTX'
       when site in ('W') then 'WWI'
       when site in ('R', 'A') then 'WYX'
       else 'TBD' end tkt_prefix
    , site
    , first_entry_ts
    , distinct_entries
    , cause_code_list_in
    , trbl_fnd_cd_list_in
    , trbl_fnd_desc_in
    from
    (
    SELECT ext_key1
    , site
    , year(entry_ts) entry_year
    , min(entry_ts) first_entry_ts
    , count(distinct entry_ts) distinct_entries
    , concat_ws(",", collect_set(cast(cast(caus_cd as integer) as string))) cause_code_list_in
    , concat_ws(",", collect_set(cast(cast(trbl_fnd_cd as integer) as string))) trbl_fnd_cd_list_in
    , concat_ws(",", collect_set(trbl_fnd_desc)) trbl_fnd_desc_in
    FROM `ri.foundry.main.dataset.a66ab7be-b938-4779-ba24-2dc644803bb1`
    WHERE lower(ext_key1) REGEXP '^[a-z][a-z][0-9][0-9][0-9][0-9][0-9][0-9]$|[0-9a-z][0-9a-z][0-9a-z][0-9a-z][0-9a-z][0-9a-z][0-9a-z][0-9a-z][0-9a-z]'
    GROUP BY
    ext_key1
    , site
    , year(entry_ts)
)