from transforms.api import transform_df, Input, Output
from pyspark.sql import functions as F
from pyspark.sql.window import Window


@transform_df(
    Output("ri.foundry.main.dataset.b69f8736-7db1-4955-8df0-63653c3aa646"),
    latest_month_iqi=Input("ri.foundry.main.dataset.5dbda0fe-8deb-482f-b454-6d3b38100be6"),
)
def oc_mou_sector(latest_month_iqi):
    """
    Calculate overlapping coverage based on minute of usage for sectors
    Output only include latest month
    """
    return oc_mou_backup_level_month(latest_month_iqi, backup_level='ecgi_full', ecgi_map=None, failed_backup=[])

def oc_mou_backup_level_month(
                                iqi,
                                cols=[
                                    "yyyymm",
                                    "ecgi_full",
                                    "mgrs100m",
                                    'ecgi_rank',
                                ],
                                mou="volte_duration",
                                rsrp="rsrp",
                                backup_level='ecgi_full',
                                ecgi_map=None,
                                failed_backup=[]
):
    """ Calculate overlapping coverage based on minute of usage for backup_level in 1 month
    ---- Input
    iqi: IQI 100m summary data in desired months
    yyyymm: time duration in months
    backup_level: primary key of this analysis. Examples: ecgi_full, ecgi_short, usid, fa_location
    ecgi_map: mapping between primary key to ecgi_full at yyyymm time duration
    failed_backup: list of failed backup equipment. For harden, just (all-harden)
    ---- Output Cols
    yyyymm: month
    backup_level: equipment level
    total_mou: total minute of usage
    primary_mou: aggregated primary minute of usage on different locations
    backup_mou: minute of usage that is backed up by another equipment
    oc_rate: overlapping coverage rate. If null, it means there is no minute of usage for that equipment
    """
    # Check input
    if not ecgi_map:
        assert(backup_level == 'ecgi_full')
    # Select relevant columns
    df = iqi.select(*cols, mou, rsrp)
    df = df.withColumn("mou", F.col(mou)).drop(mou)
    df = df.withColumn("avg_rsrp", F.col(rsrp)).drop(rsrp)
    
    # Add mapping column
    if ecgi_map:
        assert('ecgi_full' in ecgi_map.columns)
        df = df.join(ecgi_map, 'ecgi_full', how='inner') #TODO: Think whether this inner join makes sense

    # Ensure primary keys are valid
    df = df.filter(F.col(backup_level).isNotNull())

    # ----------------------------------------------------------------------------------- #
    # --------- End of DataFrame Prep. Overlapping Based on MOU Calculation ------------- #
    # ----------------------------------------------------------------------------------- #
    # General formula:
    # OC_Rate = (total.total_mou - primary_mou.primary_mou + backup_mou.backup_mou) / total.total_mou)
    # Calculate total MOU by group
    group = ["yyyymm", backup_level]
    total_mou = df.groupBy(*group).agg(F.sum('mou').alias('total_mou'))

    # Primary mou
    primary = df.where(F.col('ecgi_rank') == 1)
    primary_mou = primary.groupBy(*group).agg(F.sum('mou').alias('primary_mou'))

    # Backup mou
    # Let B be the backup of A on a mgrs100m bin. B!=A, B is not primary for mgrs100m bin, and B has descent rsrp
    backup = df.where(((F.col('ecgi_rank') != 1) & (F.col('avg_rsrp') > -105)))
    cols = backup.columns
    cols.remove('mgrs100m')
    backup = backup.select('mgrs100m', *[F.col(c).alias("backup_"+c) for c in cols])

    # Find mgrs100m bins that have a backup ecgi that's not on the same tower as primary
    bin_coverage = primary.join(backup, 'mgrs100m', how='inner')\
                    .where(primary[backup_level] != backup["backup_"+backup_level])
    
    # remove failed equipment
    bin_coverage = bin_coverage.filter(~F.col(backup_level).isin(failed_backup))
    
    # reassign bin rank for backup ecgi
    window = Window.partitionBy('mgrs100m').orderBy(F.asc('backup_ecgi_rank'))
    bin_rank = bin_coverage.withColumn('bin_rank', F.row_number().over(window))

    # Keep only top backup ecgi, and calculate backup mou
    backup_rec = bin_rank.filter(F.col('bin_rank') == 1)
    backup_mou = backup_rec.groupBy(*group).agg(F.sum('mou').alias('backup_mou'))
    
    # Calculate backup rate for each group
    combined_mou = total_mou.join(primary_mou, group, how='left')\
                            .join(backup_mou, group, how='left')
    combined_mou = combined_mou.na.fill(value=0)
    oc_rate = combined_mou.withColumn("oc_rate", (F.col('total_mou') - F.col('primary_mou') + F.col('backup_mou')) / F.col('total_mou'))
    return oc_rate
