CREATE TABLE `ri.foundry.main.dataset.c69b58c9-7c17-44fa-a725-c4a513832809` TBLPROPERTIES (foundry_transform_profiles = 'EXECUTOR_MEMORY_MEDIUM, NUM_EXECUTORS_16') AS
SELECT HUMAN_TOUCH.ticket_number
, concat_ws(',', collect_list(HUMAN_TOUCH.adj_mod_user)) as human_pathway
, concat_ws(',', collect_set(HUMAN_TOUCH.adj_mod_user)) as distinct_humans
, first(HUMAN_TOUCH.adj_mod_user) as first_human_attuid
, last(HUMAN_TOUCH.adj_mod_user) as last_human_attuid
, concat_ws(',', collect_set(USER_LOOKUP.supervisor_name)) as distinct_supervisor_name
, first(USER_LOOKUP.supervisor_name) first_supervisor_name
, last(USER_LOOKUP.supervisor_name) last_supervisor_name
, concat_ws(',', collect_set(USER_LOOKUP.director_name)) as distinct_director_name
, first(USER_LOOKUP.director_name) first_director_name
, last(USER_LOOKUP.director_name) last_director_name
, concat_ws(',', collect_set(USER_LOOKUP.avp_name)) as distinct_avp_name
, first(USER_LOOKUP.avp_name) first_avp_name
, last(USER_LOOKUP.avp_name) last_avp_name
, concat_ws(',', collect_set(USER_LOOKUP.vp_name)) as distinct_vp_name
, first(USER_LOOKUP.vp_name) first_vp_name
, last(USER_LOOKUP.vp_name) last_vp_name
, concat_ws(',', collect_set(USER_LOOKUP.svp_name)) as distinct_svp_name
, first(USER_LOOKUP.svp_name) first_svp_name
, last(USER_LOOKUP.svp_name) last_svp_name
, first(cogs_1_name) first_cogs_1_name
, first(cogs_2_name) first_cogs_2_name
, first(cogs_3_name) first_cogs_3_name
, first(cogs_4_name) first_cogs_4_name
, first(cogs_5_name) first_cogs_5_name
, first(cogs_6_name) first_cogs_6_name
, first(cogs_7_name) first_cogs_7_name
, last(cogs_1_name) last_cogs_1_name
, last(cogs_2_name) last_cogs_2_name
, last(cogs_3_name) last_cogs_3_name
, last(cogs_4_name) last_cogs_4_name
, last(cogs_5_name) last_cogs_5_name
, last(cogs_6_name) last_cogs_6_name
, last(cogs_7_name) last_cogs_7_name
, concat_ws(',', collect_set(USER_LOOKUP.vp_org_name)) as distinct_vp_org_name
, MIN(HUMAN_TOUCH.Modified_Time_1M) first_human_touch
, MAX(HUMAN_TOUCH.Modified_Time_1M) last_human_touch
, COUNT(HUMAN_TOUCH.ticket_number) total_human_touches
, concat_ws(',', collect_list(HUMAN_TOUCH.active_org)) as active_org_pathway
, concat_ws(',', collect_set(HUMAN_TOUCH.active_org)) as distinct_active_org
, count(distinct HUMAN_TOUCH.active_org) distinct_active_org_count
, first(HUMAN_TOUCH.active_org) first_active_org
, last(HUMAN_TOUCH.active_org) last_active_org
, first(HUMAN_TOUCH.work_queue) first_work_queue
, last(HUMAN_TOUCH.work_queue) last_work_queue
, first(rm_l1) first_rm_l1
, first(rm_l2) first_rm_l2
, first(rm_l3) first_rm_l3
, first(center_l1_area) first_center_l1_area
, first(center_l2_platform) first_center_l2_platform
, first(center_l3_unit) first_center_l3_unit
, first(strategic_non_strategic) first_strategic_indicator
, last(rm_l1) last_rm_l1
, last(rm_l2) last_rm_l2
, last(rm_l3) last_rm_l3
, last(center_l1_area) last_center_l1_area
, last(center_l2_platform) last_center_l2_platform
, last(center_l3_unit) last_center_l3_unit
, last(strategic_non_strategic) last_strategic_indicator
, concat_ws(',', collect_list(center_l1_area)) as center_l1_area_pathway
, concat_ws(',', collect_set(center_l1_area)) as distinct_center_l1_area
FROM `ri.foundry.main.dataset.fa90e03a-47f2-4deb-8f58-be2a6be0c9aa` HUMAN_TOUCH
LEFT JOIN `ri.foundry.main.dataset.c79bf09a-89b8-4d58-bb05-dbdda0f280a2` USER_LOOKUP
ON HUMAN_TOUCH.adj_mod_user=USER_LOOKUP.adj_mod_user
LEFT JOIN `ri.foundry.main.dataset.18213df6-4c2c-486c-bba2-1febde688fa1` LK_BUCKET
ON HUMAN_TOUCH.ticket_number=LK_BUCKET.ticket and LK_BUCKET.bucket is not null and LK_BUCKET.bucket != 'Internal Engagement'
LEFT JOIN `ri.foundry.main.dataset.df0abf5d-677c-4cb9-8bf0-d8d7ff25b467` LK_CENTER
ON (
        UPPER(trim(LK_BUCKET.bucket))=upper(trim(LK_CENTER.logic_group)) 
        AND _mapping_type=7
  )
  /*OR (
          UPPER(TRIM(HUMAN_TOUCH.active_org))=upper(trim(LK_CENTER.worklist_l1)) 
          AND UPPER(TRIM(HUMAN_TOUCH.org_group))=UPPER(TRIM(LK_CENTER.worklist_l3)) 
          AND _mapping_type=3
  ) org_group doesn't exist in activity log */ 
  OR (
          UPPER(TRIM(HUMAN_TOUCH.active_org))=upper(trim(LK_CENTER.worklist_l1))
          AND UPPER(TRIM(HUMAN_TOUCH.work_queue))=upper(trim(LK_CENTER.worklist_l2))
          AND _mapping_type=2
  )
  or (
          UPPER(TRIM(HUMAN_TOUCH.active_org))=UPPER(TRIM(LK_CENTER.worklist_l1)) 
          AND LK_CENTER._mapping_type=1
  )
WHERE is_human=1
GROUP BY HUMAN_TOUCH.ticket_number


