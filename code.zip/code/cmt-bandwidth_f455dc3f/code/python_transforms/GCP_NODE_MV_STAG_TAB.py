from transforms.api import transform, Input, Output, incremental
from utility.column_clean import clean_columns, lowercase_columns
from pyspark.sql.types import TimestampType
from pyspark.sql import functions as F

@incremental(semantic_version=1)
@transform(
    out=Output("ri.foundry.main.dataset.5aabee8d-e5f4-4eda-8146-e0971cdcbd23"),
    df=Input("ri.foundry.main.dataset.80fa137f-561f-4996-be8e-4b63717bbb04")
)
def my_compute_function(df, out):
    df = clean_columns(
        df.dataframe(),
        strip_columns=strip_columns,
        integer_columns=cast_to_integer_columns,
        double_columns=cast_to_double_columns,
        decimal_columns=cast_to_decimal_columns,
        timestamp_columns=cast_to_timestamp_from_long_columns,
        date_columns=cast_to_date_from_long_columns,
        datetime_columns=cast_to_timestamp_columns,
        datetime_format=datetime_format,
        #date_columns=cast_to_date_columns,
        date_format=date_format,
        id_columns=cast_to_string_columns,
        integer_from_num_columns=cast_to_integer_from_decimal_columns
    )
    df = lowercase_columns(df)
    df = df.select(*[F.col(col).alias(col.lower()) for col in df.columns])
    df = df.dropDuplicates()
    df = lowercase_columns(df)
    #df = df.withColumn("load_ts", F.current_timestamp())
    df = df.withColumn("load_ts", F.current_timestamp().cast(TimestampType()))

    df = df.withColumn("createddate", F.from_utc_timestamp(F.from_unixtime(df["createddate"] / 1000), "UTC").cast(TimestampType()))
    df = df.withColumn("lastmodifieddate", F.from_utc_timestamp(F.from_unixtime(df["lastmodifieddate"] / 1000), "UTC").cast(TimestampType()))
    df = df.withColumn("devicereplaceddate", F.from_utc_timestamp(F.from_unixtime(df["devicereplaceddate"] / 1000), "UTC").cast(TimestampType()))

    out.write_dataframe(df)

date_format = 'yyyy-MM-dd'
datetime_format = 'yyyy-MM-dd HH:mm:ss'

cast_to_date_columns = []
cast_to_timestamp_columns = []
cast_to_timestamp_from_long_columns = ['SF_LOAD_TS_EST']
cast_to_date_from_long_columns = []
cast_to_integer_columns = []
cast_to_double_columns = []
cast_to_decimal_columns = []
cast_to_string_columns = []
cast_to_integer_from_decimal_columns = []
strip_columns = []
stg_columns_to_remove = []
