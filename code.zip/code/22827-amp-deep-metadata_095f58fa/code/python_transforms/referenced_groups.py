from transforms.api import transform_df, Input, Output
from myproject.utils.global_code import PARENT_FOLDER


@transform_df(
    Output(f"{PARENT_FOLDER}/referenced_groups", sever_permissions=True),
    projects_to_groups=Input(f"{PARENT_FOLDER}/projects_to_groups"),
)
def my_compute_function(projects_to_groups):
    df = projects_to_groups
    df = df.select(
        df["group_rid"].alias("ref_group_rid"),
        df["access_level"].alias("ref_access_level"),
        df["project_rid"].alias("referenced_project_rid"),
    )
    return df
