from transforms.api import transform, Input, Output, incremental, configure
from utility.incremental.update_insert import update_insert_core
import logging
from pyspark.sql import functions as F
from transforms.api import transform, Input, Output, incremental
from utility.column_clean import clean_columns, lowercase_columns, remove_prefix
logger = logging.getLogger(__name__)


@configure(profile=['EXECUTOR_MEMORY_MEDIUM', 'NUM_EXECUTORS_16'])
@incremental(semantic_version=5)
@transform(
   out=Output("/Innovation Lab/[Source] Oracle ESAR/data/clean/ars_dbor_r10.event_message"),
   updates=Input("/Innovation Lab/[Source] Oracle ESAR/data/raw/Prod/snowflake/esaars_dbor_rviews.event_message_snowflake"),
   backfill=Input("/Innovation Lab/[Source] Oracle ESAR/data/raw/Prod/esaars_dbor_rviews.event_message"),
   )
def my_compute_function(ctx, out, updates, backfill):
    backfill = backfill.dataframe()
    backfill = backfill.withColumn("LOAD_TS", F.lit(1648664339))
    updates = updates.dataframe()
    updates = backfill.unionByName(updates)
    updates_df = clean_columns(
        updates,
        strip_columns=strip_columns,
        integer_columns=cast_to_integer_columns,
        double_columns=cast_to_double_columns,
        decimal_columns=cast_to_decimal_columns,
        timestamp_columns=cast_to_timestamp_from_long_columns,
        datetime_columns=cast_to_timestamp_columns,
        datetime_format=datetime_format,
        date_columns=cast_to_date_columns,
        date_format=date_format,
        id_columns=cast_to_string_columns,
        integer_from_num_columns=cast_to_integer_from_decimal_columns
    )
    
    updates_df = lowercase_columns(updates_df)
    for c in cast_to_short_columns:
        updates_df = updates_df.withColumn(c, updates_df[c].cast('short'))
    
    keys = ["request_id","em_seq"]
    # logger.info(f"{dir(out)}")
    # update_insert_core(ctx, output, updates_df, keys, ["node_record_added"], num_partitions=200)
    update_insert_core(ctx, out, updates_df, primary_keys=keys, order_cols=["modified_date"])

cast_to_short_columns=[]
date_format = 'yyyy-MM-dd'
datetime_format = 'yyyy-MM-dd HH:mm:ss'

cast_to_date_columns = []
cast_to_timestamp_columns = []
cast_to_timestamp_from_long_columns = ["MODIFIED_DATE","EVENT_DATE"]
cast_to_integer_columns = []
cast_to_double_columns = []
cast_to_decimal_columns = []
cast_to_string_columns = []
cast_to_integer_from_decimal_columns = []
strip_columns = []