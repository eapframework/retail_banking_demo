CREATE TABLE `/Innovation Lab/[ETL] Ticketing/data/clean/aotstm_lk_ticket_touch_instances` TBLPROPERTIES (foundry_transform_profile = 'EXECUTOR_MEMORY_MEDIUM') AS
SELECT gems_ticket AS ticket_number
, date_trunc('minute',activity_time) Modified_Time_1M
, M.active_org
, TICKET.work_queue
, M.last_modified_by
, M.last_user
, M.last_mod_by
, LK_LAST_MODIFIED_BY.attuid lmodifiedby_attuid
, LK_LAST_USER.attuid luser_attuid
, LK_LAST_MOD_BY.attuid lmodby_attuid
, CASE WHEN M.last_modified_by REGEXP '^[a-zA-Z][a-zA-Z][0-9][0-9][0-9][0-9a-zA-Z]' THEN lower(M.last_modified_by)
       WHEN M.last_user REGEXP '^[a-zA-Z][a-zA-Z][0-9][0-9][0-9][0-9a-zA-Z]' THEN lower(M.last_user)
       WHEN M.last_mod_by REGEXP '^[a-zA-Z][a-zA-Z][0-9][0-9][0-9][0-9a-zA-Z]' THEN lower(M.last_mod_by)
       WHEN M.last_modified_by REGEXP '[_][a-zA-Z][a-zA-Z][0-9][0-9][0-9][0-9a-zA-Z]$' THEN lower(right(M.last_modified_by,6))
       WHEN M.last_user REGEXP '[_][a-zA-Z][a-zA-Z][0-9][0-9][0-9][0-9a-zA-Z]$' THEN lower(right(M.last_user,6))
       WHEN M.last_mod_by REGEXP '[_][a-zA-Z][a-zA-Z][0-9][0-9][0-9][0-9a-zA-Z]$' THEN lower(right(M.last_mod_by,6))
       WHEN LK_LAST_MODIFIED_BY.attuid is not null THEN LK_LAST_MODIFIED_BY.attuid
       WHEN LK_LAST_USER.attuid is not null THEN LK_LAST_USER.attuid 
       WHEN LK_LAST_MOD_BY.attuid is not null THEN LK_LAST_MOD_BY.attuid
       WHEN M.last_user is not null then M.last_user
       WHEN M.last_modified_by is not null then M.last_modified_by
       WHEN M.last_mod_by is not null then M.last_mod_by
     ELSE 'Nobody' END as adj_mod_user 
, CASE WHEN first(LK_MECH_MODIFIED_BY.id) is not null then 0
       WHEN first(LK_MECH_LAST_USER.id) is not null then 0
       WHEN first(LK_MECH_LAST_MOD_BY.id) is not null then 0
       WHEN M.last_modified_by REGEXP '^[a-zA-Z][a-zA-Z][0-9][0-9][0-9][0-9a-zA-Z]$' THEN 1
       WHEN M.last_user REGEXP '^[a-zA-Z][a-zA-Z][0-9][0-9][0-9][0-9a-zA-Z]$' THEN 1
       WHEN M.last_mod_by REGEXP '^[a-zA-Z][a-zA-Z][0-9][0-9][0-9][0-9a-zA-Z]$' THEN 1
       WHEN M.last_modified_by REGEXP '[_][a-zA-Z][a-zA-Z][0-9][0-9][0-9][0-9a-zA-Z]$' THEN 1
       WHEN M.last_user REGEXP '[_][a-zA-Z][a-zA-Z][0-9][0-9][0-9][0-9a-zA-Z]$' THEN 1
       WHEN M.last_mod_by REGEXP '[_][a-zA-Z][a-zA-Z][0-9][0-9][0-9][0-9a-zA-Z]$' THEN 1
       WHEN LK_LAST_MODIFIED_BY.attuid is not null THEN 1
       WHEN LK_LAST_USER.attuid is not null THEN 1
       WHEN LK_LAST_MOD_BY.attuid is not null THEN 1
     ELSE 0 END is_human
FROM `/Innovation Lab/[Source] Oracle ESAR/data/clean/ticket_transfer` M
LEFT JOIN `/Innovation Lab/[ETL] Ticketing/data/clean/AOTSTM_TICKET_CLEAN` TICKET
on M.gems_ticket=TICKET.ticket
LEFT JOIN `/Innovation Lab/[ETL] Ticketing/data/lookup/lk_attuid - values` LK_LAST_MODIFIED_BY
ON M.last_modified_by=LK_LAST_MODIFIED_BY.username
LEFT JOIN `/Innovation Lab/[ETL] Ticketing/data/lookup/lk_attuid - values` LK_LAST_USER
ON M.last_user=LK_LAST_USER.username
LEFT JOIN `/Innovation Lab/[ETL] Ticketing/data/lookup/lk_attuid - values` LK_LAST_MOD_BY
ON M.last_mod_by=LK_LAST_MOD_BY.username
LEFT JOIN `/Innovation Lab/[ETL] Ticketing/data/lookup/lk_nonhuman_users - values` LK_MECH_MODIFIED_BY
on lower(M.last_modified_by)=lower(LK_MECH_MODIFIED_BY.id)
LEFT JOIN `/Innovation Lab/[ETL] Ticketing/data/lookup/lk_nonhuman_users - values` LK_MECH_LAST_USER
on lower(M.last_user)=lower(LK_MECH_LAST_USER.id)
LEFT JOIN `/Innovation Lab/[ETL] Ticketing/data/lookup/lk_nonhuman_users - values` LK_MECH_LAST_MOD_BY
on lower(M.last_mod_by)=lower(LK_MECH_LAST_MOD_BY.id)
GROUP BY gems_ticket, M.active_org, TICKET.work_queue, M.last_modified_by, last_user, last_mod_by, LK_LAST_MODIFIED_BY.attuid, LK_LAST_USER.attuid, LK_LAST_MOD_BY.attuid
, CASE WHEN M.last_modified_by REGEXP '^[a-zA-Z][a-zA-Z][0-9][0-9][0-9][0-9a-zA-Z]$' THEN M.last_modified_by
       WHEN M.last_user REGEXP '^[a-zA-Z][a-zA-Z][0-9][0-9][0-9][0-9a-zA-Z]$' THEN M.last_user
       WHEN M.last_mod_by REGEXP '^[a-zA-Z][a-zA-Z][0-9][0-9][0-9][0-9a-zA-Z]$' THEN M.last_mod_by
       WHEN M.last_modified_by REGEXP '[_][a-zA-Z][a-zA-Z][0-9][0-9][0-9][0-9a-zA-Z]$' THEN right(M.last_modified_by,6)
       WHEN M.last_user REGEXP '[_][a-zA-Z][a-zA-Z][0-9][0-9][0-9][0-9a-zA-Z]$' THEN right(M.last_user,6)
       WHEN M.last_mod_by REGEXP '[_][a-zA-Z][a-zA-Z][0-9][0-9][0-9][0-9a-zA-Z]$' THEN right(M.last_mod_by,6)
       WHEN M.last_user is not null then M.last_user
       WHEN M.last_modified_by is not null then M.last_modified_by
       WHEN M.last_mod_by is not null then M.last_mod_by
       WHEN LK_LAST_MODIFIED_BY.attuid is not null THEN LK_LAST_MODIFIED_BY.attuid
       WHEN LK_LAST_USER.attuid is not null THEN LK_LAST_USER.attuid 
       WHEN LK_LAST_MOD_BY.attuid is not null THEN LK_LAST_MOD_BY.attuid
     ELSE 'Nobody' END, date_trunc('minute',activity_time)
ORDER BY gems_ticket, date_trunc('minute',activity_time)