"""
MSO uTicket — SDP Pipeline (Gold Layer)
========================================
Contour analyses → @dp.materialized_view() (complex multi-way JOINs)
CSV export tables → @dp.table() streaming (formerly @dlt.view, now streaming tables)

Table type decisions:
  - Gold analytics (5-way LEFT JOINs + filters): @dp.materialized_view()
    Multi-way streaming JOINs need complex watermark orchestration; batch MVs
    recompute on each pipeline update and are operationally simpler.
  - Export streaming tables: @dp.table() reading from gold MVs
    Databricks supports spark.readStream.table() on MVs within same pipeline.

SDK migration:
  - @dlt.view     → @dp.table() (promoted from view to streaming table)
  - dlt.read("x") → spark.read.table("x")
"""

from pyspark import pipelines as dp
from pyspark.sql import functions as F
from utilities import (
    STATUS_MAP, TASK_STATUS_MAP, APPROVAL_STATUS_MAP, map_status,
    MSO_REQUESTER_GROUPS, MSO_CATEGORY_OVERRIDE,
)


# ═══════════════════════════════════════════════════════════════════════════
# Helper: Build the base joined dataset (shared across all 4 gold tables)
# ═══════════════════════════════════════════════════════════════════════════

def _build_base_joined(include_tasks=True, include_apsig=True,
                        include_equipment=True, include_techs=True,
                        include_cllis=True):
    """
    Reconstruct the Contour starting dataset + 5 LEFT JOINs.
    All joins on change_id. Prefixes match the Contour join-columns config.
    Uses spark.read.table() (batch) since gold tables are materialized views.
    """
    chg = spark.read.table("clean_chg_change")

    if include_apsig:
        # Join 1: ap_signature_enriched (prefix: apsig_) on change_id = request
        apsig = spark.read.table("silver_ap_signature_enriched").select(
            F.col("request"),
            F.col("approver_signature").alias("apsig_approver_signature"),
            F.col("role").alias("apsig_role"),
            F.col("approval_status").alias("apsig_approval_status"),
        )
        chg = chg.join(apsig, chg.change_id == apsig.request, "left")
        # Rename 'request' to 'apsig_request' to match Contour prefix convention
        chg = chg.withColumnRenamed("request", "apsig_request")

    if include_equipment:
        # Join 2: acmr23_mobility_equipment_info on change_id
        equip = spark.read.table("clean_acmr23_mobility_equipment_info").select(
            "change_id",
            F.col("equipment_id"),
            F.col("equipment_name"),
            F.col("equipment_type"),
        ).alias("equip")
        chg = chg.join(equip, chg.change_id == F.col("equip.change_id"), "left").drop(F.col("equip.change_id"))

    if include_tasks:
        # Join 3: chg_task (prefix: task_) on change_id
        task = spark.read.table("clean_chg_task").select(
            "change_id",
            F.col("implementor_group").alias("task_implementor_group"),
            F.col("task_id").alias("task_task_id"),
            F.col("description").alias("task_description"),
            F.col("summary").alias("task_summary"),
            F.col("status").alias("task_status"),
            F.col("task_full_name").alias("task_task_full_name"),
            F.col("implementor_name_").alias("task_implementor_name_"),
            F.col("implementor_e_mail").alias("task_implementor_e_mail"),
            F.col("task_closed_by_date_rpt").alias("task_task_closed_by_date_rpt"),
            F.col("planned_start_date").alias("task_planned_start_date"),
            F.col("planned_end_date").alias("task_planned_end_date"),
            F.col("planned_end_eastern_dt").alias("task_planned_end_eastern_dt"),
            F.col("planned_start_eastern_dt").alias("task_planned_start_eastern_dt"),
            F.col("task_closed_by_date").alias("task_task_closed_by_date"),
        ).alias("task")
        chg = chg.join(task, chg.change_id == F.col("task.change_id"), "left").drop(F.col("task.change_id"))

    if include_techs:
        # Join 4: acmr14_affected_techs (prefix: new_) on change_id
        techs = spark.read.table("clean_acmr14_affected_techs").select(
            "change_id",
            F.col("technology").alias("new_technology"),
        ).alias("techs")
        chg = chg.join(techs, chg.change_id == F.col("techs.change_id"), "left").drop(F.col("techs.change_id"))

    if include_cllis:
        # Join 5: acmr14_affected_cllis on change_id (brings 'location' column)
        cllis = spark.read.table("clean_acmr14_affected_cllis").select(
            "change_id",
            F.col("location"),
        ).alias("cllis")
        chg = chg.join(cllis, chg.change_id == F.col("cllis.change_id"), "left").drop(F.col("cllis.change_id"))

    return chg


def _apply_mso_requester_filter(df):
    """Filter: requester_group IN (...MSO groups...) OR category = 'Mobility-External Partner'."""
    return df.filter(
        F.col("requester_group").isin(MSO_REQUESTER_GROUPS)
        | (F.col("category") == F.lit(MSO_CATEGORY_OVERRIDE))
    )


def _apply_status_mappings(df):
    """Apply CASE WHEN mappings for status, task_status, approval_status."""
    df = df.withColumn("status", map_status("status", STATUS_MAP))
    if "task_status" in df.columns:
        df = df.withColumn("task_status", map_status("task_status", TASK_STATUS_MAP, "Status Unknown"))
    if "approval_status" in df.columns:
        df = df.withColumn("approval_status", map_status("approval_status", APPROVAL_STATUS_MAP))
    return df


def _apply_eastern_date_formatting(df, columns_utc, columns_raw=None):
    """Convert UTC timestamps to Eastern TZ formatted strings."""
    fmt = "yyyy-MM-dd HH:mm:ss a"
    for c in columns_utc:
        if c in df.columns:
            df = df.withColumn(c, F.date_format(F.from_utc_timestamp(F.col(c), "America/New_York"), fmt))
    for c in (columns_raw or []):
        if c in df.columns:
            df = df.withColumn(c, F.date_format(F.col(c), fmt))
    return df


# ═══════════════════════════════════════════════════════════════════════════
# GOLD 1: mso_aotscm_open_tickets — Materialized View
#   Contour RID: b22912bc | Filter: status NOT IN (7, 8) | 62 columns
# ═══════════════════════════════════════════════════════════════════════════

_OPEN_CLOSED_KEPT_COLUMNS = [
    "change_id", "order_number", "create_date", "modified_date",
    "planned_start_date", "planned_end_date", "status", "category",
    "type", "item", "summary", "work_type", "requester_group",
    "requester_name", "requester_login_name", "assignee_login_name",
    "assignee", "service_affected_aots", "services_supported",
    "product_affected", "reason_aots", "business_risk_aots",
    "technical_risk_aots", "impact", "customer_impacted",
    "first_moved_to_pending_apprvl", "closure_code", "aots_closure_code",
    "closure_code2", "root_cause_code", "root_cause_action_plan_aots",
    "rescheduled_count", "approval_status", "description", "clli",
    "closing_comments_aots", "number_of_tasks", "assignee_group",
    "task_implementor_group", "task_task_id", "task_description",
    "task_summary", "task_status", "task_task_full_name",
    "task_implementor_name_", "task_implementor_e_mail",
    "impacted_state", "location", "new_technology",
    "equipment_id", "equipment_name", "equipment_type",
    "apsig_approval_status", "apsig_request", "apsig_role",
    "apsig_approver_signature", "emergency_",
    "supervisor_location", "change_closed_by_eastern_dt",
    "task_task_closed_by_date_rpt",
    "task_planned_start_eastern_dt", "task_planned_end_eastern_dt",
]


@dp.materialized_view(
    name="mso_aotscm_open_tickets",
    comment="Gold: MSO AOTS CM Open Tickets. Contour-derived, 62 columns. Status NOT IN (Closed, Cancelled).",
    table_properties={"quality": "gold"},
)
def mso_aotscm_open_tickets():
    """Converted from: Contour b22912bc → MSO_AOTS_CM_OpenTickets.py"""
    df = _build_base_joined()
    df = _apply_mso_requester_filter(df)
    df = df.filter(~F.col("status").isin(7, 8))
    df = _apply_status_mappings(df)

    if "supervisor_group" in df.columns:
        df = df.withColumnRenamed("supervisor_group", "assignee_group")

    available = [c for c in _OPEN_CLOSED_KEPT_COLUMNS if c in df.columns]
    df = df.select(available)

    df = _apply_eastern_date_formatting(
        df,
        columns_utc=["create_date", "modified_date", "planned_start_date", "planned_end_date"],
        columns_raw=["change_closed_by_eastern_dt"],
    )
    return df


# ═══════════════════════════════════════════════════════════════════════════
# GOLD 2: mso_aotscm_closed_tickets — Materialized View
#   Contour RID: 42820dd4 | Filter: status IN (7, 8) + closed last year
# ═══════════════════════════════════════════════════════════════════════════

@dp.materialized_view(
    name="mso_aotscm_closed_tickets",
    comment="Gold: MSO AOTS CM Closed Tickets. Status IN (Closed, Cancelled), last 1 year.",
    table_properties={"quality": "gold"},
)
def mso_aotscm_closed_tickets():
    """Converted from: Contour 42820dd4 → MSO_AOTS_CM_ClosedTickets.py"""
    df = _build_base_joined()
    df = _apply_mso_requester_filter(df)
    df = df.filter(F.col("status").isin(7, 8))
    df = df.filter(
        (F.year(F.col("change_closed_by_eastern_dt")) >= (F.year(F.current_date()) - 1))
        & (F.col("change_closed_by_eastern_dt") <= F.current_date())
    )
    df = _apply_status_mappings(df)

    if "supervisor_group" in df.columns:
        df = df.withColumnRenamed("supervisor_group", "assignee_group")

    available = [c for c in _OPEN_CLOSED_KEPT_COLUMNS if c in df.columns]
    df = df.select(available)

    df = _apply_eastern_date_formatting(
        df,
        columns_utc=["create_date", "planned_start_date", "planned_end_date"],
        columns_raw=["change_closed_by_eastern_dt"],
    )
    return df


# ═══════════════════════════════════════════════════════════════════════════
# GOLD 3: cmclosed_tasks — Materialized View
#   Contour RID: 46d229a0 | Only task join | 50 columns
# ═══════════════════════════════════════════════════════════════════════════

_CMCLOSED_TASKS_KEPT_COLUMNS = [
    "change_id", "task_task_id", "task_implementor_group",
    "task_description", "task_summary", "task_status",
    "task_task_full_name", "task_task_closed_by_date",
    "task_implementor_name_", "task_implementor_e_mail",
    "task_task_closed_by_date_rpt", "work_type", "reason_aots",
    "planned_start_date", "emergency_", "technical_risk_aots",
    "first_moved_to_pending_apprvl", "business_risk_aots",
    "status", "change_closed_by_eastern_dt", "requester_group",
    "category", "summary", "planned_end_date", "type", "item",
    "requester_name", "requester_login_name",
    "task_planned_start_date", "task_planned_end_date",
    "order_number", "create_date", "modified_date",
    "assignee_login_name", "assignee", "service_affected_aots",
    "services_supported", "product_affected", "impact",
    "customer_impacted", "closure_code", "closure_code2",
    "aots_closure_code", "root_cause_code",
    "root_cause_action_plan_aots", "rescheduled_count",
    "approval_status", "description",
    "planned_end_eastern_dt", "planned_start_eastern_dt",
]


@dp.materialized_view(
    name="cmclosed_tasks",
    comment="Gold: CM Closed Tasks. Change+Task join only, closed last 365 days. 50 columns.",
    table_properties={"quality": "gold"},
)
def cmclosed_tasks():
    """Converted from: Contour 46d229a0 → cmclosed_tasks.py"""
    df = _build_base_joined(
        include_tasks=True, include_apsig=False,
        include_equipment=False, include_techs=False, include_cllis=False,
    )
    df = _apply_mso_requester_filter(df)
    df = df.filter(
        (F.col("change_closed_by_eastern_dt") >= F.date_sub(F.current_date(), 365))
        & (F.col("change_closed_by_eastern_dt") <= F.current_date())
    )
    df = df.filter(F.col("status").isin(7, 8))
    df = _apply_status_mappings(df)

    available = [c for c in _CMCLOSED_TASKS_KEPT_COLUMNS if c in df.columns]
    df = df.select(available)

    df = _apply_eastern_date_formatting(
        df,
        columns_utc=["planned_start_date", "planned_end_date"],
        columns_raw=["change_closed_by_eastern_dt"],
    )
    return df


# ═══════════════════════════════════════════════════════════════════════════
# GOLD 4: cmclosed_notasks — Materialized View
#   Contour RID: 064b7d50 | 4 joins (no task) | 53 columns
# ═══════════════════════════════════════════════════════════════════════════

_CMCLOSED_NOTASKS_KEPT_COLUMNS = [
    "change_id", "order_number", "create_date", "modified_date",
    "planned_start_date", "planned_end_date", "status", "category",
    "type", "item", "summary", "work_type", "requester_group",
    "requester_name", "requester_login_name", "assignee_login_name",
    "assignee", "service_affected_aots", "services_supported",
    "product_affected", "reason_aots", "business_risk_aots",
    "technical_risk_aots", "impact", "customer_impacted",
    "first_moved_to_pending_apprvl", "closure_code", "aots_closure_code",
    "closure_code2", "root_cause_code", "root_cause_action_plan_aots",
    "rescheduled_count", "approval_status", "description", "clli",
    "closing_comments_aots", "number_of_tasks", "supervisor_group",
    "impacted_state", "location", "new_technology",
    "equipment_id", "equipment_name", "equipment_type",
    "apsig_approval_status", "apsig_request", "apsig_role",
    "apsig_approver_signature", "emergency_",
    "change_closed_by_eastern_dt", "supervisor_location",
    "planned_end_eastern_dt", "planned_start_eastern_dt",
]


@dp.materialized_view(
    name="cmclosed_notasks",
    comment="Gold: CM Closed No-Tasks. Change+Equipment+Techs+CLLIs+ApSig, no tasks. 53 columns.",
    table_properties={"quality": "gold"},
)
def cmclosed_notasks():
    """Converted from: Contour 064b7d50 → cmclosed_notasks.py"""
    df = _build_base_joined(
        include_tasks=False, include_apsig=True,
        include_equipment=True, include_techs=True, include_cllis=True,
    )
    df = _apply_mso_requester_filter(df)
    df = df.filter(
        (F.col("change_closed_by_eastern_dt") >= F.date_sub(F.current_date(), 365))
        & (F.col("change_closed_by_eastern_dt") <= F.current_date())
    )
    df = df.filter(F.col("status").isin(7, 8))
    df = _apply_status_mappings(df)

    available = [c for c in _CMCLOSED_NOTASKS_KEPT_COLUMNS if c in df.columns]
    df = df.select(available)

    df = _apply_eastern_date_formatting(
        df,
        columns_utc=["create_date", "modified_date", "planned_start_date", "planned_end_date"],
        columns_raw=["change_closed_by_eastern_dt"],
    )
    return df


# ═══════════════════════════════════════════════════════════════════════════
# EXPORT STREAMING TABLES (formerly @dlt.view → now @dp.table streaming)
#
# These replace the 4 Foundry Python transforms that wrote CSV with custom
# delimiters. Promoted from DLT views to streaming tables so downstream
# consumers can subscribe to changes.
#
# The original Foundry CSV parameters were:
#   sep="|_|;|_|", lineSep="\u0177", header=True, coalesce(1)
# If CSV export is still needed, use a separate Databricks Job.
# ═══════════════════════════════════════════════════════════════════════════

@dp.table(
    name="mso_aotscm_open_tickets_export",
    comment="Streaming export of MSO open tickets. Replaces Foundry CSV export.",
    table_properties={"quality": "gold", "pipelines.autoOptimize.managed": "true"},
)
def mso_aotscm_open_tickets_export():
    """Reads from gold MV as a stream — captures every MV refresh as new data."""
    return spark.readStream.table("mso_aotscm_open_tickets")


@dp.table(
    name="mso_aotscm_closed_tickets_export",
    comment="Streaming export of MSO closed tickets. Replaces Foundry CSV export.",
    table_properties={"quality": "gold"},
)
def mso_aotscm_closed_tickets_export():
    return spark.readStream.table("mso_aotscm_closed_tickets")


@dp.table(
    name="cmclosed_tasks_export",
    comment="Streaming export of CM closed tasks. Replaces Foundry CSV export.",
    table_properties={"quality": "gold"},
)
def cmclosed_tasks_export():
    return spark.readStream.table("cmclosed_tasks")


@dp.table(
    name="cmclosed_notasks_export",
    comment="Streaming export of CM closed no-tasks. Replaces Foundry CSV export.",
    table_properties={"quality": "gold"},
)
def cmclosed_notasks_export():
    return spark.readStream.table("cmclosed_notasks")
