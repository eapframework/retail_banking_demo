from transforms.api import transform, Input, Output, incremental
#from utility.incremental.update_insert import update_insert
from myproject.datasets.utils import update_insert
from utility.column_clean import clean_columns, lowercase_columns, remove_prefix, long_to_datetime
from pyspark.sql import functions as F
from myproject.datasets.column_clean import strip_all_string_col
from pyspark.sql.types import DecimalType, IntegerType



time_cols = ['askme_creat_tm','actl_comptln_tm','comp_can_tm','cmtmt_tm','rstrl_tm','acc_bgn_tm','acc_end_tm','askme_frst_asgn_tm','frst_dsptch_tm','cust_rptd_tm','ord_ptd_tm','ord_iad_tm','ord_wot_tm','appt_tm','load_start_tm','load_end_tm']
#We configure this as incrementa eventhough the raw is in snapshot to use adopt the feature like time_cols,strip_cols
@incremental(semantic_version=7)
@transform(
   output=Output("/Innovation Lab/[Source] Teradata EDW - ASKME/data/clean/VCTD485_STG2"),
   updates=Input("ri.foundry.main.dataset.45627190-c2a0-4fa4-a956-9b766e0c5aec"),
)
def vctd485_details(ctx, output, updates):
    updates = updates.dataframe()
    updates=lowercase_columns(updates)
    updates=strip_all_string_col(updates)
    updates=updates.drop("pull_slice") #This is required when we do the backfill using hashbucket only# 
    updates = updates.withColumn("wr_id", F.col("wr_id").cast(DecimalType(10,0))) \
               .withColumn("askme_creat_mam_tm", F.col("askme_creat_mam_tm").cast(IntegerType())) \
               .withColumn("actl_comptln_mam_tm", F.col("actl_comptln_mam_tm").cast(IntegerType())) \
               .withColumn("comp_can_mam_tm", F.col("comp_can_mam_tm").cast(IntegerType())) \
               .withColumn("cmtmt_mam_tm", F.col("cmtmt_mam_tm").cast(IntegerType())) \
               .withColumn("rstrl_mam_tm", F.col("rstrl_mam_tm").cast(IntegerType())) \
               .withColumn("dmna_strt_mam_tm1", F.col("dmna_strt_mam_tm1").cast(IntegerType())) \
               .withColumn("dmna_end_mam_tm1", F.col("dmna_end_mam_tm1").cast(IntegerType())) \
               .withColumn("dmna_strt_mam_tm2", F.col("dmna_strt_mam_tm2").cast(IntegerType())) \
               .withColumn("dmna_end_mam_tm2", F.col("dmna_end_mam_tm2").cast(IntegerType())) \
               .withColumn("askme_rcv_to_dsptch_dur", F.col("askme_rcv_to_dsptch_dur").cast(IntegerType())) \
               .withColumn("askme_rcv_to_prem_dur", F.col("askme_rcv_to_prem_dur").cast(IntegerType())) \
               .withColumn("askme_tot_wrk_tm_dur", F.col("askme_tot_wrk_tm_dur").cast(IntegerType())) \
               .withColumn("askme_rcv_to_clr2_dur", F.col("askme_rcv_to_clr2_dur").cast(IntegerType())) \
               .withColumn("askme_rcv_to_clr_dur", F.col("askme_rcv_to_clr_dur").cast(IntegerType())) \
               .withColumn("askme_dsptch_to_clr2_dur", F.col("askme_dsptch_to_clr2_dur").cast(IntegerType())) \
               .withColumn("askme_dsptch_to_clr_dur", F.col("askme_dsptch_to_clr_dur").cast(IntegerType())) \
               .withColumn("askme_frst_asgn_mam_tm", F.col("askme_frst_asgn_mam_tm").cast(IntegerType())) \
               .withColumn("frst_dsptch_mam_tm", F.col("frst_dsptch_mam_tm").cast(IntegerType())) \
               .withColumn("cust_rptd_mam_tm", F.col("cust_rptd_mam_tm").cast(IntegerType())) \
               .withColumn("ord_ptd_mam_tm", F.col("ord_ptd_mam_tm").cast(IntegerType())) \
               .withColumn("ord_iad_mam_tm", F.col("ord_iad_mam_tm").cast(IntegerType())) \
               .withColumn("ord_wot_mam_tm", F.col("ord_wot_mam_tm").cast(IntegerType())) \
               .withColumn("estd_tech_dur", F.col("estd_tech_dur").cast(DecimalType(5,0))) \
               .withColumn("appt_mam_tm", F.col("appt_mam_tm").cast(IntegerType())) \
               .withColumn("dsp_to_clr_na_dur", F.col("dsp_to_clr_na_dur").cast(IntegerType())) \
               .withColumn("rcpt_to_clr_na_dur", F.col("rcpt_to_clr_na_dur").cast(IntegerType())) \
               .withColumn("rcpt_to_dsp_na_dur", F.col("rcpt_to_dsp_na_dur").cast(IntegerType())) \
               .withColumn("askme_dsp_to_on_prem_dur", F.col("askme_dsp_to_on_prem_dur").cast(IntegerType())) \
               .withColumn("askme_pernr", F.col("askme_pernr").cast(IntegerType())) \
               .withColumn("load_start_mam_tm", F.col("load_start_mam_tm").cast(IntegerType())) \
               .withColumn("load_end_mam_tm", F.col("load_end_mam_tm").cast(IntegerType())) \
               .withColumn("askme_rcv_to_rstrl_dur", F.col("askme_rcv_to_rstrl_dur").cast(IntegerType())) \
               .withColumn("askme_dsptch_to_rstrl_dur", F.col("askme_dsptch_to_rstrl_dur").cast(IntegerType())) \
               .withColumn("last_on_prmss_to_rstrl_dur", F.col("last_on_prmss_to_rstrl_dur").cast(IntegerType())) \
               .withColumn("root_wr_id", F.col("root_wr_id").cast(DecimalType(10,0))) \
               .withColumn("from_wr_id", F.col("from_wr_id").cast(DecimalType(10,0))) \
               .withColumn("askme_cc_tot_wrk_tm", F.col("askme_cc_tot_wrk_tm").cast(IntegerType())) \
               .withColumn("askme_max_rstrl_mam_tm", F.col("askme_max_rstrl_mam_tm").cast(IntegerType())) \
               .withColumn("askme_alt_blg_loc_id", F.col("askme_alt_blg_loc_id").cast(DecimalType(18,0)))
    update_insert(ctx, output, updates, primary_keys=["wr_id" , "ext_key1" , "comp_can_ts" , "src_cd"], order_cols=["dw_load_dt", "comp_can_dt"],time_cols=time_cols)
