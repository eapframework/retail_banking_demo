CREATE TABLE `ri.foundry.main.dataset.c1d5c184-621d-4729-9ab9-2c5458af5816` AS
    SELECT ext_key1
    , concat_ws(';', collect_set(cast(caus_cd as integer)))  cause_code_list_in
    , concat_ws(';', collect_set(cast(trbl_fnd_cd as integer)))  trbl_fnd_cd_list_in
    , concat_ws(';', collect_list(trbl_fnd_desc)) trbl_fnd_desc_in
    FROM `ri.foundry.main.dataset.a66ab7be-b938-4779-ba24-2dc644803bb1`
    WHERE lower(ext_key1) REGEXP '^[a-z][a-z][0-9][0-9][0-9][0-9][0-9][0-9]$|[0-9a-z][0-9a-z][0-9a-z][0-9a-z][0-9a-z][0-9a-z][0-9a-z][0-9a-z][0-9a-z]'
    group by ext_key1