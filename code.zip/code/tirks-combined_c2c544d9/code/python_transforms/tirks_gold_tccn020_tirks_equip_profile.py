from transforms.api import transform, Input, Output, incremental
from utility.column_clean import clean_columns, lowercase_columns
#from myproject.datasets.utils import write_output_buckets
from pyspark.sql import functions as F


# @incremental(semantic_version=3)
@transform(
    out=Output("ri.foundry.main.dataset.a2f17218-8684-418f-8d41-10b09285b72b"),
    inp=Input("ri.tables.main.table.b535c583-5e40-42ae-a7b1-c462c8ec4c93")
)
def my_compute_function(ctx, inp, out):
    df = clean_columns(
        inp.dataframe(),
        strip_columns=strip_columns,
        integer_columns=cast_to_integer_columns,
        double_columns=cast_to_double_columns,
        decimal_columns=cast_to_decimal_columns,
        timestamp_columns=cast_to_timestamp_from_long_columns,
        datetime_columns=cast_to_timestamp_columns,
        datetime_format=datetime_format,
        date_columns=cast_to_date_columns,
        date_format=date_format,
        id_columns=cast_to_string_columns,
        integer_from_num_columns=cast_to_integer_from_decimal_columns
    )
    df = lowercase_columns(df)
    df = convert_to_string_from_timestamp(df)
    df = df.drop(*columnstoDrop)
    out.write_dataframe(df)
    # write_output_buckets(ctx, inp, out, df, 'data_dt')


columnstoDrop = [
    "dl_src_file_name",
    "dl_load_ts"
]

date_format = 'yyyy-MM-dd'
datetime_format = 'yyyy-MM-dd HH:mm:ss'

cast_to_date_columns = []
cast_to_timestamp_columns = []
cast_to_timestamp_from_long_columns = []
cast_to_integer_columns = []
cast_to_double_columns = []
cast_to_decimal_columns = []
cast_to_string_columns = []
cast_to_integer_from_decimal_columns = []
strip_columns = []

def convert_to_string_from_timestamp(dtfrm):
    return dtfrm.withColumn("load_ts", F.from_unixtime(F.unix_timestamp("dl_load_ts"), "yyyy/MM/dd HH:mm:ss"))