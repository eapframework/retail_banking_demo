from transforms.api import transform, Input, Output, incremental
from utility.column_clean import clean_columns, lowercase_columns, remove_prefix, long_to_datetime
from pyspark.sql import functions as F

@transform(
    out=Output("/Innovation Lab/[Source] Oracle AOTS-M/data/clean/BOADMIN.TROUBLE_TICKET"),
    df=Input("/Innovation Lab/[Source] Oracle AOTS-M/data/raw/Prod/trouble_ticket"),
)
def my_compute_function(df, out):
    df = clean_columns(
        df.dataframe(),
        date_format=date_format, 
        date_columns=string_to_date,
        datetime_format=datetime_format, 
        datetime_columns=long_unixtime_to_timestamp,
        timestamp_from_string_format=string_unixtime_format,
        timestamp_from_string_columns=string_unixtime_to_timestamp,
        timestamp_format=long_unixtime_format, 
        timestamp_columns=long_unixtime_to_timestamp,
        integer_columns=string_to_integer_columns,
        double_columns=string_to_double_columns,
        decimal_columns=string_to_decimal_columns,
        id_columns=numeric_to_string_columns,
        integer_from_num_columns=decimal_to_integer,
        strip_columns=strip_string_columns,
    )
    df = lowercase_columns(df)
    df = df.withColumn("alarm_time", long_to_datetime(F.col("alarm_time"), 'seconds'))
    #df = df.withColumn("date_time_up", long_to_datetime(F.col("date_time_up"), 'seconds'))
    #df = df.withColumn("create_date", long_to_datetime(F.col("create_date"), 'seconds'))
    df = df.withColumn("return_to_service", long_to_datetime(F.col("return_to_service"), 'seconds'))
    df = df.withColumn("resolved_time", long_to_datetime(F.col("resolved_time"), 'seconds'))
    df = df.withColumn("closed_time", long_to_datetime(F.col("closed_time"), 'seconds'))
    df = df.withColumn("notamcreatetime", long_to_datetime(F.col("notamcreatetime"), 'seconds'))
    #df = df.withColumn("modified_date", long_to_datetime(F.col("modified_date"), 'seconds'))
    out.write_dataframe(df)

drop_columns = []
date_format = 'yyyy-MM-dd'
string_to_date = []
datetime_format = 'yyyy-MM-dd HH:mm:ss'
string_to_timestamp = []
string_unixtime_format = None
string_unixtime_to_timestamp = []
long_unixtime_format = None
long_unixtime_to_timestamp = []
string_to_integer_columns = []
string_to_double_columns = []
string_to_decimal_columns = []
numeric_to_string_columns = []
decimal_to_integer = []
strip_string_columns = []
