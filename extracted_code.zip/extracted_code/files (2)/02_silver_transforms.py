"""
MSO uTicket — Databricks DLT Pipeline (Silver Layer)
=====================================================
Clean/curated transforms converted from Foundry Python transforms.
Each table corresponds to a Foundry @transform decorated function.

Conversion notes:
- Foundry @transform → DLT @dlt.table
- Foundry @incremental with SCD1 upsert → DLT APPLY CHANGES (or full-refresh with dedup)
- Foundry clean_columns + lowercase_columns → utilities.clean_columns + lowercase_columns
- Foundry perform_timestamp_parsing → utilities.parse_epoch_millis_columns
"""

import dlt
from pyspark.sql import functions as F
from utilities import (
    clean_columns, lowercase_columns, parse_epoch_millis_columns,
    perform_timestamp_parsing, scd1_upsert,
)


# ═══════════════════════════════════════════════════════════════════════════
# 1. chg_change (clean)
#    Source: chg_change.py — @incremental(semantic_version=3)
#    Foundry: [Source] Oracle ESAR/data/clean/chg_change
#    PK: (change_id, seqno)  |  Order: modified_date  |  SCD Type 1
# ═══════════════════════════════════════════════════════════════════════════

# --- Option A: Full-refresh DLT table with dedup (simpler, recommended for initial migration) ---

@dlt.table(
    name="clean_chg_change",
    comment="Cleaned CHG_CHANGE. SCD1 deduplicated on (change_id, seqno) ordered by modified_date.",
    table_properties={"quality": "silver", "pipelines.autoOptimize.managed": "true"},
)
def clean_chg_change():
    """
    Converted from: chg_change.py
    Foundry RID: 515f79aa → e8409bca (cross-project ref collapsed)
    
    Key transformations:
    - Epoch-millis → Timestamp for 27+ date columns
    - Many columns cast to decimal (status, seqno, risk scores, etc.)
    - 6 columns cast to string (maintenance_window_*, lab_tested_*, 72_hours_advance)
    - backout_start / backout_end: custom epoch-millis / 1000 → timestamp
    - All column names lowercased
    - Dedup: keep latest row per (change_id, seqno) ordered by modified_date DESC
    """
    raw = dlt.read("raw_chg_change_snowflake")

    # --- Timestamp columns (epoch-millis → timestamp) ---
    timestamp_cols = [
        "create_date", "modified_date", "planned_start_date", "planned_end_date",
        "auto_close_time", "requested_completion_date", "actual_end_date",
        "actual_start_date", "igems_ccb_accept_date", "igems_deadline_date",
        "old_igems_rom_time", "lead_days_start_date", "lead_days_end_date",
        "lead_start_date", "lead_end_date", "max_end_date", "max_start_date",
        "min_end_date", "min_start_date", "release_scope_closed_date", "rfs_date",
        "red_tech_team_review_date", "release_fit_test_end_date",
        "release_fit_test_start_date", "client_ebond_date",
        "scheduled_downtime_start_date", "scheduled_downtime_end_date",
    ]

    # --- Decimal columns ---
    decimal_cols = [
        "planned_duration__in_hours", "actual_duration__in_hours",
        "igems_total_time_worked", "igems_rom_time", "ztemptotaltimetask",
        "ztmpbackoutduration", "rescheduled_count", "seqno", "status",
        "request_urgency", "closure_code", "pending", "scope",
        "ztmpsubmitassociation", "escalated", "auto_close_days",
        "request_manager_to_reassign", "ztmpactiononsubmit", "confirm_resolution",
        "ztempnooftasks", "approval_status", "number_of_tasks", "priority",
        "source", "hotlist", "risk", "impact", "sequence",
        "zchangerelationshipkeyint", "zdependencynotification",
        "zotherchangessameorder", "zsubmittingdependent", "approval_required",
        "error_in_approval_process", "usersbylocf", "usersbyassetf",
        "target_level_mgtchain", "zlevelmgtchain", "business_risk",
        "technical_risk", "wap_type", "emergency", "cboenforcechgdependency",
        "cboenforcetskdependency", "palm_status", "ztmpuseescbushrs",
        "closure_impact", "reason", "total_components", "total_unsuccesful",
        "total_customer_impact", "ztempplanneddateduration", "zcc_excel_row",
        "zcc_excel_column", "zcc_excelrowcount", "ztempstatus",
        "ztempapprovalstatus", "previous_status", "previous_approval_status",
        "rejectcount", "approval_list_count", "approval_row_count",
        "zpreappcount", "zappcount", "ztemppreviousnumber",
        "ztemptotalapprovers", "asset_type", "igems_rom_costd", "in_window_",
        "visible_to_customer", "cbus_notif_fail_count", "reuse_integer_field1",
        "internalcircuittaskcount", "total_circuits",
        "total_qualifying_circuits", "total_ckt__tasks_created",
        "total_ckt_task_create_failures", "days", "hours", "minutes",
        "ztmprowcount", "total_total_ckt__tasks_created",
        "total_tasks_waiting_approval", "total_tasks_still_open",
        "verification_date_time", "ztmpdays", "ztmphours", "ztmpmin",
        "ztmpgmapprovaldate", "reuse_drop_down1", "allow_approval_comments",
        "details_2__tab_available", "max_critical_step_duration",
        "tmpmax_critical_step_duration", "re_approve_on_field_change",
        "sentinel_folder_created", "wms_ticket_created",
        "attachment_add_delete_forces_r", "ztmpbmpexists",
        "ztmpaffectedassetadddeleteflag", "affected_cllis_required",
        "affected_technologies_required", "auto_approve",
        "backout_summary_required", "checklistrequired", "cn_type_ticket",
        "components_tab", "cust_impact_description_requir",
        "customersfacriskrequired", "emergency_threshold",
        "enable_timed_notifications", "enable_timed_notificationsold",
        "force_conflict", "impact_required", "onsite_contact_info_required",
        "pci_ticket", "removal_required", "require_conflict_id_",
        "smop_details_tab_enabled", "step_specifics_required",
        "technical_risk_flex_option", "tmpmopdefaults", "tmpsteptblcnt",
        "work_type_required", "zstatelength", "ztmpreapprovalstatuscount",
        "in_scope_of_crp", "description_not_uct_test", "duration",
        "by_clli_metro_filter", "emergency_variable", "var_non_disruptive",
        "var_fcc_yes", "var_emergency_exceptions", "var_service_affected_911",
        "var_change_id_format_filter", "var_category_format_filter",
        "var_pa_right_format_filter", "var_sa_right_format_filter",
        "var_business_risk_format_filter", "end_date", "start_date",
    ]

    string_cols = [
        "nrm_72_hours_advance", "maintenance_window_nrm", "maintenance_window_ip",
        "lab_tested_nrm", "lab_tested_ip", "ip_72_hours_advance",
    ]

    # Step 1: Lowercase all column names
    df = raw.select([F.col(c).alias(c.lower()) for c in raw.columns])

    # Step 2: Parse epoch-millis timestamps
    df = clean_columns(df, timestamp_columns=timestamp_cols, datetime_format="yyyy-MM-dd HH:mm:ss")
    df = perform_timestamp_parsing(df)

    # Step 3: Cast decimal columns
    for c in decimal_cols:
        if c in df.columns:
            df = df.withColumn(c, F.col(c).cast("decimal(38,10)"))

    # Step 4: Cast string columns
    for c in string_cols:
        if c in df.columns:
            df = df.withColumn(c, F.col(c).cast("string"))

    # Step 5: Special backout timestamp handling
    if "backout_start" in df.columns:
        df = df.withColumn("backout_start", F.from_unixtime(F.col("backout_start") / 1000).cast("timestamp"))
    if "backout_end" in df.columns:
        df = df.withColumn("backout_end", F.from_unixtime(F.col("backout_end") / 1000).cast("timestamp"))

    # Step 6: SCD1 dedup — keep latest row per (change_id, seqno)
    from pyspark.sql import Window
    w = Window.partitionBy("change_id", "seqno").orderBy(F.col("modified_date").desc())
    df = df.withColumn("__rn__", F.row_number().over(w)).filter("__rn__ = 1").drop("__rn__")

    return df


# --- Option B: DLT APPLY CHANGES (streaming SCD1) --- uncomment if using streaming ingestion ---
# dlt.create_streaming_table("clean_chg_change_streaming")
# dlt.apply_changes(
#     target="clean_chg_change_streaming",
#     source="raw_chg_change_snowflake",
#     keys=["change_id", "seqno"],
#     sequence_by="modified_date",
#     stored_as_scd_type=1,
# )


# ═══════════════════════════════════════════════════════════════════════════
# 2. chg_task (clean)
#    Source: chg_task.py — batch (no incremental)
#    Foundry: [Source] Oracle ESAR/data/clean/chg_task
# ═══════════════════════════════════════════════════════════════════════════

@dlt.table(
    name="clean_chg_task",
    comment="Cleaned CHG_TASK. 190 columns lowercased, many cast to decimal.",
    table_properties={"quality": "silver"},
)
def clean_chg_task():
    """
    Converted from: chg_task.py
    Foundry RID: d59e3472-db57-47c2-ab46-176f23a26476
    """
    raw = dlt.read("raw_chg_task_snowflake")

    decimal_cols = [
        "seqno", "status", "request_urgency", "closure_code", "pending", "scope",
        "ztmpsubmitassociation", "request_supervisor_to_reassign", "ztempprevseqnum",
        "ztmpconflictsfound", "first_in_line", "ztmpbusinesshrsselection",
        "planned_duration", "actual_duration", "zclosedthistransaction",
        "zscheduledthistransaction", "zwipthistransaction", "zcanceledthistransaction",
        "ztmpreassignment", "priority", "hotlist", "sequence",
        "zdependencynotification", "ztmpothertaskssameorde", "cboenforcetskdependency",
        "work_order", "webserviceorder", "ztempnooftasks", "escalated",
        "chg_appr_status", "ztempstatus", "previous_status", "ztempplannedend",
        "ztemptotaltime", "ztempdifftime", "tasksequence", "previoustasksequence",
        "visible_to_customer",
    ]

    # Lowercase all columns
    df = raw.select([F.col(c).alias(c.lower()) for c in raw.columns])
    df = perform_timestamp_parsing(df)

    # Cast decimal columns
    for c in decimal_cols:
        if c in df.columns:
            df = df.withColumn(c, F.col(c).cast("decimal(38,10)"))

    return df


# ═══════════════════════════════════════════════════════════════════════════
# 3. acmr14_affected_cllis (clean)
#    Source: acmr14_affected_cllis.py — batch
# ═══════════════════════════════════════════════════════════════════════════

@dlt.table(
    name="clean_acmr14_affected_cllis",
    comment="Cleaned ACMR14 Affected CLLIs. STATUS cast to integer, timestamps parsed.",
    table_properties={"quality": "silver"},
)
def clean_acmr14_affected_cllis():
    """
    Converted from: acmr14_affected_cllis.py
    Foundry RID: 365744b9-deef-4449-8e82-2e1be8690df1
    """
    raw = dlt.read("raw_acmr14_affected_cllis")

    df = clean_columns(
        raw,
        timestamp_columns=["CREATE_DATE", "MODIFIED_DATE"],
        integer_columns=["STATUS"],
        datetime_format="yyyy-MM-dd HH:mm:ss",
    )
    df = perform_timestamp_parsing(df)
    df = lowercase_columns(df)

    return df


# ═══════════════════════════════════════════════════════════════════════════
# 4. acmr14_affected_techs (clean)
#    Source: acmr14_affected_techs.py — batch
# ═══════════════════════════════════════════════════════════════════════════

@dlt.table(
    name="clean_acmr14_affected_techs",
    comment="Cleaned ACMR14 Affected Technologies. STATUS, USED_FOR_CHG_TEMPLATE cast to integer.",
    table_properties={"quality": "silver"},
)
def clean_acmr14_affected_techs():
    """
    Converted from: acmr14_affected_techs.py
    Foundry RID: 071983e5-e8b6-47ea-833e-a39b32284633
    """
    raw = dlt.read("raw_acmr14_affected_techs_snowflake")

    df = clean_columns(
        raw,
        timestamp_columns=["CREATE_DATE", "MODIFIED_DATE"],
        integer_columns=["STATUS", "USED_FOR_CHG_TEMPLATE"],
        datetime_format="yyyy-MM-dd HH:mm:ss",
    )
    df = perform_timestamp_parsing(df)
    df = lowercase_columns(df)

    return df


# ═══════════════════════════════════════════════════════════════════════════
# 5. ars_dbor_cm_r1_acmr23_mobility_equipment_info (clean)
#    Source: ars_dbor_cm_r1_acmr23_mobility_equipment_info.py
#    @incremental(semantic_version=5) — SCD1 on (med_record_id)
# ═══════════════════════════════════════════════════════════════════════════

@dlt.table(
    name="clean_acmr23_mobility_equipment_info",
    comment="Cleaned ACMR23 Mobility Equipment. SCD1 on med_record_id, ordered by modified_date.",
    table_properties={"quality": "silver"},
)
def clean_acmr23_mobility_equipment_info():
    """
    Converted from: ars_dbor_cm_r1_acmr23_mobility_equipment_info.py
    Foundry RID: ae0545f5-c03b-4292-961d-2e7459397e95
    """
    raw = dlt.read("raw_acmr23_mobility_equipment_info_snowflake")

    df = clean_columns(
        raw,
        timestamp_columns=["CREATE_DATE", "MODIFIED_DATE", "PLANNED_START_DATE", "PLANNED_END_DATE"],
        datetime_format="yyyy-MM-dd HH:mm:ss",
    )
    df = perform_timestamp_parsing(df)
    df = lowercase_columns(df)

    # SCD1 dedup: keep latest per med_record_id
    from pyspark.sql import Window
    w = Window.partitionBy("med_record_id").orderBy(F.col("modified_date").desc())
    df = df.withColumn("__rn__", F.row_number().over(w)).filter("__rn__ = 1").drop("__rn__")

    return df


# ═══════════════════════════════════════════════════════════════════════════
# 6. ars_dbor_cm_r1_ap_signature (clean)
#    Source: ars_dbor_cm_r1_ap_signature.py — batch
# ═══════════════════════════════════════════════════════════════════════════

@dlt.table(
    name="clean_ap_signature",
    comment="Cleaned AP_SIGNATURE. Integer + float casts, 6 timestamp columns parsed.",
    table_properties={"quality": "silver"},
)
def clean_ap_signature():
    """
    Converted from: ars_dbor_cm_r1_ap_signature.py
    Foundry RID: 60bb71df (clean ap_signature)
    """
    raw = dlt.read("raw_ap_signature")

    integer_cols = [
        "SEQNO", "APPROVAL_STATUS", "SIGNATURE_METHOD", "INDEPENDENT",
        "IF_MULTIPLE_APPROVERS", "NUMBER_OF_GLOBAL_NOTIFICATIONS",
        "NUMBER_OF_STATE_NOTIFICATIONS", "LEVEL_SIG", "PREVIOUSSIGNATURENUMBER",
        "NEXTSIGNATURENUMBER", "XREFSIGNATUREID", "COMPLETED", "ORDER_X",
        "REACHED_DONE", "APPROVAL_LEVEL", "EXEMPT_FROM_REAPPROVAL",
    ]
    float_cols = [
        "CURRENT_APPROVAL_LEVEL", "CURRENT_APPROVAL_LEVEL_COUNT", "LAST_APP_CR_COUNT",
    ]
    timestamp_cols = [
        "CREATE_DATE_SIG", "MODIFIED_DATE_SIG", "NEXT_ACTION_ESCALATION_TIME",
        "NEXT_GLOBAL_ESCALATION_TIME", "NEXT_STATE_ESCALATION_TIME", "MODIFIED",
    ]

    df = clean_columns(
        raw,
        timestamp_columns=timestamp_cols,
        integer_columns=integer_cols,
        datetime_format="yyyy-MM-dd HH:mm:ss",
    )
    df = perform_timestamp_parsing(df)

    # Re-cast integer columns (Foundry code does this after initial clean)
    for c in integer_cols:
        if c.lower() in [col.lower() for col in df.columns]:
            df = df.withColumn(c, F.col(c).cast("integer"))

    # Cast float columns
    for c in float_cols:
        if c in df.columns:
            df = df.withColumn(c, F.col(c).cast("float"))

    df = lowercase_columns(df)
    return df


# ═══════════════════════════════════════════════════════════════════════════
# 7. ars_dbor_cm_r1_ap_detail (clean)
#    Source: ars_dbor_cm_r1_ap_detail.py — batch
# ═══════════════════════════════════════════════════════════════════════════

@dlt.table(
    name="clean_ap_detail",
    comment="Cleaned AP_DETAIL. Integer + decimal casts, 2 timestamp columns.",
    table_properties={"quality": "silver"},
)
def clean_ap_detail():
    """
    Converted from: ars_dbor_cm_r1_ap_detail.py
    Foundry RID: fbcca57c (clean ap_detail)
    """
    raw = dlt.read("raw_ap_detail_snowflake")

    integer_cols = [
        "SEQNO", "STATUS_DTL", "PRIORITY", "LEVEL_X", "APPROVAL_METHOD",
        "INTEGER_FIELD_1", "INTEGER_FIELD_2", "STATISTICAL_OVERRIDE", "ORDER_X",
    ]
    float_cols = [
        "REAL_FIELD_1", "REAL_FIELD_2", "DECIMAL_FIELD_1", "DECIMAL_FIELD_2",
    ]
    timestamp_cols = ["CREATE_DATE_DTL", "MODIFIED_DATE_DTL"]

    df = clean_columns(
        raw,
        timestamp_columns=timestamp_cols,
        integer_columns=integer_cols,
        datetime_format="yyyy-MM-dd HH:mm:ss",
    )
    df = perform_timestamp_parsing(df)

    # Re-cast integer cols to decimal (Foundry code does cast("decimal") after clean)
    for c in integer_cols:
        if c in df.columns:
            df = df.withColumn(c, F.col(c).cast("decimal(38,10)"))

    # Cast float cols to decimal
    for c in float_cols:
        if c in df.columns:
            df = df.withColumn(c, F.col(c).cast("decimal(38,10)"))

    df = lowercase_columns(df)
    return df


# ═══════════════════════════════════════════════════════════════════════════
# 8. ap_signature (SQL join)
#    Source: ap_signature.sql
#    Foundry: /Innovation Lab/GTOC Change Management Metrics and Reports/ontology/clean/ap_signature
#    Joins clean ap_signature with clean ap_detail to get the REQUEST column
# ═══════════════════════════════════════════════════════════════════════════

@dlt.table(
    name="silver_ap_signature_enriched",
    comment="AP_SIGNATURE joined with AP_DETAIL to resolve request (change_id). Converted from ap_signature.sql.",
    table_properties={"quality": "silver"},
)
def silver_ap_signature_enriched():
    """
    Converted from: ap_signature.sql
    Foundry RID: a306bde0-7a8f-45a4-a431-c5d85903b856
    
    SQL logic:
      SELECT signature_id, alternate_signature, AP_SIGNATURE.approval_id,
             approval_status, approver_signature, approvers, modified_date_sig,
             role, AP_DETAIL.request
      FROM clean_ap_signature
      LEFT JOIN (SELECT request, approval_id FROM clean_ap_detail) AS AP_DETAIL
        ON AP_DETAIL.approval_id = AP_SIGNATURE.approval_id
      WHERE AP_DETAIL.request IS NOT NULL
    """
    ap_sig = dlt.read("clean_ap_signature")
    ap_dtl = dlt.read("clean_ap_detail").select("request", "approval_id")

    result = (
        ap_sig.alias("AP_SIGNATURE")
        .join(
            ap_dtl.alias("AP_DETAIL"),
            F.col("AP_SIGNATURE.approval_id") == F.col("AP_DETAIL.approval_id"),
            "left",
        )
        .where(F.col("AP_DETAIL.request").isNotNull())
        .select(
            F.col("AP_SIGNATURE.signature_id"),
            F.col("AP_SIGNATURE.alternate_signature"),
            F.col("AP_SIGNATURE.approval_id"),
            F.col("AP_SIGNATURE.approval_status"),
            F.col("AP_SIGNATURE.approver_signature"),
            F.col("AP_SIGNATURE.approvers"),
            F.col("AP_SIGNATURE.modified_date_sig"),
            F.col("AP_SIGNATURE.role"),
            F.col("AP_DETAIL.request"),
        )
    )
    return result
