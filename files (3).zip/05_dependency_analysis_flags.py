"""
MSO uTicket — Dependency Analysis & Migration Flags
=====================================================
Generated from: extracted_code.zip analysis
Date: 2026-03-22

This document flags all identified gaps, missing dependencies, ambiguities,
and migration decisions that need resolution.
"""

# ═══════════════════════════════════════════════════════════════════════════
# FLAG 1: DOUBLE-HOP chg_change (TWO CLEAN DATASETS)
# Severity: MEDIUM — Needs confirmation
# ═══════════════════════════════════════════════════════════════════════════
#
# The lineage image shows TWO clean chg_change nodes:
#   chg_change_snowflake → [Source] Oracle ESAR 2/data/clean/chg_change (RID: 515f79aa)
#                        → [Source] Oracle ESAR/data/clean/chg_change (RID: e8409bca)
#
# The chg_change.py code only produces the FIRST node (515f79aa).
# The SECOND node (e8409bca) is the starting dataset for ALL 4 Contour analyses.
# The README classifies e8409bca as "RawDataset" — possibly a cross-project
# reference/link in Foundry.
#
# DECISION NEEDED: Is the second node (e8409bca) an identity pass-through?
#   If yes: Our DLT pipeline correctly collapses into one clean_chg_change table.
#   If no: There may be additional transforms happening between the two nodes
#          that we're missing.
#
# RECOMMENDATION: Verify with the Foundry admin team whether e8409bca applies
# any additional filtering, column additions, or data enrichment.


# ═══════════════════════════════════════════════════════════════════════════
# FLAG 2: MISSING CODE — "2018-2022_MSO CMRS_Brian" dataset
# Severity: LOW — Appears to be a historical/reference dataset
# ═══════════════════════════════════════════════════════════════════════════
#
# The lineage image shows a node "2018-2022_MSO CMRS_Brian" that consumes
# from multiple clean silver tables but has NO corresponding code file.
# This is likely:
#   a) A manually uploaded/maintained reference dataset
#   b) A Contour analysis by user "Brian" from historical period 2018-2022
#   c) A dashboard/view not included in the code extraction
#
# IMPACT: None on the 4 main gold tables. No downstream consumer appears
# to depend on it for the automated pipeline.
#
# ACTION: Confirm with Brian (the dataset owner) whether this still needs
# to be migrated or can be deprecated.


# ═══════════════════════════════════════════════════════════════════════════
# FLAG 3: MISSING UTILITY LIBRARIES (Foundry-internal packages)
# Severity: HIGH — Must be resolved before silver layer runs
# ═══════════════════════════════════════════════════════════════════════════
#
# The Foundry Python transforms import from several internal packages
# that are NOT included in the extracted code:
#
#   a) utility.column_clean.clean_columns
#      - Used by: ALL 7 silver Python transforms
#      - STATUS: ✅ RECONSTRUCTED in utilities.py based on observed usage patterns
#
#   b) utility.column_clean.lowercase_columns
#      - STATUS: ✅ RECONSTRUCTED — simple column rename to lower()
#
#   c) utility.column_clean.remove_prefix
#      - Imported but NOT USED in any transform
#      - STATUS: ⚠️ Not reconstructed (dead import)
#
#   d) utility.incremental.update_insert.update_insert_core
#      - Used by: chg_change.py, ars_dbor_cm_r1_acmr23_mobility_equipment_info.py
#      - STATUS: ✅ RECONSTRUCTED as scd1_upsert() in utilities.py
#      - NOTE: In DLT we use row_number() dedup or APPLY CHANGES instead
#
#   e) utility.incremental.timestamp_parsing.perform_timestamp_parsing
#      - Used by: ALL silver transforms
#      - STATUS: ✅ RECONSTRUCTED in utilities.py
#
#   f) utility.incremental.constants.RANK_COL_NAME
#      - STATUS: ✅ RECONSTRUCTED (value: "__rank__")
#
#   g) utility.incremental.util.drop_unneeded_cols
#      - Used by: process_update_insert_core in utility.py
#      - STATUS: ⚠️ Implementation unknown — likely drops internal Foundry columns
#      - RISK: May cause schema mismatch if Foundry added hidden columns
#      - ACTION: Not needed in Databricks (no Foundry internal columns)
#
#   h) myproject.datasets.utils.process_update_insert_core
#      - Used by: chg_change.py, ars_dbor_cm_r1_acmr23_mobility_equipment_info.py
#      - STATUS: ✅ RECONSTRUCTED — this is the same as utility.py's function
#                (the utility.py file provided IS myproject.datasets.utils)
#
#   i) ..utils.perform_timestamp_parsing (relative import)
#      - Used by: chg_task.py, ars_dbor_cm_r1_ap_detail.py
#      - STATUS: ✅ Same function, different import path


# ═══════════════════════════════════════════════════════════════════════════
# FLAG 4: INCREMENTAL → FULL REFRESH CONVERSION
# Severity: MEDIUM — Performance implication
# ═══════════════════════════════════════════════════════════════════════════
#
# Two Foundry transforms use @incremental with SCD1 upsert:
#   - chg_change.py:  @incremental(semantic_version=3), PK=(change_id, seqno)
#   - acmr23_equipment.py: @incremental(semantic_version=5), PK=(med_record_id)
#
# The DLT conversion provides TWO options:
#   Option A (DEFAULT): Full-refresh with row_number() dedup — simpler, correct,
#                        but re-processes all data each run.
#   Option B: DLT APPLY CHANGES (streaming SCD1) — incremental, requires
#             streaming source and proper watermarking.
#
# RECOMMENDATION: Start with Option A for initial migration validation.
# Once reconciliation passes, switch to Option B for production efficiency.
#
# NOTE: 5 other silver transforms had @incremental COMMENTED OUT in Foundry,
# meaning they were already running as full-refresh there too.


# ═══════════════════════════════════════════════════════════════════════════
# FLAG 5: CSV EXPORT WITH CUSTOM DELIMITERS
# Severity: MEDIUM — Downstream system dependency
# ═══════════════════════════════════════════════════════════════════════════
#
# Four Foundry transforms produce CSV files with unusual delimiters:
#   - Column separator: "|_|;|_|" (multi-char)
#   - Line separator:   "ŷ" / "\u0177"
#   - Single file (coalesce(1))
#
# This strongly suggests a downstream system (possibly AOTS — "Automated
# Operations Ticketing System") reads these CSVs with a custom parser.
#
# ACTIONS NEEDED:
#   1. Identify the downstream consumer of these CSV files
#   2. Determine if the consumer can read Delta tables directly (preferred)
#   3. If CSV is still required, create a separate Databricks Job to export
#      from the gold Delta tables to ADLS as CSV with the custom delimiters
#   4. The export job should use:
#      df.coalesce(1).write.csv(path, sep="|_|;|_|", lineSep="\u0177", header=True)


# ═══════════════════════════════════════════════════════════════════════════
# FLAG 6: CONTOUR CATEGORY FILTER (Board 11/12) — PARTIAL EXTRACTION
# Severity: LOW — Filter likely redundant
# ═══════════════════════════════════════════════════════════════════════════
#
# All 4 contours have an "alpha-filter" board on the "category" column
# (Board 11 in open/closed, Board 7/10 in cmclosed variants).
# The JSON shows the filter type but NOT the selected values.
# This filter appears AFTER the requester_group filter which already
# scopes to MSO Mobility groups.
#
# RISK: The category filter may further narrow results. Without the
# selected values, we cannot replicate it exactly.
#
# RECOMMENDATION: Run the pipeline without the category filter first,
# then compare row counts against Foundry. If counts differ, the
# Foundry admin should export the Contour filter configuration.


# ═══════════════════════════════════════════════════════════════════════════
# FLAG 7: LEFT JOIN FANOUT / CARDINALITY
# Severity: MEDIUM — May need dedup or aggregation
# ═══════════════════════════════════════════════════════════════════════════
#
# The Contour performs 5 LEFT JOINs all on change_id. Several of these
# are 1:N relationships:
#   - chg_task: Multiple tasks per change → creates row fanout
#   - acmr14_affected_techs: Multiple technologies per change
#   - acmr14_affected_cllis: Multiple CLLIs per change
#   - ap_signature_enriched: Multiple signatures per change
#   - acmr23_equipment: Multiple equipment records per change
#
# The Contour's matchType=ALL means it keeps ALL matching rows (LEFT JOIN),
# so the output is intentionally denormalized with row multiplication.
#
# This matches the original behavior, but be aware that:
#   1. Row counts will be much higher than unique change_id count
#   2. Aggregations on the gold tables need GROUP BY to avoid double-counting
#   3. Power BI reports built on these should use distinct counts


# ═══════════════════════════════════════════════════════════════════════════
# FLAG 8: MAGRITTE AGENT CONFIGURATION (Ingestion)
# Severity: HIGH — Must be configured separately
# ═══════════════════════════════════════════════════════════════════════════
#
# The Foundry pipeline used 3 Magritte agents to sync from Oracle ESAR:
#   - Agent ef60021d (connects to DataSource ba31895a = Oracle ESAR)
#   - Agent ba489249
#   - Agent 5fd879bb
#
# In Databricks, you need to configure equivalent ingestion:
#   Option A: Databricks Lakeflow Connect → Oracle/Snowflake connector
#   Option B: Azure Data Factory pipeline → ADLS Gen2 → Auto Loader
#   Option C: Direct Snowflake connector if data already in Snowflake
#
# The bronze layer Auto Loader definitions assume data lands in ADLS Gen2
# in Parquet format. Adjust the cloudFiles.format if using CSV/JSON.
#
# CRITICAL: The Magritte sync schedule and change-data-capture (CDC)
# behavior need to be replicated. The chg_change and acmr23 tables
# used incremental SCD1 in Foundry, suggesting the Magritte sync
# delivered change deltas, not full snapshots.


# ═══════════════════════════════════════════════════════════════════════════
# FLAG 9: COLUMN clean_columns MISMATCH — ap_detail.py
# Severity: LOW — Likely intentional
# ═══════════════════════════════════════════════════════════════════════════
#
# In ars_dbor_cm_r1_ap_detail.py, after clean_columns casts integer_columns
# to integer, the code IMMEDIATELY re-casts them to decimal:
#   for column in cast_to_integer_columns:
#       df = df.withColumn(column, df[column].cast("decimal"))
#
# This is preserved in the DLT conversion but seems redundant.
# The net effect is: STRING → INTEGER → DECIMAL(38,10).
# Possible reasons: Foundry's clean_columns might handle nulls differently
# when casting through integer first.


# ═══════════════════════════════════════════════════════════════════════════
# FLAG 10: TIMEZONE HANDLING
# Severity: MEDIUM — Verify against Foundry output
# ═══════════════════════════════════════════════════════════════════════════
#
# The Contour boards format dates using:
#   date_format(from_utc_timestamp("col", 'America/New_York'), 'yyyy-MM-dd HH:mm:ss a')
#
# This converts UTC timestamps to Eastern Time formatted strings.
# The change_closed_by_eastern_dt column is already in Eastern TZ
# (just gets date_format applied, no timezone conversion).
#
# In Databricks, the cluster timezone setting affects from_utc_timestamp.
# RECOMMENDATION: Set spark.sql.session.timeZone = "UTC" in the DLT
# pipeline configuration to ensure consistent behavior.


# ═══════════════════════════════════════════════════════════════════════════
# COMPLETE DEPENDENCY GRAPH (text representation)
# ═══════════════════════════════════════════════════════════════════════════
#
# ┌─────────────────────────────────────────────────────────────────────────┐
# │ BRONZE (Raw Ingestion)                                                  │
# │                                                                         │
# │  raw_chg_change_snowflake ─────────────────────────────┐                │
# │  raw_chg_task_snowflake ─────────────────────────┐     │                │
# │  raw_acmr14_affected_cllis ───────────────┐      │     │                │
# │  raw_acmr14_affected_techs_snowflake ──┐  │      │     │                │
# │  raw_acmr23_mobility_equipment_info ─┐ │  │      │     │                │
# │  raw_ap_signature ────────────────┐  │ │  │      │     │                │
# │  raw_ap_detail_snowflake ──────┐  │  │ │  │      │     │                │
# └────────────────────────────────┼──┼──┼─┼──┼──────┼─────┼────────────────┘
#                                  │  │  │ │  │      │     │
# ┌────────────────────────────────▼──▼──┼─┼──┼──────┼─────┼────────────────┐
# │ SILVER (Clean/Curated)               │ │  │      │     │                │
# │                                      │ │  │      │     │                │
# │  clean_ap_detail ◄───────────────────┘ │  │      │     │                │
# │  clean_ap_signature ◄─────────────────┘  │      │     │                │
# │       │                                   │      │     │                │
# │       ▼                                   │      │     │                │
# │  silver_ap_signature_enriched ◄───────────┘      │     │                │
# │  (ap_sig JOIN ap_dtl)                             │     │                │
# │                                                   │     │                │
# │  clean_acmr14_affected_techs ◄────────────────────┘     │                │
# │  clean_acmr14_affected_cllis ◄───────────────────────┐  │                │
# │  clean_acmr23_mobility_equipment_info ◄──────────┐   │  │                │
# │  clean_chg_task ◄────────────────────────────┐   │   │  │                │
# │  clean_chg_change ◄──────────────────────┐   │   │   │  │                │
# └──────────────────────────────────────────┼───┼───┼───┼──┼────────────────┘
#                                            │   │   │   │  │
# ┌──────────────────────────────────────────▼───▼───▼───▼──▼────────────────┐
# │ GOLD (Contour Analytics)                                                  │
# │                                                                           │
# │  mso_aotscm_open_tickets   ◄─ 5 LEFT JOINs + FILTER(open)              │
# │  mso_aotscm_closed_tickets ◄─ 5 LEFT JOINs + FILTER(closed, last yr)   │
# │  cmclosed_tasks             ◄─ 1 LEFT JOIN(task) + FILTER(closed, 365d) │
# │  cmclosed_notasks           ◄─ 4 LEFT JOINs(no task) + FILTER(closed)  │
# └───────────────────────────────────────────────────────────────────────────┘
#
# TOTAL: 7 bronze → 8 silver → 4 gold tables


# ═══════════════════════════════════════════════════════════════════════════
# RECONCILIATION CHECKLIST
# ═══════════════════════════════════════════════════════════════════════════
#
# After deploying the DLT pipeline, run reconciliation on these metrics:
#
# 1. Row counts per table (Foundry vs Databricks)
# 2. Distinct change_id counts per gold table
# 3. Column-level profile comparison (null %, unique %, min/max dates)
# 4. Status distribution (count per status value) in gold tables
# 5. Sample spot-checks on specific change_ids
#
# Use the foundry-profiler v2.1 tool (already built) for Foundry-side profiles,
# and the reconciliation framework for automated comparison.
