# Resource ID Scheme Change

**Date**: February 27, 2026  
**Status**: ✅ Implemented and tested

## Summary

Changed the auto-generated resource ID format from `mi-{uuid}` to `{platform}:{type}:{identifier}` for better platform awareness and filtering capabilities.

## Motivation

The original `mi-{uuid}` format had limitations:
- ❌ No indication of what the resource is
- ❌ No indication of where it lives
- ❌ Difficult to filter by platform or type
- ❌ Not self-documenting

## New Format

**Pattern**: `{platform}:{type}:{identifier}`

**Components**:
- **Platform**: `foundry`, `databricks`, `github`, `adls`, `auto` (default)
- **Type**: Lowercase resource type (`dataset`, `table`, `app`, etc.)
- **Identifier**: 12 hex characters from UUID4

**Examples**:
- `foundry:dataset:abc123def456` - Foundry dataset
- `databricks:table:a1b2c3d4e5f6` - Databricks table
- `databricks:app:7f8e9d0c1b2a` - Databricks app
- `github:code_repository:1a2b3c4d5e6f` - GitHub repository
- `adls:file:9f8e7d6c5b4a` - ADLS file
- `auto:dataset:3c4d5e6f7a8b` - Auto-generated (unknown platform)

## Benefits

1. **Self-documenting** - ID tells you what it is and where it lives
2. **Platform-aware** - Easy to filter: `WHERE resource_id LIKE 'foundry:%'`
3. **Type-aware** - Easy to filter: `WHERE resource_id LIKE '%:dataset:%'`
4. **Migration-friendly** - Track resources by source platform
5. **Backward compatible** - Can still use custom IDs like `dataset.orders.v1`

## Changes Made

### Code Changes

1. **`app/schemas/resource.py`**
   - Updated `generate_resource_id()` to accept `resource_type` and `platform` parameters
   - Added `platform` field to `ResourceCreate` schema
   - New signature: `generate_resource_id(resource_type: ResourceType, platform: str = "auto")`

2. **`app/services/store.py`**
   - Updated both `InMemoryStore.create_resource()` and `DeltaStore.create_resource()`
   - Pass `resource_type` and `platform` to `generate_resource_id()`
   - Platform defaults to `"auto"` if not provided

3. **`tests/test_resources_api.py`**
   - Updated `test_auto_generate_resource_id()` to expect new format
   - Added `test_auto_generate_with_platform()` to test platform-specific IDs

### Documentation Changes

1. **`README.md`**
   - Updated overview with new ID format examples
   - Updated API examples showing both auto and platform-specific IDs
   - Updated Python SDK examples

2. **`docs/AUTO_ID_GENERATION.md`**
   - Complete rewrite explaining new format
   - Added platform-specific examples
   - Added filtering best practices
   - Updated all code examples

3. **`docs/ID_SCHEME_CHANGE.md`** (this file)
   - Migration guide and rationale

## API Usage

### Without Platform (defaults to "auto")

```bash
curl -X POST http://localhost:8000/api/v1/resources \
  -H "Content-Type: application/json" \
  -d '{
    "resource_name": "My Dataset",
    "resource_type": "DATASET",
    "actor_type": "AGENT",
    "actor_name": "Cascade"
  }'

# Response: {"resource_id": "auto:dataset:a1b2c3d4e5f6", ...}
```

### With Platform

```bash
curl -X POST http://localhost:8000/api/v1/resources \
  -H "Content-Type: application/json" \
  -d '{
    "resource_name": "Foundry Dataset",
    "resource_type": "DATASET",
    "platform": "foundry",
    "actor_type": "AGENT",
    "actor_name": "Cascade"
  }'

# Response: {"resource_id": "foundry:dataset:abc123def456", ...}
```

### Custom ID (unchanged)

```bash
curl -X POST http://localhost:8000/api/v1/resources \
  -H "Content-Type: application/json" \
  -d '{
    "resource_id": "dataset.orders.v1",
    "resource_name": "Orders Dataset",
    "resource_type": "DATASET",
    "actor_type": "HUMAN",
    "actor_name": "Judy"
  }'

# Response: {"resource_id": "dataset.orders.v1", ...}
```

## Filtering Examples

### Find all Foundry resources
```sql
SELECT * FROM resources WHERE resource_id LIKE 'foundry:%'
```

### Find all datasets
```sql
SELECT * FROM resources WHERE resource_id LIKE '%:dataset:%'
```

### Find all Foundry datasets
```sql
SELECT * FROM resources WHERE resource_id LIKE 'foundry:dataset:%'
```

### Find all Databricks tables
```sql
SELECT * FROM resources WHERE resource_id LIKE 'databricks:table:%'
```

## Migration Impact

### Existing Data
- ✅ **No impact** - Existing resources with custom IDs remain unchanged
- ✅ **Backward compatible** - Old IDs like `dataset.orders.v1` still work

### New Resources
- Resources created **without** `resource_id` will use new format
- Resources created **with** explicit `resource_id` use that ID (unchanged)

### Client Code
- ✅ **No breaking changes** - API contract unchanged
- ✅ **Optional enhancement** - Clients can now specify `platform` field
- ⚠️ **ID format changed** - If clients parse auto-generated IDs, they need updates

## Testing

All 23 tests pass with the new scheme:
- ✅ `test_auto_generate_resource_id` - Validates `auto:dataset:{id}` format
- ✅ `test_auto_generate_with_platform` - Validates `foundry:dataset:{id}` format
- ✅ All other tests unchanged and passing

## Recommendations

1. **Specify platform when known** - Use `platform="foundry"` or `platform="databricks"` for better filtering
2. **Use explicit IDs for important resources** - Easier to reference and debug
3. **Use auto-IDs for transient resources** - Less management overhead
4. **Filter by platform** - Leverage the new format for queries and reports
5. **Document your strategy** - Team should know when to use auto vs. explicit IDs

## Platform Values

Recommended platform identifiers:
- `foundry` - Palantir Foundry
- `databricks` - Databricks (workspace, tables, apps)
- `github` - GitHub repositories
- `adls` - Azure Data Lake Storage
- `snowflake` - Snowflake
- `auto` - Unknown/unspecified platform (default)

## Future Enhancements

Potential improvements:
1. Add platform enum to enforce valid values
2. Add platform field to ResourceRead for easier filtering
3. Create helper functions for parsing platform/type from ID
4. Add platform-based statistics to diagnostics endpoint
