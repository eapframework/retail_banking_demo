from __future__ import annotations

import uuid
from datetime import datetime
from enum import Enum
from typing import Optional

from pydantic import BaseModel, Field


class ResourceStatus(str, Enum):
    PLANNED = "PLANNED"
    DISCOVERED = "DISCOVERED"
    EXTRACTED = "EXTRACTED"
    TRANSFORMED = "TRANSFORMED"
    DEPLOYED = "DEPLOYED"
    STAGED_FOR_DECOMMISSION = "STAGED_FOR_DECOMMISSION"


class ActorType(str, Enum):
    AGENT = "AGENT"
    HUMAN = "HUMAN"


class ResourceType(str, Enum):
    # M1.1: Datasets & Data Connections
    DATASET = "DATASET"
    DATA_CONNECTION = "DATA_CONNECTION"

    # M1.2: Pipeline Builder (low-code)
    PIPELINE_BUILDER = "PIPELINE_BUILDER"

    # M1.3: Code Repositories (pro-code)
    CODE_REPOSITORY = "CODE_REPOSITORY"

    # M1.4: Ontology
    ONTOLOGY = "ONTOLOGY"
    OBJECT_TYPE = "OBJECT_TYPE"
    ACTION = "ACTION"
    FUNCTION = "FUNCTION"

    # M1.5: Workshop (app config & widgets)
    WORKSHOP = "WORKSHOP"

    # M1.6: Contour / Fusion (analytics)
    CONTOUR = "CONTOUR"
    FUSION = "FUSION"
    CODE_WORKBOOK = "CODE_WORKBOOK"

    # M1.7: Build & Scheduling
    BUILD = "BUILD"
    SCHEDULE = "SCHEDULE"

    # M1.8: Data Lineage & Health (metadata)
    DATA_LINEAGE = "DATA_LINEAGE"
    DATA_HEALTH = "DATA_HEALTH"

    # M1.9: Vertex & Map (geo/graph)
    VERTEX = "VERTEX"
    MAP = "MAP"

    # M1.10: Model (ML artifacts)
    MODEL = "MODEL"

    # M1.11: Time Series Catalog
    TIME_SERIES = "TIME_SERIES"

    # M1.12: Projects & Files (security/governance)
    PROJECT = "PROJECT"
    FILE = "FILE"
    MARKING = "MARKING"

    # M1.13: AIP (deferred but included for completeness)
    AIP_AGENT = "AIP_AGENT"
    AIP_LOGIC = "AIP_LOGIC"
    AIP_EVAL = "AIP_EVAL"

    # Automate
    AUTOMATE = "AUTOMATE"
    # Branch
    BRANCH = "BRANCH"
    # Link Type
    LINK_TYPE = "LINK_TYPE"
    # Artifact
    ARTIFACT = "ARTIFACT"

    # Deployment & Infrastructure
    APP = "APP"
    TABLE = "TABLE"
    INFRASTRUCTURE = "INFRASTRUCTURE"


def generate_resource_id(resource_type: ResourceType, platform: str = "auto") -> str:
    """Generate a unique resource_id with platform and type awareness.
    
    Format: {platform}:{type}:{identifier}
    
    Args:
        resource_type: The type of resource (DATASET, TABLE, APP, etc.)
        platform: Platform identifier (foundry, databricks, github, adls, auto)
    
    Returns:
        Formatted resource_id like "databricks:dataset:a1b2c3d4e5f6"
    
    Examples:
        - "foundry:dataset:abc123def456"
        - "databricks:table:a1b2c3d4e5f6"
        - "auto:app:7f8e9d0c1b2a"
    """
    type_lower = resource_type.value.lower()
    identifier = uuid.uuid4().hex[:12]
    return f"{platform}:{type_lower}:{identifier}"


class ResourceCreate(BaseModel):
    resource_id: Optional[str] = Field(
        default=None,
        description="Unique primary key. Auto-generated as {platform}:{type}:{id} if not provided."
    )
    resource_name: str = Field(min_length=1, description="Human-readable name for the resource.")
    location: Optional[str] = Field(default=None, description="URL or file path where the resource lives.")
    resource_type: ResourceType
    resource_status: ResourceStatus = ResourceStatus.DISCOVERED
    platform: Optional[str] = Field(
        default=None,
        description="Platform identifier (foundry, databricks, github, adls). Used for auto-ID generation."
    )
    actor_type: ActorType
    actor_name: str = Field(min_length=1)


class ResourceUpdate(BaseModel):
    resource_name: Optional[str] = None
    location: Optional[str] = None
    resource_type: Optional[ResourceType] = None
    resource_status: Optional[ResourceStatus] = None
    actor_type: ActorType
    actor_name: str = Field(min_length=1)


class ResourceRead(BaseModel):
    resource_id: str
    resource_name: str
    location: Optional[str] = None
    resource_type: ResourceType
    resource_status: ResourceStatus
    last_by: str
    last_update_time: datetime
