from pyspark.sql import functions as F
from transforms.api import transform_df, Input, Output


@transform_df(
    Output("/Innovation Lab/Platform Reporting/data/datasets/ontology_objects"),
    source_df=Input("ri.foundry.main.dataset.647d10f8-ba88-4875-ae2c-48d88f8a7701"),
)
def compute(source_df):
    df = source_df
    df = df.select(
        "backing_dataset_rid",
        "`objectType.rid`",
    )
    return df
