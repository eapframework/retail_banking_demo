from pyspark.sql import functions as F
from transforms.api import transform_df, Input, Output

@transform_df(
    Output("ri.foundry.main.dataset.c79d68bb-61ee-43ff-82f2-130f525399d4"),
    source_df=Input("/Innovation Lab/Data Governance/AT&T Internal Shareable Resources/access_roles_pre_object"),
    aip_approved=Input("/Innovation Lab/Data Governance/AIP Access/aip_approved_group"),
)
def compute(source_df, aip_approved):
    # Filter aip_approved for principalType = 'GROUP'
    aip_approved_groups = aip_approved.filter(F.col("principalType") == "GROUP")
    # Perform a left join between source_df and aip_approved
    joined_df = source_df.join(
        aip_approved_groups,
        source_df.group_rid == aip_approved_groups.principalId,
        "left"
    )

    # Add the new columns
    result_df = joined_df.withColumn(
        "aip_access_status",
        F.when(F.col("principalId").isNotNull(), F.lit(True)).otherwise(F.lit(False))
    ).withColumn(
        "aip_expiration_time",
        F.col("expirationTime")
    ).withColumn(
        "aip_expiration_time_set",
        F.when(F.col("expirationTime").isNotNull(), F.lit(True)).otherwise(F.lit(False))
    )

    # Select all columns from source_df and add the new columns
    columns_to_select = source_df.columns + ["aip_access_status", "aip_expiration_time", "aip_expiration_time_set"]
    
    return result_df.select(*columns_to_select)