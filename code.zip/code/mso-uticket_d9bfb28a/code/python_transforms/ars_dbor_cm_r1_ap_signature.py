from transforms.api import transform, Input, Output,incremental,configure
from utility.column_clean import clean_columns, lowercase_columns, remove_prefix
from utility.incremental.update_insert import update_insert_core
from pyspark.sql import functions as F
from utility.incremental.timestamp_parsing import perform_timestamp_parsing


# @incremental(semantic_version=2)
@transform(
   out=Output("/Innovation Lab/[Source] Oracle ESAR/data/clean/ars_dbor_cm_r1.ap_signature"),
   updates=Input("/Innovation Lab/[Source] Oracle ESAR/data/raw/Prod/snowflake/esaars_dbor_cm_rviews.ap_signature"),
)
def my_compute_function(ctx, out, updates):
    updates = clean_columns(
        updates.dataframe(),
        timestamp_columns=cast_to_timestamp_from_long_columns,
        integer_columns=cast_to_integer_columns,
        datetime_format=datetime_format,
    )

    updates_df = perform_timestamp_parsing(updates)
    for column in float_columns:
        updates_df = updates_df.withColumn(column, updates_df[column].cast("float").alias(column))
    for column in cast_to_integer_columns:
        updates_df = updates_df.withColumn(column, updates_df[column].cast("integer").alias(column))
    # keys = ["signature_id", "seqno"]
    updates_df = lowercase_columns(updates_df)
    # update_insert_core(ctx, out, updates_df, primary_keys=keys, order_cols=["modified_date_sig"])
    out.write_dataframe(updates_df)


date_format = 'yyyy-MM-dd'
datetime_format = 'yyyy-MM-dd HH:mm:ss'
float_columns = [
    "CURRENT_APPROVAL_LEVEL",
    "CURRENT_APPROVAL_LEVEL_COUNT",
    "LAST_APP_CR_COUNT"
]
cast_to_integer_columns = [
    "SEQNO",
    "APPROVAL_STATUS",
    "SIGNATURE_METHOD",
    "INDEPENDENT",
    "IF_MULTIPLE_APPROVERS",
    "NUMBER_OF_GLOBAL_NOTIFICATIONS",
    "NUMBER_OF_STATE_NOTIFICATIONS",
    "LEVEL_SIG",
    "PREVIOUSSIGNATURENUMBER",
    "NEXTSIGNATURENUMBER",
    "XREFSIGNATUREID",
    "COMPLETED",
    "ORDER_X",
    "REACHED_DONE",
    "APPROVAL_LEVEL",
    "EXEMPT_FROM_REAPPROVAL"
]
cast_to_timestamp_from_long_columns = [
    "CREATE_DATE_SIG",
    "MODIFIED_DATE_SIG",
    "NEXT_ACTION_ESCALATION_TIME",
    "NEXT_GLOBAL_ESCALATION_TIME",
    "NEXT_STATE_ESCALATION_TIME",
    "MODIFIED"

]
