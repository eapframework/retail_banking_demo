from transforms.api import transform, Input, Output, incremental, configure
from utility.incremental.update_insert import update_insert_core
import logging
from pyspark.sql import functions as F
from transforms.api import transform, Input, Output, incremental
from utility.column_clean import clean_columns, lowercase_columns, remove_prefix
from ..utils import perform_timestamp_parsing
logger = logging.getLogger(__name__)


@incremental(semantic_version=2)
@transform(
   out=Output("/Innovation Lab/[Source] Oracle ESAR/data/clean/ticket_history"),
   updates=Input("/Innovation Lab/[Source] Oracle ESAR/data/raw/Prod/esaar_tmviews.ticket"),
   )
def my_compute_function(ctx, out, updates):
    #updates = updates.dataframe()
    updates_df = clean_columns(
        updates.dataframe(),
        strip_columns=strip_columns,
        integer_columns=cast_to_integer_columns,
        double_columns=cast_to_double_columns,
        decimal_columns=cast_to_decimal_columns,
        timestamp_columns=cast_to_timestamp_from_long_columns,
        datetime_columns=cast_to_timestamp_columns,
        datetime_format=datetime_format,
        date_columns=cast_to_date_columns,
        date_format=date_format,
        id_columns=cast_to_string_columns,
        integer_from_num_columns=cast_to_integer_from_decimal_columns
    )
    # updates_df = lowercase_columns(updates_df)
    colms = updates_df.columns
    updates_df = updates_df.select(
        *[F.col(colm).alias(colm.lower()) for colm in colms]
    )
    updates_df = perform_timestamp_parsing(updates_df)
    keys = ["ticket"]
    df = update_insert_core(ctx, out, updates_df, primary_keys=keys, order_cols=["load_ts"], return_df=True)
    out.write_dataframe(df)


date_format = 'yyyy-MM-dd'
datetime_format = 'yyyy-MM-dd HH:mm:ss'

cast_to_short_columns = []
cast_to_date_columns = []
cast_to_timestamp_columns = []
cast_to_timestamp_from_long_columns = [
    "LAST_MODIFIED_DATE",
    "REQUESTED_COMPLETION_DATE",
    "SERVICE_RESTORED_DATE",
    "CLIENT_REFER_DATE",
    "CLEARED_DEFERRED_TIME",
    "AUTO_FIX_DATE",
    "CLIENT_CONFIRMED_RESTORAL_DATE",
    "NEXT_CHECK_TIME",
    "TICKET_CLEARED_DATE",
    "PARENT_NEXT_CHECK_TIME",
    "NAD_COMPLETION_DATE",
    "MFAB_RESTORED_TIME",
    "SCHEDULE_LATER_DATE",
    "LOAD_TS"
]
cast_to_integer_columns = []
cast_to_double_columns = []
cast_to_string_columns = []
cast_to_integer_from_decimal_columns = []
strip_columns = []
cast_to_decimal_columns = [
    "STATE",
    "HAS_CHILD",
    "ASSET_PRIORITY",
    "CLIENT_SATISFIED",
    "SEVERITY",
    "LOCK_X",
    "WROTE_BLTM",
    "TOTAL",
    "OPEN",
    "LOST_OR_STOLEN",
    "OLD_SERVICE_DESC_TYPE",
    "SHOW",
    "OPEN_FROM_REFERRAL",
    "NOTIFY",
    "NOTIFY_METHOD",
    "SLA",
    "NOTIFY_ASSIGNEE",
    "TICKET_PRIORITY",
    "D_M_TIME_START",
    "TEMPINT",
    "CLIENT_PRIORITY_INT",
    "SS_ACTIVITY_TYPE",
    "MULTI_LINK",
    "QTAT_STATUS",
    "IPRE_SERVICE",
    "NXT1_INTERFACE",
    "AUTO_CLOSEABLE_FLAG",
    "DOWN_UP_DURATION",
    "MANAGED_MUX",
    "NAT",
    "CLIENT_HD_TYPE",
    "RESOL_REQUEST_TYPE",
    "RESOL_SVC_IMPACT_FLAG",
    "REPT_SVC_IMPACT_FLAG",
    "REPT_REQUEST_TYPE",
    "REPT_SVC_LINE_CD",
    "TROUBLE_REPT_CD",
    "RESOL_SVC_LINE_CD",
    "RESOL_ACTION_CD",
    "SVC_COMP_CD",
    "RESOL_ITEM_CD",
    "ROOT_CAUSE_CD",
    "SUB_ROOT_CAUSE_CD",
    "REF_TKT_UPDTED",
    "MULTICAST",
    "EVENT_MESSAGE_COUNT",
    "RESTORE_D_M_TIME_MIN",
    "RESTORE_N_A_TIME_MIN",
    "TOTAL_D_M_TIME_MIN",
    "TOTAL_N_A_TIME_MIN",
    "CURRENT_SETTING",
    "CLIENT_INTERNAL_ROUTING",
    "MONITOR_FOR_CLEARED",
    "TIME_ELAPSED_FOR_MONITORING",
    "COPY_TO_CLNT_COUNT",
    "CIRCUIT_STATUS",
    "AUTO_E_BOND",
    "COPY_NOTES_TO_LOG",
    "BIG_BOARD_FG",
    "NETWORK_CHRONIC",
    "CUSTOMER_CHRONIC",
    "ESCALATION",
    "EIGHT_HUNDRED_ACTIVE",
    "AUTO_UPDATEABLE",
    "BOUNCE_INDICATOR_FG",
    "HANDOVER_FG",
    "CALL_INDICATOR",
    "NETWORK_CHRONIC_COUNT",
    "REPAIR_DURATION",
    "RESTORE_DURATION",
    "TICKET_DURATION",
    "WORKLIST_CHRONIC",
    "CRITIQUE",
    "PROBABLE_CAUSE",
    "TICKET_ROLE",
    "SCRUB_INDICATOR",
    "TICKET_CLOSURE_MODE",
    "TMP_LEVEL",
    "PREV_STATE",
    "TMP_CRITIQUED",
    "MUST_CALL_CUSTOMER",
    "AUTO_FIXABLE",
    "IGNORE_DURATION",
    "AUTOFIX_DURATION_EXP",
    "CUSTOMER_CALLED",
    "PROBABLE_CAUSE_AUTO_CLOSE",
    "WORK_AROUND_TYPE",
    "ASSET_TAB_TYPE",
    "IMPACT_ELEMENT",
    "AGNS_MANAGED",
    "INTERNAL_ASSET_ID",
    "BACKUP",
    "ASSET_TYPE",
    "TICKET_TYPE",
    "TMP_IN",
    "CHRONIC",
    "ALARM_UPDATE_COUNT",
    "CHILD_TKT_COUNT",
    "BLTM_ASSETTYPE",
    "ASSET_TYPE_CD",
    "REPAIR_N_A_TIME_MIN",
    "REPAIR_D_M_TIME_MIN",
    "DISPATCH",
    "CLIENT_PERCEPTION",
    "HAS_PARENT",
    "TTRINDEX",
    "LAST_DIALOG_INDEX",
    "A_PVC_AFFECTED",
    "SERVICEID_TYPE",
    "ALL_LEGS_DOWN_INDICATOR",
    "COUNT_TOTAL_CHILDREN",
    "LOG_UPDATED",
    "DEFAULT_TICKET_CLEARED_DATE",
    "REPORTER_EMAIL_NOTIFY_FLAG",
    "CRITIQUE_DISSAT_CODE",
    "TOTAL_WORK_TIME",
    "DSP_EVENTMSG_RETURN_CODE",
    "COUNT_OPEN_CHILDREN",
    "COUNT_CLOSED_CHILDREN",
    "COUNT_NOT_CRITIQUED_CHILDREN",
    "CLOSED_BY_PARENT_FLAG",
    "ALERT_LEVEL_SELECTION",
    "TIME_TO_CREATE",
    "TIME_TO_REPAIR_UNADJ_REPORTED",
    "ADJTIMETOREPAIR",
    "TIME_TO_RESTORE_UNADJ_REPORTED",
    "ADJTIMETORESTORE",
    "TIME_TO_REPAIR_UNADJ_OPEN",
    "TIME_TO_REPAIR_OPEN",
    "TIME_TO_RESTORE_UNADJ_OPEN",
    "TIME_TO_RESTORE_OPEN",
    "TICKET_DURATION_OPEN",
    "TICKET_DURATION_REPORTED",
    "ESCALATED_REPORTED",
    "ESCALATED_OPEN",
    "NOTIFIED_REPORTED",
    "NOTIFIED_OPEN",
    "FIRST_CALL",
    "INIT_SEV",
    "CLOSE_W_CASE",
    "ITH_QUEUED_TO_ACTIVE",
    "NB_IPVPNINDICATOR",
    "ZBMPTICKETCHECK",
    "CONNECTION_TYPE",
    "LNPFLAG",
    "BMPCKTSVCCLS",
    "FA_FLAG",
    "A3G_INDICATOR",
    "TMP_SLA_VALUE",
    "COUNTDOWNCLOCKFLAG",
    "TMP_DEFERTIMESUM",
    "TMP_COMPLETIONDEADLINEINT",
    "AUTO_ESCALATION_INDICATOR",
    "CASE_TICKET__MAJOR_OUTAGE",
    "AUTO_STATE_CHANGE",
    "AUTO_DEFERRAL_END_DATE",
    "INBOUND_CALL_COUNT",
    "OUTBOUND_CALL_COUNT",
    "ASSET_FOUND_INDICATOR",
    "HAS_ATTACHMENT",
    "DSP_INBNDCALLCNT_FLAG",
    "DSP_OUTBNDCALLCNT_FLAG",
    "POWER_TO_CPE",
    "TROUBLE_REPORTED_LEVELS",
    "TROUBLE_REPORTED_LEVEL_3_CODE",
    "TROUBLE_REPORTED_LEVEL_4_CD",
    "TOTAL_DEFERRED_DELAYED_MAINT",
    "TOTAL_DEFERRED_NO_ACCESS",
    "REMOTE_WORKER_INDICATOR",
    "IP_PBX_INDICATOR",
    "PIID",
    "TMP_VOIPBTNCLK",
    "TOUCHED",
    "IVR_NOTIFICATION",
    "LRN",
    "PSID",
    "IS_BVOIP",
    "MFAB_FINAL",
    "MFAB_INITIAL",
    "MFAB_VERIFIED_TIME",
    "MFAB_RESPONSE",
    "MFAB_EST_CUST_AFFECTED",
    "MFAB_PORTS_AVAILABLE",
    "MFAB",
    "MFAB_MCB_STARTED_",
    "CLIENT_VENDOR_EBOND_UPDATES",
    "IS_RASGOT",
    "TMP_IS_RASGOTACTIVEORG",
    "TMP_IS_RASGOTSVCLINE",
    "BATCHPROCESSINGFLAG",
    "LOG_TYPE",
    "WF_COMBLOGLGTH",
    "WF_CUSTLOGLGTH",
    "WF_INTLOGLGTH",
    "WF_MFABLOGLGTH",
    "AVOS",
    "BUSIP_INDICATOR",
    "CORPORATE_POOL",
    "NATIVE_OR_PORTED",
    "VTN",
    "CHANGETICKETFLAG",
    "CLIENTVENDORROUTINGTIME",
    "DIAL_PLAN_ID",
    "INITBY",
    "REMOTE_WORKER_SITE_ID",
    "REMOTE_WORKER_W_NO_HUB_SITE_IN",
    "FAULTS_CAUSED_BY_CHANGE",
    "PERCENT_FUNCTIONALITY_IMPACTED",
    "EM_EBOND",
    "CUSTPROCEDURESLOGGED",
    "INTERNAL_ENG_EBOND_UPDTS",
    "NAA_MFAB_REQ",
    "NE_ROOT_CAUSE",
    "REPORTED_CUSTOMER_IMPACT",
    "START_X",
    "STRLENGTH",
    "TOTAL_IMPACTED_CUSTOMER",
    "MANUAL_TICKET_CHRONIC",
    "ENGAGEMENT_INDICATOR",
    "ODP_DATA",
    "CSI",
    "TSP",
    "ASSET_RESOLVED_IND",
    "DIAGNOSE_STATUS",
    "AOTS_INDICATOR",
    "MFAB_DURATION",
    "MFAB_TOTAL_TIME",
    "MULTIPLE_BUNDLES",
    "VERIFY_STATUS",
    "NETWORK_TICKET_PRIORITY",
    "NUM_CONCURCALLS",
    "LOAD_ID"
]
