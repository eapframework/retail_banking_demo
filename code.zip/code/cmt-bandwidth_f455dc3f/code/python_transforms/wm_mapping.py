'''
/*************************************************************************************************
**  Creator: Aneet Kapur, AK9540
**  Date Created: 09/30/2022
**  Description: Cleansing script to properly clean and scrub the datatypes into the CEWA > data.
**
**  Date Modified:
**      20220930 - AK9540, <INITIAL CLEANSE>.
**
*************************************************************************************************/
'''
from transforms.api import transform_df, Input, Output
from pyspark.sql.functions import col, from_unixtime


@transform_df(
    Output("ri.foundry.main.dataset.624d3ab8-9d48-41b0-be02-9d4a34305375"),
    i=Input("ri.foundry.main.dataset.cd5267c0-9cae-41f3-a7b0-49bde6d10269")
)
def compute(i):
    o = (
        i
        .select(
            col('ATTUID').alias('attuid'),
            col('CLLI').alias('clli'),
            col('CATEGORY_ID').alias('category_id'),
            col('FUNC_ID').alias('func_id'),
            col('UPDATE_BY').alias('update_by'),
            from_unixtime(i.UPDATE_DT / 1000, "yyyy-MM-dd HH:mm:ss").cast('timestamp').alias('update_dt'),
            from_unixtime(i.SET_TO_PRINCIPLE_DT / 1000, "yyyy-MM-dd HH:mm:ss").cast('timestamp').alias('set_to_principle_dt')
        )
    )

    return o