from transforms.api import transform, Input, Output, incremental
from utility.column_clean import clean_columns, lowercase_columns, remove_prefix
from pyspark.sql.functions import col


@transform(
    out=Output(
        "/Innovation Lab/[Source] Teradata EDW - ACCESS_VIEWS/data/prod_clean/vctn021_tirks_equip_asgnd_unit"
    ),
    df=Input(
        "/Innovation Lab/[Source] Teradata EDW - ACCESS_VIEWS/data/raw/snowflake/ACCESS_VIEWS.VCTN021_TIRKS_EQUIP_ASGND_UNIT"
    ),
)
def my_compute_function(df, out):
    df = clean_columns(
        df.dataframe(),
        date_format=date_format,
        date_columns=string_to_date,
        datetime_format=datetime_format,
        datetime_columns=long_unixtime_to_timestamp,
        timestamp_from_string_format=string_unixtime_format,
        timestamp_from_string_columns=string_unixtime_to_timestamp,
        timestamp_format=long_unixtime_format,
        timestamp_columns=long_unixtime_to_timestamp,
        integer_columns=string_to_integer_columns,
        double_columns=string_to_double_columns,
        decimal_columns=string_to_decimal_columns,
        id_columns=numeric_to_string_columns,
        integer_from_num_columns=decimal_to_integer,
        strip_columns=strip_string_columns,
    )
    # df = df.drop(*drop_columns)
    # df = remove_prefix(df, 'example_prefix')
    df = lowercase_columns(df)
    df = df.select(
        [
            col(c).cast("short") if c in columns_to_convert else col(c)
            for c in df.columns
        ]
    )
    out.write_dataframe(df)


drop_columns = []

date_format = "yyyy-MM-dd"
string_to_date = []
datetime_format = "yyyy-MM-dd HH:mm:ss"
string_to_timestamp = []
columns_to_convert = [
    "subdivision_qty",
    "pull_slice",
    "note_segment_key_nbr",
    "frame_segment_key_nbr",
]
string_unixtime_format = None
string_unixtime_to_timestamp = []
long_unixtime_format = None
long_unixtime_to_timestamp = []

string_to_integer_columns = []
string_to_double_columns = []
string_to_decimal_columns = []

numeric_to_string_columns = []
decimal_to_integer = []

strip_string_columns = [
    "SBC_COMPANY_CD",
    "SBC_SYSTEM_CD",
    "SBC_STATE_CD",
    "EQUIPMENT_LOCATION_CLLI_CD",
    "HUMAN_EQUIP_CATALOG_ITEM_CD",
    "RELAY_RACK_CD",
    "UNIT_NBR",
    "UNIT_STATUS_CD",
    "FAULTY_EQUIPMENT_CD",
    "ASSIGNMENT_STATUS_CD",
    "UNIT_INFORMATION_TXT",
    "SOFTWARE_FIRMWARE_CD",
    "IN_EFFECT_ORDER_NBR",
    "EQUIPMENT_OWNER_CD",
    "PLUGIN_EQUIPPED_CD",
    "PLUGIN_ORDER_CD",
    "PLUGIN_MODEL_NBR",
    "CARRIER_NETWORK_IDNTFCN_CD",
    "PRE_EQUIPPED_CD",
    "ELEC_DGTL_SGNL_CRSS_CNN_STS_CD",
    "EQUIPMENT_USE_CD",
    "SPECIAL_LEVEL_TREATMENT_CD",
    "VENDOR_RULE_IDENTIFICATION_CD",
    "VENDOR_RULE_DATA_CD",
    "RELATED_EQUIP_LOCATION_CLLI_CD",
]
