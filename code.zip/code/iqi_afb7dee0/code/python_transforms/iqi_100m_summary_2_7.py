from pyspark.sql import functions as F
from transforms.api import transform_df, Input, Output, configure
from ..utils import remove_oob_records, remove_offshoots


@configure(profile=['EXECUTOR_MEMORY_LARGE', 'NUM_EXECUTORS_16'])
@transform_df(
    Output("ri.foundry.main.dataset.7a482456-442b-4652-a78d-4461b14debcd"),
    source_df=Input("ri.foundry.main.dataset.061e5bf7-bfac-4344-bff2-335743f29b3b"),
    yyyymm=Input("ri.foundry.main.dataset.2a6acd1d-f0d4-4c73-bb70-42f1ff08ae55")
)
def clean_iqi_month_data(source_df, yyyymm, mth=1):
    '''
    Get latest month of IQI data
    '''
    latest = yyyymm.filter((F.col("rank") <= 7) & (F.col("rank") >= 2)).select("yyyymm").rdd.flatMap(lambda x: x).collect()
    df = source_df.filter(F.col("yyyymm").isin(latest))
    df = remove_oob_records(df)
    df = remove_offshoots(df)
    return df
