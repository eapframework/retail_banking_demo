# Auto-ID Generation in Magical Index

## Overview

Magical Index supports **automatic resource ID generation** with platform and type awareness. The generated IDs follow the format `{platform}:{type}:{identifier}`, making them self-documenting and easy to filter.

This is useful when:
- Agents discover resources without stable identifiers
- You want the system to manage IDs for you
- You need platform-aware IDs for filtering and querying
- You're creating temporary or intermediate resources

## How It Works

### 1. Schema Definition

In `app/schemas/resource.py`:

```python
def generate_resource_id(resource_type: ResourceType, platform: str = "auto") -> str:
    """Generate a unique resource_id with platform and type awareness.
    
    Format: {platform}:{type}:{identifier}
    
    Args:
        resource_type: The type of resource (DATASET, TABLE, APP, etc.)
        platform: Platform identifier (foundry, databricks, github, adls, auto)
    
    Returns:
        Formatted resource_id like "databricks:dataset:a1b2c3d4e5f6"
    """
    type_lower = resource_type.value.lower()
    identifier = uuid.uuid4().hex[:12]
    return f"{platform}:{type_lower}:{identifier}"

class ResourceCreate(BaseModel):
    resource_id: Optional[str] = Field(
        default=None, 
        description="Unique primary key. Auto-generated as {platform}:{type}:{id} if not provided."
    )
    resource_name: str
    platform: Optional[str] = Field(
        default=None,
        description="Platform identifier (foundry, databricks, github, adls). Used for auto-ID generation."
    )
    # ... other fields
```

The `resource_id` field is **optional** in `ResourceCreate`. If you omit it, the system generates one.

### 2. Store Implementation

In `app/services/store.py`:

```python
def create_resource(self, data: ResourceCreate) -> ResourceRead:
    """Create a new resource. Auto-generates resource_id if not provided."""
    rid = data.resource_id or generate_resource_id(
        resource_type=data.resource_type,
        platform=data.platform or "auto"
    )
    
    if rid in self._resources:
        raise ValueError(f"Resource already exists: {rid}")
    
    # Create resource with generated or provided ID
    resource = ResourceRead(
        resource_id=rid,
        resource_name=data.resource_name,
        # ... other fields
    )
    
    self._resources[rid] = resource
    return resource
```

**Key logic**: `rid = data.resource_id or generate_resource_id(resource_type, platform)`
- If `resource_id` is provided → use it
- If `resource_id` is `None` → generate `{platform}:{type}:{12-char-hex}`
- Platform defaults to `"auto"` if not specified

### 3. API Response

The generated ID is **immediately returned** to the caller in the response:

```json
POST /api/v1/resources
{
  "resource_name": "My Dataset",
  "resource_type": "DATASET",
  "actor_type": "AGENT",
  "actor_name": "Cascade"
}

Response (201 Created):
{
  "resource_id": "auto:dataset:a1b2c3d4e5f6",
  "resource_name": "My Dataset",
  "location": null,
  "resource_type": "DATASET",
  "resource_status": "DISCOVERED",
  "last_by": "AGENT:Cascade",
  "last_update_time": "2026-02-27T21:30:00.123456"
}
```

## ID Format

**Pattern**: `{platform}:{type}:{identifier}`

- **Platform**: Platform identifier (foundry, databricks, github, adls, auto)
- **Type**: Lowercase resource type (dataset, table, app, etc.)
- **Identifier**: 12 hexadecimal characters from UUID4
- **Examples**:
  - `foundry:dataset:abc123def456` (Foundry dataset)
  - `databricks:table:a1b2c3d4e5f6` (Databricks table)
  - `databricks:app:7f8e9d0c1b2a` (Databricks app)
  - `github:code_repository:1a2b3c4d5e6f` (GitHub repo)
  - `auto:dataset:9f8e7d6c5b4a` (auto-generated, unknown platform)
- **Collision probability**: ~1 in 16^12 (281 trillion) — negligible for practical use

**Benefits**:
1. **Self-documenting** - ID tells you what it is and where it lives
2. **Platform-aware** - Easy to filter by platform (e.g., all Foundry resources)
3. **Type-aware** - Easy to filter by resource type
4. **Backward compatible** - Can still use custom IDs like `dataset.orders.v1`

## Usage Examples

### Python SDK

```python
from magical_index_client import MagicalIndexClient

mi = MagicalIndexClient("https://magical-index.example.com")

# Option 1: Let the system generate the ID (auto platform)
resource = mi.create_resource(
    resource_name="Discovered Dataset",
    resource_type="DATASET",
    actor_name="Discovery-Agent"
)
print(f"Generated ID: {resource.resource_id}")  # e.g., "auto:dataset:7f8e9d0c1b2a"

# Option 1b: Specify platform for auto-generated ID
resource = mi.create_resource(
    resource_name="Foundry Dataset",
    resource_type="DATASET",
    platform="foundry",
    actor_name="Discovery-Agent"
)
print(f"Generated ID: {resource.resource_id}")  # e.g., "foundry:dataset:abc123def456"

# Option 2: Provide your own ID
resource = mi.create_resource(
    resource_id="dataset.orders.v1",
    resource_name="Orders Dataset",
    resource_type="DATASET",
    actor_name="Judy"
)
print(f"Your ID: {resource.resource_id}")  # "dataset.orders.v1"
```

### curl

```bash
# Auto-generated ID (auto platform)
curl -X POST http://localhost:8000/api/v1/resources \
  -H "Content-Type: application/json" \
  -d '{
    "resource_name": "Auto-ID Resource",
    "resource_type": "DATASET",
    "actor_type": "AGENT",
    "actor_name": "Cascade"
  }'

# Response includes generated ID:
# {"resource_id": "auto:dataset:3c4d5e6f7a8b", ...}

# Auto-generated ID with platform
curl -X POST http://localhost:8000/api/v1/resources \
  -H "Content-Type: application/json" \
  -d '{
    "resource_name": "Databricks Table",
    "resource_type": "TABLE",
    "platform": "databricks",
    "actor_type": "AGENT",
    "actor_name": "Cascade"
  }'

# Response includes generated ID:
# {"resource_id": "databricks:table:5e6f7a8b9c0d", ...}

# Explicit ID
curl -X POST http://localhost:8000/api/v1/resources \
  -H "Content-Type: application/json" \
  -d '{
    "resource_id": "my.custom.id",
    "resource_name": "Custom ID Resource",
    "resource_type": "DATASET",
    "actor_type": "HUMAN",
    "actor_name": "Judy"
  }'
```

## When to Use Auto-Generated IDs

### ✅ Good Use Cases

1. **Agent-discovered resources** without natural keys
   ```python
   # Agent finds a file in ADLS
   resource = mi.create_resource(
       resource_name=f"File: {file_path}",
       location=file_path,
       resource_type="FILE",
       platform="adls",
       actor_name="Discovery-Agent"
   )
   # System generates: adls:file:1a2b3c4d5e6f
   ```

2. **Temporary/intermediate resources**
   ```python
   # Create a temporary staging resource
   staging = mi.create_resource(
       resource_name="Staging Area",
       resource_type="DATASET",
       platform="databricks",
       actor_name="ETL-Agent"
   )
   # System generates: databricks:dataset:2b3c4d5e6f7a
   ```

3. **Bulk imports** where you don't want to manage ID generation
   ```python
   for item in discovered_items:
       resource = mi.create_resource(
           resource_name=item.name,
           resource_type=item.type,
           platform=item.platform,  # e.g., "foundry", "databricks"
           actor_name="Bulk-Import-Agent"
       )
       # Store mapping: item.source_id -> resource.resource_id
       # Generated IDs like: foundry:dataset:abc123, databricks:table:def456
   ```

### ❌ When to Provide Your Own ID

1. **Resources with natural keys**
   ```python
   # Foundry dataset RID
   resource = mi.create_resource(
       resource_id="ri.foundry.main.dataset.abc123",
       resource_name="Orders Dataset",
       resource_type="DATASET",
       actor_name="Migration-Agent"
   )
   ```

2. **Human-readable identifiers**
   ```python
   # Semantic naming
   resource = mi.create_resource(
       resource_id="dataset.orders.v1",
       resource_name="Orders Dataset v1",
       resource_type="DATASET",
       actor_name="Judy"
   )
   ```

3. **External system references**
   ```python
   # Databricks table FQN
   resource = mi.create_resource(
       resource_id="cdo_catalog.magical_index.gandalf-magical-index-rid",
       resource_name="Resources Table",
       resource_type="TABLE",
       actor_name="Deployment-Agent"
   )
   ```

## Idempotency Considerations

**Auto-generated IDs are NOT idempotent** — each call creates a new ID:

```python
# Call 1
r1 = mi.create_resource(resource_name="Dataset A", resource_type="DATASET", actor_name="Agent")
# r1.resource_id = "auto:dataset:111111111111"

# Call 2 (same payload)
r2 = mi.create_resource(resource_name="Dataset A", resource_type="DATASET", actor_name="Agent")
# r2.resource_id = "auto:dataset:222222222222"  ← DIFFERENT ID!
```

**For idempotency**, provide your own ID:

```python
# Call 1
r1 = mi.create_resource(
    resource_id="dataset.A",
    resource_name="Dataset A",
    resource_type="DATASET",
    actor_name="Agent"
)

# Call 2 (same ID) → 409 Conflict
try:
    r2 = mi.create_resource(
        resource_id="dataset.A",
        resource_name="Dataset A",
        resource_type="DATASET",
        actor_name="Agent"
    )
except HTTPException as e:
    print(e.status_code)  # 409
```

## Activity Log Tracking

Every resource creation is logged, including auto-generated IDs:

```python
# Create resource with auto-ID
resource = mi.create_resource(
    resource_name="Auto Resource",
    resource_type="DATASET",
    actor_name="Agent"
)

# Query activity logs
logs = mi.list_logs(resource_id=resource.resource_id)
# [
#   {
#     "log_id": "log-abc123def456",
#     "resource_id": "foundry:dataset:7f8e9d0c1b2a",
#     "action": "RESOURCE_CREATED",
#     "actor_type": "AGENT",
#     "actor_name": "Agent",
#     "details": "resource_name=Auto Resource, resource_type=DATASET",
#     "timestamp": "2026-02-27T21:30:00.123456"
#   }
# ]
```

## Database Storage

Both `InMemoryStore` and `DeltaStore` handle auto-generated IDs identically:

**InMemoryStore** (tests):
```python
rid = data.resource_id or generate_resource_id(
    resource_type=data.resource_type,
    platform=data.platform or "auto"
)
self._resources[rid] = ResourceRead(resource_id=rid, ...)
```

**DeltaStore** (production):
```python
rid = data.resource_id or generate_resource_id(
    resource_type=data.resource_type,
    platform=data.platform or "auto"
)
cursor.execute(
    f"INSERT INTO {self._rid_fqn} (resource_id, ...) VALUES (?, ...)",
    (rid, ...)
)
```

The Unity Catalog table stores the generated ID just like any other ID.

## Best Practices

1. **Store the returned ID** — the caller must save the generated ID for future reference
2. **Specify platform when known** — use `platform="foundry"` or `platform="databricks"` for better filtering
3. **Use explicit IDs for important resources** — easier to debug and reference
4. **Use auto-IDs for transient resources** — less management overhead
5. **Document your ID strategy** — team should know when to use auto vs. explicit IDs
6. **Consider external mappings** — if migrating from another system, maintain a mapping table
7. **Filter by platform** — query like `WHERE resource_id LIKE 'foundry:%'` to find all Foundry resources

## Testing

The test suite verifies auto-ID generation:

```python
def test_auto_generate_resource_id(client):
    """resource_id should be auto-generated when not provided."""
    payload = {
        "resource_name": "Auto-ID Resource",
        "resource_type": "DATASET",
        "actor_type": "AGENT",
        "actor_name": "Cascade",
    }
    r = client.post("/api/v1/resources/", json=payload)
    assert r.status_code == 201
    body = r.json()
    # Format: auto:dataset:{12-hex-chars}
    assert body["resource_id"].startswith("auto:dataset:")
    parts = body["resource_id"].split(":")
    assert len(parts) == 3
    assert parts[0] == "auto"
    assert parts[1] == "dataset"
    assert len(parts[2]) == 12
```

See `tests/test_resources_api.py` for full test coverage.
