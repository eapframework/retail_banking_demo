from __future__ import annotations
from typing import List, Optional

from pydantic import BaseModel, Field

from app.schemas.resource import ActorType


class PrepareExtractionRequest(BaseModel):
    resource_ids: List[str] = Field(..., min_length=1)
    actor_type: ActorType
    actor_name: str


class ExtractionTask(BaseModel):
    source_resource_id: str
    target_resource_id: str
    target_location: str


class ExtractionInfo(BaseModel):
    source_resource_id: str
    target_resource_id: str
    message: str


class PrepareExtractionResponse(BaseModel):
    tasks: List[ExtractionTask] = Field(default_factory=list)
    pending_location_count: int = Field(
        default=0,
        description="Number of resources without a target location assigned, still waiting for their downstream GitHub resource's location to be updated.",
    )
