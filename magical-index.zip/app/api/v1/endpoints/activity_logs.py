from __future__ import annotations

from typing import List, Optional

from fastapi import APIRouter, Depends, Query

from app.schemas.activity_log import ActivityLogRead
from app.schemas.pagination import PaginatedResponse, PaginationParams
from app.services.store import store


router = APIRouter()


@router.get("/", response_model=PaginatedResponse[ActivityLogRead])
def list_logs(
    resource_id: Optional[str] = Query(None),
    pagination: PaginationParams = Depends(),
) -> PaginatedResponse[ActivityLogRead]:
    """List activity logs with pagination, optionally filtered by ``resource_id``.

    Logs are returned in reverse chronological order (newest first).
    Supports pagination via offset and limit query parameters.
    """
    items, total = store.list_logs(
        resource_id=resource_id,
        offset=pagination.offset,
        limit=pagination.limit,
    )
    return PaginatedResponse.create(
        items=items,
        total=total,
        offset=pagination.offset,
        limit=pagination.limit,
    )
