from transforms.api import transform, Input, Output, Check
from transforms import expectations as E
from quantum_api_ingest.foundry.magritte import MagritteClient
from quantum_api_ingest.foundry.get_config import get_config
from pyspark.sql.types import StringType, StructField, StructType
import pyspark.sql.functions as F


schema = StructType([
    StructField('rid', StringType()),
    StructField('sourceName', StringType()),
    StructField('sourceType', StringType()),
    StructField('sourceConfig', StringType())
])


@transform(
    output=Output(
        "ri.foundry.main.dataset.f69ab92a-fec9-4324-a3a3-ef45517d914a", sever_permissions=True,
        checks=[
            Check(E.primary_key("rid"), "RID should be unique", "FAIL")
        ]
    ),
    config=Input("ri.foundry.main.dataset.b5cb343e-1109-4401-b3fb-5137c32cb781"),
    compass_resources=Input("ri.foundry.main.dataset.abafe87f-53af-4252-804c-9bbd24e010fa"),
    multipass=Input("ri.foundry.main.dataset.dc71055c-0725-45ca-935a-655cf3cf5b41")
)
def compute(ctx, output, config, compass_resources, multipass):
    compass_resources = compass_resources.dataframe()
    mp_renamed = (
        multipass
        .dataframe()
        .select(
            F.col("user_id").alias("last_modified_by_user"),
            F.col("user_id").alias("created_by_user"),

            F.col("user_name").alias("last_modified_by_user_name"),
            F.col("user_name").alias("created_by_user_name")
        )
    )

    compass_resources = (
        compass_resources
        .join(
            mp_renamed.select("last_modified_by_user", "last_modified_by_user_name"),
            ["last_modified_by_user"],
            "left"
        )
        .join(
            mp_renamed.select("created_by_user", "created_by_user_name"),
            ["created_by_user"],
            "left"
        )
    )

    magritte_coordinator = MagritteClient(get_config(config))
    result = []

    sources = magritte_coordinator.get_sources()

    for source_id, source_attributes in sources.items():
        source_config = magritte_coordinator.get_source_configuration(source_id)
        result.append({
            'rid': str(source_id),
            'sourceName': str(source_attributes['name']),
            'sourceType': str(source_attributes['type']),
            'sourceConfig': str(source_config['source'])
        })

    output.write_dataframe(
        ctx
        .spark_session
        .createDataFrame(result, schema)
        .join(
            # this information can be used to chase down owners of sources who haven't
            # shared passwords with CDO during agent rotation
            compass_resources.select(
                "rid",
                "created_by_user",
                "last_modified_by_user",
                "created_by_user_name",
                "last_modified_by_user_name",
                "created_time",
                "last_modified_time"
            ),
            "rid",
            "left"
        )
    )
