from transforms.api import transform, Input, Output, incremental
from utility.column_clean import clean_columns, lowercase_columns, remove_prefix


@transform(
    out=Output("/Innovation Lab/[Source] Teradata EDW - ASI_VIEWS/data/clean/vcan055_tirks_ckt_general_detl"),
    df=Input("/Innovation Lab/[Source] Teradata EDW - ASI_VIEWS/data/raw/snowflake/vcan055_tirks_ckt_general_detl"),
)
def my_compute_function(df, out):
    df = clean_columns(
        df.dataframe(),
        date_format=date_format, 
        date_columns=string_to_date,
        datetime_format=datetime_format, 
        datetime_columns=long_unixtime_to_timestamp,
        timestamp_from_string_format=string_unixtime_format,
        timestamp_from_string_columns=string_unixtime_to_timestamp,
        timestamp_format=long_unixtime_format, 
        timestamp_columns=long_unixtime_to_timestamp,
        integer_columns=string_to_integer_columns,
        double_columns=string_to_double_columns,
        decimal_columns=string_to_decimal_columns,
        id_columns=numeric_to_string_columns,
        integer_from_num_columns=decimal_to_integer,
        strip_columns=strip_string_columns,
    )
    df = lowercase_columns(df)
    df = df.drop(*drop_columns)
    # df = remove_prefix(df, 'example_prefix')
    out.write_dataframe(df)


drop_columns = ["dw_load_dt", "dw_load_tm", "dw_load_user", "dw_updt_ts", "dw_updt_user"]

date_format = 'yyyy-MM-dd'
string_to_date = []
datetime_format = 'yyyy-MM-dd HH:mm:ss'
string_to_timestamp = []

string_unixtime_format = None
string_unixtime_to_timestamp = []
long_unixtime_format = None
long_unixtime_to_timestamp = []

string_to_integer_columns = []
string_to_double_columns = []
string_to_decimal_columns = []

numeric_to_string_columns = []
decimal_to_integer = []

strip_string_columns = [
    "SBC_COMPANY_CD",
    "SBC_SYSTEM_CD",
    "CIRCUIT_ACCESS_CD",
    "CIRCUIT_LAYOUT_ORDER_NBR",
    "SBC_STATE_CD",
    "ADMINISTRATIVE_AREA_CD",
    "RELATED_CIRCUIT_ID",
    "SUBSCBR_LINE_LOC_A_CLLI_CD",
    "SUBSCBR_LINE_LOC_A_EQUIP_CD",
    "SUBSCBR_LINE_LOC_Z_CLLI_CD",
    "SUBSCBR_LINE_LOC_Z_EQUIP_CD",
    "PBX_LOCATION_A_CLLI_CD",
    "PBX_LOCATION_A_EQUIPMENT_CD",
    "PBX_LOCATION_Z_CLLI_CD",
    "PBX_LOCATION_Z_EQUIPMENT_CD",
]
