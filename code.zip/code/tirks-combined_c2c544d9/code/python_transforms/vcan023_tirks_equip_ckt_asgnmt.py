from transforms.api import transform, Input, Output, incremental
from utility.column_clean import clean_columns, lowercase_columns, remove_prefix


@transform(
    out=Output("/Innovation Lab/[Source] Teradata EDW - ASI_VIEWS/data/clean/vcan023_tirks_equip_ckt_asgnmt"),
    df=Input("/Innovation Lab/[Source] Teradata EDW - ASI_VIEWS/data/raw/snowflake/VCAN023_TIRKS_EQUIP_CKT_ASGNMT"),
)
def my_compute_function(df, out):
    df = clean_columns(
        df.dataframe(),
        date_format=date_format, 
        date_columns=string_to_date,
        datetime_format=datetime_format, 
        datetime_columns=long_unixtime_to_timestamp,
        timestamp_from_string_format=string_unixtime_format,
        timestamp_from_string_columns=string_unixtime_to_timestamp,
        timestamp_format=long_unixtime_format, 
        timestamp_columns=long_unixtime_to_timestamp,
        integer_columns=string_to_integer_columns,
        double_columns=string_to_double_columns,
        decimal_columns=string_to_decimal_columns,
        id_columns=numeric_to_string_columns,
        integer_from_num_columns=decimal_to_integer,
        strip_columns=strip_string_columns,
    )
    # df = remove_prefix(df, 'example_prefix')
    df = df.withColumn("CIRCUIT_ASSIGNMENT_SEQ_NBR", df["CIRCUIT_ASSIGNMENT_SEQ_NBR"].cast("short"))
    df = lowercase_columns(df)
    df = df.drop(*drop_columns)
    out.write_dataframe(df)


drop_columns = ["dw_load_dt", "dw_load_tm", "dw_load_user", "dw_updt_ts", "dw_updt_user"]

date_format = 'yyyy-MM-dd'
string_to_date = []
datetime_format = 'yyyy-MM-dd HH:mm:ss'
string_to_timestamp = []

string_unixtime_format = None
string_unixtime_to_timestamp = []
long_unixtime_format = None
long_unixtime_to_timestamp = []

string_to_integer_columns = []
string_to_double_columns = []
string_to_decimal_columns = []

numeric_to_string_columns = []
decimal_to_integer = []

strip_string_columns = [
    "SBC_COMPANY_CD",
    "SBC_SYSTEM_CD",
    "SBC_STATE_CD",
    "EQUIPMENT_LOCATION_CLLI_CD",
    "HUMAN_EQUIP_CATALOG_ITEM_CD",
    "RELAY_RACK_CD",
    "UNIT_NBR",
    "SUBDIVISION_CD",
    "PRIMARY_ALTERNATE_ASGNMT_CD",
    "CIRCUIT_ASSIGNMENT_VIEW_CD",
    "CIRCUIT_ASSIGNMENT_ACTIVITY_CD",
    "CIRCUIT_LAYOUT_ORDER_NBR",
    "EQUIP_CKT_IDNTFCN_FORMAT_CD",
    "EQUIP_CKT_IDENTIFICATION_CD",
    "DETL_RGLTY_FACILITY_CLASS_CD",
    "ASSIGNMENT_MISUSE_CD",
    "EQUIPMENT_FUNCTION_CD",
    "CIRCUIT_ROUTING_DIVERSITY_CD",
    "CIRCUIT_ACCESS_CD",
    "CIRCUIT_LOCATION_A_CLLI_CD",
    "CIRCUIT_LOCATION_Z_CLLI_CD",
    "CIRCUIT_GROUP_ACCESS_CD",
    "LOC_A_DETL_RGLTY_STUDY_AREA_CD",
    "LOC_Z_DETL_RGLTY_STUDY_AREA_CD",
    "CKT_LYT_ORD_ACTIVITY_STATUS_CD",
    "SERVICE_RESUMPTION_PRIORITY_CD",
]