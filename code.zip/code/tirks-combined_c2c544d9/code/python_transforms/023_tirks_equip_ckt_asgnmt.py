from transforms.api import transform_df, Input, Output, incremental
import pyspark.sql.functions as F


@transform_df(
    Output("/Innovation Lab/[ETL] Tirks Combined/data/023_tirks_equip_ckt_asgnmt"),
    asi=Input("ri.foundry.main.dataset.1dca801a-764d-4c1b-bc11-8fdedc37f028"),
    telco=Input("/Innovation Lab/[Source] Teradata EDW - ACCESS_VIEWS/data/prod_clean/vctn023_tirks_equip_ckt_asgnmt"),
)
def my_compute_function(telco, asi):
    telco = telco.withColumn("source", F.lit('telco'))
    asi = asi.withColumn("source", F.lit('asi'))
    df = telco.unionByName(asi)
    return df
