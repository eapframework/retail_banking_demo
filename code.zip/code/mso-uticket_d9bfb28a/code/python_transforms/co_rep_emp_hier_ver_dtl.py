from transforms.api import transform, Input, Output, configure, incremental
from pyspark.sql import functions as F, types as T
from myproject.datasets.utils import uid_to_num, uid_dt_to_num


@configure(profile='rubix-sixteen-executors')
@incremental(snapshot_inputs=["tbl_hier_hist_daily", "tbl_cenet_full", "initial_load"])
@transform(
    out=Output("ri.foundry.main.dataset.c80d3388-55a0-402e-b859-2db07bf92415"),
    tbl_hier_hist_daily=Input("ri.foundry.main.dataset.01a9b2a5-9f99-4577-bdd0-fd77bdb3a138"),
    initial_load=Input("ri.foundry.main.dataset.ae5315b0-7f88-4fc2-88b0-35233744421f"),
    tbl_cenet_full=Input("ri.foundry.main.dataset.293d7d73-8e66-4221-89d6-a05b61aa34b6")
)
def my_compute_function(ctx, tbl_hier_hist_daily, initial_load, tbl_cenet_full, out):

    # set flag to false when doing initial load and set flag to true when doing incremental process
    # Make sure that the initial load aka co_rep_hier_ver_dtl_create is updated before running the initial load process in this script
    # as co_rep_hier_ver_dtl is the initial_load that builds the hierarchy in the first place
    
    flag = True

    initial_load = initial_load.dataframe(mode='current')

    # run_date = F.lit('2025-02-02') #F.current_date() # 1) this is only for reruns ** 2025-02-02 pulls start dates = 2025-02-01 

    if flag:
        tbl_cenet_full = tbl_cenet_full.dataframe(mode='current').alias("cc")
        tbl_cenet_full = tbl_cenet_full.filter(tbl_cenet_full.active == 'Y')
        tbl_hier_hist_daily = tbl_hier_hist_daily.dataframe(mode='current')
        # initialize both udf's and apply them to two new columns: uid_based_key and uid_dt_based_key
        spark = ctx.spark_session
        my_udf = F.udf(lambda z: uid_to_num(z), T.StringType())
        _ = spark.udf.register("my_udf", my_udf)

        uid_dt_based_udf = F.udf(lambda arr: uid_dt_to_num(arr), T.StringType())
        _ = spark.udf.register("uid_dt_based_udf", uid_dt_based_udf)
        curr_schema = T.StructType([
                                    T.StructField('sbc_uid', T.StringType(), True),
                                    T.StructField('rc', T.StringType(), True),
                                    T.StructField('status',  T.StringType(), True),
                                    T.StructField('start_date',  T.TimestampType(), True),
                                    T.StructField('end_date',  T.TimestampType(), True),
                                    T.StructField('position',  T.IntegerType(), True),
                                    T.StructField('mgmt_level',  T.IntegerType(), True),
                                    T.StructField('first_name',  T.StringType(), True),
                                    T.StructField('last_name',  T.StringType(), True),
                                    T.StructField('unofficial_first_name',  T.StringType(), True),
                                    T.StructField('middle_name',  T.StringType(), True),
                                    T.StructField('l0_sbc_uid',  T.StringType(), True),
                                    T.StructField('l1_sbc_uid',  T.StringType(), True),
                                    T.StructField('l2_sbc_uid', T.StringType(), True),
                                    T.StructField('l3_sbc_uid',  T.StringType(), True),
                                    T.StructField('l4_sbc_uid',  T.StringType(), True),
                                    T.StructField('l5_sbc_uid',  T.StringType(), True),
                                    T.StructField('l6_sbc_uid',  T.StringType(), True),
                                    T.StructField('l7_sbc_uid',  T.StringType(), True),
                                    T.StructField('l8_sbc_uid',  T.StringType(), True),
                                    T.StructField('l9_sbc_uid',  T.StringType(), True),
                                    T.StructField('l10_sbc_uid',  T.StringType(), True),
                                    T.StructField('l11_sbc_uid',  T.StringType(), True),
                                    T.StructField('l12_sbc_uid',  T.StringType(), True),
                                    T.StructField('l13_sbc_uid',  T.StringType(), True),
                                    T.StructField('l14_sbc_uid',  T.StringType(), True),
                                    T.StructField('l15_sbc_uid',  T.StringType(), True),
                                    T.StructField('l0_name',  T.StringType(), True),
                                    T.StructField('l0_mgt_level_indicator',  T.StringType(), True),
                                    T.StructField('l0_emp_status_code',  T.StringType(), True),
                                    T.StructField('l0_active',  T.StringType(), True),
                                    T.StructField('l0_job_description',  T.StringType(), True),
                                    T.StructField('l1_name',  T.StringType(), True),
                                    T.StructField('l1_mgt_level_indicator',  T.StringType(), True),
                                    T.StructField('l1_emp_status_code',  T.StringType(), True),
                                    T.StructField('l1_active',  T.StringType(), True),
                                    T.StructField('l1_job_description',  T.StringType(), True),
                                    T.StructField('l2_name',  T.StringType(), True),
                                    T.StructField('l2_mgt_level_indicator',  T.StringType(), True),
                                    T.StructField('l2_emp_status_code',  T.StringType(), True),
                                    T.StructField('l2_active',  T.StringType(), True),
                                    T.StructField('l2_job_description',  T.StringType(), True),
                                    T.StructField('l3_name',  T.StringType(), True),
                                    T.StructField('l3_mgt_level_indicator',  T.StringType(), True),
                                    T.StructField('l3_emp_status_code',  T.StringType(), True),
                                    T.StructField('l3_active',  T.StringType(), True),
                                    T.StructField('l3_job_description',  T.StringType(), True),
                                    T.StructField('l4_name',  T.StringType(), True),
                                    T.StructField('l4_mgt_level_indicator',  T.StringType(), True),
                                    T.StructField('l4_emp_status_code',  T.StringType(), True),
                                    T.StructField('l4_active',  T.StringType(), True),
                                    T.StructField('l4_job_description',  T.StringType(), True),
                                    T.StructField('l5_name',  T.StringType(), True),
                                    T.StructField('l5_mgt_level_indicator',  T.StringType(), True),
                                    T.StructField('l5_emp_status_code',  T.StringType(), True),
                                    T.StructField('l5_active',  T.StringType(), True),
                                    T.StructField('l5_job_description',  T.StringType(), True),
                                    T.StructField('l6_name',  T.StringType(), True),
                                    T.StructField('l6_mgt_level_indicator',  T.StringType(), True),
                                    T.StructField('l6_emp_status_code',  T.StringType(), True),
                                    T.StructField('l6_active',  T.StringType(), True),
                                    T.StructField('l6_job_description',  T.StringType(), True),
                                    T.StructField('l7_name',  T.StringType(), True),
                                    T.StructField('l7_mgt_level_indicator',  T.StringType(), True),
                                    T.StructField('l7_emp_status_code',  T.StringType(), True),
                                    T.StructField('l7_active',  T.StringType(), True),
                                    T.StructField('l7_job_description',  T.StringType(), True),
                                    T.StructField('l8_name',  T.StringType(), True),
                                    T.StructField('l8_mgt_level_indicator',  T.StringType(), True),
                                    T.StructField('l8_emp_status_code',  T.StringType(), True),
                                    T.StructField('l8_active',  T.StringType(), True),
                                    T.StructField('l8_job_description',  T.StringType(), True),
                                    T.StructField('l9_name',  T.StringType(), True),
                                    T.StructField('l9_mgt_level_indicator',  T.StringType(), True),
                                    T.StructField('l9_emp_status_code',  T.StringType(), True),
                                    T.StructField('l9_active',  T.StringType(), True),
                                    T.StructField('l9_job_description',  T.StringType(), True),
                                    T.StructField('l10_name',  T.StringType(), True),
                                    T.StructField('l10_mgt_level_indicator',  T.StringType(), True),
                                    T.StructField('l10_emp_status_code',  T.StringType(), True),
                                    T.StructField('l10_active',  T.StringType(), True),
                                    T.StructField('l10_job_description',  T.StringType(), True),
                                    T.StructField('l11_name',  T.StringType(), True),
                                    T.StructField('l11_mgt_level_indicator',  T.StringType(), True),
                                    T.StructField('l11_emp_status_code',  T.StringType(), True),
                                    T.StructField('l11_active',  T.StringType(), True),
                                    T.StructField('l11_job_description',  T.StringType(), True),
                                    T.StructField('l12_name',  T.StringType(), True),
                                    T.StructField('l12_mgt_level_indicator',  T.StringType(), True),
                                    T.StructField('l12_emp_status_code',  T.StringType(), True),
                                    T.StructField('l12_active',  T.StringType(), True),
                                    T.StructField('l12_job_description',  T.StringType(), True),
                                    T.StructField('l13_name',  T.StringType(), True),
                                    T.StructField('l13_mgt_level_indicator',  T.StringType(), True),
                                    T.StructField('l13_emp_status_code',  T.StringType(), True),
                                    T.StructField('l13_active',  T.StringType(), True),
                                    T.StructField('l13_job_description',  T.StringType(), True),
                                    T.StructField('l14_name',  T.StringType(), True),
                                    T.StructField('l14_mgt_level_indicator',  T.StringType(), True),
                                    T.StructField('l14_emp_status_code',  T.StringType(), True),
                                    T.StructField('l14_active',  T.StringType(), True),
                                    T.StructField('l14_job_description',  T.StringType(), True),
                                    T.StructField('l15_name',  T.StringType(), True),
                                    T.StructField('l15_mgt_level_indicator',  T.StringType(), True),
                                    T.StructField('l15_emp_status_code',  T.StringType(), True),
                                    T.StructField('l15_active',  T.StringType(), True),
                                    T.StructField('l15_job_description',  T.StringType(), True),
                                    T.StructField('company_code',  T.StringType(), True),
                                    T.StructField('work_addr1',  T.StringType(), True),
                                    T.StructField('work_city',  T.StringType(), True),
                                    T.StructField('work_state',  T.StringType(), True),
                                    T.StructField('work_zip',  T.StringType(), True),
                                    T.StructField('supv_uid',  T.StringType(), True),
                                    T.StructField('emp_classification',  T.StringType(), True),
                                    T.StructField('hrid',  T.StringType(), True),
                                    T.StructField('job_desc',  T.StringType(), True),
                                    T.StructField('job_function_code',  T.StringType(), True),
                                    T.StructField('supervisor_sbc_uid',  T.StringType(), True),
                                    T.StructField('ncs_date',  T.DateType(), True),
                                    T.StructField('contractor',  T.StringType(), True),
                                    T.StructField('uid_based_key',  T.LongType(), True),
                                    T.StructField('uid_dt_based_key',  T.LongType(), True)
                                    ])

        # set the current dataframe to be the previous runs output, since the initial load is done.
        current = out.dataframe(mode='previous', schema=curr_schema).alias('curr')

        # set the new_records to only have a high end_date and have a start_date of today
        co_rep_emp_hier_ver_dtl = tbl_hier_hist_daily.filter((tbl_hier_hist_daily.end_date == '2050-01-01')
        & (tbl_hier_hist_daily.start_date == F.date_sub(F.current_date(), 1)))
        #                                     & (tbl_hier_hist_daily.start_date == F.date_sub(run_date, 1)))  # 2) use run_date for reruns
        
        active_employees = tbl_hier_hist_daily.filter((tbl_hier_hist_daily.end_date.cast('Date') == '2050-01-01'))

        co_rep_emp_hier_ver_dtl = co_rep_emp_hier_ver_dtl.alias('a')
        co_rep_emp_hier_ver_dtl = co_rep_emp_hier_ver_dtl.join(tbl_cenet_full.alias("c0"),  [F.col("c0.uid") == co_rep_emp_hier_ver_dtl.uid_0], "left") \
            .join(tbl_cenet_full.alias("c1"), [F.col("c1.uid") == co_rep_emp_hier_ver_dtl.uid_1], "left") \
            .join(tbl_cenet_full.alias("c2"), [F.col("c2.uid") == co_rep_emp_hier_ver_dtl.uid_2], "left") \
            .join(tbl_cenet_full.alias("c3"), [F.col("c3.uid") == co_rep_emp_hier_ver_dtl.uid_3], "left") \
            .join(tbl_cenet_full.alias("c4"), [F.col("c4.uid") == co_rep_emp_hier_ver_dtl.uid_4], "left") \
            .join(tbl_cenet_full.alias("c5"), [F.col("c5.uid") == co_rep_emp_hier_ver_dtl.uid_5], "left") \
            .join(tbl_cenet_full.alias("c6"), [F.col("c6.uid") == co_rep_emp_hier_ver_dtl.uid_6], "left") \
            .join(tbl_cenet_full.alias("c7"), [F.col("c7.uid") == co_rep_emp_hier_ver_dtl.uid_7], "left") \
            .join(tbl_cenet_full.alias("c8"), [F.col("c8.uid") == co_rep_emp_hier_ver_dtl.uid_8], "left") \
            .join(tbl_cenet_full.alias("c9"), [F.col("c9.uid") == co_rep_emp_hier_ver_dtl.uid_9], "left") \
            .join(tbl_cenet_full.alias("c10"), [F.col("c10.uid") == co_rep_emp_hier_ver_dtl.uid_10], "left") \
            .join(tbl_cenet_full.alias("c11"), [F.col("c11.uid") == co_rep_emp_hier_ver_dtl.uid_11], "left") \
            .join(tbl_cenet_full.alias("c12"), [F.col("c12.uid") == co_rep_emp_hier_ver_dtl.uid_12], "left") \
            .join(tbl_cenet_full.alias("c13"), [F.col("c13.uid") == co_rep_emp_hier_ver_dtl.uid_13], "left") \
            .join(tbl_cenet_full.alias("c14"), [F.col("c14.uid") == co_rep_emp_hier_ver_dtl.uid_14], "left") \
            .join(tbl_cenet_full.alias("c15"), [F.col("c15.uid") == co_rep_emp_hier_ver_dtl.uid_15], "left") \
            .selectExpr(
                "a.uid_0 as sbc_uid",
                "a.rc",
                "a.status as status",
                "CAST(a.start_date AS varchar(20)) AS start_date",
                "a.end_date as end_date",
                "a.position as position",
                "a.mgmt_level as mgmt_level",
                "c0.f_name as first_name",
                "c0.l_name as last_name",
                "c0.u_f_name as unofficial_first_name",
                "c0.m_name as middle_name",
                "a.uid_0 as l0_sbc_uid",
                "a.uid_1 as l1_sbc_uid",
                "a.uid_2 as l2_sbc_uid",
                "a.uid_3 as l3_sbc_uid",
                "a.uid_4 as l4_sbc_uid",
                "a.uid_5 as l5_sbc_uid",
                "a.uid_6 as l6_sbc_uid",
                "a.uid_7 as l7_sbc_uid",
                "a.uid_8 as l8_sbc_uid",
                "a.uid_9 as l9_sbc_uid",
                "a.uid_10 as l10_sbc_uid",
                "a.uid_11 as l11_sbc_uid",
                "a.uid_12 as l12_sbc_uid",
                "a.uid_13 as l13_sbc_uid",
                "a.uid_14 as l14_sbc_uid",
                "a.uid_15 as l15_sbc_uid",
                "CONCAT(c0.l_name, ',', ' ', c0.u_f_name) as l0_name",
                "c0.mgmt_level as l0_mgt_level_indicator",
                "c0.emp_status_code as l0_emp_status_code",
                "c0.active as l0_active",
                "c0.job_desc as l0_job_description",
                "CONCAT(c1.l_name, ',', ' ', c1.u_f_name) as l1_name",
                "c1.mgmt_level as l1_mgt_level_indicator",
                "c1.emp_status_code as l1_emp_status_code",
                "c1.active as l1_active",
                "c1.job_desc as l1_job_description",
                "CONCAT(c2.l_name, ',', ' ', c2.u_f_name) as l2_name",
                "c2.mgmt_level as l2_mgt_level_indicator",
                "c2.emp_status_code as l2_emp_status_code",
                "c2.active as l2_active",
                "c2.job_desc as l2_job_description",
                "CONCAT(c3.l_name, ',', ' ', c3.u_f_name) as l3_name",
                "c3.mgmt_level as l3_mgt_level_indicator",
                "c3.emp_status_code as l3_emp_status_code",
                "c3.active as l3_active",
                "c3.job_desc as l3_job_description",
                "CONCAT(c4.l_name, ',', ' ', c4.u_f_name) as l4_name",
                "c4.mgmt_level as l4_mgt_level_indicator",
                "c4.emp_status_code as l4_emp_status_code",
                "c4.active as l4_active",
                "c4.job_desc as l4_job_description",
                "CONCAT(c5.l_name, ',', ' ', c5.u_f_name) as l5_name",
                "c5.mgmt_level as l5_mgt_level_indicator",
                "c5.emp_status_code as l5_emp_status_code",
                "c5.active as l5_active",
                "c5.job_desc as l5_job_description",
                "CONCAT(c6.l_name, ',', ' ', c6.u_f_name) as l6_name",
                "c6.mgmt_level as l6_mgt_level_indicator",
                "c6.emp_status_code as l6_emp_status_code",
                "c6.active as l6_active",
                "c6.job_desc as l6_job_description",
                "CONCAT(c7.l_name, ',', ' ', c7.u_f_name) as l7_name",
                "c7.mgmt_level as l7_mgt_level_indicator",
                "c7.emp_status_code as l7_emp_status_code",
                "c7.active as l7_active",
                "c7.job_desc as l7_job_description",
                "CONCAT(c8.l_name, ',', ' ', c8.u_f_name) as l8_name",
                "c8.mgmt_level as l8_mgt_level_indicator",
                "c8.emp_status_code as l8_emp_status_code",
                "c8.active as l8_active",
                "c8.job_desc as l8_job_description",
                "CONCAT(c9.l_name, ',', ' ', c9.u_f_name) as l9_name",
                "c9.mgmt_level as l9_mgt_level_indicator",
                "c9.emp_status_code as l9_emp_status_code",
                "c9.active as l9_active",
                "c9.job_desc as l9_job_description",
                "CONCAT(c10.l_name, ',', ' ', c10.u_f_name) as l10_name",
                "c10.mgmt_level as l10_mgt_level_indicator",
                "c10.emp_status_code as l10_emp_status_code",
                "c10.active as l10_active",
                "c10.job_desc as l10_job_description",
                "CONCAT(c11.l_name, ',', ' ', c11.u_f_name) as l11_name",
                "c11.mgmt_level as l11_mgt_level_indicator",
                "c11.emp_status_code as l11_emp_status_code",
                "c11.active as l11_active",
                "c11.job_desc as l11_job_description",
                "CONCAT(c12.l_name, ',', ' ', c12.u_f_name) as l12_name",
                "c12.mgmt_level as l12_mgt_level_indicator",
                "c12.emp_status_code as l12_emp_status_code",
                "c12.active as l12_active",
                "c12.job_desc as l12_job_description",
                "CONCAT(c13.l_name, ',', ' ', c13.u_f_name) as l13_name",
                "c13.mgmt_level as l13_mgt_level_indicator",
                "c13.emp_status_code as l13_emp_status_code",
                "c13.active as l13_active",
                "c13.job_desc as l13_job_description",
                "CONCAT(c14.l_name, ',', ' ', c14.u_f_name) as l14_name",
                "c14.mgmt_level as l14_mgt_level_indicator",
                "c14.emp_status_code as l14_emp_status_code",
                "c14.active as l14_active",
                "c14.job_desc as l14_job_description",
                "CONCAT(c15.l_name, ',', ' ', c15.u_f_name) as l15_name",
                "c15.mgmt_level as l15_mgt_level_indicator",
                "c15.emp_status_code as l15_emp_status_code",
                "c15.active as l15_active",
                "c15.job_desc as l15_job_description",
                "c0.company_code",
                "c0.work_addr1",
                "c0.work_city",
                "c0.work_state",
                "c0.work_zip",
                "c0.supv_uid",
                "c0.emp_classification",
                "c0.hrid",
                "c0.job_desc",
                "c0.job_function_code",
                "a.supv_uid as supervisor_sbc_uid",
                "c0.ncs_date",
                "c0.contractor"
            ).filter((co_rep_emp_hier_ver_dtl.status != 'D'))
        co_rep_emp_hier_ver_dtl = co_rep_emp_hier_ver_dtl.dropDuplicates()

        co_rep_emp_hier_ver_dtl = co_rep_emp_hier_ver_dtl.withColumn('start_date', co_rep_emp_hier_ver_dtl.start_date.cast(T.StringType()))
        co_rep_emp_hier_ver_dtl = co_rep_emp_hier_ver_dtl.withColumn('uid_based_key', my_udf('sbc_uid').cast(T.LongType()))

        co_rep_emp_hier_ver_dtl = co_rep_emp_hier_ver_dtl.withColumn('uid_dt_based_key', uid_dt_based_udf(F.array('uid_based_key', 'start_date')).cast(T.LongType()))
        co_rep_emp_hier_ver_dtl = co_rep_emp_hier_ver_dtl.withColumn('start_date', co_rep_emp_hier_ver_dtl.start_date.cast(T.DateType()))

        # create an end_dates df with all the uids that have new hierarchy versions and the rows with a max end date
        end_dates = current.join(co_rep_emp_hier_ver_dtl, on=[current.sbc_uid == co_rep_emp_hier_ver_dtl.sbc_uid, current.end_date == '2050-01-01'], how='left_semi').alias('end')

        # anti_join the current data and the rows that need to be updated, so we don't have duplicates
        current = current.join(end_dates, on=[current.sbc_uid == end_dates.sbc_uid, F.col('curr.end_date') == '2050-01-01'], how='left_anti').alias('curr')

        # gather the terminated employees into a terminated employees df
        terminated_emp_condition = [current.sbc_uid == active_employees.uid_0]
        terminated_employees = current.join(active_employees, on=terminated_emp_condition, how='left_anti')
        terminated_employees = terminated_employees.filter(terminated_employees.end_date.cast('Date') == '2050-01-01').alias('term')

        # remove the terminated employees from the current dataset with a high end date
        current = current.withColumn('end_date', current.end_date.cast('Date')).alias('curr')
        curr_terminated_cond = [current.sbc_uid == terminated_employees.sbc_uid, F.col('curr.end_date') == '2050-01-01']
        current = current.join(terminated_employees, on=curr_terminated_cond, how="left_anti")
        current = current.withColumn('end_date', current.end_date.cast('Timestamp')).alias('curr')

        # then union back in the terminated employees with the current date as end_date
        terminated_employees = terminated_employees.withColumn('end_date',
            F.when((terminated_employees.start_date.cast('Date') == F.date_sub(F.current_date(), 1)), 
                F.date_sub(F.current_date(), 1))
                .otherwise(F.date_sub(F.current_date(), 2)))
             # F.when((terminated_employees.start_date.cast('Date') == F.date_sub(run_date, 1)),   # 3) use run_date for reruns
             #        F.date_sub(run_date, 1))                                                     # 3) use run_date for reruns
             # .otherwise(F.date_sub(run_date, 2)))                                                # 3) use run_date for reruns

        # set end date for non current records as current date or current date - 1
        end_dates = end_dates.withColumn('end_date',
        F.when((terminated_employees.start_date.cast('Date') == F.date_sub(F.current_date(), 1)),
            F.date_sub(F.current_date(), 1))
            .otherwise(F.date_sub(F.current_date(), 2)))
                                         # F.when((terminated_employees.start_date.cast('Date') == F.date_sub(run_date, 1)),    # 4) use run_date for reruns
                                         #       F.date_sub(run_date, 1))                                                       # 4) use run_date for reruns
                                         # .otherwise(F.date_sub(run_date, 2)))                                                 # 4) use run_date for reruns
        # union back in new, current, old records that needed to be closed, and terminated employees with their closed record.
        ret = co_rep_emp_hier_ver_dtl.unionByName(end_dates).unionByName(current).unionByName(terminated_employees)

        ret = ret.withColumn('end_date', ret.end_date.cast('Date'))
        ret = ret.withColumn('end_date', ret.end_date.cast('String'))
        # 2020-08-20 - DP - append end_date with '00:00:00' if it a high date else append it with '23:59:59'
        ret = ret.withColumn('end_date', F.when(ret.end_date == '2050-01-01', F.concat(ret.end_date, F.lit(' 00:00:00')))
                             .otherwise(F.concat(ret.end_date, F.lit(' 23:59:00'))))
        ret = ret.withColumn('start_date', ret.start_date.cast('Timestamp'))
        ret = ret.withColumn('end_date', ret.end_date.cast('Timestamp'))
        ret = ret.withColumn('ncs_date', ret.ncs_date.cast('Date'))
        ret = ret.orderBy(ret.start_date.desc())
        out.set_mode("replace")
        out.write_dataframe(ret)
    else:
        initial_load.orderBy(initial_load.start_date.desc())
        out.set_mode("replace")
        out.write_dataframe(initial_load)

