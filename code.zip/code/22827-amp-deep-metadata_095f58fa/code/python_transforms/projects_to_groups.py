from transforms.api import transform_df, Input, Output
from myproject.utils.global_code import (
    session,
    get_header,
    PARENT_FOLDER,
    COMPASS_URI,
    ACTIVITY_URI,
)
import pyspark.sql.types as T
import re
from datetime import datetime


@transform_df(
    Output(f"{PARENT_FOLDER}/projects_to_groups", sever_permissions=True),
    config=Input("ri.foundry.main.dataset.b5cb343e-1109-4401-b3fb-5137c32cb781"),
)
def projects_to_groups(ctx, config):
    INNO_LAB_RID = "ri.compass.main.folder.6db4e35e-437a-4069-9d1a-e95bf4bec3ff"
    INNO_LAB_RID_2 = "ri.compass.main.folder.d789ef3d-524d-41b0-a536-7aa446936b61"
    INNO_LAB_RID_3 = "ri.compass.main.folder.41694218-4019-4eac-a913-6c44edfefec2"
    INNO_LAB_RID_4 = "ri.compass.main.folder.cd81a775-2b0e-4412-9697-f6dd931e8250"
    headers = get_header(config)

    schema = T.StructType(
        [
            T.StructField("project_rid", T.StringType()),
            T.StructField("project_name", T.StringType()),
            T.StructField("project_path", T.StringType()),
            T.StructField("project_type", T.StringType()),
            T.StructField("project_description", T.StringType()),
            T.StructField("pipeline_type", T.StringType()),
            T.StructField("ingestion_managers", T.StringType()),
            T.StructField("project_stage", T.StringType()),
            T.StructField("default_role", T.StringType()),
            T.StructField("group_rid", T.StringType()),
            T.StructField("access_level", T.StringType()),
            T.StructField("most_recent_activity_time", T.TimestampType()),
            T.StructField("most_recent_activity_type", T.StringType()),
        ]
    )

    rows = []
    get_all_projects = session.get(
        "{}/hierarchy/organizations/{}/project-rids".format(COMPASS_URI, INNO_LAB_RID),
        headers=headers,
    )
    project_rid_list = get_all_projects.json()
    get_all_projects = session.get(
        "{}/hierarchy/organizations/{}/project-rids".format(
            COMPASS_URI, INNO_LAB_RID_2
        ),
        headers=headers,
    )
    project_rid_list += get_all_projects.json()
    get_all_projects = session.get(
        "{}/hierarchy/organizations/{}/project-rids".format(
            COMPASS_URI, INNO_LAB_RID_3
        ),
        headers=headers,
    )
    project_rid_list += get_all_projects.json()
    get_all_projects = session.get(
        "{}/hierarchy/organizations/{}/project-rids".format(
            COMPASS_URI, INNO_LAB_RID_4
        ),
        headers=headers,
    )
    project_rid_list += get_all_projects.json()

    get_all_project_info = session.post(
        "{}/batch/projects-by-rids".format(COMPASS_URI),
        headers=headers,
        json=project_rid_list,
    )
    project_info = get_all_project_info.json()

    for key_pair in project_info.items():
        project_rid = key_pair[0]
        permissions = key_pair[1]["permissions"]
        project_name = key_pair[1]["resource"]["name"]
        description = key_pair[1]["resource"]["description"]
        project_path = key_pair[1]["resource"]["path"]
        project_stage = None
        project_type = None
        pipeline_type = None
        ingestion_managers = None

        activity = session.post(
            "{}/activity/search".format(ACTIVITY_URI),
            headers=headers,
            json={
                "latestFirst": True,
                "limit": 1,
                "rid": project_rid,
                "typesFilter": [
                    "compass:resource-created",
                    "compass:resource-modified",
                ],
            },
        )
        isActivity = len(activity.json()["activity"]) != 0
        if isActivity:
            latestActivity = activity.json()["activity"][0]
            activityType = str(latestActivity["type"])
            activityTime = str(latestActivity["datetime"])
            search = re.search("(.*)\..*", activityTime)
            if search:
                activityTime = search.group(1)
                activityTime = datetime.strptime(activityTime, "%Y-%m-%dT%H:%M:%S")
        else:
            activityType = None
            activityTime = None

        if key_pair[1]["resource"]["namedTags"]:
            all_tags = key_pair[1]["resource"]["namedTags"]
            print(all_tags)
            for tag in all_tags:
                if "Project Type" in tag["name"]:
                    project_type = tag["name"][13:]
                elif "Pipeline Type" in tag["name"]:
                    pipeline_type = tag["name"][14:]
                elif "Ingestion Managers" in tag["name"]:
                    ingestion_managers = tag["name"][19:]
                elif "Project Stage" in tag["name"]:
                    project_stage = tag["name"][14:]

        for perm in permissions:
            # default role on project
            default_role = "NONE"
            group_rid = perm["principal"]["id"]
            access_level = perm["accessLevel"]

            if perm["principal"]["type"] == "EVERYONE":
                default_role = access_level
            if group_rid == None:
                group_rid = "USER"
            # else:
            # if perm["principal"]["type"] == "USER":
            # {u'accessLevel': u'OWN', u'principal': {u'type': u'USER', u'id': u'161d8c1d-8cda-44d5-bdac-91fdcc8820ff'}}

            rows.append(
                {
                    "project_rid": project_rid,
                    "project_name": project_name,
                    "project_path": project_path,
                    "project_type": project_type,
                    "project_description": description,
                    "pipeline_type": pipeline_type,
                    "ingestion_managers": ingestion_managers,
                    "project_stage": project_stage,
                    "default_role": default_role,
                    "group_rid": group_rid,
                    "access_level": access_level,
                    "most_recent_activity_time": activityTime,
                    "most_recent_activity_type": activityType,
                }
            )
        # break
    return ctx.spark_session.createDataFrame(rows, schema=schema)
