import requests
from pyspark.sql import functions as F
from pyspark.sql import types as T
from transforms.api import Input, Output, transform_df


@transform_df(
    Output("ri.foundry.main.dataset.be3621b4-7a1b-4c13-9123-ea6aaaff1cfc"),
    nonempty_multipass_groups=Input("ri.foundry.main.dataset.92eb8aaf-91e8-48d2-ae68-1647ee3d0a1f"),
    config=Input("ri.foundry.main.dataset.b5cb343e-1109-4401-b3fb-5137c32cb781"),
)
def all_multipass_groups_with_empty(ctx, nonempty_multipass_groups, config):
    headers = get_header(config)
    session = requests.Session()

    MULTIPASS_URI = "https://paloma.palantirfoundry.com/multipass/api"
    realms = ["sso", "palantir_internal_realm", "palantir", "mechid-sso"]

    schema = T.StructType([
        T.StructField("group_rid", T.StringType()),
        T.StructField("group_name", T.StringType()),
        T.StructField("group_realm", T.StringType()),
    ])

    search_requests_with_realms = []
    for realm in realms:
        search_requests_with_realms.append({
            "attributeFilters": {"multipass:realm": [realm]},
            "query": "",
            "pageStart": 0,
            "pageSize": 1000,
        })

    multipass_groups = []
    for search_request in search_requests_with_realms:
        resp = session.post(
            "{}/search/v2/search/groups".format(MULTIPASS_URI), headers=headers, json=search_request
        ).json()["values"]

        multipass_groups += resp

    rows = []
    for group in multipass_groups:
        group = group["group"]
        group_id = group["id"]
        group_realm = group["attributes"]["multipass:realm"][0]
        group_name = group["name"]
        rows.append({"group_rid": group_id, "group_name": group_name, "group_realm": group_realm})

    df = ctx.spark_session.createDataFrame(rows, schema=schema)
    df = nonempty_multipass_groups.join(df, ["group_rid", "group_name", "group_realm"], "full")
    df = (
        df.withColumn(
            "user_list", F.coalesce(F.col("user_list"), F.from_json(F.lit("[]"), T.ArrayType(T.StringType())))
        )
        .withColumn(
            "user_list_attuids",
            F.coalesce(F.col("user_list_attuids"), F.from_json(F.lit("[]"), T.ArrayType(T.StringType()))),
        )
        .withColumn("max_expiration", F.lit(None).cast(T.TimestampType()))
        .withColumn("max_duration_in_seconds", F.lit(0))
    )
    return df


def get_config(config):
    config_df = config.dataframe() if hasattr(config, "dataframe") else config
    return {row["key"]: row["value"] for row in config_df.collect()}


def get_header(config):
    AUTH = get_config(config).get("FOUNDRY_TOKEN")
    return {"Authorization": "Bearer {0}".format(AUTH), "Content-Type": "application/json"}
