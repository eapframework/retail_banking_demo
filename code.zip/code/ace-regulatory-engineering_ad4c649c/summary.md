# Project Inventory Summary

**Project name:** ACE REGULATORY ENGINEERING

**Merge timestamp:** 2026-03-16T15:49:16.152344

**Project output dir:** `ace-regulatory-engineering_ad4c649c`

**Total resources in project folder:** 11

**Total merged records:** 17

**Unresolved (project_only) resources:** 0

## Resource Counts by Type

- **datasource:** 1
- **eddiepipeline:** 4
- **magritteagent:** 4
- **pipelinebuilder:** 1
- **rawdataset:** 4
- **sqltransformation:** 1
- **vectorworkbook:** 2

## Mode

Flat output — workshop subdirectories removed after merge.
