CREATE TABLE `/Innovation Lab/[ETL] Ticketing/logic/aotsm/aotsm_lk_first_change_id` AS
    SELECT ticket_number, regexp_extract(log_text, '(CHG000[0-9]*)', 1) as first_change_id 
     FROM `/Innovation Lab/[Source] Oracle AOTS-M/data/clean/BOADMIN.TT_WORK_DONE_ENTRIES`
    WHERE log_text REGEXP 'CHG000[0-9]*'
    UNION
    SELECT ticket_number, regexp_extract(log_text, '(CHG000[0-9]*)', 1) as first_change_id 
     FROM `/Innovation Lab/[Source] Oracle AOTS-M/data/clean/BOADMIN.TT_WORK_DONE_ENTRIES_ARCHIVE`
    WHERE log_text REGEXP 'CHG000[0-9]*'