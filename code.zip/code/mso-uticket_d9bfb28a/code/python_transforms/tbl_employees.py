from transforms.api import transform_df, Input, Output
import pyspark.sql.functions as F


@transform_df(
    Output("ri.foundry.main.dataset.9221b527-894f-4544-81d2-72f76c59ba4f"),
    tbl_cenet=Input("ri.foundry.main.dataset.293d7d73-8e66-4221-89d6-a05b61aa34b6"),
)
def my_compute_function(tbl_cenet):
    # creating tbl_employees

    # The inner select that is in the tbl_employees query where the management level must be numeric and not null
    # essentiially this ensures that we get employees with a hierarchy
    inner_select = tbl_cenet.selectExpr(
        "uid",
        "supv_uid",
        "CASE WHEN UPPER(mgmt_level) = LOWER(mgmt_level) THEN mgmt_level ELSE NULL END mgmt_level",
        "rc",
        "vacant_supv_uid",
        "emp_status_code",
        "active"
    )

    # Filtering out all the non-active employees and employees that don't have an rc
    # This ensures that we have all active employees
    tbl_employees = inner_select.selectExpr(
        "uid",
        "supv_uid",
        "mgmt_level",
        "rc",
        "vacant_supv_uid",
        "emp_status_code as status"
    ).filter(
        (inner_select.active == 'Y') &
        (inner_select.rc.isNull() == False)
    )
    tbl_employees = tbl_employees.filter(F.isnull(tbl_employees.uid) == False)
    return tbl_employees
