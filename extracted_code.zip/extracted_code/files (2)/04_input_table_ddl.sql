-- ============================================================================
-- MSO uTicket — Unity Catalog Input Table DDL (Bronze Layer)
-- ============================================================================
-- These CREATE TABLE statements define the bronze-layer landing tables
-- in Unity Catalog. Schemas are derived from the Foundry data source
-- sample Excel files provided.
--
-- IMPORTANT: Adjust catalog, schema, and external location to your environment.
-- ============================================================================

CREATE CATALOG IF NOT EXISTS mso_uticket;
USE CATALOG mso_uticket;
CREATE SCHEMA IF NOT EXISTS bronze COMMENT 'Raw ingestion from Oracle ESAR via Snowflake';
CREATE SCHEMA IF NOT EXISTS silver COMMENT 'Cleaned/curated transforms';
CREATE SCHEMA IF NOT EXISTS gold COMMENT 'Contour-derived analytics tables';

-- ============================================================================
-- 1. raw_chg_change_snowflake (756 columns)
--    Source: Oracle ESAR → chg_change
--    PK: (CHANGE_ID, SEQNO)
--    NOTE: Only critical columns shown; full 756-column schema should be
--          auto-inferred by Auto Loader (cloudFiles.inferColumnTypes=true)
-- ============================================================================

CREATE TABLE IF NOT EXISTS bronze.raw_chg_change_snowflake (
    CHANGE_ID                       STRING      NOT NULL COMMENT 'Change ticket ID (e.g., CHG000010393449)',
    SEQNO                           BIGINT      COMMENT 'Sequence number within change',
    SUBMITTED_FOR                   STRING,
    CREATE_DATE                     BIGINT      COMMENT 'Epoch millis — parsed to TIMESTAMP in silver',
    ASSIGNEE_LOGIN_NAME             STRING,
    LAST_MODIFIED_BY                STRING,
    MODIFIED_DATE                   BIGINT      COMMENT 'Epoch millis',
    STATUS                          BIGINT      COMMENT '0=New,1=Assigned,...,7=Closed,8=Cancelled',
    SUMMARY                         STRING,
    CATEGORY                        STRING      COMMENT 'E.g., Mobility-Regional, ATT_IT',
    TYPE                            STRING,
    ITEM                            STRING,
    REQUESTER_GROUP                 STRING      COMMENT 'Key filter field for MSO scope',
    REQUESTER_NAME                  STRING,
    REQUESTER_LOGIN_NAME            STRING,
    SUPERVISOR_GROUP                STRING      COMMENT 'Renamed to assignee_group in gold',
    DESCRIPTION                     STRING,
    PLANNED_START_DATE              BIGINT      COMMENT 'Epoch millis',
    PLANNED_END_DATE                BIGINT      COMMENT 'Epoch millis',
    APPROVAL_STATUS                 BIGINT      COMMENT '0=Required,1=Pending,...,5=Not Required',
    CHANGE_CLOSED_BY_EASTERN_DT     STRING      COMMENT 'Pre-formatted Eastern datetime string',
    ORDER_NUMBER                    STRING,
    WORK_TYPE                       STRING,
    EMERGENCY_                      STRING,
    CLLI                            STRING,
    IMPACTED_STATE                  STRING,
    SUPERVISOR_LOCATION             STRING
    -- ... 730+ additional columns omitted; Auto Loader infers full schema
)
USING DELTA
COMMENT 'Raw CHG_CHANGE from Oracle ESAR. 756 columns. Key source for all change tickets.'
TBLPROPERTIES ('quality' = 'bronze');


-- ============================================================================
-- 2. raw_chg_task_snowflake (190 columns)
--    Source: Oracle ESAR → chg_task
--    PK: (TASK_ID, SEQNO)
-- ============================================================================

CREATE TABLE IF NOT EXISTS bronze.raw_chg_task_snowflake (
    TASK_ID                         STRING      NOT NULL COMMENT 'Task ID (e.g., TSK000004816948)',
    SEQNO                           BIGINT,
    SUBMITTER                       STRING,
    CREATE_DATE001                  BIGINT      COMMENT 'Epoch millis',
    ASSIGNEE_LOGIN_NAME             STRING,
    LAST_MODIFIED_BY                STRING,
    MODIFIED_DATE001                BIGINT      COMMENT 'Epoch millis',
    STATUS                          BIGINT      COMMENT '0=New,1=Scheduled,...,4=Closed',
    SUMMARY                         STRING,
    CATEGORY                        STRING,
    CHANGE_ID                       STRING      COMMENT 'FK to CHG_CHANGE',
    IMPLEMENTOR_GROUP               STRING,
    IMPLEMENTOR_NAME_               STRING,
    IMPLEMENTOR_E_MAIL              STRING,
    TASK_FULL_NAME                  STRING,
    TASK_CLOSED_BY_DATE             STRING,
    TASK_CLOSED_BY_DATE_RPT         BIGINT      COMMENT 'Epoch millis',
    PLANNED_START_DATE              BIGINT      COMMENT 'Epoch millis',
    PLANNED_END_DATE                BIGINT      COMMENT 'Epoch millis',
    PLANNED_END_EASTERN_DT          STRING,
    PLANNED_START_EASTERN_DT        STRING,
    DESCRIPTION                     STRING
    -- ... 168 additional columns omitted
)
USING DELTA
COMMENT 'Raw CHG_TASK from Oracle ESAR. 190 columns.'
TBLPROPERTIES ('quality' = 'bronze');


-- ============================================================================
-- 3. raw_acmr14_affected_cllis (15 columns)
-- ============================================================================

CREATE TABLE IF NOT EXISTS bronze.raw_acmr14_affected_cllis (
    REQUEST_ID                      BIGINT      COMMENT 'Request ID (numeric PK)',
    SUBMITTER                       STRING,
    CREATE_DATE                     BIGINT      COMMENT 'Epoch millis',
    ASSIGNED_TO                     STRING,
    LAST_MODIFIED_BY                STRING,
    MODIFIED_DATE                   BIGINT      COMMENT 'Epoch millis',
    STATUS                          BIGINT,
    SHORT_DESCRIPTION               STRING,
    CHANGE_ID                       STRING      COMMENT 'FK to CHG_CHANGE',
    CLLI                            STRING      COMMENT 'Common Language Location Identifier',
    CITY                            STRING,
    LOCATION                        STRING      COMMENT 'Joined into gold tables',
    WMS_INTERFACE_STATUS            STRING,
    WMS_TASK_ID                     STRING,
    CLLISTATUS                      STRING
)
USING DELTA
COMMENT 'Raw ACMR14 Affected CLLIs. 15 columns.'
TBLPROPERTIES ('quality' = 'bronze');


-- ============================================================================
-- 4. raw_acmr14_affected_techs_snowflake (19 columns)
-- ============================================================================

CREATE TABLE IF NOT EXISTS bronze.raw_acmr14_affected_techs_snowflake (
    REQUEST_ID                      BIGINT,
    SUBMITTER                       STRING,
    CREATE_DATE                     BIGINT      COMMENT 'Epoch millis',
    ASSIGNED_TO                     STRING,
    LAST_MODIFIED_BY                STRING,
    MODIFIED_DATE                   BIGINT      COMMENT 'Epoch millis',
    STATUS                          BIGINT,
    SHORT_DESCRIPTION               STRING,
    CHANGE_ID                       STRING      COMMENT 'FK to CHG_CHANGE',
    TECHNOLOGY_ID                   BIGINT,
    UNIQUE_TECHNOLOGY_CODE          STRING,
    TECHNOLOGY                      STRING      COMMENT 'Joined as new_technology in gold',
    USED_FOR_CHG_TEMPLATE           BIGINT,
    CATEGORY                        STRING,
    CHANGE_ID_TEMP                  STRING,
    ITEM                            STRING,
    TYPE                            STRING,
    ADDITIONAL_APPOVER              STRING,
    SUBMIT_FOR_APPROVAL             STRING
)
USING DELTA
COMMENT 'Raw ACMR14 Affected Technologies. 19 columns.'
TBLPROPERTIES ('quality' = 'bronze');


-- ============================================================================
-- 5. raw_acmr23_mobility_equipment_info_snowflake (32 columns)
--    PK: MED_RECORD_ID (for SCD1 upsert in silver)
-- ============================================================================

CREATE TABLE IF NOT EXISTS bronze.raw_acmr23_mobility_equipment_info_snowflake (
    MED_RECORD_ID                   STRING      NOT NULL COMMENT 'PK (e.g., MED000028790381)',
    CREATE_DATE                     BIGINT      COMMENT 'Epoch millis',
    LAST_MODIFIED_BY                STRING,
    MODIFIED_DATE                   BIGINT      COMMENT 'Epoch millis',
    CTS_NUMBER                      STRING,
    EQUIPMENT_ID                    STRING      COMMENT 'Joined into gold',
    GCP_STATUS                      STRING,
    CTS_STATUS                      STRING,
    ENGAGEMENT_STATUS               STRING,
    COMMON_ID                       STRING,
    PARENT_ID                       STRING,
    EQUIPMENT_NAME                  STRING      COMMENT 'Joined into gold',
    PARENT_NAME                     STRING,
    EQUIPMENT_TYPE                  STRING      COMMENT 'Joined into gold',
    CTS_TYPE                        STRING,
    MODEL                           STRING,
    REGION                          STRING,
    MARKET_CLUSTER                  STRING,
    MARKET                          STRING,
    LOCATION                        STRING,
    CHANGE_ID                       STRING      COMMENT 'FK to CHG_CHANGE',
    LAST_CTS_MESSAGE                STRING,
    CTS_EQUIPMENT_ENTRYID           STRING,
    PLANNED_START_DATE              BIGINT      COMMENT 'Epoch millis',
    PLANNED_END_DATE                BIGINT      COMMENT 'Epoch millis',
    SEVERITY                        STRING,
    STATUS                          STRING,
    CLOSURE_COMMENTS                STRING,
    SHORT_DESCRIPTION               STRING,
    SUBMITTER                       STRING,
    ASSIGNED_TO                     STRING,
    SERVICES_SUPPORTED              STRING
)
USING DELTA
COMMENT 'Raw ACMR23 Mobility Equipment Info. 32 columns. SCD1 key: MED_RECORD_ID.'
TBLPROPERTIES ('quality' = 'bronze');


-- ============================================================================
-- 6. raw_ap_signature (52 columns)
-- ============================================================================

CREATE TABLE IF NOT EXISTS bronze.raw_ap_signature (
    SIGNATURE_ID                    BIGINT      COMMENT 'Signature PK',
    SEQNO                           BIGINT,
    SUBMITTER_SIG                   STRING,
    CREATE_DATE_SIG                 BIGINT      COMMENT 'Epoch millis',
    ASSIGNED_TO_SIG                 STRING,
    LAST_MODIFIED_BY_SIG            STRING,
    MODIFIED_DATE_SIG               BIGINT      COMMENT 'Epoch millis',
    APPROVAL_STATUS                 BIGINT      COMMENT '0-5 status code',
    APPROVAL_ID                     BIGINT      COMMENT 'FK to AP_DETAIL',
    SIGNATURE_METHOD                BIGINT,
    ERROR                           STRING,
    INDEPENDENT                     BIGINT,
    ORIGINAL_APPROVERS              STRING,
    APPROVER_SIGNATURE              STRING      COMMENT 'Joined into gold',
    NEXT_APPROVERS                  STRING,
    ALTERNATE_SIGNATURE             STRING,
    APPROVERS                       STRING,
    IF_MULTIPLE_APPROVERS           BIGINT,
    MORE_INFORMATION                STRING,
    ROLE                            STRING      COMMENT 'Joined into gold',
    NEXT_ACTION_ESCALATION_TIME     BIGINT      COMMENT 'Epoch millis',
    NEXT_GLOBAL_ESCALATION_TIME     BIGINT      COMMENT 'Epoch millis',
    NEXT_STATE_ESCALATION_TIME      BIGINT      COMMENT 'Epoch millis',
    LEVEL_SIG                       BIGINT,
    MODIFIED                        BIGINT      COMMENT 'Epoch millis',
    COMPLETED                       BIGINT,
    ORDER_X                         BIGINT,
    REACHED_DONE                    BIGINT,
    APPROVAL_LEVEL                  BIGINT,
    EXEMPT_FROM_REAPPROVAL          BIGINT,
    CURRENT_APPROVAL_LEVEL          DOUBLE,
    CURRENT_APPROVAL_LEVEL_COUNT    DOUBLE,
    LAST_APP_CR_COUNT               DOUBLE
    -- ... 19 additional columns omitted
)
USING DELTA
COMMENT 'Raw AP_SIGNATURE. 52 columns.'
TBLPROPERTIES ('quality' = 'bronze');


-- ============================================================================
-- 7. raw_ap_detail_snowflake (40 columns)
-- ============================================================================

CREATE TABLE IF NOT EXISTS bronze.raw_ap_detail_snowflake (
    APPROVAL_ID                     BIGINT      COMMENT 'PK (with SEQNO)',
    SEQNO                           BIGINT,
    SUBMITTER_DTL                   STRING,
    CREATE_DATE_DTL                 BIGINT      COMMENT 'Epoch millis',
    ASSIGNED_TO_DTL                 STRING,
    LAST_MODIFIED_BY_DTL            STRING,
    MODIFIED_DATE_DTL               BIGINT      COMMENT 'Epoch millis',
    STATUS_DTL                      BIGINT,
    REQUEST                         STRING      COMMENT 'FK to CHG_CHANGE.CHANGE_ID',
    PROCESS                         STRING,
    APPLICATION                     STRING,
    PRIORITY                        BIGINT,
    COMMENTS                        STRING,
    APPROVAL_AUDIT_TRAIL            STRING,
    LEVEL_X                         BIGINT,
    COMPLETED                       BIGINT,
    APPROVAL_METHOD                 BIGINT,
    ROLE                            STRING,
    REAL_FIELD_1                    DOUBLE,
    REAL_FIELD_2                    DOUBLE,
    DECIMAL_FIELD_1                 DOUBLE,
    DECIMAL_FIELD_2                 DOUBLE,
    INTEGER_FIELD_1                 BIGINT,
    INTEGER_FIELD_2                 BIGINT,
    STATISTICAL_OVERRIDE            BIGINT,
    ORDER_X                         BIGINT
    -- ... 14 additional columns omitted
)
USING DELTA
COMMENT 'Raw AP_DETAIL. 40 columns. Links APPROVAL_ID to CHANGE_ID via REQUEST column.'
TBLPROPERTIES ('quality' = 'bronze');
