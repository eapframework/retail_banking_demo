CREATE TABLE `/Innovation Lab/[ETL] Ticketing/logic/aotstm/aotstm_lk_wfa_ticket_all` AS
 SELECT ticket, first(wfa_ticket) wfa_ticket
 FROM (
    (SELECT * FROM `/Innovation Lab/[ETL] Ticketing/logic/aotstm/aotstm_lk_wfa_from_handover_text`)
    UNION
    (SELECT * FROM `/Innovation Lab/[ETL] Ticketing/logic/aotstm/aotstm_lk_wfa_from_reference_ticket`)
    UNION
    (SELECT * FROM `/Innovation Lab/[ETL] Ticketing/logic/aotstm/aotstm_lk_wfa_from_ticket_log`)
    UNION
    (SELECT * FROM `/Innovation Lab/[ETL] Ticketing/logic/aotstm/aotstm_lk_wfa_from_referral_ticket`)
 ) GROUP BY ticket