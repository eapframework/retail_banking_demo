'''
/*************************************************************************************************
**  Creator: Joanie Sapp, es0597
**  Date Created: 09/29/2022
**  Description: Cleansing script to properly clean and scrub the datatypes into the CEWA > data.
**
**  Date Modified:
**      YYYYMMDD - aa9999, <add comments here>.
**
*************************************************************************************************/
'''
from transforms.api import transform_df, Input, Output
from pyspark.sql.functions import col


@transform_df(
    Output("/Innovation Lab 3/[Source] Snowflake DIY ACE/data/clean/WCMT/wm_func"),
    i=Input("/Innovation Lab 3/[Source] Snowflake DIY ACE/data/raw/WCMT/WM_FUNC")
)
def compute(i):
    o = (
        i
        .select(
            col('CATEGORY_ID').alias('category_id'),
            col('FUNC_ID').alias('func_id'),
            col('FUNC_NAME').alias('func_name'),
            col('FUNC_ABBR').alias('func_abbr'),
            col('LEGACY_ABBR').alias('legacy_abbr'),
            col('LEGACY_ONLY').alias('legacy_only'),
            col('REQUIRE_EACH_WC').alias('require_each_wc'),
            col('LIMIT_1_PER_WC').alias('limit_1_per_wc'),
            col('PURPOSE').alias('purpose'),
            col('IMPORTANCE').alias('importance'),
            col('CONTACT_REASONS').alias('contact_reasons'),
            col('ADDITIONAL_INFORMATION').alias('additional_information'),
            col('INTERACTING_FUNCTIONS').alias('interacting_functions')
        )
    )

    return o
