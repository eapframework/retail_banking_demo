# Project Inventory Summary

**Project name:** Design Technology WebPhone Data

**Merge timestamp:** 2026-03-17T10:30:09.510708

**Project output dir:** `design-technology-webphone-data_4ff86f6a`

**Total resources in project folder:** 7

**Total merged records:** 14

**Unresolved (project_only) resources:** 0

## Resource Counts by Type

- **contouranalysis:** 1
- **datasource:** 1
- **eddiepipeline:** 1
- **networkegresspolicy:** 4
- **pipelinebuilder:** 4
- **pythontransformation:** 1
- **rawdataset:** 1
- **virtualtable:** 1

## Mode

Flat output — workshop subdirectories removed after merge.
