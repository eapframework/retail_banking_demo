from transforms.api import transform, Output, Input, configure
from pyspark.sql import functions as F
from .program_category_utils import applyFilters, rollup_crp


SPARK_PROFILES = [
        'DRIVER_MEMORY_EXTRA_EXTRA_LARGE',
        'DRIVER_CORES_LARGE',
        'EXECUTOR_MEMORY_LARGE',
        'EXECUTOR_CORES_LARGE',
        'NUM_EXECUTORS_32',
        'EXECUTOR_MEMORY_OVERHEAD_LARGE',
        'DYNAMIC_ALLOCATION_DISABLED'
]


@configure(profile=SPARK_PROFILES)
@transform(
    # replace this with your output dataset path
    outinternal_lvl_2_sites=Output("ri.foundry.main.dataset.abbd3a7d-c765-44d8-b65f-60a8f49abe99"),
    outinternal_lvl_1=Input("ri.foundry.main.dataset.45d4e145-6d09-4832-a86d-d1a7559f97d7"),
    ib_lvl_2_sites=Input("ri.foundry.main.dataset.34d7a6c8-332b-401d-a572-c7c1b591dd4a"),
    smallcell_lvl_2_sites=Input("ri.foundry.main.dataset.7ed8adea-d4a4-4bb7-96fd-b9f207ae903c"),
    mca_lvl_2_sites=Input("ri.foundry.main.dataset.a717def0-53c1-408c-a138-23c55fc6a37c"),
    iwm=Input("ri.foundry.main.dataset.53bb3121-e1f0-4b82-b910-b540db3e1bdf"),
    progcat_mapping_allinone=Input("ri.foundry.main.dataset.e2d8d814-aab3-4b34-ab6f-df4105884894"),
    )
def my_compute_function(ctx, iwm, progcat_mapping_allinone,
                        outinternal_lvl_1, outinternal_lvl_2_sites,
                        ib_lvl_2_sites, smallcell_lvl_2_sites, mca_lvl_2_sites):

    # get the necessary data from pace snapshot
    cols = [F.col("IWM_JOB_NUMBER").alias("iwm_number"),
            F.col("NATIONAL_PROGRAM").alias("national_program"),
            F.col("JOB_SCOPE").alias("job_scope"),
            F.col("JOB_STATUS").alias("status"),
            F.col("ORACLE_PTN").alias("oracle_ptn"),
            F.col("MOD_CODE").alias("mod_code"),
            F.col("SPECTRUM").alias("spectrum"),
            F.col("N_UDF4").alias("n_udf4"),
            F.col("N_UDF5").alias("n_udf5"),
            F.col("PRODUCT_GROUP").alias("product_group"),
            F.col("PRODUCT_SUB_GROUP").alias("product_subgroup"),
            F.col("PLANNING_NUMBER").alias("planning_number"),
            F.col("PLANNING_STATUS").alias("iplan_status"),
            F.col("FA_LOCATION_CODE").alias("fa_location_code"),
            F.col("ONAIR_ACTUAL_END_DATE").alias("onair_actual"),
            F.col("ONAIR_PLAN_END_DATE").alias("onair_forecast"),
            F.col("JOB_CATEGORY").alias("job_category"),
            F.col("ALLOCATION").alias("allocation"),
            F.col("SOLUTION").alias("solution"),
            F.col("NEW_SITE_BUILD").alias("new_site_build"),
            F.col("ASSOCIATED_FA").alias("associated_fa"),
            F.col("1220T_ACTUAL").alias("1220t_actual"),
            F.col("COMMITMENT_DATE").alias("commitment_date"),
            F.col("SCOPE_NAME").alias("scope_name"),
            ]

    iwm_df = iwm.dataframe().select(*cols).distinct()
    iwm_df = iwm_df.withColumn("allocation", F.when(F.col("allocation").isNull(), F.lit("NULL"))
                                              .otherwise(F.col("allocation")))

    # Catpture the Level 1 tagging required for MCA Sites tagging
    outinternal_lvl_1_df = outinternal_lvl_1.dataframe()
    outinternal_lvl_1_df = outinternal_lvl_1_df.withColumnRenamed('program', 'level1_program')

    # Get the matching job's attributes
    iwm_df = iwm_df.join(
        outinternal_lvl_1_df,
        "iwm_number",
        "left"
    )

    # Grap MPT AllInOne config changes
    progcat_mapping_allinone_df = progcat_mapping_allinone.dataframe()

    # Filter the programs for Level 2 tagging
    progcat_mapping_allinone_df = progcat_mapping_allinone_df.where("coalesce(Filter_Level,'1') = '2'")

    # Get the program details
    program_df = progcat_mapping_allinone_df.select(F.col("Program").alias("program")).distinct()

    # Get the program's rollup details
    prgroll_df = progcat_mapping_allinone_df.select(F.col("Program").alias("program"),
                F.col("Rollup").alias("rollup")) \
                .distinct() \
                .where('Rollup != ""')

    # Get the program's National jobScope Task Mappings
    prgjsmapping_df = progcat_mapping_allinone_df.select(F.col("Program").alias("program"),
                F.col("NationalProgram").alias("national_program"),
                F.col("JobScope").alias("job_scope")) \
                .distinct() \
                .where('NationalProgram != "" or JobScope != ""')

    # Capture the filter details and split into levels
    prgfilters_df = progcat_mapping_allinone_df.select(F.col("Program").alias("program"),
                F.col("Filter").alias("filter")) \
                .distinct() \
                .where("Filter != ''")

    # ----------------- Merge the MCA, SmallCell and IB Sites here -----------------
    mca_lvl_2_sites_df = mca_lvl_2_sites.dataframe()
    smallcell_lvl_2_sites_df = smallcell_lvl_2_sites.dataframe()
    ib_lvl_2_sites_df = ib_lvl_2_sites.dataframe()

    out_df = (
        iwm_df
        .join(mca_lvl_2_sites_df, 'iwm_number', 'left')
        .join(smallcell_lvl_2_sites_df, 'iwm_number', 'left')
        .join(ib_lvl_2_sites_df, 'iwm_number', 'left')
    )

    # ----------------- Program Category SmallCell Sites tagging ENDs here -----------------

    # apply Filters to populate the Level-1 Programs
    out_df = applyFilters(ctx, out_df, program_df, prgjsmapping_df, prgfilters_df)

    # Get the spl Rollup logic for IB Sites into "IB-All In Jobs"
    ib_out_df = out_df.filter(F.col("program").isin('IB-BAU Mods Sites_C', 'IB-BAU Mods Sites_PA',
        'IB-NSB Sites_C', 'IB-NSB Sites_PA', 'IB-Nokia Swaps Sites_C', 'IB-Nokia Swaps Sites_PA',
        'IB-Ericsson Modernization Sites_C', 'IB-Ericsson Modernization Sites_PA'))

    # get the distint FA locations for IB Sites
    ib_out_df = ib_out_df.select("iwm_number").distinct()

    # reset the dates to valid
    iwm_df = iwm_df \
        .withColumn("onair_actual", F.to_date(F.col("onair_actual"))) \
        .withColumn("onair_forecast", F.to_date(F.col("onair_forecast")))

    # get the distint FA locations for IB Sites
    ib_out_df = (
        ib_out_df
        .join(iwm_df, "iwm_number", "left")
        .withColumn("yr",
        F.when(
        F.coalesce(F.col("onair_actual"), F.col("onair_forecast")).isNotNull(),
        F.year(F.coalesce(F.col("onair_actual"), F.col("onair_forecast")))
        ).otherwise(None))
    .select(F.col("fa_location_code"), F.col("yr")).distinct()
    )

    # Filter out 2023 and Prior Year jobs
    ib_out_df = ib_out_df.where("coalesce(yr,2023) > 2023")

    ib_out_df = (
        ib_out_df
        .join(iwm_df, "fa_location_code", "inner")
        .select(["iwm_number", "fa_location_code", "commitment_date", "onair_forecast", "onair_actual", "yr"])
        .distinct()
    ).where("((commitment_date is not null and year(commitment_date) = yr) or \
            (onair_forecast is not null and year(onair_forecast) = yr) or \
            (onair_actual is not null and year(onair_actual) = yr)) and \
        national_program like 'IB-%' and national_program != 'IB-Vendor Direct'")

    ib_out_df = (
        ib_out_df
        .withColumn("program", F.lit("IB-All In Jobs"))
        .select("iwm_number", "program")
        )

    # apply IB rollup changes
    out_df = out_df.unionByName(ib_out_df)

    # apply rollup changes
    rollup_df = rollup_crp(prgroll_df)

    out_df2 = (
        out_df
        .join(rollup_df, "program", "inner")
        .withColumn("program", F.col("rollup_program"))
        .drop("rollup_program")
    )

    # apply rollup changes
    out_df = out_df.unionByName(out_df2).distinct()

    # Overall Level 1 Changes
    outinternal_lvl_2_sites.write_dataframe(out_df)
