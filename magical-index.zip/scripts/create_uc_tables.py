"""
Create Unity Catalog Delta tables for Magical Index.

Reads configuration from environment variables (you can set them in a local .env file):

Required for connection:
- DATABRICKS_HOST        e.g. https://adb-<workspace-id>.<region>.azuredatabricks.net
- DATABRICKS_HTTP_PATH   e.g. /sql/1.0/warehouses/<warehouse-id>

Authentication (one of the following):
- Service Principal (OAuth M2M) — for Databricks Apps deployment:
    DATABRICKS_CLIENT_ID, DATABRICKS_CLIENT_SECRET
- Personal Access Token (PAT) — for local development:
    DATABRICKS_TOKEN   DO NOT COMMIT THIS.

Location config:
- UC_CATALOG             e.g. cdo_catalog
- UC_SCHEMA              e.g. magical_index

Optional (with defaults shown):
- MAGICAL_INDEX_RID_TABLE = gandalf-magical-index-rid
- MAGICAL_INDEX_REL_TABLE = gandalf-magical-index-rel

Usage (Windows PowerShell):
  # In project root (magical_index/) and with .venv activated
  python -m pip install -r requirements.txt
  python scripts/create_uc_tables.py

This script is idempotent: it creates catalog/schema if missing and creates the two
Delta tables if they do not already exist.
"""
from __future__ import annotations

import os
import sys
from dataclasses import dataclass

from databricks import sql as dbsql

# For local development, load .env if present
# In Databricks Apps, environment variables come from app.yaml
if os.path.exists(".env"):
    from dotenv import load_dotenv
    load_dotenv()


@dataclass
class UCConfig:
    host: str
    http_path: str
    catalog: str
    schema: str
    rid_table: str = "gandalf-magical-index-rid"
    rel_table: str = "gandalf-magical-index-rel"
    log_table: str = "gandalf-magical-index-log"

    @classmethod
    def from_env(cls) -> "UCConfig":
        missing = []
        host = os.getenv("DATABRICKS_HOST") or ""
        http_path = os.getenv("DATABRICKS_HTTP_PATH") or ""
        catalog = os.getenv("UC_CATALOG") or ""
        schema = os.getenv("UC_SCHEMA") or ""
        rid = os.getenv("MAGICAL_INDEX_RID_TABLE", "gandalf-magical-index-rid")
        rel = os.getenv("MAGICAL_INDEX_REL_TABLE", "gandalf-magical-index-rel")
        log = os.getenv("MAGICAL_INDEX_LOG_TABLE", "gandalf-magical-index-log")
        for name, val in (
            ("DATABRICKS_HOST", host),
            ("DATABRICKS_HTTP_PATH", http_path),
            ("UC_CATALOG", catalog),
            ("UC_SCHEMA", schema),
        ):
            if not val:
                missing.append(name)
        if missing:
            raise RuntimeError(
                f"Missing required environment variables: {', '.join(missing)}. "
                "Set them in your environment or a local .env (never commit secrets)."
            )
        return cls(host=host, http_path=http_path, catalog=catalog, schema=schema, rid_table=rid, rel_table=rel, log_table=log)


def q_ident(name: str) -> str:
    """Quote an identifier with backticks to allow hyphens and reserved words."""
    return f"`{name}`"


def create_objects(cfg: UCConfig) -> None:
    qual_schema = f"{q_ident(cfg.catalog)}.{q_ident(cfg.schema)}"
    rid_full = f"{qual_schema}.{q_ident(cfg.rid_table)}"
    rel_full = f"{qual_schema}.{q_ident(cfg.rel_table)}"
    log_full = f"{qual_schema}.{q_ident(cfg.log_table)}"

    # Desired column specs (name, type)
    rid_columns = [
        ("resource_id", "STRING"),
        ("resource_name", "STRING"),
        ("location", "STRING"),
        ("resource_type", "STRING"),
        ("resource_status", "STRING"),
        ("last_by", "STRING"),
        ("last_update_time", "TIMESTAMP"),
    ]

    rel_columns = [
        ("upstream_resource_id", "STRING"),
        ("downstream_resource_id", "STRING"),
        ("relationship_type", "STRING"),
        ("notes", "STRING"),
    ]

    log_columns = [
        ("log_id", "STRING"),
        ("resource_id", "STRING"),
        ("action", "STRING"),
        ("actor_type", "STRING"),
        ("actor_name", "STRING"),
        ("details", "STRING"),
        ("timestamp", "TIMESTAMP"),
    ]

    create_rid_sql = f"""
        CREATE TABLE IF NOT EXISTS {rid_full} (
            resource_id STRING NOT NULL,
            resource_name STRING NOT NULL,
            location STRING,
            resource_type STRING NOT NULL,
            resource_status STRING NOT NULL,
            last_by STRING NOT NULL,
            last_update_time TIMESTAMP,
            PRIMARY KEY (resource_id)
        )
        USING DELTA
    """.strip()

    create_rel_sql = f"""
        CREATE TABLE IF NOT EXISTS {rel_full} (
            upstream_resource_id STRING NOT NULL,
            downstream_resource_id STRING NOT NULL,
            relationship_type STRING NOT NULL,
            notes STRING,
            PRIMARY KEY (upstream_resource_id, downstream_resource_id, relationship_type)
        )
        USING DELTA
    """.strip()

    create_log_sql = f"""
        CREATE TABLE IF NOT EXISTS {log_full} (
            log_id STRING NOT NULL,
            resource_id STRING NOT NULL,
            action STRING NOT NULL,
            actor_type STRING NOT NULL,
            actor_name STRING NOT NULL,
            details STRING,
            timestamp TIMESTAMP,
            PRIMARY KEY (log_id)
        )
        USING DELTA
    """.strip()

    def fetch_existing_columns(cur, table_fqn: str) -> set[str]:
        """Return a set of existing column names (lowercased) for a table.

        Uses SHOW COLUMNS which returns a single column list of column names.
        """
        cur.execute(f"SHOW COLUMNS IN {table_fqn}")
        rows = cur.fetchall()
        return {str(r[0]).lower() for r in rows}

    def ensure_table_and_columns(cur, table_fqn: str, create_sql: str, desired: list[tuple[str, str]]):
        # Create table if missing
        cur.execute(create_sql)
        # Compute missing columns
        existing_cols = fetch_existing_columns(cur, table_fqn)
        missing = [(n, t) for (n, t) in desired if n.lower() not in existing_cols]
        if missing:
            add_cols = ", ".join(f"{n} {t}" for (n, t) in missing)
            alter_sql = f"ALTER TABLE {table_fqn} ADD COLUMNS ({add_cols})"
            print(f"Executing: ALTER ... ADD COLUMNS for {table_fqn} -> {', '.join(n for n, _ in missing)}")
            cur.execute(alter_sql)

    def ensure_pk(cur, table_fqn: str, name: str, cols: str):
        """Best-effort add a PRIMARY KEY constraint. Ignored if already exists or unsupported."""
        try:
            cur.execute(f"ALTER TABLE {table_fqn} ADD CONSTRAINT {name} PRIMARY KEY ({cols})")
            print(f"Executing: ALTER TABLE {table_fqn} ADD CONSTRAINT {name} PRIMARY KEY ({cols})")
        except Exception as e:  # noqa: BLE001 - ignore if already exists/unsupported
            print(f"Note: could not add PRIMARY KEY {name} on {table_fqn}: {e}")

    print("Connecting to Databricks SQL endpoint...")
    # Use shared auth module (service principal or PAT, auto-detected)
    from app.services.db_auth import get_connection

    with get_connection(host=cfg.host, http_path=cfg.http_path) as conn:
        with conn.cursor() as cur:
            # Select catalog and ensure schema exists
            print(f"Executing: USE CATALOG {cfg.catalog} ...")
            cur.execute(f"USE CATALOG {q_ident(cfg.catalog)}")
            print(f"Executing: CREATE SCHEMA IF NOT EXISTS {cfg.catalog}.{cfg.schema} ...")
            cur.execute(f"CREATE SCHEMA IF NOT EXISTS {qual_schema}")

            # Ensure tables and add any missing columns
            ensure_table_and_columns(cur, rid_full, create_rid_sql, rid_columns)
            ensure_table_and_columns(cur, rel_full, create_rel_sql, rel_columns)
            ensure_table_and_columns(cur, log_full, create_log_sql, log_columns)
            # Best-effort: ensure PK constraints on existing tables
            ensure_pk(cur, rid_full, "pk_resource_id", "resource_id")
            ensure_pk(cur, rel_full, "pk_relationship_edge", "upstream_resource_id, downstream_resource_id, relationship_type")
            ensure_pk(cur, log_full, "pk_log_id", "log_id")
    print("Done. UC objects ensured:")
    print(f"  Schema: {cfg.catalog}.{cfg.schema}")
    print(f"  Table (resources): {cfg.rid_table}")
    print(f"  Table (relationships): {cfg.rel_table}")
    print(f"  Table (activity_logs): {cfg.log_table}")


def main() -> int:
    try:
        cfg = UCConfig.from_env()
        create_objects(cfg)
        return 0
    except Exception as exc:  # noqa: BLE001 (simple CLI)
        print(f"ERROR: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
