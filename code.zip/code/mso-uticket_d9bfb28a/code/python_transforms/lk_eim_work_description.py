from pyspark.sql import functions as F
from transforms.api import transform_df, Input, Output


@transform_df(
    Output("/Innovation Lab/[ETL] Ticketing/logic/datasets/aotstm/lk_eim_work_description"),
    eim_work=Input("ri.foundry.main.dataset.f664bd7d-7edf-4cf3-97fb-2a2784cc572c"),
)
def compute(eim_work):
    eim_work = (
        eim_work
        .filter(F.col("related_ams_ticket").isNotNull())
        .groupby(F.col("related_ams_ticket"))
        .agg(
            F.concat_ws("", F.collect_set("description_of_work")).alias("all_work_description")
        )
    )
    return eim_work
