from transforms.api import transform, Input, Output
from utility.column_clean import clean_columns, lowercase_columns


@transform(
   out=Output("/Innovation Lab/[Source] Vertica IQI/data/clean/mgrs_reference_full"),
   df=Input("ri.foundry.main.dataset.77c22766-183a-4339-b67c-20ebbc8404df"),
)
def my_compute_function(df, out):
    df = clean_columns(
        df.dataframe(),
        strip_columns=strip_columns,
        integer_columns=cast_to_integer_columns,
        double_columns=cast_to_double_columns,
        decimal_columns=cast_to_decimal_columns,
        timestamp_columns=cast_to_timestamp_from_long_columns,
        datetime_columns=cast_to_timestamp_columns,
        datetime_format=datetime_format,
        date_columns=cast_to_date_columns,
        date_format=date_format,
        id_columns=cast_to_string_columns,
        integer_from_num_columns=cast_to_integer_from_decimal_columns
    )
    df = lowercase_columns(df)
    out.write_dataframe(df)


date_format = 'yyyy-MM-dd'
datetime_format = 'yyyy-MM-dd HH:mm:ss'

cast_to_date_columns = []
cast_to_timestamp_columns = []
cast_to_timestamp_from_long_columns = []
cast_to_integer_columns = []
cast_to_double_columns = []
cast_to_decimal_columns = []
cast_to_string_columns = []
cast_to_integer_from_decimal_columns = []
strip_columns = []
