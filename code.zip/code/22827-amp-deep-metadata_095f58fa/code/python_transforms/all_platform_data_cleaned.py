from transforms.api import transform_df, Input, Output


@transform_df(
    Output(
        "ri.foundry.main.dataset.890e7cbb-45f2-437e-8345-38029c577c54",
        sever_permissions=True,
    ),
    all_data=Input(
        "ri.foundry.main.dataset.61a953b1-85a0-41ca-a970-c32def1c5f4e"
    ),
)
def my_compute_function(all_data):
    # Removing raw datasets as they can sometimes have sensitive data elements in their schema
    df = all_data.filter(all_data["magritte_extract_rid"].isNull())
    # df = df.drop('magritte_extract_rid', 'magritte_extract_name', 'magritte_source_name', 'magritte_source_type', 'magritte_source_rid', 'magritte_subfolder') # Downstream datasets rely on these columns

    # filter our datasets in personal folders
    df = df.filter(~df["project_name"].contains("@att.com"))

    # filtering out un-important datasets and blank datasets
    df = df.filter(~(df["dataset_name"].contains("New Dataset")))
    df = df.filter(~(df["schema"].isNull() & df["column_stats"].isNull()))

    return df
