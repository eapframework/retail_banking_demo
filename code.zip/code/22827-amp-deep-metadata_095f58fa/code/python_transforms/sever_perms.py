from transforms.api import transform_df, Input, Output, Pipeline

metrics = [
    "/Innovation Lab/Usage Statistics/data/resources/viewed_report_agg",
    "/Innovation Lab/Usage Statistics/data/resources/jobs_run_agg",
    #"/Innovation Lab/Usage Statistics/data/resources/viewed_dataset_preview_agg",
    "/Innovation Lab/Usage Statistics/data/resources/viewed_contour_agg",
    "/Innovation Lab/Usage Statistics/data/users/active_users_vp_org_agg",
    "/Innovation Lab/Data Governance/Data Ingestion Requests/Reporting/cycle_time_metrics",
    "/Innovation Lab/Data Governance/Data Ingestion Requests/Admin/data_ingestion_request_form_dataset",
    "/Innovation Lab/Usage Statistics/data/users/vp_details",
    "/Innovation Lab/[Source] Webphone/data/clean/webphone_with_emails",
    "/Innovation Lab/Usage Statistics/data/users/active_users",
    "/Innovation Lab/Data Governance/Data Ingestion Requests/Reporting/cycletime_statuses",
    "/Innovation Lab/Data Governance/Data Ingestion Requests/Admin/data_ingestion_request_form_writeback_dataset",
    "/Innovation Lab/Usage Statistics/data/resources/jobs_worker_type",
    "/Innovation Lab/Platform Reporting/data/datasets/ontology_objects",
    "/Innovation Lab/Platform Reporting/data/datasets/ontology_workflows",
]


def generate_transforms():
    transforms = []
    for metric in metrics:
        @transform_df(
            Output("/Innovation Lab/Platform Reporting/data/severed_imports/" + metric.split("/")[-1] + '_sp', sever_permissions=True),
            metric=Input(metric),
        )
        def compute_function(metric):
            return metric
        transforms.append(compute_function)
    return transforms


pipeline = Pipeline()
transforms = generate_transforms()
pipeline.add_transforms(*transforms)