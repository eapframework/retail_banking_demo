from functools import reduce
from transforms.api import transform, Output, Input, configure
from pyspark.sql import DataFrame, functions as F
from pyspark.sql.window import Window
from pyspark.sql.types import StructType, StructField, StringType

SPARK_PROFILES = [
        'DRIVER_MEMORY_EXTRA_EXTRA_LARGE',
        'DRIVER_CORES_LARGE',
        'EXECUTOR_MEMORY_LARGE',
        'EXECUTOR_CORES_LARGE',
        'NUM_EXECUTORS_32',
        'EXECUTOR_MEMORY_OVERHEAD_LARGE',
        'DYNAMIC_ALLOCATION_DISABLED'
]


@configure(profile=SPARK_PROFILES)
@transform(
    # replace this with your output dataset path
        dev_program_category_mapping_v2=Output("ri.foundry.main.dataset.a88082cf-51ca-48ad-9f90-912d951b06b1"),
        progcat_mapping_allinone=Input("ri.foundry.main.dataset.b881766d-ae91-43f7-a5f2-49c353377ca0"),
    )
def my_compute_function(ctx, progcat_mapping_allinone, dev_program_category_mapping_v2):

    # Grap MPT AllInOne config changes for Valid filter Lines
    progcat_mapping_allinone_df = progcat_mapping_allinone.dataframe().where("coalesce(__is_deleted,False) = False")

    '''
    progcat_mapping_allinone_df = progcat_mapping_allinone.dataframe() \
        .where("category in ('MCA','NSB')")
    '''

    # Set the Detfault values for those missing values
    progcat_mapping_allinone_df = progcat_mapping_allinone_df.withColumn("is_national_program_excluded",
            F.when(F.col("is_national_program_excluded").isNull(), F.lit(False))
             .otherwise(F.col("is_national_program_excluded")))
    progcat_mapping_allinone_df = progcat_mapping_allinone_df.withColumn("is_jobscope_excluded",
            F.when(F.col("is_jobscope_excluded").isNull(), F.lit(False))
             .otherwise(F.col("is_jobscope_excluded")))
    progcat_mapping_allinone_df = progcat_mapping_allinone_df.withColumn("is_mod_code_excluded",
            F.when(F.col("is_mod_code_excluded").isNull(), F.lit(False))
             .otherwise(F.col("is_mod_code_excluded")))
    progcat_mapping_allinone_df = progcat_mapping_allinone_df.withColumn("is_allocation_excuded",
            F.when(F.col("is_allocation_excuded").isNull(), F.lit(False))
             .otherwise(F.col("is_allocation_excuded")))
    progcat_mapping_allinone_df = progcat_mapping_allinone_df.withColumn("is_new_sitebuild_excuded",
            F.when(F.col("is_new_sitebuild_excuded").isNull(), F.lit(False))
             .otherwise(F.col("is_new_sitebuild_excuded")))
    progcat_mapping_allinone_df = progcat_mapping_allinone_df.withColumn("is_product_group_excuded",
            F.when(F.col("is_product_group_excuded").isNull(), F.lit(False))
             .otherwise(F.col("is_product_group_excuded")))
    progcat_mapping_allinone_df = progcat_mapping_allinone_df.withColumn("is_product_subgroup_excuded",
            F.when(F.col("is_product_subgroup_excuded").isNull(), F.lit(False))
             .otherwise(F.col("is_product_subgroup_excuded")))

    # Get the Program attributes
    program_df = progcat_mapping_allinone_df.select(F.col("program")).distinct().where('program != ""')
    program_filter_df = progcat_mapping_allinone_df.select(F.col("program"), F.col("sql_query_text"),
                F.col("filter_level")).distinct().where('sql_query_text != ""')
    prg_js_mapping_df = progcat_mapping_allinone_df.select(F.col("program"), F.col("category"),
                F.col("national_program"), F.col("job_scope"), F.col("is_jobscope_excluded")).distinct() \
                .where('(national_program != "" or job_scope != "") and is_national_program_excluded = False')

    prg_js_mapping_df = prg_js_mapping_df.withColumn("job_scope",
            F.when(F.col("is_jobscope_excluded") == F.lit(True), F.lit(""))
            .otherwise(F.col("job_scope")))

    prg_js_mapping_df = prg_js_mapping_df.select(F.col("program"), F.col("category"),
                F.col("national_program"), F.col("job_scope"))

    program_audit_df = progcat_mapping_allinone_df.groupBy(F.col("program")) \
                    .agg(F.min(F.col("create_timestamp")).alias("create_timestamp"),
                         F.max(F.col("edit_time")).alias("edit_time"))

    progcat_mapping_allinone_df = progcat_mapping_allinone_df.withColumn("notes", F.lit(None))

    program_notes_df = progcat_mapping_allinone_df.groupBy(F.col("program")) \
                    .agg(F.concat_ws(", ", F.collect_list("notes")).alias("notes"))

    program_notes_df = program_notes_df.withColumn(
            "notes",
            F.when(F.col("program") == 'FNET', F.lit('Test FNET Notes'))
            .when(F.col("program") == 'MCA HW Sites (Nokia Swaps)_C', F.lit('Test MCA HW Sites (Nokia Swaps)_C Notes'))
            .otherwise(F.lit(None)))
    program_notes_df = program_notes_df.where("notes !=''")

    # get the collected Rollup data
    program_roll_df = getProgramSQLRollups(ctx, progcat_mapping_allinone_df)

    # Rank the category if there is more that one
    program_category_df = progcat_mapping_allinone_df.select(F.col("program"), F.col("category")).distinct()
    partition = Window.partitionBy("program").orderBy(['category'])
    program_category_df = (
        program_category_df
        .withColumn('cat_rank', F.row_number().over(partition))
    )

    # Filter the first and Other Category
    program_cat_other_df = program_category_df.filter(F.col('cat_rank') > 1)
    program_category_df = program_category_df.filter(F.col('cat_rank') == 1)

    # Get NP and JP Ranking to add unique data if there is more than one.
    partition = Window.partitionBy("program").orderBy(['national_program', 'job_scope'])
    prg_js_mapping_df = (
        prg_js_mapping_df
        .withColumn('js_rank', F.row_number().over(partition))
    )

    '''
    partition_1 = Window.partitionBy("program").orderBy(['national_program'])
    prg_js_mapping_df_1 = (
        prg_js_mapping_df
        .withColumn('js_rank', F.row_number().over(partition_1))
        .filter('job_scope = ""')
    )

    prg_js_mapping_df = prg_js_mapping_df_0.unionByName(prg_js_mapping_df_1, allowMissingColumns=True)
    '''

    # Filter the first and Other Category
    prg_js_mapping_other_df = prg_js_mapping_df.filter(F.col('js_rank') > 1)
    prg_js_mapping_df = prg_js_mapping_df.select(['program', 'national_program', 'job_scope']) \
        .filter(F.col('js_rank') == 1)

    # call the function to Get all the Filters combined except NP and JobScope
    sql_filter_df = getProgramSQLFilter(ctx, progcat_mapping_allinone_df)

    # combine all dataframe into a final BRD
    final_df = program_df.join(program_category_df, on="program", how="left") \
                         .join(prg_js_mapping_df, on="program", how="left") \
                         .join(program_roll_df, on="program", how="left") \
                         .join(program_filter_df, on="program", how="left") \
                         .join(sql_filter_df, on="program", how="left") \
                         .join(program_audit_df, on="program", how="left") \
                         .join(program_notes_df, on="program", how="left")

    # combine extra category into a final BRD
    final_df = final_df.unionByName(prg_js_mapping_other_df, allowMissingColumns=True)
    final_df = final_df.unionByName(program_cat_other_df, allowMissingColumns=True)

    final_df = final_df.withColumn("job_scope", F.expr("case when national_program is not null and \
        (job_scope = '' or job_scope is null) then 'ALL' else job_scope end"))

    final_df = final_df.select(F.col("program").alias("Program"),
                         F.col("category").alias("Category"),
                         F.col("national_program").alias("NationalProgram"),
                         F.col("job_scope").alias("JobScope"),
                         F.col("sql_query").alias("Filter"),
                         F.col("filter_level").alias("Filter_Level"),
                         F.col("rollups").alias("Rollup"),
                         F.col("notes").alias("Notes"),
                         F.col("create_timestamp").alias("CreatedOn"),
                         F.col("edit_time").alias("ModifiedOn"),
                         ).distinct()

    # Overall Combined BRD changes based on WorkShop Changes
    dev_program_category_mapping_v2.write_dataframe(final_df)


def getProgramSQLFilter(ctx, progcat_mapping_allinone_df):  # noqa: C901

    # Get the Program attributes
    program_df = progcat_mapping_allinone_df.select(F.col("program").alias("program")).distinct().where('program != ""')

    # Get the program's National jobScope Task Mappings
    prg_js_mapping_df = progcat_mapping_allinone_df.select(F.col("program").alias("program"),
                F.col("national_program").alias("national_program"),
                F.col("job_scope").alias("job_scope"),
                F.col("is_national_program_excluded").alias("nat_exc"),
                F.col("is_jobscope_excluded").alias("job_exc")) \
                .distinct() \
                .where('(national_program != "" and is_national_program_excluded  = True) or \
                        (job_scope != "" and is_jobscope_excluded = True)')

    # Get the program's ModCode Mappings
    prg_modcode_mapping_df = progcat_mapping_allinone_df.select(F.col("program").alias("program"),
                F.col("mod_code").alias("mod_code"),
                F.col("is_mod_code_excluded").alias("mod_exc")) \
                .distinct() \
                .where('mod_code != ""')

    # Get the program's ALLOCATION mappings
    prg_allocation_mapping_df = progcat_mapping_allinone_df.select(F.col("program").alias("program"),
                F.col("allocation").alias("allocation"),
                F.col("is_allocation_excuded").alias("all_exc")) \
                .distinct() \
                .where('allocation != ""')

    # Get the program's NewSiteBuild Mappings
    prg_nsb_mapping_df = progcat_mapping_allinone_df.select(F.col("program").alias("program"),
                F.col("new_site_build").alias("new_site_build"),
                F.col("is_new_sitebuild_excuded").alias("nsb_exc")) \
                .distinct() \
                .where('new_site_build != ""')

    # Get the program's National jobScope Task Mappings
    prg_pgsg_mapping_df = progcat_mapping_allinone_df.select(F.col("program").alias("program"),
                F.col("product_group").alias("product_group"),
                F.col("product_sub_group").alias("product_subgroup"),
                F.col("is_product_group_excuded").alias("prg_exc"),
                F.col("is_product_subgroup_excuded").alias("prgs_exc")) \
                .distinct() \
                .where('product_group != "" or product_sub_group != ""')

    # Capture the filter details and split into levels
    prg_filters_df = progcat_mapping_allinone_df.select(F.col("program").alias("program"),
                F.col("job_category").alias("job_category"),
                F.col("job_status").alias("status"),
                F.col("oracle_ptn").alias("oracle_ptn"),
                F.col("spectrum").alias("spectrum"),
                F.col("sql_query_text").alias("sql_filter")) \
                .distinct() \
                .where("job_category != '' or job_status != '' or \
                        oracle_ptn != '' or spectrum != '' or \
                        trim(sql_query_text) != ''")

    df_lists = []

    # initialize and create datafram to collect the SQL details
    schema = StructType([
        StructField("program", StringType(), True),
        StructField("sql_query", StringType(), True)
    ])

    # Provides an initial empty DataFrame with the same schema
    out_df = ctx.spark_session.createDataFrame([], schema)

    # crpColl_df = program_df.select("program").distinct().toLocalIterator()
    crpColl_df = program_df.select("program").distinct().collect()

    for rcrp in crpColl_df:
        program = rcrp["program"]
        print("Pprogram :" + program)
        filter_js_df = prg_js_mapping_df.filter(F.col("program") == program).distinct()
        filter_mod_df = prg_modcode_mapping_df.filter(F.col("program") == program).distinct()
        filter_all_df = prg_allocation_mapping_df.filter(F.col("program") == program).distinct()
        filter_nsb_df = prg_nsb_mapping_df.filter(F.col("program") == program).distinct()
        filter_pgsg_df = prg_pgsg_mapping_df.filter(F.col("program") == program).distinct()
        filter_fil_df = prg_filters_df.filter(F.col("program") == program).distinct()

        # declare the temp variables
        condition = ""

        # ======================= NationalProgram and JobScope exclution check =======================
        np_lists = ""
        js_lists = ""

        np_list = filter_js_df.select('national_program').distinct().where("nat_exc = True")
        np_list = [row.national_program for row in np_list.select('national_program').collect()]
        if len(np_list) > 0:
            np_lists = "', '".join(np_list)

        js_list = filter_js_df.select('job_scope').distinct().where("job_exc = True")
        js_list = [row.job_scope for row in js_list.select('job_scope').collect()]
        if len(js_list) > 0:
            js_lists = "', '".join(js_list)

        if np_lists:
            np_lists = "national_program not in ('" + np_lists + "')"
        if js_lists:
            js_lists = "job_scope not in ('" + js_lists + "')"

        # Add the valid NP or JS Exclutions
        if np_lists != "":
            if condition != "":
                condition = condition + " AND " + np_lists
            else:
                condition = np_lists

        if js_lists != "":
            if condition != "":
                condition = condition + " AND " + js_lists
            else:
                condition = js_lists

        # ======================= Add ModCode filter details =======================
        md_lists = ""
        md_e_lists = ""

        md_list = filter_mod_df.select('mod_code').distinct().where("mod_exc = False")
        md_list = [row.mod_code for row in md_list.select('mod_code').collect()]
        if len(md_list) > 0:
            md_lists = "', '".join(md_list)

        md_e_list = filter_mod_df.select('mod_code').distinct().where("mod_exc = True")
        md_e_list = [row.mod_code for row in md_e_list.select('mod_code').collect()]
        if len(md_e_list) > 0:
            md_e_lists = "', '".join(md_e_list)

        if md_lists:
            md_lists = "mod_code in ('" + md_lists + "')"
        if md_e_lists:
            md_e_lists = "mod_code not in ('" + md_e_lists + "')"

        if md_lists != "":
            if condition != "":
                condition = condition + " AND " + md_lists
            else:
                condition = md_lists

        if md_e_lists != "":
            if condition != "":
                condition = condition + " AND " + md_e_lists
            else:
                condition = md_e_lists

        # ======================= Add ALLOCATION filter details =======================
        all_lists = ""
        all_e_lists = ""

        all_list = filter_all_df.select('allocation').distinct().where("all_exc = False")
        all_list = [row.allocation for row in all_list.select('allocation').collect()]
        if len(all_list) > 0:
            all_lists = "', '".join(all_list)

        all_e_list = filter_all_df.select('allocation').distinct().where("all_exc = True")
        all_e_list = [row.allocation for row in all_e_list.select('allocation').collect()]
        if len(all_e_list) > 0:
            all_e_lists = "', '".join(all_e_list)

        if all_lists:
            all_lists = "allocation in ('" + all_lists + "')"
        if all_e_lists:
            all_e_lists = "allocation not in ('" + all_e_lists + "')"

        # Add the valid Allocation Filters (Include/Exclude)
        if all_lists != "":
            if condition != "":
                condition = condition + " AND " + all_lists
            else:
                condition = all_lists

        if all_e_lists != "":
            if condition != "":
                condition = condition + " AND " + all_e_lists
            else:
                condition = all_e_lists

        # ======================= Add NewSiteBuild filter details =======================
        nsb_lists = ""
        nsb_e_lists = ""

        nsb_list = filter_nsb_df.select('new_site_build').distinct().where("nsb_exc = False")
        nsb_list = [row.new_site_build for row in nsb_list.select('new_site_build').collect()]
        if len(nsb_list) > 0:
            nsb_lists = "', '".join(nsb_list)

        nsb_e_list = filter_nsb_df.select('new_site_build').distinct().where("nsb_exc = True")
        nsb_e_list = [row.new_site_build for row in nsb_e_list.select('new_site_build').collect()]
        if len(nsb_e_list) > 0:
            nsb_e_lists = "', '".join(nsb_e_list)

        if nsb_lists:
            nsb_lists = "new_site_build in ('" + nsb_lists + "')"
        if nsb_e_lists:
            nsb_e_lists = "new_site_build not in ('" + nsb_e_lists + "')"

        # Add the valid NewSiteBuild Filters (Include/Exclude)
        if nsb_lists != "":
            if condition != "":
                condition = condition + " AND " + nsb_lists
            else:
                condition = nsb_lists

        if nsb_e_lists != "":
            if condition != "":
                condition = condition + " AND " + nsb_e_lists
            else:
                condition = nsb_e_lists

        # ======================= ProductGroup and ProductSubGroup exclution check =======================
        pgpsg_filter = ""
        pg_lists = ""
        psg_lists = ""

        pg_list = filter_pgsg_df.select('product_group').distinct().where("prg_exc = True")
        pg_list = [row.product_group for row in pg_list.select('product_group').collect()]
        if len(pg_list) > 0:
            pg_lists = "', '".join(pg_list)

        psg_list = filter_pgsg_df.select('product_subgroup').distinct().where("prgs_exc = True")
        psg_list = [row.product_subgroup for row in psg_list.select('product_subgroup').collect()]
        if len(psg_list) > 0:
            psg_lists = "', '".join(psg_list)

        if pg_lists:
            pg_lists = "product_group not in ('" + pg_lists + "')"
        if psg_lists:
            psg_lists = "product_subgroup not in ('" + psg_lists + "')"

        # Add the valid PG or PSG Exclutions
        if pg_lists != "":
            if condition != "":
                condition = condition + " AND " + pg_lists
            else:
                condition = pg_lists

        if psg_lists != "":
            if condition != "":
                condition = condition + " AND " + psg_lists
            else:
                condition = psg_lists

        # other PG and PSG filter details
        filter_js_lt = prg_pgsg_mapping_df.filter(F.col("program") == program).distinct().toLocalIterator()
        for row in filter_js_lt:
            fltr = ""
            if (row["prg_exc"] != True):
                if (row["product_group"] != ""):
                    fltr = fltr + " AND product_group = '{0}'".format(row["product_group"])

            if (row["prgs_exc"] != True):
                if (row["product_subgroup"] != "" and row["product_subgroup"] is not None):
                    fltr = fltr + " AND product_subgroup = '{0}'".format(row["product_subgroup"])

            pgpsg_filter = pgpsg_filter + " OR ( " + fltr[5:] + " ) "

        # Add the valid PG and PSG filters
        if pgpsg_filter != "":
            if condition != "":
                condition = condition + " AND (" + pgpsg_filter[3:] + ") "
            else:
                condition = pgpsg_filter[3:]

        # ======================= Add the generic SQL filter details =======================
        # job_category column filter details
        sql_lists = ""

        sql_list = filter_fil_df.select('job_category').distinct().where("job_category is not null")
        sql_list = [row.job_category for row in sql_list.select('job_category').collect()]
        if len(sql_list) > 0:
            sql_lists = "', '".join(sql_list)

        if sql_lists:
            sql_lists = "job_category in ('" + sql_lists + "')"

        # Add the valid job_category Filters
        if sql_lists != "":
            if condition != "":
                condition = condition + " AND " + sql_lists
            else:
                condition = sql_lists

        # job_status column filter details
        sql_lists = ""

        sql_list = filter_fil_df.select('status').distinct().where("status is not null")
        sql_list = [row.status for row in sql_list.select('status').collect()]
        if len(sql_list) > 0:
            sql_lists = "', '".join(sql_list)

        if sql_lists:
            sql_lists = "status in ('" + sql_lists + "')"

        # Add the valid job_status Filters
        if sql_lists != "":
            if condition != "":
                condition = condition + " AND " + sql_lists
            else:
                condition = sql_lists

        # oracle_ptn column filter details
        sql_lists = ""

        sql_list = filter_fil_df.select('oracle_ptn').distinct().where("oracle_ptn is not null")
        sql_list = [row.oracle_ptn for row in sql_list.select('oracle_ptn').collect()]
        if len(sql_list) > 0:
            sql_lists = "', '".join(sql_list)

        if sql_lists:
            sql_lists = "oracle_ptn in ('" + sql_lists + "')"

        # Add the valid oracle_ptn Filters
        if sql_lists != "":
            if condition != "":
                condition = condition + " AND " + sql_lists
            else:
                condition = sql_lists

        # spectrum column filter details
        sql_lists = ""

        sql_list = filter_fil_df.select('spectrum').distinct().where("spectrum is not null")
        sql_list = [row.spectrum for row in sql_list.select('spectrum').collect()]
        if len(sql_list) > 0:
            sql_lists = "', '".join(sql_list)

        if sql_lists:
            sql_lists = "spectrum in ('" + sql_lists + "')"

        # Add the valid spectrum Filters
        if sql_lists != "":
            if condition != "":
                condition = condition + " AND " + sql_lists
            else:
                condition = sql_lists

        # sql_query_text column filter details
        gen_filers = ""

        filter_fil_df = filter_fil_df.select('sql_filter').distinct().where("sql_filter is not null")
        filter_fil_lt = [row.sql_filter for row in filter_fil_df.select('sql_filter').collect()]
        print(filter_fil_lt)
        if len(filter_fil_lt) > 0:
            gen_filers = " AND ".join(filter_fil_lt)

        print("sql_filter : " + gen_filers)
        if gen_filers != "":
            if condition != "":
                condition = condition + " AND " + gen_filers
            else:
                condition = " ( " + gen_filers + " ) "

        # ======================= consolidate all the changes for final filter =======================
        if (condition and len(condition) > 0):
            print("program : " + program + " :" + condition)
            new_data = ctx.spark_session.createDataFrame([(program, condition)], schema)
            df_lists.append(new_data)

    # Provide an initial empty DataFrame with the same schema
    empty_df = ctx.spark_session.createDataFrame([], schema)

    out_df = (
        reduce(DataFrame.unionByName, df_lists, empty_df)
    ).select("program", "sql_query").distinct()

    return out_df


def getProgramSQLRollups(ctx, progcat_mapping_allinone_df):

    # Get the Program Rollup groupping
    program_roll_df = progcat_mapping_allinone_df.select(F.col("program"), F.col("program_rollup")).distinct() \
        .where('program != "" and program_rollup != ""')

    df_lists = []

    # initialize and create datafram to collect the SQL details
    schema = StructType([
        StructField("program", StringType(), True),
        StructField("rollups", StringType(), True)
    ])

    # Provides an initial empty DataFrame with the same schema
    out_df = ctx.spark_session.createDataFrame([], schema)

    # crpColl_df = program_df.select("program").distinct().toLocalIterator()
    crpColl_df = program_roll_df.select("program").distinct().collect()

    for rcrp in crpColl_df:
        program = rcrp["program"]
        filter_roll_df = program_roll_df.filter(F.col("program") == program).distinct()

        rp_lists = ""
        rp_list = filter_roll_df.select('program_rollup').distinct()
        rp_list = [row.program_rollup for row in rp_list.select('program_rollup').collect()]
        if len(rp_list) > 0:
            rp_lists = ", ".join(rp_list)

        if rp_lists:
            # print("program : " + program + " :" + rp_lists)
            new_data = ctx.spark_session.createDataFrame([(program, rp_lists)], schema)
            df_lists.append(new_data)

    # Provide an initial empty DataFrame with the same schema
    empty_df = ctx.spark_session.createDataFrame([], schema)

    out_df = (
        reduce(DataFrame.unionByName, df_lists, empty_df)
    ).select("program", "rollups").distinct()

    return out_df
