from transforms.api import transform, Input, Output, incremental, configure
from pyspark.sql import functions as F
from pyspark.sql import types as T
import re


@incremental(v2_semantics=True)
@configure(profile="high-memory")
@transform(
    out_data=Output(
        "/Innovation Lab/[Source] Webphone/data/clean/webphone_with_emails",
        sever_permissions=True,
    ),
    df=Input("ri.tables.main.table.ffd21f42-fde0-43e7-9183-931bbcd08817"),
)
#def compute(ctx, df, output):
def my_compute_func(ctx, out_data, df):
    # check that row count did not drastically change
    df_new = df.dataframe(mode="current")
    df_new = df_new.filter(F.col("data_dt") == df_new.agg(F.max("data_dt")).collect()[0][0])
    
    if ctx.is_incremental:
        df_old = out_data.dataframe(mode="current", schema=df_new.schema)
        if df_new.count() < (df_old.count() * 0.98):
            raise ValueError(
                "new row count is: "
                + str(df_new.count())
                + " but old row count was: "
                + str(df_old.count())
            )
    # df_new = df_new.where(F.length(F.col("handle")) <7)
    df_new = convert_to_string_from_timestamp(df_new)
    df_new = df_new.drop(*columnstoDrop)

    df = df_new

    # create column called email and full_name
    df = (
        df.filter(F.col("cpid_record_indicator") != "Y")
        .withColumn("email", F.concat(F.col("handle"), F.lit("@att.com")))
        .withColumn(
            "full_name",
            F.trim(
                F.concat_ws(
                    " ", F.col("last_name"), F.col("first_name"), F.col("middle_name")
                )
            ),
        )
        .withColumn(
            "preferred_full_name",
            F.trim(
                F.concat(
                    F.col("last_name"),
                    F.lit(", "),
                    F.coalesce(
                        F.substring_index(F.col("preferred_name"), " ", 1),
                        F.col("first_name"),
                    ),
                )
            ),
        )
    )

    # filter to remove all users with emails ending in @warnermediagroup, @turner, or @ottermedia
    df = df.filter(
        (~F.col("e_mail").contains("@warnermediagroup")) | F.col("e_mail").isNull()
    )
    df = df.filter((~F.col("e_mail").contains("@turner")) | F.col("e_mail").isNull())
    df = df.filter(
        (~F.col("e_mail").contains("@ottermedia")) | F.col("e_mail").isNull()
    )

    # split cogs_common_org_grouping_sys column
    def split_cogs(cogs):
        return re.findall(".{6}", str(cogs))

    udf_split_cogs = F.udf(split_cogs, T.ArrayType(T.StringType()))
    df = df.withColumn("cogs_splt", udf_split_cogs(df.cogs_common_org_grouping_sys))

    # create temp dictionary of all avps
    avp_condition = df.jt_name.like("%AVP%")
    avp_attuid = df.filter(avp_condition).select(
        "handle", "full_name", "preferred_full_name"
    )
    avp_keypair_rdd = avp_attuid.rdd.map(lambda x: (x[0], x[1]))
    avp_map = avp_keypair_rdd.collectAsMap()  # noqa
    avp_pref_keypair_rdd = avp_attuid.rdd.map(lambda x: (x[0], x[2]))
    avp_pref_map = avp_pref_keypair_rdd.collectAsMap()  # noqa

    # create avp_attuid column
    def find_avp(cogs_splt):
        for cog in reversed(cogs_splt):
            if cog in avp_map:
                return cog

    udf_find_avp = F.udf(find_avp, T.StringType())
    df = df.withColumn("avp_attuid", udf_find_avp(df.cogs_splt))

    def find_avp_name(cogs_splt):
        for cog in reversed(cogs_splt):
            if cog in avp_map:
                return avp_map[cog]

    udf_find_avp_name = F.udf(find_avp_name, T.StringType())
    df = df.withColumn("avp_full_name", udf_find_avp_name(df.cogs_splt))

    def find_avp_pref_name(cogs_splt):
        for cog in reversed(cogs_splt):
            if cog in avp_pref_map:
                return avp_pref_map[cog]

    udf_find_avp_pref_name = F.udf(find_avp_pref_name, T.StringType())
    df = df.withColumn("avp_preferred_full_name", udf_find_avp_pref_name(df.cogs_splt))

    # create temp dictionary of all directors
    director_condition = (df.jt_name.like("DIR%")) & ~(
        (df.jt_name.like("%ASSOC%")) | (df.jt_name.like("%ASSOCIATE%"))
    )
    director_attuid = df.filter(director_condition).select(
        "handle", "full_name", "preferred_full_name"
    )
    director_keypair_rdd = director_attuid.rdd.map(lambda x: (x[0], x[1]))
    director_map = director_keypair_rdd.collectAsMap()  # noqa
    director_pref_keypair_rdd = director_attuid.rdd.map(lambda x: (x[0], x[2]))
    director_pref_map = director_pref_keypair_rdd.collectAsMap()  # noqa

    # create director attuid column
    def find_director(cogs_splt):
        for cog in reversed(cogs_splt):
            if cog in director_map:
                return cog

    udf_find_director = F.udf(find_director, T.StringType())
    df = df.withColumn("director_attuid", udf_find_director(df.cogs_splt))

    def find_director_name(cogs_splt):
        for cog in reversed(cogs_splt):
            if cog in director_map:
                return director_map[cog]

    udf_find_director_name = F.udf(find_director_name, T.StringType())
    df = df.withColumn("director_full_name", udf_find_director_name(df.cogs_splt))

    def find_director_pref_name(cogs_splt):
        for cog in reversed(cogs_splt):
            if cog in director_pref_map:
                return director_pref_map[cog]

    udf_find_director_pref_name = F.udf(find_director_pref_name, T.StringType())
    df = df.withColumn(
        "director_preferred_full_name", udf_find_director_pref_name(df.cogs_splt)
    )

    # create temp dictionary of all area managers
    area_manager_condition = (
        (df.jt_name.like("%AREA MANAGER%"))
        | (df.jt_name.like("%AREA MGR%"))
        | (df.jt_name.like("%ASSOC%"))
        | (df.jt_name.like("%ASSOCIATE%"))
    )
    area_manager_attuid = df.filter(area_manager_condition).select(
        "handle", "full_name", "preferred_full_name"
    )
    area_manager_keypair_rdd = area_manager_attuid.rdd.map(lambda x: (x[0], x[1]))
    area_manager_map = area_manager_keypair_rdd.collectAsMap()  # noqa
    area_manager_pref_keypair_rdd = area_manager_attuid.rdd.map(lambda x: (x[0], x[2]))
    area_manager_pref_map = area_manager_pref_keypair_rdd.collectAsMap()  # noqa

    # create area manager attuid column
    def find_area_manager(cogs_splt):
        for cog in reversed(cogs_splt):
            if cog in area_manager_map:
                return cog

    udf_find_area_manager = F.udf(find_area_manager, T.StringType())
    df = df.withColumn("area_manager_attuid", udf_find_area_manager(df.cogs_splt))

    def find_area_manager_name(cogs_splt):
        for cog in reversed(cogs_splt):
            if cog in area_manager_map:
                return area_manager_map[cog]

    udf_find_area_manager_name = F.udf(find_area_manager_name, T.StringType())
    df = df.withColumn(
        "area_manager_full_name", udf_find_area_manager_name(df.cogs_splt)
    )

    def find_area_manager_pref_name(cogs_splt):
        for cog in reversed(cogs_splt):
            if cog in area_manager_pref_map:
                return area_manager_pref_map[cog]

    udf_find_area_manager_pref_name = F.udf(find_area_manager_pref_name, T.StringType())
    df = df.withColumn(
        "area_manager_preferred_full_name",
        udf_find_area_manager_pref_name(df.cogs_splt),
    )

    # create temp dictionary of all vps
    # vp_condition = (F.col('vp_org_name').isNull()) | (F.col('vp_org_name') == '')
    # vp_condition = F.col('level') == 5)
    vp_condition = (
        (df.jt_name.like("%VP%")) | (df.jt_name.like("%VICE PRESIDENT%"))
    ) & ~(
        (df.jt_name.like("%SVP"))
        | (df.jt_name.like("%AVP%"))
        | (df.jt_name.like("%VPGM%"))
        | (df.jt_name.like("%ASSOCIATE VICE%"))
        | (df.jt_name.like("%ASSOC VICE%"))
    )
    vp_df = df.filter(vp_condition)
    vp_attuid = vp_df.filter(vp_df.level == "5").select(
        "handle", "full_name", "preferred_full_name"
    )
    keypair_rdd = vp_attuid.rdd.map(lambda x: (x[0], x[1]))
    vp_map = keypair_rdd.collectAsMap()  # noqa
    vp_pref_keypair_rdd = vp_attuid.rdd.map(lambda x: (x[0], x[2]))
    vp_pref_map = vp_pref_keypair_rdd.collectAsMap()  # noqa

    # create vp_attuid column
    def find_vp(cogs_splt):
        for cog in reversed(cogs_splt):
            if cog in vp_map:
                return cog

    udf_find_vp = F.udf(find_vp, T.StringType())
    df = df.withColumn("vp_attuid", udf_find_vp(df.cogs_splt))

    def find_vp_name(cogs_splt):
        for cog in reversed(cogs_splt):
            if cog in vp_map:
                return vp_map[cog]

    udf_find_vp_name = F.udf(find_vp_name, T.StringType())
    df = df.withColumn("vp_full_name", udf_find_vp_name(df.cogs_splt))

    def find_vp_pref_name(cogs_splt):
        for cog in reversed(cogs_splt):
            if cog in vp_pref_map:
                return vp_pref_map[cog]

    udf_find_vp_pref_name = F.udf(find_vp_pref_name, T.StringType())
    df = df.withColumn("vp_preferred_full_name", udf_find_vp_pref_name(df.cogs_splt))

    # create temp dictionary of all svps
    svp_condition = (df.jt_name.like("%SVP%")) | (
        df.jt_name.like("%SENIOR VICE PRESIDENT%")
    )
    svp_attuid = df.filter(svp_condition).select(
        "handle", "full_name", "preferred_full_name"
    )
    svp_keypair_rdd = svp_attuid.rdd.map(lambda x: (x[0], x[1]))
    svp_map = svp_keypair_rdd.collectAsMap()  # noqa
    svp_pref_keypair_rdd = svp_attuid.rdd.map(lambda x: (x[0], x[2]))
    svp_pref_map = svp_pref_keypair_rdd.collectAsMap()  # noqa

    # create svp_attuid column
    def find_svp(cogs_splt):
        for cog in reversed(cogs_splt):
            if cog in svp_map:
                return cog

    udf_find_svp = F.udf(find_svp, T.StringType())
    df = df.withColumn("svp_attuid", udf_find_svp(df.cogs_splt))

    def find_svp_name(cogs_splt):
        for cog in reversed(cogs_splt):
            if cog in svp_map:
                return svp_map[cog]

    udf_find_svp_name = F.udf(find_svp_name, T.StringType())
    df = df.withColumn("svp_full_name", udf_find_svp_name(df.cogs_splt))

    def find_svp_pref_name(cogs_splt):
        for cog in reversed(cogs_splt):
            if cog in svp_pref_map:
                return svp_pref_map[cog]

    udf_find_svp_pref_name = F.udf(find_svp_pref_name, T.StringType())
    df = df.withColumn("svp_preferred_full_name", udf_find_svp_pref_name(df.cogs_splt))

    # create temp dictionary of all evps
    evp_condition = df.jt_name.like("%EVP%")
    evp_attuid = df.filter(evp_condition).select(
        "handle", "full_name", "preferred_full_name"
    )
    evp_keypair_rdd = evp_attuid.rdd.map(lambda x: (x[0], x[1]))
    evp_map = evp_keypair_rdd.collectAsMap()  # noqa
    evp_pref_keypair_rdd = evp_attuid.rdd.map(lambda x: (x[0], x[2]))
    evp_pref_map = evp_pref_keypair_rdd.collectAsMap()  # noqa

    # create evp_attuid column
    def find_evp(cogs_splt):
        for cog in reversed(cogs_splt):
            if cog in evp_map:
                return cog

    udf_find_evp = F.udf(find_evp, T.StringType())
    df = df.withColumn("evp_attuid", udf_find_evp(df.cogs_splt))

    def find_evp_name(cogs_splt):
        for cog in reversed(cogs_splt):
            if cog in evp_map:
                return evp_map[cog]

    udf_find_evp_name = F.udf(find_evp_name, T.StringType())
    df = df.withColumn("evp_full_name", udf_find_evp_name(df.cogs_splt))

    def find_evp_pref_name(cogs_splt):
        for cog in reversed(cogs_splt):
            if cog in evp_pref_map:
                return evp_pref_map[cog]

    udf_find_evp_pref_name = F.udf(find_evp_pref_name, T.StringType())
    df = df.withColumn("evp_preferred_full_name", udf_find_evp_pref_name(df.cogs_splt))

    # create temp dictionary of all presidents
    pres_condition = (
        (df.jt_name.like("%PRESIDENT%")) | (df.jt_name.like("%PRES%"))
    ) & ~(
        (df.jt_name.like("%VICE PRESIDENT%"))
        | (df.jt_name.like("%OFFICE%"))
        | (df.jt_name.like("%OFICINA%"))
    )
    pres_df = df.filter(pres_condition).select("handle")
    pres_keypair_rdd = pres_df.rdd.map(lambda x: (x[0], {}))
    pres_map = pres_keypair_rdd.collectAsMap()  # noqa

    # create pres_attuid column
    def find_pres(cogs_splt):
        for cog in reversed(cogs_splt):
            if cog in pres_map:
                return cog

    udf_find_pres = F.udf(find_pres, T.StringType())
    df = df.withColumn("pres_attuid", udf_find_pres(df.cogs_splt))

    df = df.withColumn(
        "leadership_attuid",
        F.when(df["area_manager_attuid"].isNotNull(), df["area_manager_attuid"])
        .when(df["director_attuid"].isNotNull(), df["director_attuid"])
        .when(df["avp_attuid"].isNotNull(), df["avp_attuid"])
        .when(df["vp_attuid"].isNotNull(), df["vp_attuid"])
        .when(df["svp_attuid"].isNotNull(), df["svp_attuid"])
        .when(df["evp_attuid"].isNotNull(), df["evp_attuid"])
        .when(df["pres_attuid"].isNotNull(), df["pres_attuid"]),
    )

    out_data.set_mode("replace")
    df = df.dropDuplicates()
    out_data.write_dataframe(df)
    

columnstoDrop = [
    "dl_src_file_name",
    "dl_load_ts",
    "preferred_mailing_address",
    "fax_tel_number",
    "phone_extension",
]


def convert_to_string_from_timestamp(dtfrm):
    return dtfrm.withColumn(
        "load_ts",
        F.from_unixtime(F.unix_timestamp("dl_load_ts"), "yyyy/MM/dd HH:mm:ss"),
    )
