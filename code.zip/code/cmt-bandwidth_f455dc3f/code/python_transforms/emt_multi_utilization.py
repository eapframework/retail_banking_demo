from pyspark.sql import functions as F
from transforms.api import transform_df, Input, Output
from pyspark.sql.functions import split, col, trim, current_date, date_sub, count, lead, datediff, desc, sum, to_date, when, lit, first
from pyspark.sql import Window
from pyspark.sql.functions import regexp_extract


@transform_df(
    Output("ri.foundry.main.dataset.7283e98b-e4ab-49c5-bb9b-83c76e8994e5"),
     EMTLAG=Input("ri.foundry.main.dataset.af9fbaf7-24ce-4d53-8641-d8927fc1f64c"),
    vctn026_tirks_location=Input('ri.foundry.main.dataset.e31aa857-beff-4d7c-ba5e-aaab3aa337d5'),
    emt_device_type=Input('ri.foundry.main.dataset.5aabee8d-e5f4-4eda-8146-e0971cdcbd23'),

)
def compute(EMTLAG, vctn026_tirks_location, emt_device_type):
    # def emt_single_utilization(EMTLAG, vctn026_tirks_location, emt_device_type):
    df = EMTLAG
    df = extract_nte_clli(df)
    df = add_wclli(df, vctn026_tirks_location)
    df = add_emt_device_type(df, emt_device_type)
    df = split_date(df)
    df = select_columns(df)
    df = df_filter(df)
    df = last_21_days(df)
    df = pivot_and_filter_consecutive_days_threshold(df, threshold=35, consecutive_days=3)
    return df


def split_date(df):
    df = df.withColumn('date', split(col('inserted_ts'), ' ')[0])
    df = df.drop('inserted_ts')
    return df


def select_columns(df):
    df = df.withColumn('inl', when(col('speed') > 1000000, 'multi').otherwise('single'))
    df = df.select("emtlagname", "serving_wire_center_clli_cd", "nte_clli", "nodesubtype", "emt_role", "speed", "inl", "total_util", "emtlagid", "emt_status", "date")  # noqa
    return df


def df_filter(df):
    df = df.withColumn('emt_role', trim(col('emt_role')))
    df = df.filter(col('emt_role') == 'LOOP')
    df = df.filter((col('speed') >= 1) & (col('speed') > 1000000))
    # df = df.filter(col('total_util') >= 70)
    return df


# Filter the last 21 days of data
def last_21_days(df):
    # last_8_days = date_sub(current_date(), 8)
    last_21_days = date_sub(current_date(), 21)
    df = df.filter(col('date') >= last_21_days)
    return df


def pivot_and_filter_consecutive_days_threshold(df, threshold, consecutive_days):
    # Pivot the date column
    df = df.groupBy("emtlagname", "serving_wire_center_clli_cd", "nte_clli", "nodesubtype", "emt_role", "speed", "inl", "emtlagid").pivot("date").agg(first("total_util"))  # noqa

    # Add a new column '3_or_more_consecutive_days' with default value False
    df = df.withColumn('3_or_more_consecutive_days', lit(False))

    # Check for consecutive days with utilization over the threshold
    df = check_consecutive_days(df, threshold, consecutive_days)

    # Sort the DataFrame by the 'emtlagname' column in ascending order
    df = df.orderBy(col("emtlagname").asc())

    return df


def check_consecutive_days(df, threshold, consecutive_days):
    date_columns = df.columns[4:-1]
    for i in range(len(date_columns) - consecutive_days + 1):
        conditions = [col(date_columns[i + j]) >= threshold for j in range(consecutive_days)]
        combined_conditions = conditions[0]
        for condition in conditions[1:]:
            combined_conditions = combined_conditions & condition
        df = df.withColumn('3_or_more_consecutive_days', when(combined_conditions, True).otherwise(col('3_or_more_consecutive_days')))  # noqa
    return df

    # Check if the utilization is 35 or above for each of the last 3 days
    last_3_days_columns = df.columns[-3:]
    conditions = [col(c) >= 35 for c in last_3_days_columns]

    # Create a new column 'over_threshold' with boolean values (True or False)
    # based on whether all last 3 days have utilization values 35 or above
    df = df.withColumn('over_threshold', when(conditions[0] & conditions[1] & conditions[2], True).otherwise(False))

# Sort the DataFrame by the 'emtlagname' column in ascending order
    df = df.orderBy(col("emtlagname").asc())

    return df


def extract_nte_clli(df):
    pattern = r'(?<=-)[A-Z0-9]{11}(?=:)'
    df = df.withColumn('nte_clli', regexp_extract(col('emtlagname'), pattern, 0))
    return df


def add_wclli(df, vctn026_tirks_location):
    df1 = vctn026_tirks_location.select("serving_wire_center_clli_cd", "location_cd")
    df = df.join(df1, df.nte_clli == df1.location_cd, how='left')
    df = df.drop(col("location_cd"))
    return df


def add_emt_device_type(df, emt_device_type):
    emt_device_type = emt_device_type.filter(F.col('devicerole') == 'LOOP')
    df = df.join(emt_device_type, emt_device_type.fullname == df.nte_clli, how="left")
    df = df.drop("fullname")
    return df
