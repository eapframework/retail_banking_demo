from transforms.api import transform, Input, Output, incremental
from utility.column_clean import clean_columns, lowercase_columns
from pyspark.sql.functions import unix_timestamp
from pyspark.sql import functions as F
from pyspark.sql.types import TimestampType


@incremental(require_incremental=True, semantic_version=1, snapshot_inputs=['inp'])
@transform(
    out=Output("ri.foundry.main.dataset.af9fbaf7-24ce-4d53-8641-d8927fc1f64c"),
    inp=Input("ri.foundry.main.dataset.397dc552-991c-4b98-b98c-595b9a69b670"),
)
def my_compute_function(ctx, inp, out):
    df = clean_columns(
        inp.dataframe(),
        strip_columns=strip_columns,
        integer_columns=cast_to_integer_columns,
        double_columns=cast_to_double_columns,
        decimal_columns=cast_to_decimal_columns,
        timestamp_columns=cast_to_timestamp_from_long_columns,
        datetime_columns=cast_to_timestamp_columns,
        datetime_format=datetime_format,
        date_columns=cast_to_date_columns,
        date_format=date_format,
        id_columns=cast_to_string_columns,
        integer_from_num_columns=cast_to_integer_from_decimal_columns
    )
    df = lowercase_columns(df)

    # add pk
    df = (
        df
        .withColumn(
            'pk',
            F.concat_ws('_', F.col('emtlagname'), F.col('inserted_ts'))
        )
    )

    if ctx.is_incremental:
        prev_output = out.dataframe(mode='previous', schema=df.schema)

        df = (
            df
            .join(
                prev_output,
                on='pk',
                how='left_anti'
            )
        )

    out.write_dataframe(df)


date_format = 'yyyy-MM-dd'
datetime_format = 'yyyy-MM-dd HH:mm:ss'

cast_to_date_columns = []
cast_to_timestamp_columns = []
cast_to_timestamp_from_long_columns = ['INSERTED_TS']
cast_to_integer_columns = []
cast_to_double_columns = []
cast_to_decimal_columns = []
cast_to_string_columns = []
cast_to_integer_from_decimal_columns = []
strip_columns = []
