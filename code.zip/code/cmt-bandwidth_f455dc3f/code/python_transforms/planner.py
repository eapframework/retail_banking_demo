from pyspark.sql import functions as f
from transforms.api import transform_df, Input
from sonet_decom.datasets.dataset_utils import get_dataset_paths
from pyspark.sql.functions import col, lit, lower, when, upper
from sonet_decom.datasets.utils import spark_utils


@transform_df(
  **get_dataset_paths(__file__)
)

def compute(wcmt_func, wcmt_mapping, webphone):

    """Join on wire center mapping tables function/mapping for OSP Planner function name and function id
    Join on webphone for OSP Planner Level info and uid."""

    wcmt_mapping = join_to_wire_center(wcmt_func, wcmt_mapping)
    wcmt_mapping = clean_columns(wcmt_mapping)
    wcmt_mapping = join_to_webphone(wcmt_mapping, webphone)
    return wcmt_mapping


def join_to_wire_center(wcmt_func, wcmt_mapping):
    wcmt_func = wcmt_func.select(col('category_id'), col('func_id'), col('func_name'))
    wcmt_func = spark_utils.uppercase_column_names(wcmt_func)
    wcmt_mapping = wcmt_mapping.select(col('category_id'), col('func_id'), col('clli'), col('attuid'))
    wcmt_mapping = spark_utils.uppercase_column_names(wcmt_mapping)
    wcmt_mapping = wcmt_mapping.join(wcmt_func, ['CATEGORY_ID', 'FUNC_ID'], how='inner')
    wcmt_mapping = wcmt_mapping.filter(wcmt_mapping.FUNC_NAME == 'OSP Planner')
    return wcmt_mapping


def clean_columns(wcmt_mapping):
    wcmt_mapping = wcmt_mapping.withColumn('unique_id', f.concat(col('CLLI'), lit('_'), col('ATTUID')))
    return wcmt_mapping


def join_to_webphone(wcmt_mapping, webphone):
    webphone = webphone.withColumnRenamed('handle', 'ATTUID')
    webphone = webphone.select(upper(col('ATTUID')).alias('ATTUID'), col('level'), col('jt_name').alias('job_title'))
    wcmt_mapping = wcmt_mapping.join(webphone, ['ATTUID'], how='left')
    return wcmt_mapping
