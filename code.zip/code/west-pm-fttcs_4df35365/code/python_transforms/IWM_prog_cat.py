from transforms.api import transform, Input, Output
from pyspark.sql import functions as F
from pyspark.sql.functions import col,when
from datetime import date


@transform(
    oup=Output("ri.foundry.main.dataset.53bb3121-e1f0-4b82-b910-b540db3e1bdf"),
    # inp=Input("ri.foundry.main.dataset.6167d161-8831-4585-97fd-5d2ca55e4db5"),
    inp=Input("ri.foundry.main.dataset.18cfa83b-852f-420b-8f83-135530fa7d06"),
    )

def Snapshot(inp, oup):
   df_inp = inp.dataframe()

# *(col(c).fromtimestamp("timestamp").alias(c) for c in columns_to_cast_TS))  # noqa
   if(df_inp.count() == 0):
      oup.abort()
   else:
      oup.write_dataframe(df_inp)
