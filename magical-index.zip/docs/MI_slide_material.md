# Magical Index — 1-Slide Material

## What is it? (one sentence)

**Magical Index is a lightweight, API-first microservice that tracks the lifecycle and lineage of every resource being migrated across platforms** — so that humans, AI agents, and automation scripts all share a single source of truth about what exists, where it lives, and how far along it is.

---

## Why do we need it?

- **680+ Foundry use cases** must move to CDO Next (Databricks/Snowflake/Iceberg) by Q3 2026 — each use case contains 5–30+ artifacts (datasets, pipelines, ontologies, code repos, workshops, etc.)
- Without a central tracker, teams lose context: _"Was this dataset already extracted? Which pipeline feeds it? Did someone already transform it in Databricks?"_
- MI gives every resource a **lifecycle state** (PLANNED → DISCOVERED → EXTRACTED → TRANSFORMED → DEPLOYED) so any person or agent can pick up where the last one left off — across dev, test, prod, DEEP, Databricks, Snowflake — **without re-engineering context from scratch**
- **API-first** means agents (Cascade, Super Agent, extraction scripts) can bulk-register and advance hundreds of resources programmatically — critical for 90+ use cases/month throughput

---

## What's special? Why not use an existing tool?

| Alternative | Why it doesn't fit |
|---|---|
| **Apache Atlas / DataHub / Amundsen** | Data _discovery/governance_ tools — they catalog what exists in _one_ platform. MI tracks _migration state across two platforms_ (Foundry → Databricks). They don't model "this Foundry dataset was extracted to ADLS and is now being transformed into a Delta table." |
| **Unity Catalog** | Tracks Databricks-native assets (tables, volumes, models). Doesn't know about Foundry pipelines, ontologies, workshops, or the 27 resource types MI covers. No lifecycle state machine. |
| **Jira / Excel** | Manual entry, no API for agent automation, no graph lineage (A FEEDS B), doesn't scale to thousands of resources updated by AI agents in real time. |
| **Palantir's own lineage** | Only exists inside Foundry. Useless once resources leave that platform. |

**What MI uniquely provides:**
- **Cross-platform identity**: resource IDs encode platform + type (e.g., `foundry:dataset:abc123` → `databricks:table:def456`), linked by FEEDS relationships
- **Agent-native**: both humans and AI agents are first-class actors — every mutation records _who_ (HUMAN or AGENT) and _when_
- **27 resource types** covering the full Foundry artifact taxonomy (datasets, pipelines, ontologies, workshops, contour analyses, AIP agents, etc.) — no existing tool models all of these
- **3-table simplicity**: Resources + Relationships + Activity Logs. Runs on Unity Catalog Delta tables — no extra infrastructure (no Kafka, no HBase, no graph DB)

---

## How much AIFC is involved?

| Aspect | Detail |
|---|---|
| **Built with** | Cascade as pair programmer (AIFC), ~95% of code generated through AI-assisted development |
| **Special archetypes?** | **None** — MI is a bespoke FastAPI service, not generated from an archetype template. It predates the archetype system and was purpose-built for Gandalf's specific migration-tracking needs. |
| **Human contribution** | Requirements definition, design decisions (3-table schema, FEEDS-only relationships, lifecycle states), deployment configuration, production validation, bug triage |
| **AI contribution** | Code generation, schema design iteration, BFS graph traversal optimization, parameterized SQL, dual-auth handling, 66+ unit tests, 77+ deployed integration tests |
| **Tech stack** | FastAPI + Pydantic + Databricks SQL Connector + Unity Catalog Delta — all standard, no proprietary dependencies |
| **Deployment** | Databricks App (hosted on Azure Databricks), OAuth JWT auth, service principal for production |

**Net:** High AIFC leverage — one engineer + Cascade built a production-grade service with 1,190 lines of application code, a Python SDK, and 140+ tests across unit and integration suites.

---

## Gotchas / Lessons Learned

1. **Databricks Apps require OAuth, not PATs** — Personal Access Tokens (`dapi...`) are rejected with HTTP 401 by Databricks Apps endpoints. Learned this the hard way; switched to OAuth U2M flow via `databricks auth login`.

2. **Parameterized SQL gotcha in Databricks SQL Connector** — Mixing literal `IN ('PLANNED','DISCOVERED',...)` strings with `?` parameter markers in the same query silently breaks parameter binding. Fix: parameterize _everything_ or use f-strings for validated integers only (LIMIT/OFFSET).

3. **Graph traversal at scale = per-node DFS kills you** — Initial upstream-ID lookup did one SQL query per graph node (DFS). For use cases with 200+ resources, this caused 504 timeouts. Fix: batched BFS — process entire frontier per query, reduced from O(nodes) to O(depth) SQL round-trips. Result: 504s → 200 in ~4 seconds.

4. **Dual-auth conflict in deployed apps** — If both a PAT (`DATABRICKS_TOKEN`) and service principal credentials (`DATABRICKS_CLIENT_ID`) exist in the environment, the Databricks SDK raises "more than one authorization method." Fix: explicitly pass `token=None` when using SP auth.

5. **J-shaped adoption curve** — Resource count grows slowly at first (building tooling, extractors, onboarding), then accelerates as agents and automation scripts come online. The "J" is _resources tracked_ — we're still in the early flat part; the steep part starts when bulk extraction pipelines go live across all 680+ use cases.

---

_Magical Index is live at: `gandalf-magical-index-3138568880081167.7.azure.databricksapps.com/docs`_
