from pyspark.sql import functions as F
from transforms.api import transform_df, Input, Output


@transform_df(
    Output("ri.foundry.main.dataset.8fd32007-69d0-4c28-abe1-353a0f05316f"),
    df_single=Input("ri.foundry.main.dataset.07f77fda-7e15-4895-8ef4-4d842638004a"),
    df_multi=Input("ri.foundry.main.dataset.7283e98b-e4ab-49c5-bb9b-83c76e8994e5"),
    df_add_planner=Input('ri.foundry.main.dataset.851baf2f-2bcd-47e0-ac83-d4e18af60c26'),
)
def compute(df_single, df_multi, df_add_planner):
    df = df_single.union(df_multi)
    df = df.filter(F.col('3_or_more_consecutive_days') == 'true')
    df_add_planner = df_add_planner.filter(F.col('level') == '1')
    df_add_planner = df_add_planner.select('attuid', 'func_name', 'clli')
    df = df.join(df_add_planner, df.serving_wire_center_clli_cd == df_add_planner.clli, how="left")
    df = df.drop('clli')
    return df
