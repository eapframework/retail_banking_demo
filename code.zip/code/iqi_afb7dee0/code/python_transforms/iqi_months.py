from pyspark.sql import functions as F
from transforms.api import transform_df, Input, Output, configure

@configure(
    profile=[
        'EXECUTOR_MEMORY_LARGE',
        'NUM_EXECUTORS_16',
        'EXECUTOR_MEMORY_OFFHEAP_FRACTION_HIGH',
        'EXECUTOR_MEMORY_OVERHEAD_EXTRA_LARGE'
    ]
)
@transform_df(
    Output("ri.foundry.main.dataset.2a6acd1d-f0d4-4c73-bb70-42f1ff08ae55"),
    source_df=Input("ri.foundry.main.dataset.061e5bf7-bfac-4344-bff2-335743f29b3b"),
)
def compute(source_df):
    # Establish monitoring criteria and reference dataset to reduce compute for downstream.
    df = source_df.groupBy("yyyymm").count().orderBy(F.col("yyyymm").desc()).withColumn("rank", F.lit(1) + F.monotonically_increasing_id())
    return df