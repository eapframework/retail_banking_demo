CREATE TABLE `ri.foundry.main.dataset.7b2ad653-761a-4e30-888d-445f0a93cc73` TBLPROPERTIES (foundry_transform_profile = 'EXECUTOR_MEMORY_MEDIUM') AS
    SELECT distinct 
  TICKETS.ticket
, TICKETS.active_org
, TICKETS.managing_org
, TICKETS.client_id
, TICKETS.ticket_role_description
, TICKETS.first_activated_by
, TICKETS.first_cleared_by
, TICKETS.first_canceled_by
, TICKETS.first_closed_by
, TICKETS.ticket_type_desc_tx
, TICKETS.end_user_name
, TICKETS.rept_svc_line_desc_tx
, TICKETS.event_class
, TICKETS.severity
, TICKETS.ticket_state
, TICKETS.asset_id
, TICKETS.agent_id
, TICKETS.last_modified_by
, TICKETS.ticket_opened_date_utc
, TICKETS.trouble_reported_date_utc
, TICKETS.service_restored_date
, TICKETS.time_to_restore_reported
, TICKETS.restore_duration
, TICKETS.mttr
, case when TICKETS.ticket_closed_date_utc is null and TICKETS.ticket_state in ("Closed", "Cancelled") then last_modified_date
  else TICKETS.ticket_closed_date_utc end ticket_closed_date_utc
, TICKETS.problem_abstract
, TICKETS.resol_action_desc_tx
, TICKETS.resolution_text
, TICKETS.root_cause_desc_tx
, TICKETS.sub_root_cause_desc_tx
, TICKETS.first_activated
, TICKETS.resolution_set_name
, TICKETS.work_queue
, TICKETS.handover_text
, TICKETS.parent_ticket
, TICKETS.init_sev
, TICKETS.updated_by
, TICKETS.ticket_source
, TICKETS.reference_ticket_num
, TICKETS.repair_duration
, TICKETS.repair_d_m_time_min
, TICKETS.time_to_repair_unadj_reported
, TICKETS.adjtimetorepair
, TICKETS.adjtimetorestore
, TICKETS.tmp_defertimesum
, TICKETS.total_deferred_delayed_maint
, TICKETS.total_deferred_no_access
, TICKETS.deferred_reason_code
, TICKETS.account_contact
, TICKETS.account_phone
, TICKETS.account_contact_email
, TICKETS.affected_channels
, TICKETS.affected_locations
, TICKETS.asset_location_city
, TICKETS.asset_location_state
, TICKETS.asset_name
, TICKETS.asset_type
, TICKETS.billing_indicator
, TICKETS.changeactivitydate
, TICKETS.changeactivityid
, TICKETS.changeactivitysource
, TICKETS.changeactivitytype
, TICKETS.child_tkt_count
, TICKETS.chronic
, TICKETS.cleared_deferred_time
, TICKETS.client_first_notified
, TICKETS.client_name
, TICKETS.client_notified_cleared
, TICKETS.client_satisfied
, TICKETS.client_ticket
, TICKETS.closed_by
, TICKETS.completion_deadline
, TICKETS.count_closed_children
, TICKETS.count_open_children
, TICKETS.customer_care_description
, TICKETS.customer_experience
, TICKETS.discovery_method
, TICKETS.dispatch
, TICKETS.end_user_id
, TICKETS.end_user_phone
, TICKETS.equipment_clli
, TICKETS.equipment_type
, TICKETS.escalation_deadline
, TICKETS.est_time_of_arrival
, TICKETS.event_message_count
, TICKETS.faults_caused_by_change
, TICKETS.fixit_bridge
, TICKETS.handover_fg
, TICKETS.has_child
, TICKETS.has_parent
, TICKETS.impact_severity
, TICKETS.key_item_affected
, TICKETS.last_modified_date
, TICKETS.location_id
, TICKETS.location_state_province
, TICKETS.monitor_for_cleared
, TICKETS.naa_mfab_req
, TICKETS.network_technology_list
, TICKETS.next_check_time
, TICKETS.org_group
, TICKETS.original_ticket_number
, TICKETS.owner_id
, TICKETS.prev_ticket_state
, TICKETS.provider_ticket
, TICKETS.related_equipment_id
, TICKETS.related_equipment_type
, TICKETS.remediation
, TICKETS.reported_customer_impact
, TICKETS.reported_product
, TICKETS.rept_request_type
, TICKETS.rept_svc_impact_flag
, TICKETS.rept_svc_line_cd
, TICKETS.requested_completion_date
, TICKETS.resol_action_cd
, TICKETS.resol_item_cd
, TICKETS.resol_item_desc_tx
, TICKETS.resol_request_type
, TICKETS.resol_svc_impact_flag
, TICKETS.resol_svc_line_desc_tx
, TICKETS.resolution_org
, TICKETS.resolution_product
, TICKETS.restore_d_m_time_min
, TICKETS.rma_number
, TICKETS.scrub_indicator
, TICKETS.serial_number
, TICKETS.service_provider
, TICKETS.severity_classification
, TICKETS.ss_activity_type
, TICKETS.status_bridge
, TICKETS.svc_comp_desc_tx
, TICKETS.ticket_cleared_date
, TICKETS.ticket_duration
, TICKETS.ticket_originator
, TICKETS.ticket_owner
, TICKETS.ticket_role
, TICKETS.ticket_type
, TICKETS.time_elapsed_for_monitoring
, TICKETS.total_d_m_time_min
, TICKETS.total_impacted_customer
, TICKETS.trouble_rept_desc_tx
, TICKETS.voip_options
, TICKETS.ith_queued_to_active
, TICKETS.resol_request_desc_tx
, TICKETS.engagement_indicator
, TICKETS.event_abstract
, TICKETS.reported_by
, TICKETS.client_helpdesk
, LK_HUMAN_TOUCH.human_pathway
, LK_HUMAN_TOUCH.distinct_humans
, LK_HUMAN_TOUCH.first_human_attuid
, LK_HUMAN_TOUCH.last_human_attuid
, LK_HUMAN_TOUCH.distinct_supervisor_name
, LK_HUMAN_TOUCH.first_supervisor_name
, LK_HUMAN_TOUCH.last_supervisor_name
, LK_HUMAN_TOUCH.distinct_director_name
, LK_HUMAN_TOUCH.first_director_name
, LK_HUMAN_TOUCH.last_director_name
, LK_HUMAN_TOUCH.distinct_avp_name
, LK_HUMAN_TOUCH.first_avp_name
, LK_HUMAN_TOUCH.last_avp_name
, LK_HUMAN_TOUCH.distinct_vp_name
, LK_HUMAN_TOUCH.first_vp_name
, LK_HUMAN_TOUCH.last_vp_name
, LK_HUMAN_TOUCH.distinct_svp_name
, LK_HUMAN_TOUCH.first_svp_name
, LK_HUMAN_TOUCH.last_svp_name
, LK_HUMAN_TOUCH.first_cogs_1_name
, LK_HUMAN_TOUCH.first_cogs_2_name
, LK_HUMAN_TOUCH.first_cogs_3_name
, LK_HUMAN_TOUCH.first_cogs_4_name
, LK_HUMAN_TOUCH.first_cogs_5_name
, LK_HUMAN_TOUCH.first_cogs_6_name
, LK_HUMAN_TOUCH.first_cogs_7_name
, LK_HUMAN_TOUCH.last_cogs_1_name
, LK_HUMAN_TOUCH.last_cogs_2_name
, LK_HUMAN_TOUCH.last_cogs_3_name
, LK_HUMAN_TOUCH.last_cogs_4_name
, LK_HUMAN_TOUCH.last_cogs_5_name
, LK_HUMAN_TOUCH.last_cogs_6_name
, LK_HUMAN_TOUCH.last_cogs_7_name
, LK_HUMAN_TOUCH.distinct_vp_org_name
, LK_HUMAN_TOUCH.first_human_touch
, LK_HUMAN_TOUCH.last_human_touch
, LK_HUMAN_TOUCH.total_human_touches
, LK_HUMAN_TOUCH.active_org_pathway
, LK_HUMAN_TOUCH.distinct_active_org
, LK_HUMAN_TOUCH.distinct_active_org_count
, LK_HUMAN_TOUCH.first_active_org
, LK_HUMAN_TOUCH.last_active_org
, LK_HUMAN_TOUCH.first_work_queue
, LK_HUMAN_TOUCH.last_work_queue
, LK_HUMAN_TOUCH.hist_first_cogs_1_name
, LK_HUMAN_TOUCH.hist_first_cogs_2_name
, LK_HUMAN_TOUCH.hist_first_cogs_3_name
, LK_HUMAN_TOUCH.hist_first_cogs_4_name
, LK_HUMAN_TOUCH.hist_first_cogs_5_name
, LK_HUMAN_TOUCH.hist_first_cogs_6_name
, LK_HUMAN_TOUCH.hist_first_cogs_7_name
, LK_HUMAN_TOUCH.hist_last_cogs_1_name
, LK_HUMAN_TOUCH.hist_last_cogs_2_name
, LK_HUMAN_TOUCH.hist_last_cogs_3_name
, LK_HUMAN_TOUCH.hist_last_cogs_4_name
, LK_HUMAN_TOUCH.hist_last_cogs_5_name
, LK_HUMAN_TOUCH.hist_last_cogs_6_name
, LK_HUMAN_TOUCH.hist_last_cogs_7_name
, LK_HUMAN_TOUCH.hist_first_svp_name
, LK_HUMAN_TOUCH.hist_first_vp_name
, LK_HUMAN_TOUCH.hist_first_avp_name
, LK_HUMAN_TOUCH.hist_first_director_name
, LK_HUMAN_TOUCH.hist_last_svp_name
, LK_HUMAN_TOUCH.hist_last_vp_name
, LK_HUMAN_TOUCH.hist_last_avp_name
, LK_HUMAN_TOUCH.hist_last_director_name
, first_rm_l1
, first_rm_l2
, first_rm_l3
, first_center_l1_area
, first_center_l2_platform
, first_center_l3_unit
, first_strategic_indicator
, last_rm_l1
, last_rm_l2
, last_rm_l3
, last_center_l1_area
, last_center_l2_platform
, last_center_l3_unit
, last_strategic_indicator
, center_l1_area_pathway
, distinct_center_l1_area
 , LK_AUTO_TOUCH.first_auto_touch
 , LK_AUTO_TOUCH.last_auto_touch
 , LK_AUTO_TOUCH.total_auto_touches
 , CASE WHEN total_auto_touches is null and total_human_touches > 0 then 'Manual'
        WHEN total_human_touches is null and total_auto_touches > 0 then 'Fully Automated'
        WHEN total_human_touches > 0 and total_auto_touches > 0 then 'Partially Automated'
        else 'TBD' end work_driver_type
, LK_CENTER.rm_l1 as current_rm_l1
, LK_CENTER.rm_l2 as current_rm_l2
, LK_CENTER.rm_l3 as current_rm_l3
, LK_CENTER.center_l1_area as current_center_l1_area
, LK_CENTER.center_l2_platform as current_center_l2_platform
, LK_CENTER.center_l3_unit as current_center_l3_unit
, LK_CENTER.strategic_non_strategic as current_strategic_indicator
, LK_CENTER.rpt_mgr as current_rpt_mgr
, CASE WHEN total_human_touches is null THEN 'No Human Touch'
       WHEN total_human_touches = 0 THEN 'No Human Touch'
       WHEN total_human_touches = 1 THEN '1 Human Touch'
       WHEN total_human_touches between 2 and 3 THEN '2-3 Human Touch'
       WHEN total_human_touches > 3 THEN '4+ Human Touch'
       ELSE 'TBD' end Manual_Touch_Category
, CASE WHEN total_auto_touches is null THEN 'No Automation Touch'
       WHEN total_auto_touches = 0 THEN 'No Automation Touch'
       WHEN total_auto_touches BETWEEN 1 and 2 THEN '1-2 Automation Touch'
       WHEN total_auto_touches BETWEEN 3 and 10 THEN '3-10 Automation Touch'
       WHEN total_auto_touches BETWEEN 10 and 50 THEN '10-50 Automation Touch'
       WHEN total_auto_touches > 50 THEN '>50 Automation Touch'
       ELSE 'TBD' END Automation_Touch_Category
, wfa_ticket
, left(wfa_ticket, 3) wfa_ticket_region
, right(left(wfa_ticket, 5),2) wfa_ticket_center
, right(wfa_ticket, 8) wfa_ticket_short
, first_change_id
, CONCAT("http://ebizweb.att.com/opsportal/opTicketReview.cfm?ticketNum=",TICKETS.ticket) ticket_url
, CONCAT("https://cana.web.att.com/cr-details/",first_change_id) change_url
, ets_link
, mp_link
, (unix_timestamp(first_human_touch)-unix_timestamp(ticket_opened_date_utc))/3600 hours_create_to_touch
, (unix_timestamp(case when TICKETS.ticket_closed_date_utc is null and TICKETS.ticket_state in ("Closed", "Cancelled") then last_modified_date
  else TICKETS.ticket_closed_date_utc end)-unix_timestamp(ticket_opened_date_utc))/3600 hours_open_to_close
, (unix_timestamp(last_human_touch)-unix_timestamp(first_human_touch))/3600 hours_first_last_human_touch
, is_auto_closed
, case when first_active_org = last_active_org then 'Yes' else 'No' end is_first_last_active_org_same
, concat(
  substring(problem_abstract, 0, 8) 
, substring(resolution_set_name, 0, 10) 
, substring(resol_action_desc_tx, 0, 8)) concatenated_prob_res
, date_format(ticket_opened_date_utc, 'MMMMM') ticket_create_month_name
, date_format(ticket_opened_date_utc, 'yyyy') ticket_create_year
, date_format(ticket_opened_date_utc, 'yyyy-MM') ticket_create_yyyy_mm
, LK_NDRT.force_wo_cnt
, LK_NDRT.force_wo_array
, LK_NDRT.force_start_dt
, LK_NDRT.force_finish_dt
, LK_NDRT.force_first_human_touch_dt
, LK_NDRT.force_total_touches
, LK_NDRT.force_human_touches
, LK_NDRT.force_dispatch_in_cnt
, LK_NDRT.force_dispatch_out_cnt
, LK_NDRT.force_truck_roll_in
, LK_NDRT.force_truck_roll_out
, LK_NDRT.force_human_user_unique_list
, LK_NDRT.force_human_user_unique_cnt 
, LK_NDRT.force_narrative_list
, LK_NDRT.force_dispatch_first_dt
, LK_NDRT.force_dispatch_last_dt
, case when LK_NDRT.force_start_dt is not null then 
        case when (unix_timestamp(LK_NDRT.force_start_dt)-unix_timestamp(ticket_opened_date_utc))/3600 < 0 then 0
        else (unix_timestamp(LK_NDRT.force_start_dt)-unix_timestamp(ticket_opened_date_utc))/3600 end
           when case when TICKETS.ticket_closed_date_utc is null and TICKETS.ticket_state in ("Closed", "Cancelled") then last_modified_date
  else TICKETS.ticket_closed_date_utc end is not null then 
           case when (unix_timestamp(case when TICKETS.ticket_closed_date_utc is null and TICKETS.ticket_state in ("Closed", "Cancelled") then last_modified_date
  else TICKETS.ticket_closed_date_utc end)-unix_timestamp(ticket_opened_date_utc))/3600 < 0 then 0
           else (unix_timestamp(case when TICKETS.ticket_closed_date_utc is null and TICKETS.ticket_state in ("Closed", "Cancelled") then last_modified_date
  else TICKETS.ticket_closed_date_utc end)-unix_timestamp(ticket_opened_date_utc))/3600 end
           else null end noc_duration_hours
, force_start_to_first_human_hours
, force_start_to_first_dispatch_hours
, force_first_dipsatch_to_complete_hours
, force_start_to_finish_hours
, wfa_trouble_code
, wfa_start_dt
, wfa_finish_dt
, wfa_closeout_summary
, cause_code_list_in
, trbl_fnd_cd_list_in
, trbl_fnd_desc_in
, cause_code_list_out
, trbl_fnd_cd_list_out
, trbl_fnd_desc_out
, case when LK_REPEAT.ticket is not null then 1 else 0 end metric_repeat
, case when LK_METRIC_NTF.ticket is not null then 1 else 0 end metric_ntf
, case when LK_METRIC_MAINT.ticket is not null then 1 else 0 end metric_maintenance
     , case when LK_NTF_DISPATCH.ext_key1 is not null then 1 else 0 end metric_ntf_dispatch
    , case 
        when total_human_touches is null
                and total_auto_touches > 0
                and ticket_closed_date_utc is not null then 0 
        when LK_METRIC_NOT_ACTIONABLE.ticket is null then 1
        else 0 end metric_actionable
, case when CASE WHEN total_auto_touches is null and total_human_touches > 0 then 'Manual'
        WHEN total_human_touches is null and total_auto_touches > 0 then 'Fully Automated'
        WHEN total_human_touches > 0 and total_auto_touches > 0 then 'Partially Automated'
        else 'TBD' end='Partially Automated' and LK_METRIC_NOT_ACTIONABLE.ticket is null then 1 else 0 end metric_actionable_part_mech
, case when CASE WHEN total_human_touches is null THEN 'No Human Touch'
       WHEN total_human_touches = 0 THEN 'No Human Touch'
       WHEN total_human_touches = 1 THEN '1 Human Touch'
       WHEN total_human_touches between 2 and 3 THEN '2-3 Human Touch'
       WHEN total_human_touches > 3 THEN '4+ Human Touch'
       ELSE 'TBD' end = 'No Human Touch' then 1 else 0 end metric_fully_automated_noc
, case when CASE WHEN total_human_touches is null THEN 'No Human Touch'
       WHEN total_human_touches = 0 THEN 'No Human Touch'
       WHEN total_human_touches = 1 THEN '1 Human Touch'
       WHEN total_human_touches between 2 and 3 THEN '2-3 Human Touch'
       WHEN total_human_touches > 3 THEN '4+ Human Touch'
       ELSE 'TBD' end = 'No Human Touch' and (force_human_touches is null or force_human_touches = 0) then 1 else 0 end metric_fully_automated_closed_loop
, case when force_start_dt is not null or trbl_fnd_desc_in is not null or trbl_fnd_desc_out is not null then 1 else 0 end metric_dispatched
, case when force_start_dt is not null or trbl_fnd_desc_in is not null or trbl_fnd_desc_out is not null and (force_truck_roll_out is null or force_truck_roll_out < 2) then 1 else 0 end metric_dispatched_ftr
, case when (unix_timestamp(ticket_closed_date_utc)-unix_timestamp(ticket_opened_date_utc))/3600 <= 0 then null else (unix_timestamp(ticket_closed_date_utc)-unix_timestamp(ticket_opened_date_utc))/3600 end metric_mttr
, case when case when (unix_timestamp(ticket_closed_date_utc)-unix_timestamp(ticket_opened_date_utc))/3600 <= 0 then null else (unix_timestamp(ticket_closed_date_utc)-unix_timestamp(ticket_opened_date_utc))/3600 end <= 10 then 1 else 0 end metric_mttr_met
, EVENT_MESSAGE.max_event_date
, case when case when TICKETS.ticket_closed_date_utc is null and TICKETS.ticket_state in ("Closed", "Cancelled") then last_modified_date
  else TICKETS.ticket_closed_date_utc end is not null then (unix_timestamp(case when TICKETS.ticket_closed_date_utc is null and TICKETS.ticket_state in ("Closed", "Cancelled") then last_modified_date
  else TICKETS.ticket_closed_date_utc end)-unix_timestamp(ticket_opened_date_utc))/3600
        else  (unix_timestamp(current_timestamp())-unix_timestamp(ticket_opened_date_utc))/3600 end hours_open
, LK_WFAC.sf1 wfa_sf1
, LK_WFAC.sf2 wfa_sf2
, LK_WFAC.sf3 wfa_sf3
FROM `ri.foundry.main.dataset.2001d735-f563-41f6-a929-e7253ebece1f` TICKETS
LEFT JOIN `ri.foundry.main.dataset.9e9164cf-06bb-4a69-b97b-21a139481d1f` LK_HUMAN_TOUCH
ON TICKETS.ticket=LK_HUMAN_TOUCH.ticket_number
LEFT JOIN `ri.foundry.main.dataset.9147ed5e-5a30-416c-a847-1309f87a15b0` LK_AUTO_TOUCH
ON TICKETS.ticket=LK_AUTO_TOUCH.ticket_number
LEFT JOIN `ri.foundry.main.dataset.18213df6-4c2c-486c-bba2-1febde688fa1` LK_BUCKET
ON TICKETS.ticket=LK_BUCKET.ticket and LK_BUCKET.bucket is not null and LK_BUCKET.bucket != 'Internal Engagement'
LEFT JOIN `ri.foundry.main.dataset.df0abf5d-677c-4cb9-8bf0-d8d7ff25b467` LK_CENTER
ON (
        UPPER(trim(LK_BUCKET.bucket))=upper(trim(LK_CENTER.logic_group)) 
        AND _mapping_type=7
  )
  OR (
          UPPER(TRIM(TICKETS.active_org))=upper(trim(LK_CENTER.worklist_l1)) 
          AND UPPER(TRIM(TICKETS.org_group))=UPPER(TRIM(LK_CENTER.worklist_l3)) 
          AND _mapping_type=3
  )
  OR (
          UPPER(TRIM(TICKETS.active_org))=upper(trim(LK_CENTER.worklist_l1))
          AND UPPER(TRIM(TICKETS.work_queue))=upper(trim(LK_CENTER.worklist_l2))
          AND _mapping_type=2
  )
  or (
          UPPER(TRIM(TICKETS.active_org))=UPPER(TRIM(LK_CENTER.worklist_l1)) 
          AND LK_CENTER._mapping_type=1
  )
LEFT JOIN `ri.foundry.main.dataset.89b18df1-7297-43f6-8ae8-4f151b4a9602` LK_WFA
ON TICKETS.ticket=LK_WFA.ticket
LEFT JOIN (select ticket, last(first_change_id) first_change_id from `ri.foundry.main.dataset.33218cd5-3137-4a79-b25a-0cf7a0a7326e` group by ticket) LK_CHANGE
ON TICKETS.ticket=LK_CHANGE.ticket
LEFT JOIN `ri.foundry.main.dataset.c399377e-0aee-47af-9bd7-710febb4e552` LK_ETS_LINK
ON TICKETS.ticket=LK_ETS_LINK.ticket
LEFT JOIN `ri.foundry.main.dataset.a1456228-c6e8-4bc2-9c70-d2f50a966524` LK_MP_LINK
ON TICKETS.ticket=LK_MP_LINK.ticket
LEFT JOIN `ri.foundry.main.dataset.75b1dd6d-d3f9-4c7b-a8f8-b77731d9d876` LK_AUTO_CLOSE
ON TICKETS.ticket=LK_AUTO_CLOSE.ticket
LEFT JOIN `ri.foundry.main.dataset.8cc5ddf9-30f5-4d15-b18f-18c116cbc5d5` LK_NDRT
ON right(LK_WFA.wfa_ticket, 8)=LK_NDRT.extkey1
LEFT JOIN `ri.foundry.main.dataset.b17eea8f-0650-4dc9-a72f-59c250a86c45` LK_WFAC
ON concat(LK_WFA.wfa_ticket, date_format(ticket_opened_date_utc, 'yyyy'))=LK_WFAC.join_key
LEFT JOIN `ri.foundry.main.dataset.e593a378-9e0b-45e3-a743-1fdef243a184` LK_REPEAT
ON TICKETS.ticket=LK_REPEAT.ticket
LEFT JOIN `ri.foundry.main.dataset.a3f42359-25cb-4cb5-9576-42383db5e9ad` LK_METRIC_NTF
on TICKETS.ticket=LK_METRIC_NTF.ticket
LEFT JOIN `ri.foundry.main.dataset.4ddd8655-3b4c-4723-8634-fe306f81d81c` LK_METRIC_MAINT
on TICKETS.ticket=LK_METRIC_MAINT.ticket
LEFT JOIN `ri.foundry.main.dataset.eeeb286b-fb47-4aa5-a5e4-2bb4b764a103` LK_NTF_DISPATCH
ON right(LK_WFA.wfa_ticket, 8)=LK_NTF_DISPATCH.ext_key1
LEFT JOIN `ri.foundry.main.dataset.cf3bc072-76d9-4fb5-b8aa-078576c8d79b` LK_METRIC_NOT_ACTIONABLE
ON TICKETS.ticket=LK_METRIC_NOT_ACTIONABLE.ticket
LEFT JOIN (SELECT ticket_nb, max(event_date) max_event_date FROM `ri.foundry.main.dataset.9190078e-db18-401d-a4b8-d10575091795` GROUP BY ticket_nb) EVENT_MESSAGE
ON TICKETS.ticket=EVENT_MESSAGE.ticket_nb